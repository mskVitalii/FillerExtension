import{P as Je,g as ue,a as _,b as Be,c as He,s as Ge,d as M,e as pe,f as Ve,h as Ke,i as ze,j as We,k as de,r as b,J as he,n as ge,t as q,l as j,M as fe,m as Qe,A as H,o as Xe,p as Ze,q as et,u as D,v as Q,w as me,x as tt,y as X,z as ye,C as nt,B as we,D as at,E as st,F as it,G as be,H as rt,I as ve,K as Y,L as G,N as Ee,O as Se,Q as ke,R as Te,S as V,T as Le,U as ot,V as ct,W as Z,X as lt,Y as ut,Z as Ie,_ as Ae,$ as _e,a0 as pt,a1 as dt,a2 as ee,a3 as ht,a4 as gt,a5 as C,a6 as ft,a7 as mt,a8 as yt,a9 as wt}from"./template-Cy0twWAG.js";import{c as bt,a as vt}from"./phone-D3SACKoL.js";const Re={...Je,cv:"CV",coverLetter:"Cover Letter",generatePassword:"Generated password"},Et=Object.keys(Re);async function S(e){try{const n=(await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:["content-script.js"]})).map(a=>a.frameId).filter(a=>typeof a=="number");if(n.length>0)return n}catch{}try{return await chrome.scripting.executeScript({target:{tabId:e},files:["content-script.js"]}),[0]}catch{return[0]}}function St(){const e=[];for(const t of Array.from(document.querySelectorAll("iframe, frame"))){const n=t.getBoundingClientRect(),a=n.width*n.height;t.src&&n.width>=200&&n.height>=150&&e.push({src:t.src,area:a})}return{origin:location.origin,children:e}}async function kt(e){let t;try{t=await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},func:St})}catch{return[]}const n=new Set,a=new Map;for(const{result:i}of t)if(i){n.add(i.origin);for(const r of i.children){let o;try{const c=new URL(r.src);if(c.protocol!=="https:"&&c.protocol!=="http:")continue;o=c.origin}catch{continue}a.set(o,Math.max(a.get(o)??0,r.area))}}const s=[];for(const i of[...a.keys()].sort((r,o)=>a.get(o)-a.get(r))){if(n.has(i))continue;if(await chrome.permissions.contains({origins:[`${i}/*`]}).catch(()=>!1)||s.push(i),s.length===3)break}return s}async function Tt(e,t){if(e==="cv"){const s=await ue();return(s==null?void 0:s.text)??""}if(e==="coverLetter")return await _("lastCoverLetter")??"";if(e==="generatePassword"){const s=await Be(t);if(s!=null&&s.generatedPassword)return s.generatedPassword;const i=He();return s&&await Ge(t,{...s,generatedPassword:i}),i}const n=await M(),a=n[e]??"";return e==="phone"&&a?bt(a,n.country):a}const P="job-app-assistant-insert",Lt={generatePassword:"Generate password"},It=Et.map(e=>({id:e,title:Lt[e]??Re[e]}));function At(){chrome.contextMenus.removeAll(()=>{chrome.contextMenus.create({id:P,title:"Insert",contexts:["editable"]});for(const e of It)chrome.contextMenus.create({id:`${P}:${e.id}`,parentId:P,title:e.title,contexts:["editable"]})})}function _t(e){return e.startsWith(`${P}:`)?e.slice(P.length+1):null}async function Rt(e,t){if(!(t!=null&&t.id)||typeof e.menuItemId!="string")return;const n=_t(e.menuItemId);if(!n)return;const a=await Tt(n,t.id);await S(t.id);const s={type:"INSERT_VALUE",field:n,value:a};chrome.tabs.sendMessage(t.id,s,{frameId:e.frameId}).catch(()=>{})}const Ot=new Set(["profileCache","cvLibraryCache","legendLibraryCache","customFieldsCache","languageLevelsCache","faqAnswersCache","generationRulesCache","outreachRulesCache"]);let O=null;function xt(){return Promise.all([M(),ue(),pe(),Ve(),Ke(),ze(),We(),de()]).then(([e,t,n,a,s,i,r,o])=>({profile:e,cvText:(t==null?void 0:t.text)??"",personalLegend:(n==null?void 0:n.content)??"",generationRules:(a==null?void 0:a.content)??"",outreachRules:(s==null?void 0:s.content)??"",languageLevels:i,customFields:r,faq:o}))}function E(){return O||(O=xt(),O.catch(()=>{O=null})),O}var le;typeof chrome<"u"&&((le=chrome.storage)!=null&&le.onChanged)&&chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&Object.keys(e).some(n=>Ot.has(n))&&(O=null)});const I=`Write like a specific person, not an AI assistant. These rules have no exceptions:

- NEVER use an em dash ("—"), a spaced en dash ("–") or "--" as punctuation. Real people don't write that way. Use a comma, a period, parentheses, or two sentences.
- Banned words: delve, foster, leverage, utilize, facilitate, empower, streamline, robust, cutting-edge, paradigm shift, game changer, tapestry, realm, beacon, multifaceted, meticulous, intricate, paramount, transformative, elevate, embark, supercharge, harness, ever-evolving. Say the plain thing.
- Cut empty phrases: "it's worth noting", "at the end of the day", "when it comes to", "at its core", "in today's world", "the reality is", "in order to", "going forward".
- No "not X, it's Y" / "the question isn't X, it's Y" / "not just X but Y" contrasts. State Y directly.
- No throat-clearing openers ("Here's the thing", "Let me be clear", "I'll be honest") and no faux-insight setups ("what most people get wrong", "here's what nobody tells you").
- No importance puffery ("stands as a testament", "marks a pivotal moment", "plays a vital role", "underscores its significance"). State the fact and stop.
- No colon reveals: a noun phrase, a colon, then a dramatic lowercase clause.
- No trailing "-ing" clauses that editorialize ("highlighting the commitment to...", "underscoring its importance", "showcasing", "reflecting"). End the sentence.
- No metadiscourse that tells the reader what to notice ("this matters", "this distinction matters", "in other words", "as you can see").
- No "In conclusion" / "Ultimately" / "Overall" recap ending and no cute one-line kicker. Stop on the last concrete point.
- No emoji, no mid-sentence bold, no rhetorical questions.
- Vary sentence shape; don't stack short punchy fragments.
- Be concrete: name the technology, project, number, or outcome instead of calling it "significant", "impactful" or "exciting". Use active voice.`;function k(e){return e.replace(/[ \t]*[—―][ \t]*/g,", ").replace(/[ \t]+--[ \t]+/g,", ").replace(/(\D)[ \t]+–[ \t]+(?=\D)/g,"$1, ").replace(/[ \t]+([,.;:!?])/g,"$1").replace(/,(\s*[.;:!?])/g,"$1").replace(/,[ \t]*,/g,",").replace(/^[ \t]*,[ \t]*/gm,"").replace(/([([{])[ \t]*,[ \t]*/g,"$1").replace(/[ \t]*,[ \t]*([)\]}])/g,"$1").replace(/,[ \t]*$/gm,"").replace(/[ \t]+$/gm,"")}const Pt=`You write the applicant's own answers to standard interview-FAQ
questions (spec_5 section B) — general-purpose answers meant to be reused, as-is or
lightly adapted, whenever a real application form asks a close variant of one of them.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend, and
  custom fields. Never invent experience, technologies, companies, education,
  achievements, or a concrete salary figure that wasn't actually given.
- If information needed for a good answer is missing (no CV, no Personal Legend
  content covering it), write a short, honest, generically true answer rather
  than fabricating specifics — the applicant can always sharpen it later.
- Keep each answer 2-5 sentences: concrete and confident, never generic
  corporate filler, no restating the question.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text per answer, no markdown, no numbering.

${I}`;function Ct(e){return{type:"object",additionalProperties:!1,required:["answers"],properties:{answers:{type:"array",minItems:e,maxItems:e,items:{type:"string"}}}}}async function Nt(e){if(e.length===0)return[];const{profile:t,cvText:n,personalLegend:a,generationRules:s,customFields:i}=await E(),r=JSON.stringify({profile:t,cvText:n,personalLegend:a,generationRules:s,customFields:i,questions:e},null,2),o=await b({schemaName:"faq_answers",schema:Ct(e.length),systemPrompt:Pt,userPrompt:r,parse:c=>JSON.parse(c)});return e.map((c,d)=>({question:c,answer:k(o.answers[d]??"")}))}async function Mt(e,t){const n=new Map(t.map(i=>[i.question,i.answer])),a=e.filter(i=>{var r;return!((r=n.get(i))!=null&&r.trim())}),s=await Nt(a);for(const i of s)n.set(i.question,i.answer);return e.map(i=>({question:i,answer:n.get(i)??""}))}async function N(e,t,n){const a=performance.now();try{return await n()}finally{e==null||e.push({label:t,ms:performance.now()-a})}}function qt(e){return e!=null&&e.length?`Seniority levels to target: ${he.filter(n=>e.includes(n.id)).map(n=>n.label.toLowerCase()).join(", ")}. Only include postings for these levels.`:""}function jt(e,t){const n=he.filter(s=>t==null?void 0:t.includes(s.id));if(n.length===0)return e;const a=[];for(const s of e)for(const i of n)a.push(s.toLowerCase().includes(i.keyword)?s:`${i.keyword} ${s}`.trim());return[...new Set(a)]}function Oe(e){return[e.what?`Role/keywords focus: "${e.what}".`:"",e.where?`Location: "${e.where}".`:"",qt(e.grades),e.remoteOnly?"Prefer remote-friendly roles.":"",ge(e.negative)].filter(Boolean).join(" ")}const $t={type:"object",additionalProperties:!1,required:["jobs"],properties:{jobs:{type:"array",items:{type:"object",additionalProperties:!1,required:["title","company","location","url","salary","snippet","postedAt"],properties:{title:{type:"string"},company:{type:"string"},location:{type:"string"},url:{type:"string"},salary:{type:"string"},snippet:{type:"string"},postedAt:{type:"string"}}}}}};function Ut(e,t){const n=ge(t);return`You turn raw web-search results about job openings into a clean,
structured list. The input text was produced by a live internet search and may include
citations, markdown links, or unrelated surrounding prose — extract only genuine
individual job postings from it.

Rules:
- Only include entries that are clearly actual job postings with a real listing URL —
  never a company's generic careers-page homepage, a search-results page, or an
  aggregator's category page.
- "url" must be copied exactly from the source text (never invented).
- "salary" is "" when no figure was given — never guess one.
- "postedAt" is the date the posting was published, as YYYY-MM-DD, only when the text
  states it. Resolve relative dates ("posted 3 days ago", "2w") against today, ${e}.
  Use "" when no date is given — never guess one.
- Drop postings the text marks as closed, expired, filled or "no longer accepting
  applications", and postings published more than ${fe} days before ${e}.
- "snippet" is a 1-2 sentence summary of the role; when a "candidate" background is given
  below, make it say *why this posting fits them* specifically (seniority match, matching
  skills, location/remote fit) rather than just restating the posting.
- If a "candidate" background is given, drop postings that are a poor fit for them (wrong
  seniority, unrelated field) even if they're genuine job postings — only surface ones
  actually worth their time.
- Deduplicate: the same posting linked twice becomes one entry.${n?`
- ${n}`:""}
- If nothing in the text is actually a job posting, return an empty "jobs" array.`}async function xe(e,t,n,a={}){const s=n?`candidate:
${n}

---

${e.slice(0,4e4)}`:e.slice(0,4e4),i=await b({schemaName:"job_listings",schema:$t,systemPrompt:Ut(q(),a.negative),userPrompt:s,reasoningEffort:a.reasoningEffort,timeoutMs:a.timeoutMs,signal:a.signal,label:"Parsing search results",parse:r=>JSON.parse(r)});return j(i.jobs.filter(r=>r.url.trim()).map(r=>({...r,source:t})))}function Pe(e){return e.length===0?"":`

Already found and shown to the applicant — do NOT return any of these again,
find genuinely different postings instead:
${e.map(n=>`- ${n.title} at ${n.company} (${n.url})`).join(`
`)}`}function A(e){return typeof e=="string"?e.trim():""}function Ft(e){const t=e.trim().replace(/^(?:[-*•]|\d+[.)])\s+/u,"").replace(/,$/,"");if(!t.startsWith("{")||!t.endsWith("}"))return null;let n;try{n=JSON.parse(t)}catch{return null}const a=A(n.url),s=A(n.title);return!/^https?:\/\//i.test(a)||!s?null:{title:s,company:A(n.company),location:A(n.location),url:a,salary:A(n.salary),snippet:A(n.snippet),postedAt:A(n.postedAt)}}function Dt(e){let t="";function n(a){const s=Ft(a);s&&e(s)}return{push(a){t+=a;let s;for(;(s=t.indexOf(`
`))!==-1;)n(t.slice(0,s)),t=t.slice(s+1)},end(){n(t),t=""}}}const Yt=6,te=[{id:"ats",focus:`Look on applicant tracking systems: ${H.join(", ")}.`},{id:"careers",focus:"Look on the hiring companies' own career pages (company websites, not job boards)."},{id:"boards",focus:"Look on job boards and aggregators (LinkedIn, Indeed, StepStone, Glassdoor, Welcome to the Jungle, Wellfound, Arbeitnow and similar); when the board links to the employer's own posting, give that URL."}];function Jt(e,t,n=[],a){const s=Oe(e),i=q();return`Search the web for current, actually open job postings that fit this
candidate:

${t||"(no candidate background available)"}

${s||"No further constraints — use the candidate's own background to pick a fitting role/location."}

Today is ${i}. Only include postings published in the last ${fe} days
that are still accepting applications — skip anything marked closed, expired or filled,
or shown with an older date. Skip postings that are a poor fit for the candidate (wrong
seniority, unrelated field).
Prefer the employer's own posting on its applicant tracking system (${H.join(", ")})
or career page over copies on aggregators, which often outlive the real posting.
Only real individual postings with their direct listing URL — never a search results page,
a generic careers homepage or an aggregator's category page.${a?`
${a}`:""}${Pe(n)}

OUTPUT FORMAT — follow exactly. Up to ${Yt} of the best matches, best first, as JSON
Lines: one JSON object per line, nothing else (no prose, no markdown, no code fences, no
citations). Each object has exactly these string keys:
{"title":"","company":"","location":"","url":"","salary":"","postedAt":"","snippet":""}
- "url": the posting's direct URL as found.
- "salary": as stated, or "" — never guess.
- "postedAt": YYYY-MM-DD when the posting states a date (resolve "3 days ago" against
  ${i}), else "".
- "snippet": one sentence, at most 25 words, on why it fits this candidate.
If you find no fitting posting, output nothing.`}const F={timeoutMs:9e4,idleMs:4e4,parseTimeoutMs:3e4};function ne(e){const t=n=>n.toLowerCase().replace(/[^a-z0-9]+/g," ").trim();return e.company?`${t(e.company)}|${t(e.title)}`:e.url}async function Bt(e,t,n=[],a,s,i){const r=performance.now();let o=null;const c=[],d=new Set,l=p=>d.has(p.url)||d.has(ne(p))?!1:(d.add(p.url),d.add(ne(p)),c.push(p),!0),h=await Promise.allSettled(te.map(async p=>{const y=Jt(e,t,n,p.focus),v=Dt($=>{const[U]=j([{...$,source:"openai"}]);!U||!l(U)||(o??(o=performance.now()),s==null||s([U]))}),x=performance.now();try{const $=await Qe(y,v.push,{reasoningEffort:"low",timeoutMs:F.timeoutMs,idleMs:F.idleMs,signal:i});return v.end(),$}finally{a==null||a.push({label:`Web search (${p.id})`,ms:performance.now()-x})}}));a==null||a.push({label:"Web search",ms:performance.now()-r}),o!==null&&(a==null||a.push({label:"First result",ms:o-r}));const m=h.flatMap((p,y)=>p.status==="rejected"?[{id:te[y].id,err:p.reason}]:[]),f=p=>p instanceof Error?p.message:"the search failed";if(m.length===h.length&&c.length===0)throw m[0].err;const w=m.map(p=>`Web search (${p.id}) stopped: ${f(p.err)}`);if(c.length>0)return{results:c,warnings:w};const g=h.map(p=>p.status==="fulfilled"?p.value:"").filter(p=>p.trim()).join(`

---

`);return g?{results:await N(a,"Parse results",()=>xe(g,"openai",t,{negative:e.negative,reasoningEffort:"low",timeoutMs:F.parseTimeoutMs,signal:i})),warnings:w}:{results:c,warnings:w}}const Ht="https://api.tavily.com/search",Gt=2e3;function Vt(e,t,n,a=[]){const s=`Find job postings from the last few weeks, still open, that fit this candidate.
${Oe(e)}

Candidate background: ${n||"(none available)"}${Pe(a)}`.trim().slice(0,Gt),i=Xe(e.negative);return{api_key:t,query:s,search_depth:"advanced",max_results:15,include_answer:!1,time_range:"month",include_published_date:!0,include_domains:H,include_domains_mode:"prefer",...i.length>0?{exclude_domains:i}:{}}}const J={searchTimeoutMs:25e3,parseTimeoutMs:4e4};async function Kt(e,t){for(let n=1;;n++){const a=AbortSignal.timeout(J.searchTimeoutMs);let s;try{s=await fetch(Ht,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e),signal:t?AbortSignal.any([t,a]):a})}catch(r){if(a.aborted)throw new Error(`Tavily search timed out after ${J.searchTimeoutMs/1e3} s.`);if(t!=null&&t.aborted||n>=2)throw r;continue}if(s.ok)return await s.json();const i=await s.text().catch(()=>"");if(n>=2||!(s.status===429||s.status>=500))throw new Error(`Tavily search failed (${s.status}): ${i.slice(0,300)}`);await new Promise(r=>setTimeout(r,1500))}}function zt(e){return j(e.map(t=>{var n;return{title:t.title,company:"",location:"",url:t.url,salary:"",snippet:t.content.slice(0,240),postedAt:((n=t.published_date)==null?void 0:n.slice(0,10))??"",source:"tavily"}}))}async function Wt(e,t,n,a=[],s,i){var d;const r=Vt(e,t,n,a),o=await N(s,"Tavily search",()=>Kt(r,i));if(!((d=o.results)!=null&&d.length))return{results:[],warnings:[]};const c=o.results.map(l=>`Title: ${l.title}
URL: ${l.url}
${l.published_date?`Published: ${l.published_date}
`:""}${l.content}`).join(`

---

`);try{return{results:await N(s,"Parse results",()=>xe(c,"tavily",n,{negative:e.negative,reasoningEffort:"low",timeoutMs:J.parseTimeoutMs,signal:i})),warnings:[]}}catch(l){if(i!=null&&i.aborted)throw l;const h=l instanceof Error?l.message:"parse failed";return{results:zt(o.results),warnings:[`Couldn't sort Tavily's results (${h}) — showing them unfiltered.`]}}}function Qt(e,t){return!e&&!t?"":et({low:Math.round(e??t??0),high:Math.round(t??e??0)})}function Xt(e){return new Promise(t=>setTimeout(t,e))}const Zt=350,en=12,ae=15e3;function tn(e,t,n,a,s){const i=new URL(`https://api.adzuna.com/v1/api/jobs/${a}/search/${s}`);i.searchParams.set("app_id",n.appId),i.searchParams.set("app_key",n.appKey),i.searchParams.set("results_per_page","15"),i.searchParams.set("content-type","application/json"),e&&i.searchParams.set("what",e),t.where&&i.searchParams.set("where",t.where);const r=Ze(t.negative);return r&&i.searchParams.set("what_exclude",r),i.toString()}async function nn(e,t,n,a,s,i){const r=AbortSignal.timeout(ae);let o;try{o=await fetch(tn(e,t,n,a,s),{signal:i?AbortSignal.any([i,r]):r})}catch(l){throw r.aborted?new Error(`timed out after ${ae/1e3} s`):l}if(!o.ok){const l=await o.text().catch(()=>"");throw new Error(`Adzuna search failed (${o.status}): ${l.slice(0,300)}`)}const d=(await o.json()).results.map(l=>{var h,m;return{title:l.title,company:((h=l.company)==null?void 0:h.display_name)??"",location:((m=l.location)==null?void 0:m.display_name)??"",url:l.redirect_url,salary:Qt(l.salary_min,l.salary_max),snippet:(l.description??"").slice(0,300),postedAt:l.created??"",source:"adzuna",tag:e}});return j(d)}async function an(e,t,n,a=1,s,i){var g;const r=e.tags&&e.tags.length>0?e.tags:[e.what],o=Math.max(((g=e.grades)==null?void 0:g.length)??0,1),c=Math.max(1,Math.floor(en/o)),d=jt(r.slice(0,c),e.grades),l=new Set,h=[],m=[];r.length>c&&m.push(`Only the first ${c} search terms were used with ${o} grades selected.`);let f=0,w=null;for(let u=0;u<d.length&&!(i!=null&&i.aborted);u++){const p=d[u];try{const v=(await nn(p,e,t,n,a,i)).filter(x=>!l.has(x.url));for(const x of v)l.add(x.url);h.push(...v),v.length>0&&(s==null||s(v))}catch(y){f++,w??(w=y),m.push(`"${p}" — ${y instanceof Error?y.message:"search failed"}`)}u<d.length-1&&await Xt(Zt)}if(f===d.length&&w)throw w;return{results:h,warnings:m}}const sn=new Set(["AT","AU","BE","BR","CA","CH","DE","ES","FR","GB","IN","IT","MX","NL","NZ","PL","RU","SG","US","ZA"]);function rn(e){var n;const t=(n=vt(e))==null?void 0:n.toUpperCase();return t&&sn.has(t)?t.toLowerCase():"us"}const on={type:"object",additionalProperties:!1,required:["what","where"],properties:{what:{type:"string"},where:{type:"string"}}},cn=`You suggest a starting job-search query for the applicant described below.
"what" is a short role/keywords phrase (e.g. "senior backend engineer", "product designer") —
their most recent or clearly strongest role from the CV/Personal Legend. Pick ONE single title:
never join multiple roles or technologies with "/", "," or parentheses (e.g. never "Full-Stack
Developer / Backend Engineer (Go, Python, React)") — that reads as a combined AND-match to a
literal keyword search and returns nothing. "where" is a location (city, region, or country) —
their stated city/country if given, else "".
Output only the two fields, no explanation.`;async function ln(){const{profile:e,cvText:t,personalLegend:n}=await E(),a=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:n},null,2),s=await b({schemaName:"job_search_query_suggestion",schema:on,systemPrompt:cn,userPrompt:a,parse:i=>JSON.parse(i),reasoningEffort:"low"});return{what:s.what,where:s.where||[e.city,e.country].filter(Boolean).join(", ")}}const un={type:"object",additionalProperties:!1,required:["tags"],properties:{tags:{type:"array",items:{type:"string"}}}},pn=`You generate keyword search tags for Adzuna's job-search API, grounded in
the candidate's real background below. Per Adzuna's own docs
(https://developer.adzuna.com/docs/search), "what" is a single literal keyword/phrase match, not
a semantic search and not a boolean query — so ONE combined tag naming several technologies or
role variants (e.g. "Full-Stack Developer / Backend Engineer (Go, Python, React)") matches
nothing. You compensate by generating a small cross-product of short, atomic tags instead, each
run as its own separate search and merged afterwards.

Method — build the tags as a cross-product, exactly like this worked example for a candidate
whose strongest stack is Go and who also does full-stack/backend work:
  golang developer, go developer, go engineer, golang engineer,
  backend engineer, backend developer, fullstack engineer, fullstack developer,
  software engineer, software developer
That is: {primary technology + its common short aliases} × {developer, engineer}, PLUS
{their role-shape words, e.g. backend / fullstack / frontend / mobile / data — whichever
genuinely apply, without a technology} × {developer, engineer}, PLUS a generic "software
developer" / "software engineer" fallback pair.

Rules:
- Base every tag on their actual, strongest-fitting technology/field from the CV/Personal
  Legend — never invent a technology, role-shape, or seniority they don't have.
- Identify the ONE primary technology (e.g. "Go") plus its common short aliases people actually
  search with (e.g. "Golang") — do not alias unrelated technologies together.
- Each tag pairs exactly one technology-or-role-shape word with exactly one of "developer" /
  "engineer" (add "programmer" only if that's a genuinely common term for that stack). Never put
  two technologies, or a technology and a role-shape, in the same tag.
- If the CV shows a clear secondary technology/stack, budget permitting, add its own couple of
  tags the same way — still never combined with the primary one in a single tag.
- For EACH language listed in "languages" below (skip English), also include ONE of the
  strongest-technology tags translated into that language using the natural job-title term a
  native speaker would search with (not a literal word-for-word translation).
- Each tag is 1-3 words, lowercase, and never contains "/", ",", "(", ")", or a seniority
  qualifier ("senior", "junior", etc.).
- Deduplicate. Return 6-12 tags total, most relevant first.
- Output only the tags, no explanation.`;async function dn(){const{profile:e,cvText:t,personalLegend:n,languageLevels:a}=await E(),s=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:n,languages:a.map(r=>r.language)},null,2);return(await b({schemaName:"job_search_tags",schema:un,systemPrompt:pn,userPrompt:s,parse:r=>JSON.parse(r),reasoningEffort:"low"})).tags.map(r=>r.trim()).filter(Boolean)}const hn=4;function gn(e){return JSON.stringify([e.profile.city,e.profile.country,e.cvText,e.personalLegend,e.languageLevels.map(t=>t.language)])}async function fn(e){const t=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(e));return[...new Uint8Array(t)].map(n=>n.toString(16).padStart(2,"0")).join("")}async function Ce(e){var o;const t=await fn(gn(await E())),n=await _("jobSearchSuggestionCache")??[],a=n.find(c=>c.key===t);if(a&&(!e||a.tags))return{what:a.what,where:a.where,tags:a.tags,cached:!0};const[s,i]=await Promise.all([a?{what:a.what,where:a.where}:ln(),e?dn():Promise.resolve(void 0)]),r={key:t,...s,tags:i!=null&&i.length?i:a==null?void 0:a.tags};return(r.what||(o=r.tags)!=null&&o.length)&&await D("jobSearchSuggestionCache",[r,...n.filter(c=>c.key!==t)].slice(0,hn)),{what:r.what,where:r.where,tags:r.tags,cached:!1}}async function mn(e,t={}){var l,h,m;const n=performance.now(),a=[],s=()=>({totalMs:performance.now()-n,stages:a});if(e.provider==="adzuna"){const[f,w]=await Promise.all([Q(),M()]);if(!f.adzunaAppId||!f.adzunaAppKey)throw new Error("Add your Adzuna app_id and app_key in Settings first.");let g=e;if(!((l=g.tags)!=null&&l.length))if(g.what.trim())g={...g,tags:[g.what.trim()]};else{const y=performance.now(),v=await Ce(!0);a.push({label:v.cached?"Suggest tags (cached)":"Suggest tags",ms:performance.now()-y}),g={...g,what:v.what,where:g.where.trim()||v.where,tags:(h=v.tags)!=null&&h.length?v.tags:[v.what]}}const{results:u,warnings:p}=await N(a,"Adzuna search",()=>an(g,{appId:f.adzunaAppId,appKey:f.adzunaAppKey},rn(w.country),t.page??1,t.onResults,t.signal));return{results:u,resolvedQuery:g,warnings:p,...s()}}const[i,r]=await Promise.all([pe(),Q()]),o=(i==null?void 0:i.content)??"";if(e.provider==="tavily"){if(!r.tavilyApiKey)throw new Error("Add your Tavily API key in Settings first.");const{results:f,warnings:w}=await Wt(e,r.tavilyApiKey,o,t.excludeResults,a,t.signal);return f.length>0&&((m=t.onResults)==null||m.call(t,f)),{results:f,resolvedQuery:e,...w.length?{warnings:w}:{},...s()}}const{results:c,warnings:d}=await Bt(e,o,t.excludeResults,a,t.onResults,t.signal);return{results:c,resolvedQuery:e,...d.length?{warnings:d}:{},...s()}}const yn={type:"object",additionalProperties:!1,required:["keyRequirements","relevantExperienceHints","suggestedTone","suggestedFocus"],properties:{keyRequirements:{type:"array",items:{type:"string"}},relevantExperienceHints:{type:"array",items:{type:"string"}},suggestedTone:{type:"string"},suggestedFocus:{type:"string"}}};async function wn(e){return b({schemaName:"job_analysis",schema:yn,model:await me(),systemPrompt:"You analyze job postings for a job-application assistant. Identify the most important requirements and what an applicant should emphasize. Do not invent details that are not present in the posting.",userPrompt:JSON.stringify(e,null,2),parse:t=>JSON.parse(t)})}const bn=`You write tailored cover letters for job applications.

The user message holds the applicant's data as JSON, and may end with an
"Applicant's rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and
   Personal Legend. Never invent experience, technologies, companies,
   education, or achievements, even if the applicant's rules ask for them.
   If information needed to be compelling is missing, write around it
   honestly rather than fabricating it.
2. The applicant's rules. Follow every instruction there on tone, length,
   structure, language, and what to include or avoid, including where it
   departs from the defaults below. Every rule there applies to the whole
   letter, not just the opening.
3. Language. If "postingLanguage" is given, write the entire letter in that
   language, using the salutation, register, and closing conventions native
   speakers of it would expect on a job application (e.g. formal
   "Sie"/"Herr"/"Frau" address and a "Sehr geehrte(r) ..." opening in German,
   not a literal English-to-German translation).
4. The house style below. Its "no exceptions" means no exceptions of your
   own; an explicit applicant rule still overrides it.
5. Tone and emphasis tailored to the job analysis provided.

Output plain prose paragraphs, no markdown headers.

${I}`;async function vn(e,t){const a=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,analysis:e.analysis,postingLanguage:e.postingLanguage||void 0},null,2)+Ne(e.generationRules),s=await tt(bn,a,t??(()=>{}));return k(s)}function Ne(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const K={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},Me={type:"object",additionalProperties:!1,required:["subject","body"],properties:{subject:{type:["string","null"]},body:{type:"string"}}},En=`You are a sharp human editor cleaning up a cover letter draft.

Fix ONLY the flagged AI-writing patterns listed below. Make the minimum
effective edit — do not rewrite sentences that were not flagged, do not
change facts, experience, technologies, or claims, and do not add new
content. Replace banned words/clichés with plain, concrete language.
Rewrite "not X, it's Y" contrasts as a direct statement of Y. Cut
throat-clearing openers, weasel attribution, and importance-puffery instead
of softening them. If the ending is a generic summary/recap, end on the
letter's last concrete point instead. Replace every em dash ("—") with a
comma, a period, or parentheses.

The user message may end with the applicant's own rules for the letter. If a
flagged pattern is something those rules explicitly ask for, leave it as is:
the applicant's rules outrank the house style.

Do not introduce any new AI-slop while editing. For reference, the full
house style is:

${I}

Output plain prose paragraphs, no markdown headers.`;async function Sn(e,t,n=""){const a=JSON.stringify({draft:e,flaggedPatterns:t.map(i=>`${i.pattern}: "${i.match}"`)},null,2)+Ne(n),s=await b({schemaName:"cover_letter_polish",schema:K,systemPrompt:En,userPrompt:a,parse:i=>JSON.parse(i)});return k(s.content)}const kn=["delve","foster","leverage","utilize","facilitate","empower","streamline","robust","cutting-edge","paradigm shift","game changer","this is huge","this changes everything","tapestry","realm","beacon","multifaceted","meticulous","intricate","paramount","transformative","elevate","embark","supercharge","harness","ever-evolving"],Tn=["it's worth noting","it is worth noting","it's important to note","it is important to note","at the end of the day","when it comes to","at its core","in today's world","in the age of","in the world of","the reality is","the truth is","in terms of","with regard to","in order to","going forward"],Ln=["here's the thing","here's what i mean","let me be clear","i'll be honest","the uncomfortable truth is"],In=["this is the part most people skip","what most people get wrong","here's what nobody tells you","the part everyone misses"],An=["stands as a testament","marks a pivotal moment","plays a vital role","solidifies its position","underscores its significance"],_n=["experts agree","industry reports suggest","many argue","widely regarded as","studies show"],Rn=[/^in conclusion\b/i,/^ultimately\b/i,/^overall\b/i];function On(e){const t=e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`\\b${t.replace(/ /g,"\\s+")}\\b`,"i")}function R(e,t,n){const a=[];for(const s of t){const i=On(s).exec(e);i&&a.push({pattern:n,match:i[0]})}return a}function xn(e){const t=/\b(?:isn'?t|is not)\b[^.!?]{3,60}[,.]?\s*(?:it'?s|it is)\b[^.!?]{3,80}[.!?]/i,n=/\bnot just\b[^.!?]{3,60}(?:\bbut\b|[,.]?\s*(?:it'?s|it is)\b)[^.!?]{0,80}[.!?]/i,a=[],s=t.exec(e);s&&a.push({pattern:"binary-contrast",match:s[0].trim()});const i=n.exec(e);return i&&a.push({pattern:"binary-contrast",match:i[0].trim()}),a}function Pn(e){const t=e.split(/\n{2,}/).map(a=>a.trim()).filter(Boolean),n=t[t.length-1];if(!n)return[];for(const a of Rn)if(a.test(n))return[{pattern:"summary-recap-ending",match:n.slice(0,60)}];return[]}function Cn(e){const t=(e.match(/—/g)??[]).length;return t===0?[]:[{pattern:"em-dash",match:t===1?"1 em dash":`${t} em dashes`}]}function Nn(e){return[...R(e,kn,"banned-word"),...R(e,Tn,"empty-phrase"),...R(e,Ln,"throat-clearing-opener"),...R(e,In,"faux-insight-setup"),...R(e,An,"importance-puffery"),...R(e,_n,"weasel-attribution"),...xn(e),...Pn(e),...Cn(e)]}async function Mn(e,t,n){const a=await E(),s=await wn(e),i=await vn({profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,generationRules:a.generationRules,job:e,analysis:s,postingLanguage:t},n),r=Nn(i);return r.length===0?{content:i,slopFindings:r,cleaned:!1}:{content:await Sn(i,r,a.generationRules),slopFindings:r,cleaned:!0}}const qn=`You write a short outreach message an applicant sends to a named
recruiter/hiring contact BEFORE or alongside applying, to start a conversation about a specific
job posting — not a cover letter, and not addressed to "the hiring team".

The user message holds the applicant's data as JSON ("contact" is the email address or LinkedIn
URL found on the posting, "channel" is "email" or "linkedin"), and may end with an "Applicant's
rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and Personal Legend. Never
   invent experience, technologies, companies, education, or achievements.
2. The applicant's rules. Follow every instruction there on tone, length, structure, language,
   and what to include or avoid, including where it departs from the defaults below.
3. Language. If "postingLanguage" is given, write the entire message in that language, using
   the salutation and register native speakers of it would expect.
4. Channel. If "channel" is "email", write a short email: "subject" is REQUIRED, never null or
   empty: a specific, non-generic subject line under 80 characters that names the role and the
   company (and, if it fits, the applicant's strongest match), in the message's language. "body"
   opens with a greeting and closes with a signature using the applicant's name; it does not
   repeat the subject. If "channel" is "linkedin", write a LinkedIn connection/message note
   instead: "subject" is null, "body" has no email greeting/signature and stays under LinkedIn's
   informal register.
5. The house style below. Its "no exceptions" means no exceptions of your own; an explicit
   applicant rule still overrides it.

Defaults (apply unless the applicant's rules say otherwise): under 120 words, state who the
applicant is and the one or two things that make them a fit for THIS role, and end with a clear,
low-pressure ask (a quick chat, or just flagging interest before applying). Never sound like a
mass-sent template.

${I}`;async function jn(e){const n=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,contact:e.contact,channel:X(e.contact)?"email":"linkedin",postingLanguage:e.postingLanguage||void 0},null,2)+$n(e.outreachRules),a=await b({schemaName:"outreach_message",schema:Me,model:await ye(),systemPrompt:qn,userPrompt:n,parse:s=>JSON.parse(s)});return{subject:X(e.contact)?qe(a.subject,e.job):null,body:k(a.body)}}function qe(e,t){const n=k((e??"").replace(/^\s*subject\s*:\s*/i,"").replace(/\s+/g," ").trim());if(n)return n;const a=t.position.trim(),s=t.company.trim();return a&&s?`${a} at ${s}`:a||s||"Job application"}function $n(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const je={type:"array",items:{type:"object",additionalProperties:!1,required:["text","kind","matchesProfile"],properties:{text:{type:"string"},kind:{type:"string",enum:["hard","soft"]},matchesProfile:{type:"boolean"}}}};function z(e){return`KEYWORDS
- Pick the SKILLS the posting asks for, and nothing else. Each one is either:
  - "hard": a technical skill, tool, technology, programming language, framework, platform,
    method or domain expertise (e.g. "TypeScript", "Kubernetes", "C++", ".NET", "CI/CD",
    "SQL", "machine learning", "financial modelling", "Figma", "Scrum");
  - "soft": a real interpersonal/working skill (e.g. "communication", "mentoring",
    "stakeholder management", "problem-solving", "ownership").
- NEVER return anything that is not a skill. In particular, never return:
  - the company name, its products' brand names used as a name, or any other organization;
  - cities, countries, regions, addresses, time zones;
  - work modes and contract terms ("remote", "hybrid", "on-site", "full-time", "contract");
  - benefits and pay ("salary", "equity", "health insurance", "30 days vacation", "bonus");
  - job titles and seniority ("Senior Backend Engineer", "Team Lead", "junior");
  - years of experience, degrees, certificates as such ("5+ years", "Bachelor's degree");
  - spoken languages ("English", "German") — those are reported separately above;
  - generic words ("team", "experience", "work", "product", "environment", "opportunity",
    "fast-paced environment", "passion").
- Every keyword's "text" MUST be copied VERBATIM from ${e} — the exact same characters
  and casing, not a paraphrase, synonym, or translation — because the extension re-finds this
  exact text on the page to highlight it. A keyword that doesn't appear verbatim is useless.
- Prefer short phrases: single words or 2-3 word phrases, never sentences.
- Return up to 15, most important first. Fewer is fine: return an empty array rather than
  padding the list with anything from the NEVER list above.
- No duplicates, and no two keywords where one is a substring of the other (keep the more
  specific/longer one).
- Set "matchesProfile" to true when the applicant's profile/cvText/personalLegend shows they
  already have, use, or meet that skill — false when the posting asks for it but nothing in
  the applicant's material supports it. Judge substance, not exact wording (e.g.
  "Kubernetes" counts as a match if the CV mentions "container orchestration with K8s" or
  "EKS"). When genuinely unsure, set it to false — this flags a possible gap for the
  applicant to address rather than silently hiding it.`}const Un=new Set(["team","teams","experience","work","job","role","position","company","candidate","opportunity","environment","product","products","customer","customers","client","clients","project","projects","skills","knowledge","ability","responsibilities","requirements","tasks","career","growth","culture","mission","vision","values","impact","passion","motivation","startup","scale-up","industry","business","fast-paced environment","dynamic environment","nice to have","must have","plus","years","year","years of experience","professional experience","work experience","degree","bachelor","bachelor's degree","master","master's degree","university degree","diploma","phd","intern","internship","junior","middle","mid-level","senior","lead","principal","staff","head","manager","remote","fully remote","remote work","hybrid","on-site","onsite","office","in office","home office","homeoffice","relocation","visa sponsorship","full-time","full time","part-time","part time","contract","freelance","permanent","temporary","salary","competitive salary","bonus","equity","stock options","esop","benefits","vacation","paid time off","pto","holidays","health insurance","insurance","pension","gym","gym membership","free lunch","snacks","flexible hours","flexible working hours","learning budget","parental leave","erfahrung","berufserfahrung","aufgaben","anforderungen","unternehmen","vollzeit","teilzeit","festanstellung","gehalt","urlaub","vertrag","büro","mobiles arbeiten","команда","опыт","опыт работы","работа","компания","проект","проекты","задачи","требования","обязанности","удаленно","удаленка","удаленная работа","гибрид","офис","полный день","полная занятость","частичная занятость","зарплата","оклад","бонусы","дмс","отпуск","релокация"]),Fn=new Set(nt.map(e=>L(e))),Dn=new RegExp("\\s*,?\\s*(?<![\\p{L}\\p{N}])(?:inc|ltd|llc|gmbh|ag|se|kg|ug|bv|nv|sa|sas|srl|plc|corp|corporation|co|company|oy|ab|as|ооо|ао)\\.?$","iu");function L(e){return e.normalize("NFC").toLowerCase().replace(/ё/g,"е").replace(/[’`]/g,"'").replace(/^[\s"'«».,:;!?()[\]-]+|[\s"'«».,:;!?()[\]-]+$/g,"").replace(/\s+/g," ")}function Yn(e){const t=L(e);if(!t)return[];const n=L(t.replace(Dn,""));return n&&n!==t?[t,n]:[t]}function Jn(e){const t=L(e);if(!t)return[];const n=e.split(/[,/|·•()]/).map(L).filter(Boolean);return[t,...n]}function Bn(e){return L(e.replace(/\((?:[mwfdx]\s*\/\s*)+[mwfdx]\)/gi,""))}const Hn=/^\d+(?:\s*[-–+]\s*\d*)?\+?\s*(?:years?|yrs?|jahre?n?|лет|года?|ans|años)(?![\p{L}\p{N}])/iu;function B(e,t){const n=e.trim();if([...n].length<2)return!new RegExp("^\\p{Lu}$","u").test(n);if(!new RegExp("\\p{L}","u").test(n)||/[$€£¥₽%]/u.test(n))return!0;const a=L(n);return!a||Un.has(a)||Fn.has(a)||Hn.test(a)||Yn(t.company).includes(a)||Jn(t.location).includes(a)?!0:a===Bn(t.position)}function W(e,t){const n=new Set;return e.filter(a=>{const s=L(a.text);return n.has(s)||B(a.text,t)?!1:(n.add(s),!0)})}function Gn(e,t){var s;const n=(s=e.match(/\s*[,;|·•]\s*/u))==null?void 0:s[0];if(!n)return B(e,t)?"":e;const a=new Set;return e.split(/\s*[,;|·•]\s*/u).filter(i=>{const r=L(i);return!i.trim()||a.has(r)||B(i,t)?!1:(a.add(r),!0)}).join(n)}const $e={postingLanguages:{type:"array",items:{type:"string"}},languageRequirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...be,null]}}}},keywords:je},Vn={type:"object",additionalProperties:!1,required:["company","position","location","description","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},description:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...$e}},Ue=`LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- languageRequirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or "Native"
  for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent", "professional
  working proficiency" -> "C1"; "conversational" -> "B1". If a language is mentioned but no level
  can be reasonably inferred, set level to null. Do not invent a requirement that isn't stated in
  the text. If nothing is stated, return an empty array.`,Kn=`You read the visible text of a job-posting page and do two things with it
in one pass: extract the structured posting fields, and analyze the result for language and
keywords — against the applicant profile/CV/Personal Legend given below.

EXTRACTION
- Only use information present in "pageText"; leave a field empty/null if unknown.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- For "contact", prefer a named recruiter/hiring manager's email address or LinkedIn
  profile/company URL if one is mentioned, copied VERBATIM (exact characters); otherwise null.

${Ue}

${z('"pageText"')}`;async function zn(e,t){const n=await E(),a=JSON.stringify({profile:n.profile,cvText:n.cvText,personalLegend:n.personalLegend,pageText:e.slice(0,12e3)},null,2),s=await b({schemaName:"job_extraction_and_brief",schema:Vn,model:await we(),reasoningEffort:"low",systemPrompt:Kn,userPrompt:a,parse:o=>JSON.parse(o)}),i={company:s.company,position:at(s.position),location:s.location,description:s.description,requirements:s.requirements,responsibilities:s.responsibilities,salary:s.salary,techStack:s.techStack,contact:s.contact,url:t},r={language:{postingLanguages:s.postingLanguages,requirements:s.languageRequirements},keywords:W(s.keywords,i),contact:null};return{job:i,brief:r}}const Wn={type:"object",additionalProperties:!1,required:["company","position","location","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...$e}},Qn=`You read the visible text of a job-posting page. It was already parsed
without AI: "knownFields" holds what that found. Fill in what it missed, and analyze the posting
for language and keywords — against the applicant profile/CV/Personal Legend given below.

FIELDS
- Fill only the fields named in "fieldsToFill". For every other posting field return "" / [] /
  null — those are kept from the page as they are. Never re-type the posting's description.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- company: the hiring company, not the job board or recruiting platform hosting the page.
- location: as written in the posting; "" if none.
- requirements, responsibilities: at most 8 items each, each a short phrase (12 words or fewer),
  not copied paragraphs.
- techStack: technology names only.
- contact: a named recruiter/hiring manager's email address or LinkedIn profile/company URL,
  copied VERBATIM (exact characters); otherwise null.
- Only use information present in "pageText"; leave a field empty/null if unknown.

${Ue}

${z('"pageText"')}`;async function Xn(e,t){const n=await E(),a=st(e),s=t||e.description,i=JSON.stringify({profile:n.profile,cvText:n.cvText,personalLegend:n.personalLegend,knownFields:{position:e.position,company:e.company,location:e.location,salary:e.salary,contact:e.contact},fieldsToFill:a,pageText:s.slice(0,12e3)},null,2),r=await b({schemaName:"job_completion_and_brief",schema:Wn,model:await we(),reasoningEffort:"low",systemPrompt:Qn,userPrompt:i,parse:d=>JSON.parse(d)}),o=it(e,r,a,s),c={language:{postingLanguages:r.postingLanguages,requirements:r.languageRequirements},keywords:W(r.keywords,o),contact:null};return{job:o,brief:c}}const Zn=`You are editing an existing cover letter draft on the applicant's
instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the
  letter the instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements
  that aren't already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the
  instruction explicitly asks to change it.
- Output plain prose paragraphs, no markdown headers.
- Don't introduce AI-slop while editing, and clean it from any sentence you
  touch.

${I}`;async function ea(e,t,n){const a=JSON.stringify({draft:e,instructions:t,job:n},null,2),s=await b({schemaName:"cover_letter_revision",schema:K,model:await rt(),systemPrompt:Zn,userPrompt:a,parse:i=>JSON.parse(i)});return k(s.content)}const ta=`You are editing an existing outreach message (an email or LinkedIn note
to a recruiter/hiring contact) on the applicant's instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the message the
  instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements that aren't
  already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the instruction explicitly
  asks to change it.
- If the draft's "subject" is null, keep it null (it's a LinkedIn note). Otherwise keep a
  specific subject line, changing it only if the instruction (or the edit) requires it.
- Don't introduce AI-slop while editing, and clean it from any sentence you touch.

${I}`;async function na(e,t,n){const a=JSON.stringify({draft:e,instructions:t,job:n},null,2),s=await b({schemaName:"outreach_message_revision",schema:Me,model:await ye(),systemPrompt:ta,userPrompt:a,parse:i=>JSON.parse(i)});return{subject:e.subject===null?null:qe(s.subject||e.subject,n),body:k(s.body)}}const aa=`You translate a cover letter for the applicant's own understanding —
not for submission. Translate faithfully, preserve paragraph breaks, and keep
names, companies, and technical terms as-is where translating them would be
unnatural. Do not use em dashes ("—"); use commas or periods. Output plain
prose paragraphs, no markdown headers, no notes about the translation itself.`;async function sa(e,t){const n=JSON.stringify({content:e,targetLanguage:t},null,2),a=await b({schemaName:"cover_letter_translation",schema:K,systemPrompt:aa,userPrompt:n,parse:s=>JSON.parse(s)});return k(a.content)}const se=new RegExp([String.raw`(?:additional|further|other|more|extra|supplementary)\s+(?:information|info|details|comments?|remarks?|notes?|thoughts)`,String.raw`anything\s+else`,String.raw`is\s+there\s+anything(?:\s+else)?`,String.raw`any(?:thing)?\s+(?:other|further|additional|final)\s+(?:comments?|remarks?|notes?|information|thoughts)`,String.raw`(?:any|final)\s+(?:comments?|remarks?|notes?|thoughts)`,String.raw`(?:a\s+)?(?:message|note)\s+(?:to|for)\s+(?:the\s+|our\s+)?(?:hiring\s+(?:team|manager)|recruit(?:er|ing\s+team|ment\s+team)|team|us|company|employer)`,String.raw`(?:weitere|zus[aä]tzliche|sonstige|erg[aä]nzende|andere)\s+(?:informationen|infos?|angaben|anmerkungen|hinweise|bemerkungen|mitteilungen|kommentare)`,String.raw`sonstiges`,String.raw`(?:m[oö]chten|willst|m[oö]chtest)\s+(?:sie|du)\s+uns\s+(?:sonst\s+)?noch\s+(?:etwas|was)`,String.raw`gibt\s+es\s+(?:sonst\s+)?noch\s+(?:etwas|was)`,String.raw`(?:nachricht|mitteilung)\s+an\s+(?:uns|das\s+team|den\s+recruiter|die\s+personalabteilung)`,String.raw`informations?\s+compl[ée]mentaires?`,String.raw`informaci[oó]n\s+adicional`,String.raw`дополнительн(?:ая|ые)\s+(?:информация|сведения|комментари[йи])`].join("|"),"iu"),ia=/^(?:your\s+|ihre?\s+|deine?\s+|persönliche\s+)?(?:messages?|comments?|remarks?|notes?|nachricht|anmerkungen?|bemerkungen?|kommentare?|hinweise?|mitteilung|commentaires?|comentarios?|комментари[йи]|сообщение)$/iu,ra=/^(?:your\s+|ihr\s+)?(?:cover\s+letter|motivation(?:al)?\s+letter|anschreiben|motivationsschreiben|lettre\s+de\s+motivation|carta\s+de\s+presentaci[oó]n|сопроводительное\s+письмо)$/iu,oa=new RegExp(String.raw`\b(?:optional|freiwillig|facultatif|opcional|необязательно|please|bitte|here|hier|you|you'?d|would|like|to|share|add|tell|let|us|know|mention|with|about|yourself|we|should|that|the|a|an|and|or|for|me|your|our|any|on|in|of|this|application|role|position|job|team|hiring|sie|du|uns|noch|etwas|was|mitteilen|teilen|sagen|zu|ihrer|ihre|deiner|bewerbung|stelle|möchten|möchtest|gibt|es|sonst|und|oder|für|die|der|das|den|dem|an|mit|über|is|there|else|do|have|want|wish|feel|free|e\.?\s?g\.?|z\.?\s?b\.?)\b`,"giu");function ca(e){return e.replace(/[*✱:?!.…]+/g," ").replace(/\((?:optional|freiwillig|facultatif|opcional|необязательно)\)/giu," ").replace(/\s+/g," ").trim()}function la(e,t){return e.replace(t," ").replace(/[()[\],;/\-–—"'„“”]+/g," ").replace(oa," ").split(/\s+/).filter(a=>new RegExp("\\p{L}{2}","u").test(a))}function ua(e){const t=ca(e);return t?ra.test(t)?"coverLetter":ia.test(t)?"weak":new RegExp(se.source,"giu").test(t)?la(t,new RegExp(se.source,"giu")).length>=3?null:"strong":null:null}const pa=[/\b(?:please|kindly)\b[^.!?\n]{0,100}\b(?:mention|include|state|indicate|tell\s+us|let\s+us\s+know|add|note|specify|quote|answer)\b[^.!?\n]{0,100}\b(?:application|cover\s+letter|message|submission)\b[^.!?\n]*/iu,/\bin\s+your\s+(?:application|cover\s+letter|message)\b[^.!?\n]{0,100}\b(?:mention|include|state|tell\s+us|let\s+us\s+know|answer|describe)\b[^.!?\n]*/iu,/\b(?:code\s?word|keyword|reference\s+(?:number|code)|kennwort|kennziffer|referenznummer|stichwort)\b[^.!?\n]*/iu,/\b(?:geben|nennen|teilen|erw[aä]hnen|beantworten)\s+sie\b[^.!?\n]{0,120}\b(?:bewerbung|anschreiben|nachricht)\b[^.!?\n]*/iu,/\bin\s+ihrer\s+bewerbung\b[^.!?\n]{0,120}\b(?:an|nennen|angeben|mitteilen|erw[aä]hnen|beantworten)\b[^.!?\n]*/iu];function ie(e){const t=[e.description??"",...e.requirements??[],...e.responsibilities??[]].join(`
`);for(const n of pa){const a=n.exec(t);if(a)return a[0].trim().slice(0,300)}return null}function da(e,t){if(t.required===!0)return{action:"write",reason:"required",postingAsk:ie(e)??void 0};const n=ie(e);return n?{action:"write",reason:"posting",postingAsk:n}:t.required===!1?{action:"skip"}:{action:"write",reason:"asked"}}const ha={type:"object",additionalProperties:!1,required:["skip","answer"],properties:{skip:{type:"boolean"},answer:{type:"string"}}},ga=`You decide what, if anything, goes into the open catch-all field at the end of a
job application form ("Additional information", "Anything else you'd like to share?", "Weitere
Informationen", "Sonstiges", "Message to the hiring team"). The recruiter already has everything
in "formValues", "otherAnswers", the attached CV ("cvText"), the cover letter ("coverLetter") and
the profile. Repeating any of it wastes their time and makes the application look padded.

Rules:
- "skip": true, "answer": "" is the normal result. Choose it whenever there is nothing NEW and
  relevant to add. An empty field is fine.
- Never repeat or paraphrase: contact data (name, email, phone, address, city), links (LinkedIn,
  GitHub, portfolio, website), salary expectations, start date / notice period / availability,
  work permit / visa / relocation, language levels, a summary of the CV or the experience, or the
  motivation already given in the cover letter or other answers.
- "postingAsk" (when present) is what the job posting explicitly asks applicants to include.
  Answer exactly that, from the applicant's data, if it isn't already in the form. If the data
  doesn't have it, skip.
- "required": true means the form won't submit with the field empty. Then don't skip: write ONE
  short sentence with something new from the Personal Legend or custom fields, or, if there is
  truly nothing new, one plain neutral sentence (e.g. that you look forward to hearing from them).
- Otherwise ("required" false or unknown), write only when there is a genuinely new, relevant fact
  (e.g. a constraint the recruiter must know that appears nowhere else).
- At most 2 sentences, plain text, no greeting, no sign-off, no lists, no markdown.
- Never invent facts. Use ONLY the applicant data given.
- If "postingLanguage" is given, write in that language with its native application register.

${I}`,fa=/\b(?:https?:\/\/|www\.)\S+|\b[\w.-]+\.(?:com|de|io|dev|net|org|me)\/\S*/i,ma=/\b[\w.+-]+@[\w-]+\.[\w.-]+\b/,ya=/(?:\+|\b00)\d[\d\s/().-]{6,}\d|\b0\d{2,4}[\s/-]?\d{3,}[\s-]?\d{2,}\b/;function wa(e){return e.replace(/\s+/g," ").trim().split(new RegExp("(?<=[.!?])\\s+(?=\\S)","u")).filter(n=>n&&!fa.test(n)&&!ma.test(n)&&!ya.test(n)).slice(0,2).join(" ").trim()}async function Fe(e,t,n,a){const s=da(t,n);if(s.action==="skip")return{answer:"",sufficientInfo:!0,skipped:!0};const[i,r]=await Promise.all([E(),_("lastCoverLetter")]),o=JSON.stringify({job:t,profile:i.profile,cvText:i.cvText,coverLetter:r??"",coverLetterAttached:n.coverLetterAttached||void 0,personalLegend:i.personalLegend,customFields:i.customFields,languageLevels:i.languageLevels,generationRules:i.generationRules,postingLanguage:a||void 0,formValues:(n.formValues??[]).filter(l=>l.value.trim()),otherAnswers:(n.otherAnswers??[]).filter(l=>l.answer.trim()),postingAsk:s.postingAsk,required:n.required??"unknown",question:e},null,2),c=await b({schemaName:"catch_all_answer",schema:ha,systemPrompt:ga,userPrompt:o,label:"Catch-all answer",parse:l=>JSON.parse(l)}),d=c.skip?"":wa(k(c.answer));return d?{answer:d,sufficientInfo:!0,skipped:!1}:{answer:"",sufficientInfo:n.required!==!0,skipped:!0}}const ba={type:"object",additionalProperties:!1,required:["answer","sufficientInfo"],properties:{answer:{type:"string"},sufficientInfo:{type:"boolean"}}},re=`You answer a custom question from a job application form on the
applicant's behalf.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend,
  cover letter, custom fields, language levels, and job posting. Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, the
  "languageLevels" list is the authoritative answer (CEFR levels the
  applicant self-reported in Settings) — use it directly rather than
  guessing from the CV or defaulting to a low/neutral level.
- If the profile/CV/Personal Legend/etc genuinely lack what's needed to
  answer this question — not just a minor detail, but the actual substance
  being asked for — set "sufficientInfo" to false and "answer" to an empty
  string. Do NOT write a sentence explaining that you don't have the
  information (e.g. "I don't have this information available") — that text
  would otherwise get typed straight into the applicant's form field, which
  is worse than leaving it blank for the applicant to fill in themselves.
  Only do this when the information is truly absent; a question you can
  answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient —
  set sufficientInfo to true and give that honest answer.
- If "postingLanguage" is given, write the answer in that language, using
  the salutation/register conventions native speakers of it would expect on
  a job application (e.g. formal "Sie"/"Herr"/"Frau" address in German, not
  a literal English-to-German translation) — unless the question itself, or
  "generationRules", explicitly asks for a different language.
- If this question is a newsletter, marketing-email, or job-alert
  subscription opt-in phrased as a choice (e.g. "Would you like to
  subscribe to our newsletter? Yes/No"), always choose the option that
  declines it — the applicant never needs this to submit the application.
- "faq" is a set of pre-written answers to standard interview-FAQ questions
  (spec_5 section B). If the question being asked now is the same as, or a
  close variant of, one already in "faq", reuse its substance and phrasing —
  adapt only what the target field's length/format actually requires — so
  the applicant's answer stays consistent across different forms rather
  than being re-derived from scratch each time.
- Match the question's expected length: a short field gets a short answer, an
  open-ended "tell us about..." field gets a fuller one.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text, no markdown, no restating the question.

${I}`,va=/\b(?:please\s+(?:provide|specify|clarify)|could\s+you\s+(?:please\s+)?(?:provide|clarify|specify)|i\s+(?:don'?t|do\s+not)\s+see)\b.{0,40}?\b(?:question|prompt)\b|\bno\s+(?:specific\s+)?question\s+(?:was|is)?\s*(?:provided|given|specified|attached)\b/i;function De(e){const t=e.trim();return t?t.length<220&&va.test(t):!0}const Ea=`
- This is a MULTIPLE-CHOICE question: "options" lists the allowed answers.
  Reply with EXACTLY ONE option, copied verbatim, and nothing else.
- Base the choice on the applicant's profile/CV/Personal Legend. If the
  needed fact is genuinely absent (e.g. pronouns not stated anywhere),
  prefer a neutral option, an explicit "prefer not to say", or the option
  that commits the applicant least.`,Sa=`
- This is a SELECT-ALL-THAT-APPLY question: "options" lists every allowed
  answer. Reply with every option that genuinely applies, each copied
  verbatim, joined by " | " (a single pipe surrounded by one space on each
  side) — nothing else. If none apply, reply with an empty string.
- Base each choice strictly on the applicant's profile/CV/Personal Legend —
  never include an option just because it's plausible or common; only ones
  the applicant's own material actually supports.`,ka=`
- This field only accepts a plain number: reply with digits only (a single
  "." for a decimal if needed) — no currency symbol, no thousands
  separator, no unit, no words, no range. If a range genuinely fits best
  (e.g. a salary expectation given as "65-75k"), reply with one
  representative figure (its midpoint), not the range.`;function Ta(e){return`
- This field only accepts a date in the exact format "${Le[e]}"
  — reply with ONLY that value, nothing else (no words, no explanation).
  "todayISO" in the data below is today's date: compute the answer from it
  — e.g. "available with one month's notice" → todayISO plus one month;
  "immediately" / "as soon as possible" / no stated constraint → todayISO
  itself. Never answer with a description of the notice period or
  availability instead of the date itself.`}async function La(e,t,n,a,s,i,r,o){if(!(n&&n.length>0)&&!a&&!s&&(o||o===void 0&&ua(e)==="strong"))return Fe(e,t,o??{},r);const[d,l]=await Promise.all([E(),_("lastCoverLetter")]),{input:h,promptCacheKey:m}=ve(d,l??"",t,r),f={question:e,options:n,multi:i,numeric:a,dateKind:s},w=Y(f);try{const g=await G({input:h,promptCacheKey:m,questions:w?Ee(f,0):[Se(f,0)]});if(w){const u=ke(f,0,g);if(u)return u}else if(Te(0,g)===!1)return{answer:"",sufficientInfo:!1}}catch(g){if(g instanceof V)throw g;console.warn("[Filler] Decisions API failed, answering via Responses:",g)}return Ia(e,t,n,a,s,i,r)}async function Ia(e,t,n,a,s,i,r){const[o,c]=await Promise.all([E(),_("lastCoverLetter")]),d=JSON.stringify({job:t,profile:o.profile,cvText:o.cvText,personalLegend:o.personalLegend,generationRules:o.generationRules,coverLetter:c??"",languageLevels:o.languageLevels,customFields:o.customFields,faq:o.faq.filter(f=>f.answer.trim()),todayISO:q(),postingLanguage:r||void 0,question:e,options:n&&n.length>0?n:void 0},null,2),l=[n&&n.length>0?i?Sa:Ea:"",a?ka:"",s?Ta(s):""].filter(Boolean),h=await b({schemaName:"custom_question_answer",schema:ba,systemPrompt:l.length>0?[re,...l].join(`
`):re,userPrompt:d,parse:f=>JSON.parse(f)});return!h.sufficientInfo||De(h.answer)?{answer:"",sufficientInfo:h.sufficientInfo}:{answer:n&&n.length>0||a||!!s?h.answer:k(h.answer),sufficientInfo:!0}}const Aa={type:"object",additionalProperties:!1,required:["questions"],properties:{questions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","question"],properties:{index:{type:"integer"},question:{type:"string"}}}}}},_a=`You are given a block of a job-application form: its visible text, and a
list of the input fields inside it. For each field that asks the applicant
something, return the question it is asking, phrased as a plain question.

Rules:
- Use ONLY the visible text provided. Never invent a question.
- Match each question to its field by "index".
- Omit a field that is not a real question (layout helper, hidden field,
  search box, honeypot, a plain "First name"-style profile field).
- A field with "options" is a multiple-choice question — still return only
  its question text, not the options.
- Output the question text only — no numbering, no "Question:" prefix.
- Questions may be in any language; keep the form's own language.`;async function Ra(e,t){if(t.length===0)return{};const n=JSON.stringify({blockText:e.slice(0,6e3),fields:t},null,2),a=await b({schemaName:"block_questions",schema:Aa,systemPrompt:_a,userPrompt:n,parse:i=>JSON.parse(i)}),s={};for(const i of a.questions)i.question.trim()&&(s[i.index]=i.question.trim());return s}const Oa={type:"object",additionalProperties:!1,required:["checkboxDecisions","questionAnswers"],properties:{checkboxDecisions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","check","category","reason"],properties:{index:{type:"integer"},check:{type:"boolean"},category:{type:"string",enum:["required-consent","marketing","optional","unclear"]},reason:{type:"string"}}}},questionAnswers:{type:"array",items:{type:"object",additionalProperties:!1,required:["id","answer","sufficientInfo"],properties:{id:{type:"string"},answer:{type:"string"},sufficientInfo:{type:"boolean"}}}}}},xa=`You fill in two independent things found on a job-application form at once:
consent checkboxes to decide, and custom questions to answer on the applicant's behalf. The
applicant has already chosen to submit this application.

CHECKBOXES (one decision per item in "checkboxes", matched back by "index")

TICK (check: true) — things required to submit, or that a candidate is normally expected to
accept:
- privacy policy / data protection / GDPR / Datenschutz consent
- terms & conditions / AGB / Nutzungsbedingungen
- confirming the entered information is accurate / truthful
- consent to process and store the application data for THIS hiring process
- storing the data in a talent pool ONLY when the checkbox is marked required
- eligibility self-declarations that hold for any ordinary adult applying for a real job (e.g.
  "I am at least 18 years old", "I am legally entitled to work in [country]", "I have no
  undisclosed conflicts of interest") — assume true unless the profile/CV explicitly states
  otherwise; a genuine job applicant submitting this form is virtually always eligible, and
  leaving a required declaration like this unticked blocks submission for no real reason

DO NOT TICK (check: false) — optional and promotional:
- newsletters, marketing e-mails, "career news", event invitations
- job alerts / notifications about new postings (e.g. "Benachrichtigungen über neue
  Stellenausschreibungen erhalten")
- sharing data with third parties / partner companies for marketing
- joining a talent pool / candidate database when NOT required
- anything that benefits the applicant only beyond this one application

Rules:
- "required: true" means the form marks the field mandatory — a strong signal to tick, unless
  the text is clearly marketing.
- A newsletter/marketing-email/job-alert opt-in is NEVER ticked, even when the form marks it
  "required" — that flag is routinely misused by forms to guilt-trip applicants into
  subscribing, even though applicants never actually need it to submit. When genuinely in doubt
  whether a required checkbox is a real submission requirement or a disguised newsletter
  opt-in, prefer NOT ticking it.
- If a checkbox is ambiguous AND not required, set check: false.
- Labels may be in any language; judge by meaning, not keywords.
- category: "required-consent" (ticked, mandatory-type), "marketing" (left off), "optional"
  (non-marketing but skippable, left off unless required), "unclear" (left off). reason: one
  short phrase.
- Return one decision per input item in "checkboxes", using its "index". If "checkboxes" is
  empty, return an empty array.

QUESTIONS (one answer per item in "questions", matched back by "id")

Ground rules:
- Use ONLY facts present in the shared "profile"/"cvText"/"personalLegend"/"generationRules"/
  "coverLetter"/"languageLevels"/"customFields"/"faq" given below, plus "job". Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, "languageLevels" is the
  authoritative answer (CEFR levels the applicant self-reported in Settings) — use it directly
  rather than guessing from the CV or defaulting to a low/neutral level.
- If the shared material genuinely lacks what's needed to answer a given question — not just a
  minor detail, but the actual substance being asked for — set that item's "sufficientInfo" to
  false and "answer" to an empty string. Do NOT write a sentence explaining that you don't have
  the information — that text would otherwise get typed straight into the applicant's form
  field, which is worse than leaving it blank. Only do this when the information is truly
  absent; a question you can answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient.
- If "postingLanguage" is given, write answers in that language, using the salutation/register
  conventions native speakers of it would expect on a job application (e.g. formal
  "Sie"/"Herr"/"Frau" address in German) — unless the question itself, or "generationRules",
  explicitly asks for a different language.
- A newsletter/marketing-email/job-alert subscription opt-in phrased as a question (e.g. "Would
  you like to subscribe to our newsletter? Yes/No") always gets the option that declines it.
- "faq" is a set of pre-written answers to standard interview-FAQ questions. If a question being
  asked now is the same as, or a close variant of, one already in "faq", reuse its substance and
  phrasing — adapt only what the target field's length/format actually requires.
- Match each question's expected length: a short field gets a short answer, an open-ended
  "tell us about..." field gets a fuller one.
- Output plain text per answer, no markdown, no restating the question.
- Each item in "questions" may also carry:
  - "options" (and not "multi"): a single-choice question — reply with EXACTLY ONE option,
    copied verbatim, nothing else. If the needed fact is genuinely absent (e.g. pronouns not
    stated anywhere), prefer a neutral option or an explicit "prefer not to say".
  - "options" with "multi": true: a select-all-that-apply question — reply with every option
    that genuinely applies, each copied verbatim, joined by " | " (one pipe, one space each
    side). If none apply, reply with an empty string. Never include an option just because it's
    plausible — only ones the applicant's own material actually supports.
  - "numeric": true: the field only accepts a plain number — reply with digits only (a single
    "." for a decimal if needed), no currency symbol, no thousands separator, no unit, no words,
    no range. If a range genuinely fits best (e.g. "65-75k"), reply with one representative
    figure (its midpoint).
  - "dateFormat": the field only accepts a date in exactly that format — reply with ONLY that
    value, nothing else. "todayISO" below is today's date: compute the answer from it — e.g.
    "available with one month's notice" -> todayISO plus one month; "immediately"/"as soon as
    possible"/no stated constraint -> todayISO itself.
- Return one answer per input item in "questions", using its "id". If "questions" is empty,
  return an empty array.

${I}`;function Pa(e,t){const n=new Map;for(const a of t)n.set(a.index,a);return e.map((a,s)=>{const i=n.get(s);if(i){const r=i.check&&Z(a.label)?!1:i.check;return{name:a.name,label:a.label,check:r,category:i.category,reason:i.reason}}return Z(a.label)?{name:a.name,label:a.label,check:!1,category:"marketing",reason:"No decision returned — looks like a newsletter/marketing opt-in"}:{name:a.name,label:a.label,check:a.required,category:a.required?"required-consent":"unclear",reason:a.required?"Marked required by the form":"No decision returned"}})}function Ca(e,t){const n=new Map;for(const a of t)n.set(a.id,a);return e.map(a=>{const s=n.get(a.id);if(!s)return{id:a.id,answer:"",sufficientInfo:!0};if(!s.sufficientInfo||De(s.answer))return{id:a.id,answer:"",sufficientInfo:s.sufficientInfo};const i=a.options&&a.options.length>0||a.numeric||!!a.dateKind;return{id:a.id,answer:i?s.answer:k(s.answer),sufficientInfo:!0}})}async function oe(e,t,n,a){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[s,i]=await Promise.all([E(),_("lastCoverLetter")]),r=JSON.stringify({job:n,profile:s.profile,cvText:s.cvText,personalLegend:s.personalLegend,generationRules:s.generationRules,coverLetter:i??"",languageLevels:s.languageLevels,customFields:s.customFields,faq:s.faq.filter(c=>c.answer.trim()),todayISO:q(),postingLanguage:a||void 0,checkboxes:e.map((c,d)=>({index:d,label:c.label,required:c.required,currentlyChecked:c.checked})),questions:t.map(c=>({id:c.id,question:c.question,options:c.options&&c.options.length>0?c.options:void 0,multi:c.multi,numeric:c.numeric,dateFormat:c.dateKind?Le[c.dateKind]:void 0}))},null,2),o=await b({schemaName:"page_content_decisions",schema:Oa,systemPrompt:xa,userPrompt:r,parse:c=>JSON.parse(c)});return{checkboxDecisions:Pa(e,o.checkboxDecisions),questionAnswers:Ca(t,o.questionAnswers)}}async function Na(e,t,n,a){const s=t.filter(l=>l.catchAll),i=s.length>0?t.filter(l=>!l.catchAll):t,r=await Ma(e,i,n,a);if(s.length===0)return r;const o=i.flatMap(l=>{var m;const h=((m=r.questionAnswers.find(f=>f.id===l.id))==null?void 0:m.answer)??"";return h?[{question:l.question,answer:h}]:[]}),c=await Promise.all(s.map(async l=>{const{answer:h,sufficientInfo:m}=await Fe(l.question,n,{required:l.required??!1,formValues:l.formValues,otherAnswers:o,coverLetterAttached:l.coverLetterAttached},a);return{id:l.id,answer:h,sufficientInfo:m}})),d=new Map([...r.questionAnswers,...c].map(l=>[l.id,l]));return{checkboxDecisions:r.checkboxDecisions,questionAnswers:t.map(l=>d.get(l.id)??{id:l.id,answer:"",sufficientInfo:!0})}}async function Ma(e,t,n,a){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[s,i]=await Promise.all([E(),_("lastCoverLetter")]),{input:r,promptCacheKey:o}=ve(s,i??"",n,a),c=t.map((u,p)=>({q:u,i:p})),d=c.filter(({q:u})=>Y(u)),l=c.filter(({q:u})=>!Y(u));let h;try{h=await G({input:r,promptCacheKey:o,questions:[...ot(e),...d.flatMap(({q:u,i:p})=>Ee(u,p)),...l.map(({q:u,i:p})=>Se(u,p))]})}catch(u){if(u instanceof V)throw u;return console.warn("[Filler] Decisions API failed, falling back to Responses:",u),oe(e,t,n,a)}const m=e.map((u,p)=>ct(u,p,h)),f=e.filter((u,p)=>!m[p]),w=new Map,g=[];for(const{q:u,i:p}of d){const y=ke(u,p,h);y?w.set(u.id,{id:u.id,...y}):g.push(u)}for(const{q:u,i:p}of l)Te(p,h)===!1?w.set(u.id,{id:u.id,answer:"",sufficientInfo:!1}):g.push(u);if(f.length>0||g.length>0){const u=await oe(f,g,n,a);for(const y of u.questionAnswers)w.set(y.id,y);const p=new Map(u.checkboxDecisions.map(y=>[y.name+"\0"+y.label,y]));e.forEach((y,v)=>{m[v]||(m[v]=p.get(y.name+"\0"+y.label)??null)})}return{checkboxDecisions:m.filter(u=>u!==null),questionAnswers:t.map(u=>w.get(u.id)??{id:u.id,answer:"",sufficientInfo:!0})}}const qa={type:"object",additionalProperties:!1,required:["postingLanguages","requirements","keywords","contact"],properties:{postingLanguages:{type:"array",items:{type:"string"}},requirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...be,null]}}}},keywords:je,contact:{type:["string","null"]}}},ja=`You read a job posting and report three independent things about it: its
language, the skills it asks for (keywords), and (only if asked below) a recruiter/hiring
contact. Judge language and keywords against the applicant profile/CV/Personal Legend given
below.

LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- requirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or
  "Native" for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent",
  "professional working proficiency" -> "C1"; "conversational" -> "B1". If a language is
  mentioned but no level can be reasonably inferred, set level to null. Do not invent a
  requirement that isn't stated in the text. If nothing is stated, return an empty array.

${z("the posting text (job title, description, requirements, responsibilities)")}

CONTACT
- "job.contact" below is the recruiter/hiring contact already found elsewhere, or null if none
  was found yet.
- If it is already set (not null), ignore this entirely and return "contact": null — there is
  nothing to add.
- If it is null, look for one in the job's own text (description/requirements/responsibilities):
  a named recruiter/hiring manager's email address, or a LinkedIn profile/company URL. If you
  find one, copy it VERBATIM (exact characters) so it can be re-found on the page for
  highlighting — the same rule as for keywords. If none is mentioned, return "contact": null.`;async function $a(e){const t=await E(),n=JSON.stringify({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,job:e},null,2),a=await b({schemaName:"job_brief",schema:qa,model:await me(),systemPrompt:ja,userPrompt:n,parse:s=>JSON.parse(s)});return{language:{postingLanguages:a.postingLanguages,requirements:a.requirements},keywords:W(a.keywords,e),contact:a.contact}}const Ua={type:"object",additionalProperties:!1,required:["cvId","reason"],properties:{cvId:{type:"string"},reason:{type:"string"}}},Fa=`You pick which of an applicant's CVs to send to one job posting.
Each CV has an id, a name, the language it's written in, the applicant's own rules for which
postings it's for, and the start of its text.
- Prefer a CV written in the posting's language; if none, an English one.
- Then follow the applicant's rules: the CV whose rules fit this posting best.
- Then the one marked default for that language.
Return the chosen CV's exact "id" and a reason of at most 10 words. Plain text, no em dashes.`;async function Da(e,t,n){if(t.length<2)return null;const a=t.map((s,i)=>`cv${i+1}`);try{const s=await G({input:[{role:"user",content:[{type:"input_text",text:"A job posting the applicant is applying to:"},{type:"input_json",data:{position:e.position,company:e.company,location:e.location,language:n??null,techStack:e.techStack,description:e.description.slice(0,4e3)}}]}],questions:[{type:"choice",name:"cv",instructions:"Which of the applicant's CVs should be sent to this posting? Prefer a CV written in the posting's language (else an English one), then the one whose rules fit the posting best, then the one marked default for that language.",choices:t.map((o,c)=>({value:a[c],description:Ya(o)}))}]}),i=lt(s,"cv"),r=i?a.indexOf(i.choice):-1;return!i||r<0||i.confidence<ut.cvChoice?null:{cvId:t[r].id,reason:"",source:"ai",confidence:i.confidence}}catch(s){if(s instanceof V)throw s;return console.warn("[Filler] Decisions API failed, choosing the CV via Responses:",s),Ja(e,t,n)}}function Ya(e){var t;return[`Name: ${Ie(e)}.`,`Language: ${e.language?Ae(e.language):"not set"}${e.isDefaultForLanguage?" (default CV for that language)":""}.`,(t=e.rules)!=null&&t.trim()?`Applicant's rules for it: ${e.rules.trim()}`:"",`Starts: ${e.text.slice(0,600).replace(/\s+/g," ")}`].filter(Boolean).join(" ")}async function Ja(e,t,n){if(t.length<2)return null;const a={posting:{position:e.position,company:e.company,location:e.location,language:n??null,techStack:e.techStack,description:e.description.slice(0,4e3)},cvs:t.map(i=>({id:i.id,name:Ie(i),language:i.language?Ae(i.language):null,defaultForLanguage:!!i.isDefaultForLanguage,rules:i.rules??"",textStart:i.text.slice(0,1200)}))},s=await b({schemaName:"cv_choice",schema:Ua,model:await _e(),reasoningEffort:"low",systemPrompt:Fa,userPrompt:JSON.stringify(a,null,2),parse:i=>JSON.parse(i)});return t.some(i=>i.id===s.cvId)?{cvId:s.cvId,reason:s.reason.replace(/—/g,",").trim()||"AI pick",source:"ai"}:null}const Ba={type:"object",additionalProperties:!1,required:["values"],properties:{values:{type:"array",items:{type:"object",additionalProperties:!1,required:["name","value","reason"],properties:{name:{type:"string"},value:{type:"string"},reason:{type:"string"}}}}}},Ha=`You adapt an applicant's CV template to one specific job posting by
choosing a value for each {{placeholder}} in it.

Each variable comes with:
- "description": the applicant's own instruction for what the placeholder means and
  how to choose it. Follow it.
- "mode": "choice" means "value" MUST be exactly one of "options", copied verbatim
  (same spelling, same case, same line breaks). "free" means "options" are only
  examples of the expected shape and length; write the value that fits this posting
  in that same shape (e.g. a city name, a comma-separated list).
- "foundInPosting": options that literally occur in the posting text, most frequent
  first. A strong hint, not an order: the role's actual focus matters more than a
  passing mention.

Rules:
- Pick what makes this CV the closest honest match for this posting: its title, its
  location, its main technology, the vocabulary it uses.
- A job title / position value is the bare role name: no bracketed asides like (m/w/d),
  (f/m/d) or (Remote), no seniority level (Senior, Middle, Junior, Sr., Staff, Principal),
  no team, location or contract qualifiers. "Senior Backend Engineer (m/f/d)" -> "Backend Engineer".
- Honesty: never make the CV claim a skill, technology or experience the applicant's
  CV text / Personal Legend doesn't support, unless the variable's description
  explicitly asks for it. For list-like values, prefer terms that are both in the
  posting and supported by the applicant's background.
- Write the value in the same language as the surrounding template text.
- Return one entry per variable given, using its exact "name".
- "reason": one short sentence (max ~15 words) on why this value fits the posting.
- Plain text only, no markdown, no em dashes.`;function Ga(e,t){const n=s=>s.trim().replace(/\s+/g," ").toLowerCase(),a=n(e);return t.options.find(s=>n(s)===a)??null}async function Va(e,t){const n=new Set(pt(t.content)),a=t.variables.filter(o=>n.has(o.name));if(a.length===0)return[];const s=await E(),i={variables:a.map(o=>({name:o.name,mode:o.mode,description:o.description,options:o.options,foundInPosting:dt(o.options,e)})),template:t.content.slice(0,12e3),job:{position:e.position,company:e.company,location:e.location,techStack:e.techStack,requirements:e.requirements,responsibilities:e.responsibilities,description:e.description.slice(0,8e3)},applicant:{cvText:s.cvText.slice(0,12e3),personalLegend:s.personalLegend.slice(0,8e3),city:s.profile.city,country:s.profile.country}},r=await b({schemaName:"cv_template_values",schema:Ba,model:await _e(),systemPrompt:Ha,userPrompt:JSON.stringify(i,null,2),parse:o=>JSON.parse(o)});return a.map(o=>{const c=r.values.find(l=>l.name===o.name);if(!c)return{name:o.name,value:ee(o,e),reason:""};if(o.mode==="choice"&&o.options.length>0){const l=Ga(c.value,o);return l?{name:o.name,value:l,reason:k(c.reason)}:{name:o.name,value:ee(o,e),reason:""}}const d=k(c.value);return{name:o.name,value:ht(o.name)?Gn(d,e):d,reason:k(c.reason)}})}async function Ye(e){const t=await S(e);await Promise.all(t.map(n=>chrome.tabs.sendMessage(e,{type:"CANCEL_ELEMENT_PICKER",tabId:e},{frameId:n}).catch(()=>{})))}async function T(e,t,n){return(await Promise.all(t.map(s=>chrome.tabs.sendMessage(e,n,{frameId:s}).catch(()=>{})))).filter(s=>!!s)}async function ce(e,t,n,a){if(n!==void 0&&t.includes(n)){const s=await chrome.tabs.sendMessage(e,a,{frameId:n}).catch(()=>{});if(s)return[s]}return T(e,t,a)}function Ka(e){const t=new Map;for(const n of e){const a=n.locator.frameId;t.set(a,[...t.get(a)??[],n])}return t}async function za(e){switch(e.type){case"FILL_STATS_REPORT":{await yt(e.run);return}case"GET_PROFILE":return{type:"PROFILE_DATA",profile:await M()};case"GET_JOB":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});if(!e.force&&(t!=null&&t.url)){const c=await ft(t.url);if(c!=null&&c.position&&c.company)return{type:"JOB_DATA",job:c,sufficient:!0}}const n=await S(e.tabId),s=(await T(e.tabId,n,e)).filter(c=>c.type==="JOB_DATA");if(s.length===0)return;const i=s.find(c=>c.sufficient);if(i)return t!=null&&t.url&&mt(t.url,i.job),i;const r=s.reduce((c,d)=>d.job.description.length>c.job.description.length?d:c),o=s.map(c=>c.visibleText??"").filter(Boolean).join(`

`).slice(0,2e4);return{type:"JOB_DATA",job:r.job,sufficient:!1,visibleText:o||r.visibleText||"",pageUrl:t==null?void 0:t.url}}case"COMPLETE_JOB":{const{job:t,brief:n}=await Xn(e.job,e.text);return{type:"JOB_DATA",job:t,sufficient:!0,brief:n}}case"EXTRACT_JOB_FROM_TEXT":{const t=await chrome.tabs.get(e.tabId).catch(()=>{}),{job:n,brief:a}=await zn(e.text,(t==null?void 0:t.url)??"");return{type:"JOB_DATA",job:n,sufficient:!0,brief:a}}case"AUTOFILL":{const t=await S(e.tabId),a=(await T(e.tabId,t,e)).filter(s=>s.type==="AUTOFILL_RESULT");return{type:"AUTOFILL_RESULT",filled:a.reduce((s,i)=>s+i.filled,0),total:a.reduce((s,i)=>s+i.total,0),generatedPassword:a.map(s=>s.generatedPassword).find(Boolean)??null}}case"GENERATE_COVER_LETTER":{const{tabId:t}=e,n=e.job.url;let a="",s=0;await C(t,{jobUrl:n,status:"generating",content:""});let i;try{i=await Mn(e.job,e.postingLanguage,r=>{chrome.runtime.sendMessage({type:"COVER_LETTER_STREAM_CHUNK",tabId:t,delta:r}).catch(()=>{}),a+=r,Date.now()-s>400&&(s=Date.now(),C(t,{jobUrl:n,status:"generating",content:a}).catch(()=>{}))})}catch(r){const o=r instanceof Error?r.message:String(r);throw await C(t,{jobUrl:n,status:"error",content:"",error:o}).catch(()=>{}),r}return await C(t,{jobUrl:n,status:"done",content:i.content,cleanedPatterns:i.cleaned?Array.from(new Set(i.slopFindings.map(r=>r.pattern))):[]}),await D("lastCoverLetter",i.content),{type:"COVER_LETTER_RESULT",content:i.content,slopFindings:i.slopFindings,cleaned:i.cleaned}}case"UPLOAD_FILE":{const t=await S(e.tabId),a=(e.targetLocator?await ce(e.tabId,t,e.targetLocator.frameId,e):await T(e.tabId,t,e)).filter(s=>s.type==="UPLOAD_FILE_RESULT");return{type:"UPLOAD_FILE_RESULT",nativeInputs:a.reduce((s,i)=>s+i.nativeInputs,0),dropZones:a.reduce((s,i)=>s+i.dropZones,0)}}case"REVISE_COVER_LETTER":{const t=await ea(e.content,e.instructions,e.job);return await D("lastCoverLetter",t),{type:"REVISE_COVER_LETTER_RESULT",content:t}}case"TRANSLATE_COVER_LETTER":return{type:"TRANSLATE_COVER_LETTER_RESULT",content:await sa(e.content,e.targetLanguage)};case"GENERATE_OUTREACH_MESSAGE":{const t=await E(),n=await jn({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,outreachRules:t.outreachRules,job:e.job,contact:e.contact,postingLanguage:e.postingLanguage});return{type:"OUTREACH_MESSAGE_RESULT",subject:n.subject,body:n.body}}case"REVISE_OUTREACH_MESSAGE":{const t=await na({subject:e.subject,body:e.body},e.instructions,e.job);return{type:"OUTREACH_MESSAGE_RESULT",subject:t.subject,body:t.body}}case"GET_FRAME_ACCESS":return{type:"FRAME_ACCESS",blockedOrigins:await kt(e.tabId)};case"DETECT_CUSTOM_QUESTIONS":{const t=await S(e.tabId),n=await T(e.tabId,t,e),a=new Set,s=[];for(const i of n)if(i.type==="CUSTOM_QUESTIONS_DATA")for(const r of i.questions)a.has(r.question)||(a.add(r.question),s.push({...r,id:`question-${s.length}`}));return{type:"CUSTOM_QUESTIONS_DATA",questions:s}}case"ANSWER_CUSTOM_QUESTION":{const t=await La(e.question,e.job,e.options,e.numeric,e.dateKind,e.multi,e.postingLanguage,e.catchAll);return{type:"CUSTOM_QUESTION_ANSWER",question:e.question,answer:t.answer,sufficientInfo:t.sufficientInfo}}case"FILL_CUSTOM_QUESTION_ANSWERS":{const t=await S(e.tabId),n=await T(e.tabId,t,e);let a=0;const s=[];for(const i of n)i.type==="CUSTOM_QUESTION_FILL_RESULT"&&(a+=i.filled,s.push(...i.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:a,unfilled:s}}case"START_ELEMENT_PICKER":{const t=await S(e.tabId),n=t.map(s=>chrome.tabs.sendMessage(e.tabId,e,{frameId:s}).then(i=>i?{result:i,frameId:s}:void 0).catch(()=>{})),a=await new Promise(s=>{let i=n.length;i===0&&s(void 0);for(const r of n)r.then(o=>{i-=1,o?s(o):i===0&&s(void 0)})});return await Promise.all(t.map(s=>chrome.tabs.sendMessage(e.tabId,{type:"CANCEL_ELEMENT_PICKER",tabId:e.tabId},{frameId:s}).catch(()=>{}))),a?{...a.result,picked:a.result.picked.map(s=>({...s,locator:{...s.locator,frameId:a.frameId}}))}:{type:"ELEMENT_PICKER_RESULT",cancelled:!0,picked:[],blockText:"",semanticCount:0}}case"CANCEL_ELEMENT_PICKER":{await Ye(e.tabId);return}case"DECOMPOSE_BLOCK":return{type:"BLOCK_QUESTIONS",questions:await Ra(e.blockText,e.fields)};case"FILL_QUESTION_ANSWERS_BY_LOCATOR":{const t=await S(e.tabId),n=(await Promise.all([...Ka(e.items)].map(([i,r])=>ce(e.tabId,t,i,{...e,items:r})))).flat();let a=0;const s=[];for(const i of n)i.type==="CUSTOM_QUESTION_FILL_RESULT"&&(a+=i.filled,s.push(...i.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:a,unfilled:s}}case"DETECT_CHECKBOXES":{const t=await S(e.tabId),n=await T(e.tabId,t,e),a=new Set,s=[];for(const i of n)if(i.type==="CHECKBOXES_DATA")for(const r of i.checkboxes){const o=r.name||r.label;!o||a.has(o)||(a.add(o),s.push({...r,id:`checkbox-${s.length}`}))}return{type:"CHECKBOXES_DATA",checkboxes:s}}case"DECIDE_PAGE_CONTENT":{const{checkboxDecisions:t,questionAnswers:n}=await Na(e.checkboxes,e.questions,e.job,e.postingLanguage);return{type:"PAGE_CONTENT_DECISIONS",checkboxDecisions:t,questionAnswers:n}}case"APPLY_CHECKBOX_DECISIONS":{const t=await S(e.tabId),n=await T(e.tabId,t,e);let a=0;for(const s of n)s.type==="CHECKBOX_APPLY_RESULT"&&(a+=s.changed);return{type:"CHECKBOX_APPLY_RESULT",changed:a}}case"DETECT_JOB_BRIEF":{const t=await $a(e.job);return{type:"JOB_BRIEF_DATA",language:t.language,keywords:t.keywords,contact:t.contact}}case"HIGHLIGHT_KEYWORDS":{const t=await S(e.tabId);return{type:"KEYWORD_HIGHLIGHT_RESULT",matched:(await T(e.tabId,t,e)).reduce((s,i)=>i.type==="KEYWORD_HIGHLIGHT_RESULT"?s+i.matched:s,0)}}case"CLEAR_KEYWORD_HIGHLIGHTS":{const t=await S(e.tabId);await T(e.tabId,t,e);return}case"GENERATE_FAQ_ANSWERS":{const t=await de(),n=await Mt(e.questions,t);try{await gt(n)}catch{}return{type:"FAQ_ANSWERS_RESULT",entries:n}}case"SEARCH_JOBS":{const{searchId:t}=e,n=t?s=>{chrome.runtime.sendMessage({type:"JOB_SEARCH_PROGRESS",searchId:t,results:s}).catch(()=>{})}:void 0,a=setInterval(()=>void chrome.runtime.getPlatformInfo().catch(()=>{}),2e4);try{return{type:"JOB_SEARCH_RESULTS",...await mn(e.query,{page:e.page,excludeResults:e.excludeResults,onResults:n})}}finally{clearInterval(a)}}case"SUGGEST_SEARCH_QUERY":{const{what:t,where:n,tags:a}=await Ce(e.provider==="adzuna");return{type:"SEARCH_QUERY_SUGGESTION",what:t,where:n,...e.provider==="adzuna"?{tags:a}:{}}}case"SUGGEST_CV_VALUES":return{type:"CV_VALUES",values:await Va(e.job,e.template)};case"CHOOSE_CV":return{type:"CV_CHOICE",choice:await Da(e.job,e.cvs,e.postingLanguage)};default:return}}const Wa="src/sidepanel/index.html";chrome.runtime.onInstalled.addListener(()=>{At(),chrome.sidePanel.setOptions({enabled:!1})});chrome.contextMenus.onClicked.addListener((e,t)=>{Rt(e,t)});chrome.action.onClicked.addListener(e=>{if(e.id===void 0)return;const t=e.id;chrome.sidePanel.setOptions({tabId:t,path:`${Wa}?tabId=${t}`,enabled:!0}),chrome.sidePanel.open({tabId:t}).catch(n=>console.error("sidePanel.open failed",n)),Qa(t)});async function Qa(e){await S(e);const t={type:"TAB_ACCESS_GRANTED",tabId:e};await chrome.runtime.sendMessage(t).catch(()=>{})}chrome.tabs.onRemoved.addListener(e=>{wt(e)});chrome.runtime.onMessage.addListener((e,t,n)=>(za(e).then(n).catch(a=>{n({type:"ERROR",error:a instanceof Error?a.message:String(a),code:a instanceof Error?a.name:void 0})}),!0));chrome.runtime.onConnect.addListener(e=>{const t=/^picker-(\d+)$/.exec(e.name);if(!t)return;const n=Number(t[1]);e.onDisconnect.addListener(()=>{Ye(n)})});
