import{P as dt,g as _e,a as P,b as ht,c as ft,s as gt,d as z,e as Re,f as mt,h as yt,i as wt,j as bt,k as Oe,r as E,J as oe,n as Ce,t as K,l as W,M as Pe,m as vt,A as Q,o as Et,p as St,q as kt,u as ee,v as de,w as xe,x as Tt,y as he,z as Ne,C as Lt,B as Me,D as At,E as It,F as _t,G as $e,H as Rt,I as ce,K as U,L as M,N as Ot,O as D,Q as te,R as je,S as Ue,T as qe,U as De,V as Fe,W as Ct,X as Pt,Y as fe,Z as G,_ as Ye,$ as Ve,a0 as He,a1 as xt,a2 as Nt,a3 as Be,a4 as Mt,a5 as $t,a6 as jt,a7 as Y,a8 as Ut,a9 as qt,aa as Dt,ab as Ft}from"./template-CqiGRpL-.js";import{c as Yt,a as Vt}from"./phone-D3SACKoL.js";const Ge={...dt,cv:"CV",coverLetter:"Cover Letter",generatePassword:"Generated password"},Ht=Object.keys(Ge);async function k(e){try{const a=(await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:["content-script.js"]})).map(n=>n.frameId).filter(n=>typeof n=="number");if(a.length>0)return a}catch{}try{return await chrome.scripting.executeScript({target:{tabId:e},files:["content-script.js"]}),[0]}catch{return[0]}}function Bt(){const e=[];for(const t of Array.from(document.querySelectorAll("iframe, frame"))){const a=t.getBoundingClientRect(),n=a.width*a.height;t.src&&a.width>=200&&a.height>=150&&e.push({src:t.src,area:n})}return{origin:location.origin,children:e}}async function Gt(e){let t;try{t=await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},func:Bt})}catch{return[]}const a=new Set,n=new Map;for(const{result:s}of t)if(s){a.add(s.origin);for(const r of s.children){let o;try{const c=new URL(r.src);if(c.protocol!=="https:"&&c.protocol!=="http:")continue;o=c.origin}catch{continue}n.set(o,Math.max(n.get(o)??0,r.area))}}const i=[];for(const s of[...n.keys()].sort((r,o)=>n.get(o)-n.get(r))){if(a.has(s))continue;if(await chrome.permissions.contains({origins:[`${s}/*`]}).catch(()=>!1)||i.push(s),i.length===3)break}return i}async function Jt(e,t){if(e==="cv"){const i=await _e();return(i==null?void 0:i.text)??""}if(e==="coverLetter")return await P("lastCoverLetter")??"";if(e==="generatePassword"){const i=await ht(t);if(i!=null&&i.generatedPassword)return i.generatedPassword;const s=ft();return i&&await gt(t,{...i,generatedPassword:s}),s}const a=await z(),n=a[e]??"";return e==="phone"&&n?Yt(n,a.country):n}const j="job-app-assistant-insert",zt={generatePassword:"Generate password"},Kt=Ht.map(e=>({id:e,title:zt[e]??Ge[e]}));function Wt(){chrome.contextMenus.removeAll(()=>{chrome.contextMenus.create({id:j,title:"Insert",contexts:["editable"]});for(const e of Kt)chrome.contextMenus.create({id:`${j}:${e.id}`,parentId:j,title:e.title,contexts:["editable"]})})}function Qt(e){return e.startsWith(`${j}:`)?e.slice(j.length+1):null}async function Xt(e,t){if(!(t!=null&&t.id)||typeof e.menuItemId!="string")return;const a=Qt(e.menuItemId);if(!a)return;const n=await Jt(a,t.id);await k(t.id);const i={type:"INSERT_VALUE",field:a,value:n};chrome.tabs.sendMessage(t.id,i,{frameId:e.frameId}).catch(()=>{})}const Zt=new Set(["profileCache","cvLibraryCache","legendLibraryCache","customFieldsCache","languageLevelsCache","faqAnswersCache","generationRulesCache","outreachRulesCache"]);let N=null;function en(){return Promise.all([z(),_e(),Re(),mt(),yt(),wt(),bt(),Oe()]).then(([e,t,a,n,i,s,r,o])=>({profile:e,cvText:(t==null?void 0:t.text)??"",personalLegend:(a==null?void 0:a.content)??"",generationRules:(n==null?void 0:n.content)??"",outreachRules:(i==null?void 0:i.content)??"",languageLevels:s,customFields:r,faq:o}))}function S(){return N||(N=en(),N.catch(()=>{N=null})),N}var Ie;typeof chrome<"u"&&((Ie=chrome.storage)!=null&&Ie.onChanged)&&chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&Object.keys(e).some(a=>Zt.has(a))&&(N=null)});const R=`Write like a specific person, not an AI assistant. These rules have no exceptions:

- NEVER use an em dash ("—"), a spaced en dash ("–") or "--" as punctuation. Real people don't write that way. Use a comma, a period, parentheses, or two sentences.
- Banned words: delve, foster, leverage, utilize, facilitate, empower, streamline, robust, cutting-edge, paradigm shift, game changer, tapestry, realm, beacon, multifaceted, meticulous, intricate, paramount, transformative, elevate, embark, supercharge, harness, ever-evolving. Say the plain thing.
- Cut empty phrases: "it's worth noting", "at the end of the day", "when it comes to", "at its core", "in today's world", "the reality is", "in order to", "going forward".
- No "not X, it's Y" / "the question isn't X, it's Y" / "not just X but Y" contrasts. State Y directly.
- No throat-clearing openers ("Here's the thing", "Let me be clear", "I'll be honest") and no faux-insight setups ("what most people get wrong", "here's what nobody tells you").
- No importance puffery ("stands as a testament", "marks a pivotal moment", "plays a vital role", "underscores its significance"). State the fact and stop.
- No colon reveals: a noun phrase, a colon, then a dramatic lowercase clause.
- No trailing "-ing" clauses that editorialize ("highlighting the commitment to...", "underscoring its importance", "showcasing", "reflecting"). End the sentence.
- No metadiscourse that tells the reader what to notice ("this matters", "this distinction matters", "in other words", "as you can see").
- No "In conclusion" / "Ultimately" / "Overall" recap ending and no cute one-line kicker. Stop on the last concrete point.
- No emoji, no mid-sentence bold, no rhetorical questions.
- Vary sentence shape; don't stack short punchy fragments.
- Be concrete: name the technology, project, number, or outcome instead of calling it "significant", "impactful" or "exciting". Use active voice.`;function T(e){return e.replace(/[ \t]*[—―][ \t]*/g,", ").replace(/[ \t]+--[ \t]+/g,", ").replace(/(\D)[ \t]+–[ \t]+(?=\D)/g,"$1, ").replace(/[ \t]+([,.;:!?])/g,"$1").replace(/,(\s*[.;:!?])/g,"$1").replace(/,[ \t]*,/g,",").replace(/^[ \t]*,[ \t]*/gm,"").replace(/([([{])[ \t]*,[ \t]*/g,"$1").replace(/[ \t]*,[ \t]*([)\]}])/g,"$1").replace(/,[ \t]*$/gm,"").replace(/[ \t]+$/gm,"")}const tn=`You write the applicant's own answers to standard interview-FAQ
questions (spec_5 section B) — general-purpose answers meant to be reused, as-is or
lightly adapted, whenever a real application form asks a close variant of one of them.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend, and
  custom fields. Never invent experience, technologies, companies, education,
  achievements, or a concrete salary figure that wasn't actually given.
- If information needed for a good answer is missing (no CV, no Personal Legend
  content covering it), write a short, honest, generically true answer rather
  than fabricating specifics — the applicant can always sharpen it later.
- Keep each answer 2-5 sentences: concrete and confident, never generic
  corporate filler, no restating the question.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text per answer, no markdown, no numbering.

${R}`;function nn(e){return{type:"object",additionalProperties:!1,required:["answers"],properties:{answers:{type:"array",minItems:e,maxItems:e,items:{type:"string"}}}}}async function an(e){if(e.length===0)return[];const{profile:t,cvText:a,personalLegend:n,generationRules:i,customFields:s}=await S(),r=JSON.stringify({profile:t,cvText:a,personalLegend:n,generationRules:i,customFields:s,questions:e},null,2),o=await E({schemaName:"faq_answers",schema:nn(e.length),systemPrompt:tn,userPrompt:r,parse:c=>JSON.parse(c)});return e.map((c,u)=>({question:c,answer:T(o.answers[u]??"")}))}async function sn(e,t){const a=new Map(t.map(s=>[s.question,s.answer])),n=e.filter(s=>{var r;return!((r=a.get(s))!=null&&r.trim())}),i=await an(n);for(const s of i)a.set(s.question,s.answer);return e.map(s=>({question:s,answer:a.get(s)??""}))}async function J(e,t,a){const n=performance.now();try{return await a()}finally{e==null||e.push({label:t,ms:performance.now()-n})}}function rn(e){return e!=null&&e.length?`Seniority levels to target: ${oe.filter(a=>e.includes(a.id)).map(a=>a.label.toLowerCase()).join(", ")}. Only include postings for these levels.`:""}function on(e,t){const a=oe.filter(i=>t==null?void 0:t.includes(i.id));if(a.length===0)return e;const n=[];for(const i of e)for(const s of a)n.push(i.toLowerCase().includes(s.keyword)?i:`${s.keyword} ${i}`.trim());return[...new Set(n)]}const cn=80;function ne(e){const t=new Set,a=[];for(const n of e){const i=n.replace(/\s+/g," ").trim().slice(0,cn).trim(),s=i.toLowerCase();!i||t.has(s)||(t.add(s),a.push(i))}return a}function q(e){const t=ne(e.terms??[]);return t.length>0?t:ne([e.what??""])}function ln(e){const t=q(e);return t.length===0?"":t.length===1?`Role/keywords focus: "${t[0]}".`:`Role/keywords: any of ${t.map(a=>`"${a}"`).join(", ")}.`}function un(e){return[ln(e),e.where?`Location: "${e.where}".`:"",rn(e.grades),e.remoteOnly?"Prefer remote-friendly roles.":"",Ce(e.negative)].filter(Boolean).join(" ")}const pn={type:"object",additionalProperties:!1,required:["jobs"],properties:{jobs:{type:"array",items:{type:"object",additionalProperties:!1,required:["title","company","location","url","salary","snippet","postedAt"],properties:{title:{type:"string"},company:{type:"string"},location:{type:"string"},url:{type:"string"},salary:{type:"string"},snippet:{type:"string"},postedAt:{type:"string"}}}}}};function dn(e,t){const a=(e??"").trim().slice(0,100),n=t?" The search is for remote jobs: drop postings that are on-site or hybrid only.":"";return a?`The search is for jobs in "${a}". Drop every posting whose workplace is outside ${a} — another country, or remote only for people elsewhere ("US only", "LATAM") — and drop it too when the text names no place at all and the employer is clearly based elsewhere. Keep postings in ${a} (any city in it) and remote postings open to people living there. "location" is the posting's own place, as specific as the text gives it ("Munich, Germany", "Remote (Germany)"); never leave it empty when the text names one.${n}`:n.trim()}function hn(e,t,a){const n=Ce(t);return`You turn raw web-search results about job openings into a clean,
structured list. The input text was produced by a live internet search and may include
citations, markdown links, or unrelated surrounding prose — extract only genuine
individual job postings from it.

Rules:
- Only include entries that are clearly actual job postings with a real listing URL —
  never a company's generic careers-page homepage, a search-results page, or an
  aggregator's category page.
- "url" must be copied exactly from the source text (never invented).
- "salary" is "" when no figure was given — never guess one.
- "postedAt" is the date the posting was published, as YYYY-MM-DD, only when the text
  states it. Resolve relative dates ("posted 3 days ago", "2w") against today, ${e}.
  Use "" when no date is given — never guess one.
- Drop postings the text marks as closed, expired, filled or "no longer accepting
  applications", and postings published more than ${Pe} days before ${e}.
- "snippet" is a 1-2 sentence summary of the role; when a "candidate" background is given
  below, make it say *why this posting fits them* specifically (seniority match, matching
  skills, location/remote fit) rather than just restating the posting.
- If a "candidate" background is given, drop postings that are clearly a poor fit for them
  (an unrelated field, a seniority far off). When unsure, keep it: a later step scores the fit.
- Deduplicate: the same posting linked twice becomes one entry.${a?`
- ${a}`:""}${n?`
- ${n}`:""}
- If nothing in the text is actually a job posting, return an empty "jobs" array.`}async function Je(e,t,a,n={}){const i=a?`candidate:
${a}

---

${e.slice(0,4e4)}`:e.slice(0,4e4),s=await E({schemaName:"job_listings",schema:pn,systemPrompt:hn(K(),n.negative,dn(n.where,n.remoteOnly)),userPrompt:i,reasoningEffort:n.reasoningEffort,timeoutMs:n.timeoutMs,signal:n.signal,label:"Parsing search results",parse:r=>JSON.parse(r)});return W(s.jobs.filter(r=>r.url.trim()).map(r=>({...r,source:t})))}function fn(e){return e.length===0?"":`

Already found and shown to the applicant — do NOT return any of these again,
find genuinely different postings instead:
${e.map(a=>`- ${a.title} at ${a.company} (${a.url})`).join(`
`)}`}function C(e){return typeof e=="string"?e.trim():""}function gn(e){const t=e.trim().replace(/^(?:[-*•]|\d+[.)])\s+/u,"").replace(/,$/,"");if(!t.startsWith("{")||!t.endsWith("}"))return null;let a;try{a=JSON.parse(t)}catch{return null}const n=C(a.url),i=C(a.title);return!/^https?:\/\//i.test(n)||!i?null:{title:i,company:C(a.company),location:C(a.location),url:n,salary:C(a.salary),snippet:C(a.snippet),postedAt:C(a.postedAt)}}function mn(e){let t="";function a(n){const i=gn(n);i&&e(i)}return{push(n){t+=n;let i;for(;(i=t.indexOf(`
`))!==-1;)a(t.slice(0,i)),t=t.slice(i+1)},end(){a(t),t=""}}}const yn=6,ge=[{id:"ats",focus:`Look on applicant tracking systems: ${Q.join(", ")}.`},{id:"careers",focus:"Look on the hiring companies' own career pages (company websites, not job boards)."},{id:"boards",focus:"Look on job boards and aggregators (LinkedIn, Indeed, StepStone, Glassdoor, Welcome to the Jungle, Wellfound, Arbeitnow and similar); when the board links to the employer's own posting, give that URL."}];function wn(e,t,a=[],n){const i=un(e),s=K();return`Search the web for current, actually open job postings that fit this
candidate:

${t||"(no candidate background available)"}

${i||"No further constraints — use the candidate's own background to pick a fitting role/location."}

Today is ${s}. Only include postings published in the last ${Pe} days
that are still accepting applications — skip anything marked closed, expired or filled,
or shown with an older date. Skip postings that are a poor fit for the candidate (wrong
seniority, unrelated field).
Prefer the employer's own posting on its applicant tracking system (${Q.join(", ")})
or career page over copies on aggregators, which often outlive the real posting.
Only real individual postings with their direct listing URL — never a search results page,
a generic careers homepage or an aggregator's category page.${n?`
${n}`:""}${fn(a)}

OUTPUT FORMAT — follow exactly. Up to ${yn} of the best matches, best first, as JSON
Lines: one JSON object per line, nothing else (no prose, no markdown, no code fences, no
citations). Each object has exactly these string keys:
{"title":"","company":"","location":"","url":"","salary":"","postedAt":"","snippet":""}
- "url": the posting's direct URL as found.
- "salary": as stated, or "" — never guess.
- "postedAt": YYYY-MM-DD when the posting states a date (resolve "3 days ago" against
  ${s}), else "".
- "snippet": one sentence, at most 25 words, on why it fits this candidate.
If you find no fitting posting, output nothing.`}const Z={timeoutMs:9e4,idleMs:4e4,parseTimeoutMs:3e4};function me(e){const t=a=>a.toLowerCase().replace(/[^a-z0-9]+/g," ").trim();return e.company?`${t(e.company)}|${t(e.title)}`:e.url}async function bn(e,t,a=[],n,i,s){const r=performance.now();let o=null;const c=[],u=new Set,l=p=>u.has(p.url)||u.has(me(p))?!1:(u.add(p.url),u.add(me(p)),c.push(p),!0),h=await Promise.allSettled(ge.map(async p=>{const w=wn(e,t,a,p.focus),L=mn(A=>{const[g]=W([{...A,source:"openai"}]);!g||!l(g)||(o??(o=performance.now()),i==null||i([g]))}),O=performance.now();try{const A=await vt(w,L.push,{reasoningEffort:"low",timeoutMs:Z.timeoutMs,idleMs:Z.idleMs,signal:s});return L.end(),A}finally{n==null||n.push({label:`Web search (${p.id})`,ms:performance.now()-O})}}));n==null||n.push({label:"Web search",ms:performance.now()-r}),o!==null&&(n==null||n.push({label:"First result",ms:o-r}));const f=h.flatMap((p,w)=>p.status==="rejected"?[{id:ge[w].id,err:p.reason}]:[]),m=p=>p instanceof Error?p.message:"the search failed";if(f.length===h.length&&c.length===0)throw f[0].err;const y=f.map(p=>`Web search (${p.id}) stopped: ${m(p.err)}`);if(c.length>0)return{results:c,warnings:y};const b=h.map(p=>p.status==="fulfilled"?p.value:"").filter(p=>p.trim()).join(`

---

`);return b?{results:await J(n,"Parse results",()=>Je(b,"openai",t,{negative:e.negative,where:e.where,remoteOnly:e.remoteOnly,reasoningEffort:"low",timeoutMs:Z.parseTimeoutMs,signal:s})),warnings:y}:{results:c,warnings:y}}const vn="https://api.tavily.com/search",ye=350,En=12,Sn=4,kn=20,Tn=160,we=16,Ln=4,An=1200,In=100,_n=[...Q,"join.com"],V=[["job-boards.greenhouse.io","boards.greenhouse.io"],["jobs.lever.co"],["jobs.ashbyhq.com"],["apply.workable.com"],["join.com"],["personio.de","recruitee.com"],["jobs.smartrecruiters.com","teamtailor.com","myworkdayjobs.com"]],H=[[{variant:"jobs"},{variant:"ats"}],...Array.from({length:Math.floor(V.length/2)},(e,t)=>V.slice(t*2,t*2+2).map(a=>({variant:"ats",hosts:a}))),[...V.slice(Math.floor(V.length/2)*2).map(e=>({variant:"ats",hosts:e})),{variant:"local"}]],Rn={germany:["Berlin","Munich","Hamburg","Frankfurt","Cologne","Stuttgart","Düsseldorf","Leipzig","Karlsruhe","Dresden","Hanover","Nuremberg","Bonn","Mannheim","Essen","Dortmund"],austria:["Vienna","Graz","Linz","Salzburg"],switzerland:["Zurich","Geneva","Basel","Bern","Lausanne","Zug"],netherlands:["Amsterdam","Rotterdam","Utrecht","Eindhoven","The Hague"],"united kingdom":["London","Manchester","Edinburgh","Cambridge","Bristol","Oxford"],france:["Paris","Lyon","Toulouse","Nantes"],spain:["Madrid","Barcelona","Valencia","Málaga"],poland:["Warsaw","Kraków","Wrocław","Gdańsk"]},ae=2;function ze(e){const t=We(e);return t?Rn[t]??[]:[]}function On(e){return H.length+Math.ceil(ze(e).length/ae)}function Cn(e,t=""){const a=(Math.max(1,e)-1)%On(t);if(a<H.length)return H[a];const n=(a-H.length)*ae;return ze(t).slice(n,n+ae).map(i=>({variant:"city",place:i}))}const Pn={germany:"germany",deutschland:"germany",германия:"germany",austria:"austria",österreich:"austria",switzerland:"switzerland",schweiz:"switzerland",netherlands:"netherlands","the netherlands":"netherlands",france:"france",spain:"spain",italy:"italy",poland:"poland",portugal:"portugal",ireland:"ireland",belgium:"belgium",sweden:"sweden",denmark:"denmark",finland:"finland",norway:"norway","czech republic":"czech republic",czechia:"czech republic","united kingdom":"united kingdom",uk:"united kingdom",england:"united kingdom","united states":"united states",usa:"united states",canada:"canada",japan:"japan",singapore:"singapore","united arab emirates":"united arab emirates",uae:"united arab emirates",australia:"australia"},Ke=new RegExp("(?<!\\p{L})(?:germany|deutschland|austria|österreich|switzerland|schweiz|berlin|münchen|munich|hamburg|köln|cologne|frankfurt|stuttgart|düsseldorf|leipzig|dresden|hannover|nürnberg|wien|vienna|zürich|zurich)(?!\\p{L})|германи","iu");function We(e){const t=e.toLowerCase();for(const[a,n]of Object.entries(Pn))if(new RegExp(`(?<![\\p{L}])${a.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}(?![\\p{L}])`,"u").test(t))return n;return""}function xn(e){const t=We(e);return t||(Ke.test(e)&&!/austria|österreich|wien|vienna|switzerland|schweiz|zürich|zurich/i.test(e)?"germany":"")}function Nn(e,t,a="jobs"){const n=e.replace(/["\s]+/g," ").trim(),i=oe.filter(l=>{var h;return(h=t.grades)==null?void 0:h.includes(l.id)}).map(l=>l.label.toLowerCase()).filter(l=>!n.toLowerCase().includes(l)),s=t.where.trim().slice(0,In),o=[{jobs:"jobs",city:"",ats:"",local:Ke.test(s)?"(m/w/d)":"job opening"}[a],s,t.remoteOnly?"remote":"",...i].filter(Boolean).join(" "),c=Math.max(1,ye-o.length-3);return`${a==="ats"||a==="city"?n.slice(0,c).trim():`"${n.slice(0,c).trim()}"`} ${o}`.slice(0,ye).trim()}function Mn(e,t,a,n="jobs",i,s){const r=Et(e.negative),o=n==="ats"||n==="city",c=o?"":xn(e.where);return{api_key:a,query:Nn(t,i?{...e,where:i}:e,n),search_depth:n==="jobs"?"advanced":"basic",max_results:kn,include_answer:!1,include_published_date:!0,include_domains:o?s!=null&&s.length?s:_n:Q,...o?{}:{include_domains_mode:"prefer"},...c?{country:c}:{},...r.length>0?{exclude_domains:r}:{}}}const ie={searchTimeoutMs:25e3,parseTimeoutMs:4e4};async function $n(e,t){for(let a=1;;a++){const n=AbortSignal.timeout(ie.searchTimeoutMs);let i;try{i=await fetch(vn,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e),signal:t?AbortSignal.any([t,n]):n})}catch(r){if(n.aborted)throw new Error(`Tavily search timed out after ${ie.searchTimeoutMs/1e3} s.`);if(t!=null&&t.aborted||a>=2)throw r;continue}if(i.ok)return await i.json();const s=await i.text().catch(()=>"");if(a>=2||!(i.status===429||i.status>=500))throw new Error(`Tavily search failed (${i.status}): ${s.slice(0,300)}`);await new Promise(r=>setTimeout(r,1500))}}function jn(e){const t=e?Date.parse(e):NaN;return Number.isNaN(t)?"":new Date(t).toISOString().slice(0,10)}function Un(e){return W(e.map(t=>({title:t.title,company:"",location:"",url:t.url,salary:"",snippet:(t.content??"").slice(0,240),postedAt:jn(t.published_date),source:"tavily"})))}async function be(e,t,a){const n=new Array(e.length);let i=0;const s=async()=>{for(;i<e.length;){const r=i++;n[r]=await a(e[r])}};return await Promise.all(Array.from({length:Math.min(t,e.length)},s)),n}function B(e){return e.trim().replace(/#.*$/,"").replace(/\/+$/,"").toLowerCase()}function qn(e,t=[],a=Tn){const n=new Set(t.map(r=>B(r.url))),i=[],s=Math.max(0,...e.map(r=>r.length));for(let r=0;r<s&&i.length<a;r++)for(const o of e){const c=o[r];if(!(!(c!=null&&c.url)||n.has(B(c.url)))&&(n.add(B(c.url)),i.push(c),i.length>=a))break}return i}async function Dn(e,t,a,n=[],i,s,r=1){const o=q(e);if(o.length===0)throw new Error("Tavily needs at least one search term.");const c=o.slice(0,En),u=[];o.length>c.length&&u.push(`Only the first ${c.length} of ${o.length} search terms were searched with Tavily.`);const l=Cn(r,e.where),h=c.flatMap(g=>l.map(({variant:v,place:$,hosts:X})=>({term:g,variant:v,place:$,hosts:X}))),f=await J(i,"Tavily search",()=>be(h,Sn,async({term:g,variant:v,place:$,hosts:X})=>{try{const F=await $n(Mn(e,g,t,v,$,X),s);return{term:g,variant:v,hits:F.results??[]}}catch(F){if(s!=null&&s.aborted)throw F;return{term:g,variant:v,hits:[],error:F}}})),m=f.filter(g=>g.error!==void 0);if(m.length===f.length)throw m[0].error;const y=[...new Set(m.map(g=>g.term))].filter(g=>m.filter(v=>v.term===g).length===l.length);for(const g of y){const v=m.find($=>$.term===g);u.push(`"${g}" — ${v.error instanceof Error?v.error.message:"search failed"}`)}const b=qn(f.map(g=>g.hits),n);if(b.length===0)return{results:[],warnings:u};const d=[];for(let g=0;g<b.length;g+=we)d.push(b.slice(g,g+we));const p=g=>g.map(v=>`Title: ${v.title}
URL: ${v.url}
${v.published_date?`Published: ${v.published_date}
`:""}${(v.content??"").slice(0,An)}`).join(`

---

`),w=await J(i,"Parse results",()=>be(d,Ln,async g=>{try{return{results:await Je(p(g),"tavily",a,{negative:e.negative,where:e.where,remoteOnly:e.remoteOnly,reasoningEffort:"low",timeoutMs:ie.parseTimeoutMs,signal:s})}}catch(v){if(s!=null&&s.aborted)throw v;return{results:Un(g),error:v}}})),L=new Set,O=w.flatMap(g=>g.results).filter(g=>{const v=B(g.url);return L.has(v)?!1:(L.add(v),!0)}),A=w.filter(g=>g.error!==void 0);if(A.length){const g=A[0].error instanceof Error?A[0].error.message:"parse failed";u.push(`Couldn't sort ${A.length===w.length?"Tavily's results":`${A.length} of ${w.length} batches of Tavily's results`} (${g}) — showing those unfiltered.`)}return{results:O,warnings:u}}function Fn(e,t){return!e&&!t?"":kt({low:Math.round(e??t??0),high:Math.round(t??e??0)})}function Yn(e){return new Promise(t=>setTimeout(t,e))}const Vn=350,Hn=12,ve=15e3;function Bn(e,t,a,n,i){const s=new URL(`https://api.adzuna.com/v1/api/jobs/${n}/search/${i}`);s.searchParams.set("app_id",a.appId),s.searchParams.set("app_key",a.appKey),s.searchParams.set("results_per_page","15"),s.searchParams.set("content-type","application/json"),e&&s.searchParams.set("what",e),t.where&&s.searchParams.set("where",t.where);const r=St(t.negative);return r&&s.searchParams.set("what_exclude",r),s.toString()}async function Gn(e,t,a,n,i,s){const r=AbortSignal.timeout(ve);let o;try{o=await fetch(Bn(e,t,a,n,i),{signal:s?AbortSignal.any([s,r]):r})}catch(l){throw r.aborted?new Error(`timed out after ${ve/1e3} s`):l}if(!o.ok){const l=await o.text().catch(()=>"");throw new Error(`Adzuna search failed (${o.status}): ${l.slice(0,300)}`)}const u=(await o.json()).results.map(l=>{var h,f;return{title:l.title,company:((h=l.company)==null?void 0:h.display_name)??"",location:((f=l.location)==null?void 0:f.display_name)??"",url:l.redirect_url,salary:Fn(l.salary_min,l.salary_max),snippet:(l.description??"").slice(0,300),postedAt:l.created??"",source:"adzuna",tag:e}});return W(u)}async function Jn(e,t,a,n=1,i,s){var d;const r=q(e),o=e.tags&&e.tags.length>0?e.tags:r.length>0?r:[e.what],c=Math.max(((d=e.grades)==null?void 0:d.length)??0,1),u=Math.max(1,Math.floor(Hn/c)),l=on(o.slice(0,u),e.grades),h=new Set,f=[],m=[];o.length>u&&m.push(`Only the first ${u} search terms were used with ${c} grades selected.`);let y=0,b=null;for(let p=0;p<l.length&&!(s!=null&&s.aborted);p++){const w=l[p];try{const O=(await Gn(w,e,t,a,n,s)).filter(A=>!h.has(A.url));for(const A of O)h.add(A.url);f.push(...O),O.length>0&&(i==null||i(O))}catch(L){y++,b??(b=L),m.push(`"${w}" — ${L instanceof Error?L.message:"search failed"}`)}p<l.length-1&&await Yn(Vn)}if(y===l.length&&b)throw b;return{results:f,warnings:m}}const zn=new Set(["AT","AU","BE","BR","CA","CH","DE","ES","FR","GB","IN","IT","MX","NL","NZ","PL","RU","SG","US","ZA"]);function Kn(e){var a;const t=(a=Vt(e))==null?void 0:a.toUpperCase();return t&&zn.has(t)?t.toLowerCase():"us"}const Wn={type:"object",additionalProperties:!1,required:["what","where"],properties:{what:{type:"string"},where:{type:"string"}}},Qn=`You suggest a starting job-search query for the applicant described below.
"what" is a short role/keywords phrase (e.g. "senior backend engineer", "product designer") —
their most recent or clearly strongest role from the CV/Personal Legend. Pick ONE single title:
never join multiple roles or technologies with "/", "," or parentheses (e.g. never "Full-Stack
Developer / Backend Engineer (Go, Python, React)") — that reads as a combined AND-match to a
literal keyword search and returns nothing. "where" is a location (city, region, or country) —
their stated city/country if given, else "".
Output only the two fields, no explanation.`;async function Xn(){const{profile:e,cvText:t,personalLegend:a}=await S(),n=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:a},null,2),i=await E({schemaName:"job_search_query_suggestion",schema:Wn,systemPrompt:Qn,userPrompt:n,parse:s=>JSON.parse(s),reasoningEffort:"low"});return{what:i.what,where:i.where||[e.city,e.country].filter(Boolean).join(", ")}}const Zn={type:"object",additionalProperties:!1,required:["tags"],properties:{tags:{type:"array",items:{type:"string"}}}},ea=`You generate keyword search tags for Adzuna's job-search API, grounded in
the candidate's real background below. Per Adzuna's own docs
(https://developer.adzuna.com/docs/search), "what" is a single literal keyword/phrase match, not
a semantic search and not a boolean query — so ONE combined tag naming several technologies or
role variants (e.g. "Full-Stack Developer / Backend Engineer (Go, Python, React)") matches
nothing. You compensate by generating a small cross-product of short, atomic tags instead, each
run as its own separate search and merged afterwards.

Method — build the tags as a cross-product, exactly like this worked example for a candidate
whose strongest stack is Go and who also does full-stack/backend work:
  golang developer, go developer, go engineer, golang engineer,
  backend engineer, backend developer, fullstack engineer, fullstack developer,
  software engineer, software developer
That is: {primary technology + its common short aliases} × {developer, engineer}, PLUS
{their role-shape words, e.g. backend / fullstack / frontend / mobile / data — whichever
genuinely apply, without a technology} × {developer, engineer}, PLUS a generic "software
developer" / "software engineer" fallback pair.

Rules:
- Base every tag on their actual, strongest-fitting technology/field from the CV/Personal
  Legend — never invent a technology, role-shape, or seniority they don't have.
- Identify the ONE primary technology (e.g. "Go") plus its common short aliases people actually
  search with (e.g. "Golang") — do not alias unrelated technologies together.
- Each tag pairs exactly one technology-or-role-shape word with exactly one of "developer" /
  "engineer" (add "programmer" only if that's a genuinely common term for that stack). Never put
  two technologies, or a technology and a role-shape, in the same tag.
- If the CV shows a clear secondary technology/stack, budget permitting, add its own couple of
  tags the same way — still never combined with the primary one in a single tag.
- For EACH language listed in "languages" below (skip English), also include ONE of the
  strongest-technology tags translated into that language using the natural job-title term a
  native speaker would search with (not a literal word-for-word translation).
- Each tag is 1-3 words, lowercase, and never contains "/", ",", "(", ")", or a seniority
  qualifier ("senior", "junior", etc.).
- Deduplicate. Return 6-12 tags total, most relevant first.
- Output only the tags, no explanation.`;async function ta(){const{profile:e,cvText:t,personalLegend:a,languageLevels:n}=await S(),i=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:a,languages:n.map(r=>r.language)},null,2);return(await E({schemaName:"job_search_tags",schema:Zn,systemPrompt:ea,userPrompt:i,parse:r=>JSON.parse(r),reasoningEffort:"low"})).tags.map(r=>r.trim()).filter(Boolean)}const na=4;function aa(e){return JSON.stringify([e.profile.city,e.profile.country,e.cvText,e.personalLegend,e.languageLevels.map(t=>t.language)])}async function ia(e){const t=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(e));return[...new Uint8Array(t)].map(a=>a.toString(16).padStart(2,"0")).join("")}async function Qe(e){var o;const t=await ia(aa(await S())),a=await P("jobSearchSuggestionCache")??[],n=a.find(c=>c.key===t);if(n&&(!e||n.tags))return{what:n.what,where:n.where,tags:n.tags,cached:!0};const[i,s]=await Promise.all([n?{what:n.what,where:n.where}:Xn(),e?ta():Promise.resolve(void 0)]),r={key:t,...i,tags:s!=null&&s.length?s:n==null?void 0:n.tags};return(r.what||(o=r.tags)!=null&&o.length)&&await ee("jobSearchSuggestionCache",[r,...a.filter(c=>c.key!==t)].slice(0,na)),{what:r.what,where:r.where,tags:r.tags,cached:!1}}async function Ee(e,t){var s;const a=performance.now(),n=await Qe(!0);e.push({label:n.cached?`${t} (cached)`:t,ms:performance.now()-a});const i=ne((s=n.tags)!=null&&s.length?n.tags:[n.what]);if(i.length===0)throw new Error("Couldn't derive search terms from your CV — type a few search terms.");return{what:n.what,where:n.where,terms:i}}async function sa(e,t={}){var l,h;const a=performance.now(),n=[],i=()=>({totalMs:performance.now()-a,stages:n});if(e.provider==="adzuna"){const[f,m]=await Promise.all([de(),z()]);if(!f.adzunaAppId||!f.adzunaAppKey)throw new Error("Add your Adzuna app_id and app_key in Settings first.");let y=e;if(!((l=y.tags)!=null&&l.length)){const p=q(y);if(p.length>0)y={...y,tags:p};else{const w=await Ee(n,"Suggest tags");y={...y,what:w.what,where:y.where.trim()||w.where,tags:w.terms}}}const{results:b,warnings:d}=await J(n,"Adzuna search",()=>Jn(y,{appId:f.adzunaAppId,appKey:f.adzunaAppKey},Kn(m.country),t.page??1,t.onResults,t.signal));return{results:b,resolvedQuery:y,warnings:d,...i()}}const[s,r]=await Promise.all([Re(),de()]),o=(s==null?void 0:s.content)??"";if(e.provider==="tavily"){if(!r.tavilyApiKey)throw new Error("Add your Tavily API key in Settings first.");let f=e;if(q(f).length===0){const b=await Ee(n,"Suggest terms");f={...f,terms:b.terms,where:f.where.trim()||b.where}}const{results:m,warnings:y}=await Dn(f,r.tavilyApiKey,o,t.excludeResults,n,t.signal,t.page??1);return m.length>0&&((h=t.onResults)==null||h.call(t,m)),{results:m,resolvedQuery:f,...y.length?{warnings:y}:{},...i()}}const{results:c,warnings:u}=await bn(e,o,t.excludeResults,n,t.onResults,t.signal);return{results:c,resolvedQuery:e,...u.length?{warnings:u}:{},...i()}}const ra={type:"object",additionalProperties:!1,required:["keyRequirements","relevantExperienceHints","suggestedTone","suggestedFocus"],properties:{keyRequirements:{type:"array",items:{type:"string"}},relevantExperienceHints:{type:"array",items:{type:"string"}},suggestedTone:{type:"string"},suggestedFocus:{type:"string"}}};async function oa(e){return E({schemaName:"job_analysis",schema:ra,model:await xe(),systemPrompt:"You analyze job postings for a job-application assistant. Identify the most important requirements and what an applicant should emphasize. Do not invent details that are not present in the posting.",userPrompt:JSON.stringify(e,null,2),parse:t=>JSON.parse(t)})}const ca=`You write tailored cover letters for job applications.

The user message holds the applicant's data as JSON, and may end with an
"Applicant's rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and
   Personal Legend. Never invent experience, technologies, companies,
   education, or achievements, even if the applicant's rules ask for them.
   If information needed to be compelling is missing, write around it
   honestly rather than fabricating it.
2. The applicant's rules. Follow every instruction there on tone, length,
   structure, language, and what to include or avoid, including where it
   departs from the defaults below. Every rule there applies to the whole
   letter, not just the opening.
3. Language. If "postingLanguage" is given, write the entire letter in that
   language, using the salutation, register, and closing conventions native
   speakers of it would expect on a job application (e.g. formal
   "Sie"/"Herr"/"Frau" address and a "Sehr geehrte(r) ..." opening in German,
   not a literal English-to-German translation).
4. The house style below. Its "no exceptions" means no exceptions of your
   own; an explicit applicant rule still overrides it.
5. Tone and emphasis tailored to the job analysis provided.

Output plain prose paragraphs, no markdown headers.

${R}`;async function la(e,t){const n=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,analysis:e.analysis,postingLanguage:e.postingLanguage||void 0},null,2)+Xe(e.generationRules),i=await Tt(ca,n,t??(()=>{}));return T(i)}function Xe(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const le={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},Ze={type:"object",additionalProperties:!1,required:["subject","body"],properties:{subject:{type:["string","null"]},body:{type:"string"}}},ua=`You are a sharp human editor cleaning up a cover letter draft.

Fix ONLY the flagged AI-writing patterns listed below. Make the minimum
effective edit — do not rewrite sentences that were not flagged, do not
change facts, experience, technologies, or claims, and do not add new
content. Replace banned words/clichés with plain, concrete language.
Rewrite "not X, it's Y" contrasts as a direct statement of Y. Cut
throat-clearing openers, weasel attribution, and importance-puffery instead
of softening them. If the ending is a generic summary/recap, end on the
letter's last concrete point instead. Replace every em dash ("—") with a
comma, a period, or parentheses.

The user message may end with the applicant's own rules for the letter. If a
flagged pattern is something those rules explicitly ask for, leave it as is:
the applicant's rules outrank the house style.

Do not introduce any new AI-slop while editing. For reference, the full
house style is:

${R}

Output plain prose paragraphs, no markdown headers.`;async function pa(e,t,a=""){const n=JSON.stringify({draft:e,flaggedPatterns:t.map(s=>`${s.pattern}: "${s.match}"`)},null,2)+Xe(a),i=await E({schemaName:"cover_letter_polish",schema:le,systemPrompt:ua,userPrompt:n,parse:s=>JSON.parse(s)});return T(i.content)}const da=["delve","foster","leverage","utilize","facilitate","empower","streamline","robust","cutting-edge","paradigm shift","game changer","this is huge","this changes everything","tapestry","realm","beacon","multifaceted","meticulous","intricate","paramount","transformative","elevate","embark","supercharge","harness","ever-evolving"],ha=["it's worth noting","it is worth noting","it's important to note","it is important to note","at the end of the day","when it comes to","at its core","in today's world","in the age of","in the world of","the reality is","the truth is","in terms of","with regard to","in order to","going forward"],fa=["here's the thing","here's what i mean","let me be clear","i'll be honest","the uncomfortable truth is"],ga=["this is the part most people skip","what most people get wrong","here's what nobody tells you","the part everyone misses"],ma=["stands as a testament","marks a pivotal moment","plays a vital role","solidifies its position","underscores its significance"],ya=["experts agree","industry reports suggest","many argue","widely regarded as","studies show"],wa=[/^in conclusion\b/i,/^ultimately\b/i,/^overall\b/i];function ba(e){const t=e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`\\b${t.replace(/ /g,"\\s+")}\\b`,"i")}function x(e,t,a){const n=[];for(const i of t){const s=ba(i).exec(e);s&&n.push({pattern:a,match:s[0]})}return n}function va(e){const t=/\b(?:isn'?t|is not)\b[^.!?]{3,60}[,.]?\s*(?:it'?s|it is)\b[^.!?]{3,80}[.!?]/i,a=/\bnot just\b[^.!?]{3,60}(?:\bbut\b|[,.]?\s*(?:it'?s|it is)\b)[^.!?]{0,80}[.!?]/i,n=[],i=t.exec(e);i&&n.push({pattern:"binary-contrast",match:i[0].trim()});const s=a.exec(e);return s&&n.push({pattern:"binary-contrast",match:s[0].trim()}),n}function Ea(e){const t=e.split(/\n{2,}/).map(n=>n.trim()).filter(Boolean),a=t[t.length-1];if(!a)return[];for(const n of wa)if(n.test(a))return[{pattern:"summary-recap-ending",match:a.slice(0,60)}];return[]}function Sa(e){const t=(e.match(/—/g)??[]).length;return t===0?[]:[{pattern:"em-dash",match:t===1?"1 em dash":`${t} em dashes`}]}function ka(e){return[...x(e,da,"banned-word"),...x(e,ha,"empty-phrase"),...x(e,fa,"throat-clearing-opener"),...x(e,ga,"faux-insight-setup"),...x(e,ma,"importance-puffery"),...x(e,ya,"weasel-attribution"),...va(e),...Ea(e),...Sa(e)]}async function Ta(e,t,a){const n=await S(),i=await oa(e),s=await la({profile:n.profile,cvText:n.cvText,personalLegend:n.personalLegend,generationRules:n.generationRules,job:e,analysis:i,postingLanguage:t},a),r=ka(s);return r.length===0?{content:s,slopFindings:r,cleaned:!1}:{content:await pa(s,r,n.generationRules),slopFindings:r,cleaned:!0}}const La=`You write a short outreach message an applicant sends to a named
recruiter/hiring contact BEFORE or alongside applying, to start a conversation about a specific
job posting — not a cover letter, and not addressed to "the hiring team".

The user message holds the applicant's data as JSON ("contact" is the email address or LinkedIn
URL found on the posting, "channel" is "email" or "linkedin"), and may end with an "Applicant's
rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and Personal Legend. Never
   invent experience, technologies, companies, education, or achievements.
2. The applicant's rules. Follow every instruction there on tone, length, structure, language,
   and what to include or avoid, including where it departs from the defaults below.
3. Language. If "postingLanguage" is given, write the entire message in that language, using
   the salutation and register native speakers of it would expect.
4. Channel. If "channel" is "email", write a short email: "subject" is REQUIRED, never null or
   empty: a specific, non-generic subject line under 80 characters that names the role and the
   company (and, if it fits, the applicant's strongest match), in the message's language. "body"
   opens with a greeting and closes with a signature using the applicant's name; it does not
   repeat the subject. If "channel" is "linkedin", write a LinkedIn connection/message note
   instead: "subject" is null, "body" has no email greeting/signature and stays under LinkedIn's
   informal register.
5. The house style below. Its "no exceptions" means no exceptions of your own; an explicit
   applicant rule still overrides it.

Defaults (apply unless the applicant's rules say otherwise): under 120 words, state who the
applicant is and the one or two things that make them a fit for THIS role, and end with a clear,
low-pressure ask (a quick chat, or just flagging interest before applying). Never sound like a
mass-sent template.

${R}`;async function Aa(e){const a=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,contact:e.contact,channel:he(e.contact)?"email":"linkedin",postingLanguage:e.postingLanguage||void 0},null,2)+Ia(e.outreachRules),n=await E({schemaName:"outreach_message",schema:Ze,model:await Ne(),systemPrompt:La,userPrompt:a,parse:i=>JSON.parse(i)});return{subject:he(e.contact)?et(n.subject,e.job):null,body:T(n.body)}}function et(e,t){const a=T((e??"").replace(/^\s*subject\s*:\s*/i,"").replace(/\s+/g," ").trim());if(a)return a;const n=t.position.trim(),i=t.company.trim();return n&&i?`${n} at ${i}`:n||i||"Job application"}function Ia(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const tt={type:"array",items:{type:"object",additionalProperties:!1,required:["text","kind","matchesProfile"],properties:{text:{type:"string"},kind:{type:"string",enum:["hard","soft"]},matchesProfile:{type:"boolean"}}}};function ue(e){return`KEYWORDS
- Pick the SKILLS the posting asks for, and nothing else. Each one is either:
  - "hard": a technical skill, tool, technology, programming language, framework, platform,
    method or domain expertise (e.g. "TypeScript", "Kubernetes", "C++", ".NET", "CI/CD",
    "SQL", "machine learning", "financial modelling", "Figma", "Scrum");
  - "soft": a real interpersonal/working skill (e.g. "communication", "mentoring",
    "stakeholder management", "problem-solving", "ownership").
- NEVER return anything that is not a skill. In particular, never return:
  - the company name, its products' brand names used as a name, or any other organization;
  - cities, countries, regions, addresses, time zones;
  - work modes and contract terms ("remote", "hybrid", "on-site", "full-time", "contract");
  - benefits and pay ("salary", "equity", "health insurance", "30 days vacation", "bonus");
  - job titles and seniority ("Senior Backend Engineer", "Team Lead", "junior");
  - years of experience, degrees, certificates as such ("5+ years", "Bachelor's degree");
  - spoken languages ("English", "German") — those are reported separately above;
  - generic words ("team", "experience", "work", "product", "environment", "opportunity",
    "fast-paced environment", "passion").
- Every keyword's "text" MUST be copied VERBATIM from ${e} — the exact same characters
  and casing, not a paraphrase, synonym, or translation — because the extension re-finds this
  exact text on the page to highlight it. A keyword that doesn't appear verbatim is useless.
- Prefer short phrases: single words or 2-3 word phrases, never sentences.
- Return up to 15, most important first. Fewer is fine: return an empty array rather than
  padding the list with anything from the NEVER list above.
- No duplicates, and no two keywords where one is a substring of the other (keep the more
  specific/longer one).
- Set "matchesProfile" to true when the applicant's profile/cvText/personalLegend shows they
  already have, use, or meet that skill — false when the posting asks for it but nothing in
  the applicant's material supports it. Judge substance, not exact wording (e.g.
  "Kubernetes" counts as a match if the CV mentions "container orchestration with K8s" or
  "EKS"). When genuinely unsure, set it to false — this flags a possible gap for the
  applicant to address rather than silently hiding it.`}const _a=new Set(["team","teams","experience","work","job","role","position","company","candidate","opportunity","environment","product","products","customer","customers","client","clients","project","projects","skills","knowledge","ability","responsibilities","requirements","tasks","career","growth","culture","mission","vision","values","impact","passion","motivation","startup","scale-up","industry","business","fast-paced environment","dynamic environment","nice to have","must have","plus","years","year","years of experience","professional experience","work experience","degree","bachelor","bachelor's degree","master","master's degree","university degree","diploma","phd","intern","internship","junior","middle","mid-level","senior","lead","principal","staff","head","manager","remote","fully remote","remote work","hybrid","on-site","onsite","office","in office","home office","homeoffice","relocation","visa sponsorship","full-time","full time","part-time","part time","contract","freelance","permanent","temporary","salary","competitive salary","bonus","equity","stock options","esop","benefits","vacation","paid time off","pto","holidays","health insurance","insurance","pension","gym","gym membership","free lunch","snacks","flexible hours","flexible working hours","learning budget","parental leave","erfahrung","berufserfahrung","aufgaben","anforderungen","unternehmen","vollzeit","teilzeit","festanstellung","gehalt","urlaub","vertrag","büro","mobiles arbeiten","команда","опыт","опыт работы","работа","компания","проект","проекты","задачи","требования","обязанности","удаленно","удаленка","удаленная работа","гибрид","офис","полный день","полная занятость","частичная занятость","зарплата","оклад","бонусы","дмс","отпуск","релокация"]),Ra=new Set(Lt.map(e=>_(e))),Oa=new RegExp("\\s*,?\\s*(?<![\\p{L}\\p{N}])(?:inc|ltd|llc|gmbh|ag|se|kg|ug|bv|nv|sa|sas|srl|plc|corp|corporation|co|company|oy|ab|as|ооо|ао)\\.?$","iu");function _(e){return e.normalize("NFC").toLowerCase().replace(/ё/g,"е").replace(/[’`]/g,"'").replace(/^[\s"'«».,:;!?()[\]-]+|[\s"'«».,:;!?()[\]-]+$/g,"").replace(/\s+/g," ")}function Ca(e){const t=_(e);if(!t)return[];const a=_(t.replace(Oa,""));return a&&a!==t?[t,a]:[t]}function Pa(e){const t=_(e);if(!t)return[];const a=e.split(/[,/|·•()]/).map(_).filter(Boolean);return[t,...a]}function xa(e){return _(e.replace(/\((?:[mwfdx]\s*\/\s*)+[mwfdx]\)/gi,""))}const Na=/^\d+(?:\s*[-–+]\s*\d*)?\+?\s*(?:years?|yrs?|jahre?n?|лет|года?|ans|años)(?![\p{L}\p{N}])/iu;function se(e,t){const a=e.trim();if([...a].length<2)return!new RegExp("^\\p{Lu}$","u").test(a);if(!new RegExp("\\p{L}","u").test(a)||/[$€£¥₽%]/u.test(a))return!0;const n=_(a);return!n||_a.has(n)||Ra.has(n)||Na.test(n)||Ca(t.company).includes(n)||Pa(t.location).includes(n)?!0:n===xa(t.position)}function pe(e,t){const a=new Set;return e.filter(n=>{const i=_(n.text);return a.has(i)||se(n.text,t)?!1:(a.add(i),!0)})}function Ma(e,t){var i;const a=(i=e.match(/\s*[,;|·•]\s*/u))==null?void 0:i[0];if(!a)return se(e,t)?"":e;const n=new Set;return e.split(/\s*[,;|·•]\s*/u).filter(s=>{const r=_(s);return!s.trim()||n.has(r)||se(s,t)?!1:(n.add(r),!0)}).join(a)}const nt={postingLanguages:{type:"array",items:{type:"string"}},languageRequirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...$e,null]}}}},keywords:tt},$a={type:"object",additionalProperties:!1,required:["company","position","location","description","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},description:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...nt}},at=`LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- languageRequirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or "Native"
  for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent", "professional
  working proficiency" -> "C1"; "conversational" -> "B1". If a language is mentioned but no level
  can be reasonably inferred, set level to null. Do not invent a requirement that isn't stated in
  the text. If nothing is stated, return an empty array.`,ja=`You read the visible text of a job-posting page and do two things with it
in one pass: extract the structured posting fields, and analyze the result for language and
keywords — against the applicant profile/CV/Personal Legend given below.

EXTRACTION
- Only use information present in "pageText"; leave a field empty/null if unknown.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- For "contact", prefer a named recruiter/hiring manager's email address or LinkedIn
  profile/company URL if one is mentioned, copied VERBATIM (exact characters); otherwise null.

${at}

${ue('"pageText"')}`;async function Ua(e,t){const a=await S(),n=JSON.stringify({profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,pageText:e.slice(0,12e3)},null,2),i=await E({schemaName:"job_extraction_and_brief",schema:$a,model:await Me(),reasoningEffort:"low",systemPrompt:ja,userPrompt:n,parse:o=>JSON.parse(o)}),s={company:i.company,position:At(i.position),location:i.location,description:i.description,requirements:i.requirements,responsibilities:i.responsibilities,salary:i.salary,techStack:i.techStack,contact:i.contact,url:t},r={language:{postingLanguages:i.postingLanguages,requirements:i.languageRequirements},keywords:pe(i.keywords,s),contact:null};return{job:s,brief:r}}const qa={type:"object",additionalProperties:!1,required:["company","position","location","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...nt}},Da=`You read the visible text of a job-posting page. It was already parsed
without AI: "knownFields" holds what that found. Fill in what it missed, and analyze the posting
for language and keywords — against the applicant profile/CV/Personal Legend given below.

FIELDS
- Fill only the fields named in "fieldsToFill". For every other posting field return "" / [] /
  null — those are kept from the page as they are. Never re-type the posting's description.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- company: the hiring company, not the job board or recruiting platform hosting the page.
- location: as written in the posting; "" if none.
- requirements, responsibilities: at most 8 items each, each a short phrase (12 words or fewer),
  not copied paragraphs.
- techStack: technology names only.
- contact: a named recruiter/hiring manager's email address or LinkedIn profile/company URL,
  copied VERBATIM (exact characters); otherwise null.
- Only use information present in "pageText"; leave a field empty/null if unknown.

${at}

${ue('"pageText"')}`;async function Fa(e,t){const a=await S(),n=It(e),i=t||e.description,s=JSON.stringify({profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,knownFields:{position:e.position,company:e.company,location:e.location,salary:e.salary,contact:e.contact},fieldsToFill:n,pageText:i.slice(0,12e3)},null,2),r=await E({schemaName:"job_completion_and_brief",schema:qa,model:await Me(),reasoningEffort:"low",systemPrompt:Da,userPrompt:s,parse:u=>JSON.parse(u)}),o=_t(e,r,n,i),c={language:{postingLanguages:r.postingLanguages,requirements:r.languageRequirements},keywords:pe(r.keywords,o),contact:null};return{job:o,brief:c}}const Ya=`You are editing an existing cover letter draft on the applicant's
instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the
  letter the instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements
  that aren't already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the
  instruction explicitly asks to change it.
- Output plain prose paragraphs, no markdown headers.
- Don't introduce AI-slop while editing, and clean it from any sentence you
  touch.

${R}`;async function Va(e,t,a){const n=JSON.stringify({draft:e,instructions:t,job:a},null,2),i=await E({schemaName:"cover_letter_revision",schema:le,model:await Rt(),systemPrompt:Ya,userPrompt:n,parse:s=>JSON.parse(s)});return T(i.content)}const Ha=`You are editing an existing outreach message (an email or LinkedIn note
to a recruiter/hiring contact) on the applicant's instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the message the
  instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements that aren't
  already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the instruction explicitly
  asks to change it.
- If the draft's "subject" is null, keep it null (it's a LinkedIn note). Otherwise keep a
  specific subject line, changing it only if the instruction (or the edit) requires it.
- Don't introduce AI-slop while editing, and clean it from any sentence you touch.

${R}`;async function Ba(e,t,a){const n=JSON.stringify({draft:e,instructions:t,job:a},null,2),i=await E({schemaName:"outreach_message_revision",schema:Ze,model:await Ne(),systemPrompt:Ha,userPrompt:n,parse:s=>JSON.parse(s)});return{subject:e.subject===null?null:et(i.subject||e.subject,a),body:T(i.body)}}const Ga=`You translate a cover letter for the applicant's own understanding —
not for submission. Translate faithfully, preserve paragraph breaks, and keep
names, companies, and technical terms as-is where translating them would be
unnatural. Do not use em dashes ("—"); use commas or periods. Output plain
prose paragraphs, no markdown headers, no notes about the translation itself.`;async function Ja(e,t){const a=JSON.stringify({content:e,targetLanguage:t},null,2),n=await E({schemaName:"cover_letter_translation",schema:le,systemPrompt:Ga,userPrompt:a,parse:i=>JSON.parse(i)});return T(n.content)}const Se=new RegExp([String.raw`(?:additional|further|other|more|extra|supplementary)\s+(?:information|info|details|comments?|remarks?|notes?|thoughts)`,String.raw`anything\s+else`,String.raw`is\s+there\s+anything(?:\s+else)?`,String.raw`any(?:thing)?\s+(?:other|further|additional|final)\s+(?:comments?|remarks?|notes?|information|thoughts)`,String.raw`(?:any|final)\s+(?:comments?|remarks?|notes?|thoughts)`,String.raw`(?:a\s+)?(?:message|note)\s+(?:to|for)\s+(?:the\s+|our\s+)?(?:hiring\s+(?:team|manager)|recruit(?:er|ing\s+team|ment\s+team)|team|us|company|employer)`,String.raw`(?:weitere|zus[aä]tzliche|sonstige|erg[aä]nzende|andere)\s+(?:informationen|infos?|angaben|anmerkungen|hinweise|bemerkungen|mitteilungen|kommentare)`,String.raw`sonstiges`,String.raw`(?:m[oö]chten|willst|m[oö]chtest)\s+(?:sie|du)\s+uns\s+(?:sonst\s+)?noch\s+(?:etwas|was)`,String.raw`gibt\s+es\s+(?:sonst\s+)?noch\s+(?:etwas|was)`,String.raw`(?:nachricht|mitteilung)\s+an\s+(?:uns|das\s+team|den\s+recruiter|die\s+personalabteilung)`,String.raw`informations?\s+compl[ée]mentaires?`,String.raw`informaci[oó]n\s+adicional`,String.raw`дополнительн(?:ая|ые)\s+(?:информация|сведения|комментари[йи])`].join("|"),"iu"),za=/^(?:your\s+|ihre?\s+|deine?\s+|persönliche\s+)?(?:messages?|comments?|remarks?|notes?|nachricht|anmerkungen?|bemerkungen?|kommentare?|hinweise?|mitteilung|commentaires?|comentarios?|комментари[йи]|сообщение)$/iu,Ka=/^(?:your\s+|ihr\s+)?(?:cover\s+letter|motivation(?:al)?\s+letter|anschreiben|motivationsschreiben|lettre\s+de\s+motivation|carta\s+de\s+presentaci[oó]n|сопроводительное\s+письмо)$/iu,Wa=new RegExp(String.raw`\b(?:optional|freiwillig|facultatif|opcional|необязательно|please|bitte|here|hier|you|you'?d|would|like|to|share|add|tell|let|us|know|mention|with|about|yourself|we|should|that|the|a|an|and|or|for|me|your|our|any|on|in|of|this|application|role|position|job|team|hiring|sie|du|uns|noch|etwas|was|mitteilen|teilen|sagen|zu|ihrer|ihre|deiner|bewerbung|stelle|möchten|möchtest|gibt|es|sonst|und|oder|für|die|der|das|den|dem|an|mit|über|is|there|else|do|have|want|wish|feel|free|e\.?\s?g\.?|z\.?\s?b\.?)\b`,"giu");function Qa(e){return e.replace(/[*✱:?!.…]+/g," ").replace(/\((?:optional|freiwillig|facultatif|opcional|необязательно)\)/giu," ").replace(/\s+/g," ").trim()}function Xa(e,t){return e.replace(t," ").replace(/[()[\],;/\-–—"'„“”]+/g," ").replace(Wa," ").split(/\s+/).filter(n=>new RegExp("\\p{L}{2}","u").test(n))}function Za(e){const t=Qa(e);return t?Ka.test(t)?"coverLetter":za.test(t)?"weak":new RegExp(Se.source,"giu").test(t)?Xa(t,new RegExp(Se.source,"giu")).length>=3?null:"strong":null:null}const ei=[/\b(?:please|kindly)\b[^.!?\n]{0,100}\b(?:mention|include|state|indicate|tell\s+us|let\s+us\s+know|add|note|specify|quote|answer)\b[^.!?\n]{0,100}\b(?:application|cover\s+letter|message|submission)\b[^.!?\n]*/iu,/\bin\s+your\s+(?:application|cover\s+letter|message)\b[^.!?\n]{0,100}\b(?:mention|include|state|tell\s+us|let\s+us\s+know|answer|describe)\b[^.!?\n]*/iu,/\b(?:code\s?word|keyword|reference\s+(?:number|code)|kennwort|kennziffer|referenznummer|stichwort)\b[^.!?\n]*/iu,/\b(?:geben|nennen|teilen|erw[aä]hnen|beantworten)\s+sie\b[^.!?\n]{0,120}\b(?:bewerbung|anschreiben|nachricht)\b[^.!?\n]*/iu,/\bin\s+ihrer\s+bewerbung\b[^.!?\n]{0,120}\b(?:an|nennen|angeben|mitteilen|erw[aä]hnen|beantworten)\b[^.!?\n]*/iu];function ke(e){const t=[e.description??"",...e.requirements??[],...e.responsibilities??[]].join(`
`);for(const a of ei){const n=a.exec(t);if(n)return n[0].trim().slice(0,300)}return null}function ti(e,t){if(t.required===!0)return{action:"write",reason:"required",postingAsk:ke(e)??void 0};const a=ke(e);return a?{action:"write",reason:"posting",postingAsk:a}:t.required===!1?{action:"skip"}:{action:"write",reason:"asked"}}const ni={type:"object",additionalProperties:!1,required:["skip","answer"],properties:{skip:{type:"boolean"},answer:{type:"string"}}},ai=`You decide what, if anything, goes into the open catch-all field at the end of a
job application form ("Additional information", "Anything else you'd like to share?", "Weitere
Informationen", "Sonstiges", "Message to the hiring team"). The recruiter already has everything
in "formValues", "otherAnswers", the attached CV ("cvText"), the cover letter ("coverLetter") and
the profile. Repeating any of it wastes their time and makes the application look padded.

Rules:
- "skip": true, "answer": "" is the normal result. Choose it whenever there is nothing NEW and
  relevant to add. An empty field is fine.
- Never repeat or paraphrase: contact data (name, email, phone, address, city), links (LinkedIn,
  GitHub, portfolio, website), salary expectations, start date / notice period / availability,
  work permit / visa / relocation, language levels, a summary of the CV or the experience, or the
  motivation already given in the cover letter or other answers.
- "postingAsk" (when present) is what the job posting explicitly asks applicants to include.
  Answer exactly that, from the applicant's data, if it isn't already in the form. If the data
  doesn't have it, skip.
- "required": true means the form won't submit with the field empty. Then don't skip: write ONE
  short sentence with something new from the Personal Legend or custom fields, or, if there is
  truly nothing new, one plain neutral sentence (e.g. that you look forward to hearing from them).
- Otherwise ("required" false or unknown), write only when there is a genuinely new, relevant fact
  (e.g. a constraint the recruiter must know that appears nowhere else).
- At most 2 sentences, plain text, no greeting, no sign-off, no lists, no markdown.
- Never invent facts. Use ONLY the applicant data given.
- If "postingLanguage" is given, write in that language with its native application register.

${R}`,ii=/\b(?:https?:\/\/|www\.)\S+|\b[\w.-]+\.(?:com|de|io|dev|net|org|me)\/\S*/i,si=/\b[\w.+-]+@[\w-]+\.[\w.-]+\b/,ri=/(?:\+|\b00)\d[\d\s/().-]{6,}\d|\b0\d{2,4}[\s/-]?\d{3,}[\s-]?\d{2,}\b/;function oi(e){return e.replace(/\s+/g," ").trim().split(new RegExp("(?<=[.!?])\\s+(?=\\S)","u")).filter(a=>a&&!ii.test(a)&&!si.test(a)&&!ri.test(a)).slice(0,2).join(" ").trim()}const it="catchAllAdds";function ci(e){return{type:"predicate",name:it,instructions:`The application form has an open catch-all field ("field"), not marked required: "Additional information", "Anything else?".
The recruiter already has the applicant's CV, cover letter, profile and every value in "formValues"
and "otherAnswers". Should the applicant write anything in it?
- Yes only if ${e?`the applicant's data covers what the posting explicitly asks applicants to include ("postingAsk") and the form doesn't already hold it, or if `:""}the applicant's data holds a genuinely NEW fact relevant to this application that appears nowhere else (e.g. a constraint the recruiter must know).
- No for anything already in the CV, cover letter, profile or form: contact data, links, salary, start date /
  notice period / availability, work permit / visa / relocation, language levels, a summary of the
  experience, the motivation.
- No when in doubt: an empty field is the normal, good outcome.`}}async function li(e,t,a,n){try{const i=[...e.input,{role:"user",content:[{type:"input_json",data:{formValues:(a.formValues??[]).filter(r=>r.value.trim()),otherAnswers:(a.otherAnswers??[]).filter(r=>r.answer.trim()),coverLetterAttached:a.coverLetterAttached||void 0,postingAsk:n??null,field:t}}]}],s=await M({input:i,promptCacheKey:e.promptCacheKey,questions:[ci(n)]});return Ot(s,it)}catch(i){if(i instanceof D)throw i;return console.warn("[Filler] Decisions API failed, writing the catch-all via Responses:",i),null}}async function st(e,t,a,n){const i=ti(t,a);if(i.action==="skip")return{answer:"",sufficientInfo:!0,skipped:!0};const[s,r]=await Promise.all([S(),P("lastCoverLetter")]);if(a.required!==!0){const l=ce(s,r??"",t,n),h=await li(l,e,a,i.postingAsk);if(h!==null&&h<U.catchAllWrite)return{answer:"",sufficientInfo:!0,skipped:!0}}const o=JSON.stringify({job:t,profile:s.profile,cvText:s.cvText,coverLetter:r??"",coverLetterAttached:a.coverLetterAttached||void 0,personalLegend:s.personalLegend,customFields:s.customFields,languageLevels:s.languageLevels,generationRules:s.generationRules,postingLanguage:n||void 0,formValues:(a.formValues??[]).filter(l=>l.value.trim()),otherAnswers:(a.otherAnswers??[]).filter(l=>l.answer.trim()),postingAsk:i.postingAsk,required:a.required??"unknown",question:e},null,2),c=await E({schemaName:"catch_all_answer",schema:ni,systemPrompt:ai,userPrompt:o,label:"Catch-all answer",parse:l=>JSON.parse(l)}),u=c.skip?"":oi(T(c.answer));return u?{answer:u,sufficientInfo:!0,skipped:!1}:{answer:"",sufficientInfo:a.required!==!0,skipped:!0}}const ui={type:"object",additionalProperties:!1,required:["answer","sufficientInfo"],properties:{answer:{type:"string"},sufficientInfo:{type:"boolean"}}},Te=`You answer a custom question from a job application form on the
applicant's behalf.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend,
  cover letter, custom fields, language levels, and job posting. Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, the
  "languageLevels" list is the authoritative answer (CEFR levels the
  applicant self-reported in Settings) — use it directly rather than
  guessing from the CV or defaulting to a low/neutral level.
- If the profile/CV/Personal Legend/etc genuinely lack what's needed to
  answer this question — not just a minor detail, but the actual substance
  being asked for — set "sufficientInfo" to false and "answer" to an empty
  string. Do NOT write a sentence explaining that you don't have the
  information (e.g. "I don't have this information available") — that text
  would otherwise get typed straight into the applicant's form field, which
  is worse than leaving it blank for the applicant to fill in themselves.
  Only do this when the information is truly absent; a question you can
  answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient —
  set sufficientInfo to true and give that honest answer.
- If "postingLanguage" is given, write the answer in that language, using
  the salutation/register conventions native speakers of it would expect on
  a job application (e.g. formal "Sie"/"Herr"/"Frau" address in German, not
  a literal English-to-German translation) — unless the question itself, or
  "generationRules", explicitly asks for a different language.
- If this question is a newsletter, marketing-email, or job-alert
  subscription opt-in phrased as a choice (e.g. "Would you like to
  subscribe to our newsletter? Yes/No"), always choose the option that
  declines it — the applicant never needs this to submit the application.
- "faq" is a set of pre-written answers to standard interview-FAQ questions
  (spec_5 section B). If the question being asked now is the same as, or a
  close variant of, one already in "faq", reuse its substance and phrasing —
  adapt only what the target field's length/format actually requires — so
  the applicant's answer stays consistent across different forms rather
  than being re-derived from scratch each time.
- Match the question's expected length: a short field gets a short answer, an
  open-ended "tell us about..." field gets a fuller one.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text, no markdown, no restating the question.

${R}`,pi=/\b(?:please\s+(?:provide|specify|clarify)|could\s+you\s+(?:please\s+)?(?:provide|clarify|specify)|i\s+(?:don'?t|do\s+not)\s+see)\b.{0,40}?\b(?:question|prompt)\b|\bno\s+(?:specific\s+)?question\s+(?:was|is)?\s*(?:provided|given|specified|attached)\b/i;function rt(e){const t=e.trim();return t?t.length<220&&pi.test(t):!0}const di=`
- This is a MULTIPLE-CHOICE question: "options" lists the allowed answers.
  Reply with EXACTLY ONE option, copied verbatim, and nothing else.
- Base the choice on the applicant's profile/CV/Personal Legend. If the
  needed fact is genuinely absent (e.g. pronouns not stated anywhere),
  prefer a neutral option, an explicit "prefer not to say", or the option
  that commits the applicant least.`,hi=`
- This is a SELECT-ALL-THAT-APPLY question: "options" lists every allowed
  answer. Reply with every option that genuinely applies, each copied
  verbatim, joined by " | " (a single pipe surrounded by one space on each
  side) — nothing else. If none apply, reply with an empty string.
- Base each choice strictly on the applicant's profile/CV/Personal Legend —
  never include an option just because it's plausible or common; only ones
  the applicant's own material actually supports.`,fi=`
- This field only accepts a plain number: reply with digits only (a single
  "." for a decimal if needed) — no currency symbol, no thousands
  separator, no unit, no words, no range. If a range genuinely fits best
  (e.g. a salary expectation given as "65-75k"), reply with one
  representative figure (its midpoint), not the range.`;function gi(e){return`
- This field only accepts a date in the exact format "${Fe[e]}"
  — reply with ONLY that value, nothing else (no words, no explanation).
  "todayISO" in the data below is today's date: compute the answer from it
  — e.g. "available with one month's notice" → todayISO plus one month;
  "immediately" / "as soon as possible" / no stated constraint → todayISO
  itself. Never answer with a description of the notice period or
  availability instead of the date itself.`}async function mi(e,t,a,n,i,s,r,o){if(!(a&&a.length>0)&&!n&&!i&&(o||o===void 0&&Za(e)==="strong"))return st(e,t,o??{},r);const[u,l]=await Promise.all([S(),P("lastCoverLetter")]),{input:h,promptCacheKey:f}=ce(u,l??"",t,r),m={question:e,options:a,multi:s,numeric:n,dateKind:i},y=te(m);try{const b=await M({input:h,promptCacheKey:f,questions:y?je(m,0):[Ue(m,0)]});if(y){const d=qe(m,0,b);if(d)return d}else if(De(0,b)===!1)return{answer:"",sufficientInfo:!1}}catch(b){if(b instanceof D)throw b;console.warn("[Filler] Decisions API failed, answering via Responses:",b)}return yi(e,t,a,n,i,s,r)}async function yi(e,t,a,n,i,s,r){const[o,c]=await Promise.all([S(),P("lastCoverLetter")]),u=JSON.stringify({job:t,profile:o.profile,cvText:o.cvText,personalLegend:o.personalLegend,generationRules:o.generationRules,coverLetter:c??"",languageLevels:o.languageLevels,customFields:o.customFields,faq:o.faq.filter(m=>m.answer.trim()),todayISO:K(),postingLanguage:r||void 0,question:e,options:a&&a.length>0?a:void 0},null,2),l=[a&&a.length>0?s?hi:di:"",n?fi:"",i?gi(i):""].filter(Boolean),h=await E({schemaName:"custom_question_answer",schema:ui,systemPrompt:l.length>0?[Te,...l].join(`
`):Te,userPrompt:u,parse:m=>JSON.parse(m)});return!h.sufficientInfo||rt(h.answer)?{answer:"",sufficientInfo:h.sufficientInfo}:{answer:a&&a.length>0||n||!!i?h.answer:T(h.answer),sufficientInfo:!0}}const wi={type:"object",additionalProperties:!1,required:["questions"],properties:{questions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","question"],properties:{index:{type:"integer"},question:{type:"string"}}}}}},bi=`You are given a block of a job-application form: its visible text, and a
list of the input fields inside it. For each field that asks the applicant
something, return the question it is asking, phrased as a plain question.

Rules:
- Use ONLY the visible text provided. Never invent a question.
- Match each question to its field by "index".
- Omit a field that is not a real question (layout helper, hidden field,
  search box, honeypot, a plain "First name"-style profile field).
- A field with "options" is a multiple-choice question — still return only
  its question text, not the options.
- Output the question text only — no numbering, no "Question:" prefix.
- Questions may be in any language; keep the form's own language.`;async function vi(e,t){if(t.length===0)return{};const a=JSON.stringify({blockText:e.slice(0,6e3),fields:t},null,2),n=await E({schemaName:"block_questions",schema:wi,systemPrompt:bi,userPrompt:a,parse:s=>JSON.parse(s)}),i={};for(const s of n.questions)s.question.trim()&&(i[s.index]=s.question.trim());return i}const Ei={type:"object",additionalProperties:!1,required:["checkboxDecisions","questionAnswers"],properties:{checkboxDecisions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","check","category","reason"],properties:{index:{type:"integer"},check:{type:"boolean"},category:{type:"string",enum:["required-consent","marketing","optional","unclear"]},reason:{type:"string"}}}},questionAnswers:{type:"array",items:{type:"object",additionalProperties:!1,required:["id","answer","sufficientInfo"],properties:{id:{type:"string"},answer:{type:"string"},sufficientInfo:{type:"boolean"}}}}}},Si=`You fill in two independent things found on a job-application form at once:
consent checkboxes to decide, and custom questions to answer on the applicant's behalf. The
applicant has already chosen to submit this application.

CHECKBOXES (one decision per item in "checkboxes", matched back by "index")

TICK (check: true) — things required to submit, or that a candidate is normally expected to
accept:
- privacy policy / data protection / GDPR / Datenschutz consent
- terms & conditions / AGB / Nutzungsbedingungen
- confirming the entered information is accurate / truthful
- consent to process and store the application data for THIS hiring process
- storing the data in a talent pool ONLY when the checkbox is marked required
- eligibility self-declarations that hold for any ordinary adult applying for a real job (e.g.
  "I am at least 18 years old", "I am legally entitled to work in [country]", "I have no
  undisclosed conflicts of interest") — assume true unless the profile/CV explicitly states
  otherwise; a genuine job applicant submitting this form is virtually always eligible, and
  leaving a required declaration like this unticked blocks submission for no real reason

DO NOT TICK (check: false) — optional and promotional:
- newsletters, marketing e-mails, "career news", event invitations
- job alerts / notifications about new postings (e.g. "Benachrichtigungen über neue
  Stellenausschreibungen erhalten")
- sharing data with third parties / partner companies for marketing
- joining a talent pool / candidate database when NOT required
- anything that benefits the applicant only beyond this one application

Rules:
- "required: true" means the form marks the field mandatory — a strong signal to tick, unless
  the text is clearly marketing.
- A newsletter/marketing-email/job-alert opt-in is NEVER ticked, even when the form marks it
  "required" — that flag is routinely misused by forms to guilt-trip applicants into
  subscribing, even though applicants never actually need it to submit. When genuinely in doubt
  whether a required checkbox is a real submission requirement or a disguised newsletter
  opt-in, prefer NOT ticking it.
- If a checkbox is ambiguous AND not required, set check: false.
- Labels may be in any language; judge by meaning, not keywords.
- category: "required-consent" (ticked, mandatory-type), "marketing" (left off), "optional"
  (non-marketing but skippable, left off unless required), "unclear" (left off). reason: one
  short phrase.
- Return one decision per input item in "checkboxes", using its "index". If "checkboxes" is
  empty, return an empty array.

QUESTIONS (one answer per item in "questions", matched back by "id")

Ground rules:
- Use ONLY facts present in the shared "profile"/"cvText"/"personalLegend"/"generationRules"/
  "coverLetter"/"languageLevels"/"customFields"/"faq" given below, plus "job". Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, "languageLevels" is the
  authoritative answer (CEFR levels the applicant self-reported in Settings) — use it directly
  rather than guessing from the CV or defaulting to a low/neutral level.
- If the shared material genuinely lacks what's needed to answer a given question — not just a
  minor detail, but the actual substance being asked for — set that item's "sufficientInfo" to
  false and "answer" to an empty string. Do NOT write a sentence explaining that you don't have
  the information — that text would otherwise get typed straight into the applicant's form
  field, which is worse than leaving it blank. Only do this when the information is truly
  absent; a question you can answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient.
- If "postingLanguage" is given, write answers in that language, using the salutation/register
  conventions native speakers of it would expect on a job application (e.g. formal
  "Sie"/"Herr"/"Frau" address in German) — unless the question itself, or "generationRules",
  explicitly asks for a different language.
- A newsletter/marketing-email/job-alert subscription opt-in phrased as a question (e.g. "Would
  you like to subscribe to our newsletter? Yes/No") always gets the option that declines it.
- "faq" is a set of pre-written answers to standard interview-FAQ questions. If a question being
  asked now is the same as, or a close variant of, one already in "faq", reuse its substance and
  phrasing — adapt only what the target field's length/format actually requires.
- Match each question's expected length: a short field gets a short answer, an open-ended
  "tell us about..." field gets a fuller one.
- Output plain text per answer, no markdown, no restating the question.
- Each item in "questions" may also carry:
  - "options" (and not "multi"): a single-choice question — reply with EXACTLY ONE option,
    copied verbatim, nothing else. If the needed fact is genuinely absent (e.g. pronouns not
    stated anywhere), prefer a neutral option or an explicit "prefer not to say".
  - "options" with "multi": true: a select-all-that-apply question — reply with every option
    that genuinely applies, each copied verbatim, joined by " | " (one pipe, one space each
    side). If none apply, reply with an empty string. Never include an option just because it's
    plausible — only ones the applicant's own material actually supports.
  - "numeric": true: the field only accepts a plain number — reply with digits only (a single
    "." for a decimal if needed), no currency symbol, no thousands separator, no unit, no words,
    no range. If a range genuinely fits best (e.g. "65-75k"), reply with one representative
    figure (its midpoint).
  - "dateFormat": the field only accepts a date in exactly that format — reply with ONLY that
    value, nothing else. "todayISO" below is today's date: compute the answer from it — e.g.
    "available with one month's notice" -> todayISO plus one month; "immediately"/"as soon as
    possible"/no stated constraint -> todayISO itself.
- Return one answer per input item in "questions", using its "id". If "questions" is empty,
  return an empty array.

${R}`;function ki(e,t){const a=new Map;for(const n of t)a.set(n.index,n);return e.map((n,i)=>{const s=a.get(i);if(s){const r=s.check&&fe(n.label)?!1:s.check;return{name:n.name,label:n.label,check:r,category:s.category,reason:s.reason}}return fe(n.label)?{name:n.name,label:n.label,check:!1,category:"marketing",reason:"No decision returned — looks like a newsletter/marketing opt-in"}:{name:n.name,label:n.label,check:n.required,category:n.required?"required-consent":"unclear",reason:n.required?"Marked required by the form":"No decision returned"}})}function Ti(e,t){const a=new Map;for(const n of t)a.set(n.id,n);return e.map(n=>{const i=a.get(n.id);if(!i)return{id:n.id,answer:"",sufficientInfo:!0};if(!i.sufficientInfo||rt(i.answer))return{id:n.id,answer:"",sufficientInfo:i.sufficientInfo};const s=n.options&&n.options.length>0||n.numeric||!!n.dateKind;return{id:n.id,answer:s?i.answer:T(i.answer),sufficientInfo:!0}})}async function Le(e,t,a,n){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[i,s]=await Promise.all([S(),P("lastCoverLetter")]),r=JSON.stringify({job:a,profile:i.profile,cvText:i.cvText,personalLegend:i.personalLegend,generationRules:i.generationRules,coverLetter:s??"",languageLevels:i.languageLevels,customFields:i.customFields,faq:i.faq.filter(c=>c.answer.trim()),todayISO:K(),postingLanguage:n||void 0,checkboxes:e.map((c,u)=>({index:u,label:c.label,required:c.required,currentlyChecked:c.checked})),questions:t.map(c=>({id:c.id,question:c.question,options:c.options&&c.options.length>0?c.options:void 0,multi:c.multi,numeric:c.numeric,dateFormat:c.dateKind?Fe[c.dateKind]:void 0}))},null,2),o=await E({schemaName:"page_content_decisions",schema:Ei,systemPrompt:Si,userPrompt:r,parse:c=>JSON.parse(c)});return{checkboxDecisions:ki(e,o.checkboxDecisions),questionAnswers:Ti(t,o.questionAnswers)}}async function Li(e,t,a,n){const i=t.filter(l=>l.catchAll),s=i.length>0?t.filter(l=>!l.catchAll):t,r=await Ai(e,s,a,n);if(i.length===0)return r;const o=s.flatMap(l=>{var f;const h=((f=r.questionAnswers.find(m=>m.id===l.id))==null?void 0:f.answer)??"";return h?[{question:l.question,answer:h}]:[]}),c=await Promise.all(i.map(async l=>{const{answer:h,sufficientInfo:f}=await st(l.question,a,{required:l.required??!1,formValues:l.formValues,otherAnswers:o,coverLetterAttached:l.coverLetterAttached},n);return{id:l.id,answer:h,sufficientInfo:f}})),u=new Map([...r.questionAnswers,...c].map(l=>[l.id,l]));return{checkboxDecisions:r.checkboxDecisions,questionAnswers:t.map(l=>u.get(l.id)??{id:l.id,answer:"",sufficientInfo:!0})}}async function Ai(e,t,a,n){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[i,s]=await Promise.all([S(),P("lastCoverLetter")]),{input:r,promptCacheKey:o}=ce(i,s??"",a,n),c=t.map((d,p)=>({q:d,i:p})),u=c.filter(({q:d})=>te(d)),l=c.filter(({q:d})=>!te(d));let h;try{h=await M({input:r,promptCacheKey:o,questions:[...Ct(e),...u.flatMap(({q:d,i:p})=>je(d,p)),...l.map(({q:d,i:p})=>Ue(d,p))]})}catch(d){if(d instanceof D)throw d;return console.warn("[Filler] Decisions API failed, falling back to Responses:",d),Le(e,t,a,n)}const f=e.map((d,p)=>Pt(d,p,h)),m=e.filter((d,p)=>!f[p]),y=new Map,b=[];for(const{q:d,i:p}of u){const w=qe(d,p,h);w?y.set(d.id,{id:d.id,...w}):b.push(d)}for(const{q:d,i:p}of l)De(p,h)===!1?y.set(d.id,{id:d.id,answer:"",sufficientInfo:!1}):b.push(d);if(m.length>0||b.length>0){const d=await Le(m,b,a,n);for(const w of d.questionAnswers)y.set(w.id,w);const p=new Map(d.checkboxDecisions.map(w=>[w.name+"\0"+w.label,w]));e.forEach((w,L)=>{f[L]||(f[L]=p.get(w.name+"\0"+w.label)??null)})}return{checkboxDecisions:f.filter(d=>d!==null),questionAnswers:t.map(d=>y.get(d.id)??{id:d.id,answer:"",sufficientInfo:!0})}}const re="(none of these)",ot="(not a profile field)",ct={salutation:"Salutation / title / gender as a form of address (Mr, Ms, Frau, Herr).",pronouns:"Preferred pronouns (she/her, he/him).",firstName:"The applicant's first / given name only.",lastName:"The applicant's last / family name only.",fullName:"The applicant's full name in one box.",email:"The applicant's e-mail address.",phone:"The applicant's phone / mobile number.",address:"Street and house number.",city:"City / town the applicant lives in.",postalCode:"Postal / ZIP code.",country:"Country the applicant lives in (not nationality, not where they want to work).",linkedin:"LinkedIn profile URL.",github:"GitHub profile URL.",website:"Personal website or portfolio URL.",expectedSalary:"The applicant's salary expectation as an amount (not a currency or period picker)."},Ii=[...Object.entries(ct).map(([e,t])=>({value:e,description:t})),{value:ot,description:"Anything else: an application question, a date, a company, a job title, a free comment, or a field about somebody else (a referrer, a reference, an emergency contact)."}],_i=`You help autofill a job-application form from the applicant's saved profile.
Two kinds of questions follow, each about one field of the form and independent of the others:
- Option questions: the field must be set to a value the applicant already gave, but its options word it differently
  (another language, an official name, a region added, an amount written as a range). Pick the option that means
  the same thing — the same country, the same city, the range containing the amount. When no option does, pick
  "${re}"; never pick a merely similar one.
- Field questions: from what the page says about a field (label, name, placeholder…), which profile value does it ask
  for? Only the applicant's own data counts; when unsure, "${ot}".
Labels may be in any language: judge by meaning.`;function Ri(e){var a,n;return[`label "${e.label}"`,`type ${e.kind}`,e.name&&`name "${e.name}"`,e.id&&`id "${e.id}"`,e.placeholder&&`placeholder "${e.placeholder}"`,e.ariaLabel&&`aria-label "${e.ariaLabel}"`,e.autocomplete&&`autocomplete "${e.autocomplete}"`,((a=e.other)==null?void 0:a.length)&&`nearby text ${e.other.map(i=>`"${i}"`).join(", ")}`,((n=e.options)==null?void 0:n.length)&&`options ${e.options.map(i=>`"${i}"`).join(", ")}`].filter(Boolean).join("; ")}function Oi(e){return{type:"choice",name:e.id,instructions:`Form field labelled "${e.label}" (the applicant's ${e.field}). The applicant's value: "${e.value}". Which option is that value?`,choices:[...new Set(e.options)].filter(t=>t!==re).map(t=>({value:t})).concat({value:re})}}function Ci(e){return[...e.optionPicks.filter(t=>t.options.length>0).map(Oi),...e.fieldKinds.map(t=>({type:"choice",name:t.id,instructions:`A form field with ${Ri(t.signals)}. Which of the applicant's profile values does it ask for?`,choices:Ii}))]}function Pi(e,t){return{optionPicks:e.optionPicks.filter(a=>t.has(a.id)).map(a=>{const n=G(t,a.id),i=n&&n.confidence>=U.optionMatch&&a.options.includes(n.choice);return{id:a.id,choice:i?n.choice:null}}),fieldKinds:e.fieldKinds.filter(a=>t.has(a.id)).map(a=>{const n=G(t,a.id),i=n&&n.confidence>=U.profileField&&n.choice in ct;return{id:a.id,field:i?n.choice:null}})}}async function xi(e){const t=Ci(e);if(t.length===0)return{optionPicks:[],fieldKinds:[]};const a=await M({input:_i,questions:t,promptCacheKey:"filler-field-decisions"});return Pi(e,a)}const Ni={type:"object",additionalProperties:!1,required:["postingLanguages","requirements","keywords","contact"],properties:{postingLanguages:{type:"array",items:{type:"string"}},requirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...$e,null]}}}},keywords:tt,contact:{type:["string","null"]}}},Mi=`You read a job posting and report three independent things about it: its
language, the skills it asks for (keywords), and (only if asked below) a recruiter/hiring
contact. Judge language and keywords against the applicant profile/CV/Personal Legend given
below.

LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- requirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or
  "Native" for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent",
  "professional working proficiency" -> "C1"; "conversational" -> "B1". If a language is
  mentioned but no level can be reasonably inferred, set level to null. Do not invent a
  requirement that isn't stated in the text. If nothing is stated, return an empty array.

${ue("the posting text (job title, description, requirements, responsibilities)")}

CONTACT
- "job.contact" below is the recruiter/hiring contact already found elsewhere, or null if none
  was found yet.
- If it is already set (not null), ignore this entirely and return "contact": null — there is
  nothing to add.
- If it is null, look for one in the job's own text (description/requirements/responsibilities):
  a named recruiter/hiring manager's email address, or a LinkedIn profile/company URL. If you
  find one, copy it VERBATIM (exact characters) so it can be re-found on the page for
  highlighting — the same rule as for keywords. If none is mentioned, return "contact": null.`;async function $i(e){const t=await S(),a=JSON.stringify({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,job:e},null,2),n=await E({schemaName:"job_brief",schema:Ni,model:await xe(),systemPrompt:Mi,userPrompt:a,parse:i=>JSON.parse(i)});return{language:{postingLanguages:n.postingLanguages,requirements:n.requirements},keywords:pe(n.keywords,e),contact:n.contact}}const ji={type:"object",additionalProperties:!1,required:["cvId","reason"],properties:{cvId:{type:"string"},reason:{type:"string"}}},Ui=`You pick which of an applicant's CVs to send to one job posting.
Each CV has an id, a name, the language it's written in, the applicant's own rules for which
postings it's for, and the start of its text.
- Prefer a CV written in the posting's language; if none, an English one.
- Then follow the applicant's rules: the CV whose rules fit this posting best.
- Then the one marked default for that language.
Return the chosen CV's exact "id" and a reason of at most 10 words. Plain text, no em dashes.`;async function qi(e,t,a){if(t.length<2)return null;const n=t.map((i,s)=>`cv${s+1}`);try{const i=await M({input:[{role:"user",content:[{type:"input_text",text:"A job posting the applicant is applying to:"},{type:"input_json",data:{position:e.position,company:e.company,location:e.location,language:a??null,techStack:e.techStack,description:e.description.slice(0,4e3)}}]}],questions:[{type:"choice",name:"cv",instructions:"Which of the applicant's CVs should be sent to this posting? Prefer a CV written in the posting's language (else an English one), then the one whose rules fit the posting best, then the one marked default for that language.",choices:t.map((o,c)=>({value:n[c],description:Di(o)}))}]}),s=G(i,"cv"),r=s?n.indexOf(s.choice):-1;return!s||r<0||s.confidence<U.cvChoice?null:{cvId:t[r].id,reason:"",source:"ai",confidence:s.confidence}}catch(i){if(i instanceof D)throw i;return console.warn("[Filler] Decisions API failed, choosing the CV via Responses:",i),Fi(e,t,a)}}function Di(e){var t;return[`Name: ${Ye(e)}.`,`Language: ${e.language?Ve(e.language):"not set"}${e.isDefaultForLanguage?" (default CV for that language)":""}.`,(t=e.rules)!=null&&t.trim()?`Applicant's rules for it: ${e.rules.trim()}`:"",`Starts: ${e.text.slice(0,600).replace(/\s+/g," ")}`].filter(Boolean).join(" ")}async function Fi(e,t,a){if(t.length<2)return null;const n={posting:{position:e.position,company:e.company,location:e.location,language:a??null,techStack:e.techStack,description:e.description.slice(0,4e3)},cvs:t.map(s=>({id:s.id,name:Ye(s),language:s.language?Ve(s.language):null,defaultForLanguage:!!s.isDefaultForLanguage,rules:s.rules??"",textStart:s.text.slice(0,1200)}))},i=await E({schemaName:"cv_choice",schema:ji,model:await He(),reasoningEffort:"low",systemPrompt:Ui,userPrompt:JSON.stringify(n,null,2),parse:s=>JSON.parse(s)});return t.some(s=>s.id===i.cvId)?{cvId:i.cvId,reason:i.reason.replace(/—/g,",").trim()||"AI pick",source:"ai"}:null}const Yi={type:"object",additionalProperties:!1,required:["values"],properties:{values:{type:"array",items:{type:"object",additionalProperties:!1,required:["name","value","reason"],properties:{name:{type:"string"},value:{type:"string"},reason:{type:"string"}}}}}},Vi=`You adapt an applicant's CV template to one specific job posting by
choosing a value for each {{placeholder}} in it.

Each variable comes with:
- "description": the applicant's own instruction for what the placeholder means and
  how to choose it. Follow it.
- "mode": "choice" means "value" MUST be exactly one of "options", copied verbatim
  (same spelling, same case, same line breaks). "free" means "options" are only
  examples of the expected shape and length; write the value that fits this posting
  in that same shape (e.g. a city name, a comma-separated list).
- "foundInPosting": options that literally occur in the posting text, most frequent
  first. A strong hint, not an order: the role's actual focus matters more than a
  passing mention.

Rules:
- Pick what makes this CV the closest honest match for this posting: its title, its
  location, its main technology, the vocabulary it uses.
- A job title / position value is the bare role name: no bracketed asides like (m/w/d),
  (f/m/d) or (Remote), no seniority level (Senior, Middle, Junior, Sr., Staff, Principal),
  no team, location or contract qualifiers. "Senior Backend Engineer (m/f/d)" -> "Backend Engineer".
- Honesty: never make the CV claim a skill, technology or experience the applicant's
  CV text / Personal Legend doesn't support, unless the variable's description
  explicitly asks for it. For list-like values, prefer terms that are both in the
  posting and supported by the applicant's background.
- Write the value in the same language as the surrounding template text.
- Return one entry per variable given, using its exact "name".
- "reason": one short sentence (max ~15 words) on why this value fits the posting.
- Plain text only, no markdown, no em dashes.`;function Hi(e,t){const a=i=>i.trim().replace(/\s+/g," ").toLowerCase(),n=a(e);return t.options.find(i=>a(i)===n)??null}async function Bi(e,t){const a=new Set(xt(t.content)),n=t.variables.filter(u=>a.has(u.name));if(n.length===0)return[];const i=await S(),s=n.filter(u=>u.mode==="choice"&&u.options.length>=2),r=n.filter(u=>!(u.mode==="choice"&&u.options.length>0)),[o,c]=await Promise.all([s.length>0?Ji(e,t,s,i):new Map,r.length>0?ut(e,t,r,i):new Map]);return n.map(u=>o.get(u.name)??c.get(u.name)??{name:u.name,value:Nt(u,e),reason:""})}const Gi=`You adapt an applicant's CV template to one specific job posting: for each {{placeholder}}
pick the variant that makes this CV the closest honest match for the posting (its title, its location,
its main technology, the vocabulary it uses). Follow the applicant's own instruction for the placeholder.
Variants that literally occur in the posting are a strong hint, not an order: the role's actual focus
matters more than a passing mention. Never pick a variant that claims a skill, technology or experience
the applicant's CV text / Personal Legend doesn't support, unless the instruction explicitly asks for it.`;async function Ji(e,t,a,n){const i=r=>`o${r+1}`,s=a.map((r,o)=>{const c=Be(r.options,e).map(u=>`${i(r.options.indexOf(u))} ("${u}")`);return{type:"choice",name:`v${o}`,instructions:[`CV placeholder {{${r.name}}}. Which variant should fill it for this posting?`,r.description.trim()?`The applicant's instruction for it: ${r.description.trim()}`:"",c.length>0?`Variants found verbatim in the posting, most frequent first: ${c.join(", ")}.`:""].filter(Boolean).join(`
`),choices:r.options.map((u,l)=>({value:i(l),description:u}))}});try{const r=await M({input:[{role:"developer",content:Gi},{role:"user",content:[{type:"input_json",data:{applicant:{cvText:n.cvText.slice(0,12e3),personalLegend:n.personalLegend.slice(0,8e3),city:n.profile.city,country:n.profile.country}}},{type:"input_json",data:{job:lt(e)}}]}],promptCacheKey:`filler-cv-values-${Mt(n.cvText+n.personalLegend)}`,questions:s}),o=new Map;return a.forEach((c,u)=>{const l=G(r,`v${u}`),h=l?c.options.findIndex((f,m)=>i(m)===l.choice):-1;!l||h<0||l.confidence<U.cvVariableChoice||o.set(c.name,{name:c.name,value:c.options[h],reason:`AI pick, ${Math.round(l.confidence*100)}% sure`})}),o}catch(r){if(r instanceof D)throw r;return console.warn("[Filler] Decisions API failed, picking CV variants via Responses:",r),ut(e,t,a,n)}}function lt(e){return{position:e.position,company:e.company,location:e.location,techStack:e.techStack,requirements:e.requirements,responsibilities:e.responsibilities,description:e.description.slice(0,8e3)}}async function ut(e,t,a,n){const i={variables:a.map(o=>({name:o.name,mode:o.mode,description:o.description,options:o.options,foundInPosting:Be(o.options,e)})),template:t.content.slice(0,12e3),job:lt(e),applicant:{cvText:n.cvText.slice(0,12e3),personalLegend:n.personalLegend.slice(0,8e3),city:n.profile.city,country:n.profile.country}},s=await E({schemaName:"cv_template_values",schema:Yi,model:await He(),systemPrompt:Vi,userPrompt:JSON.stringify(i,null,2),parse:o=>JSON.parse(o)}),r=new Map;for(const o of a){const c=s.values.find(l=>l.name===o.name);if(!c)continue;if(o.mode==="choice"&&o.options.length>0){const l=Hi(c.value,o);l&&r.set(o.name,{name:o.name,value:l,reason:T(c.reason)});continue}const u=T(c.value);r.set(o.name,{name:o.name,value:$t(o.name)?Ma(u,e):u,reason:T(c.reason)})}return r}async function pt(e){const t=await k(e);await Promise.all(t.map(a=>chrome.tabs.sendMessage(e,{type:"CANCEL_ELEMENT_PICKER",tabId:e},{frameId:a}).catch(()=>{})))}async function I(e,t,a){return(await Promise.all(t.map(i=>chrome.tabs.sendMessage(e,a,{frameId:i}).catch(()=>{})))).filter(i=>!!i)}async function Ae(e,t,a,n){if(a!==void 0&&t.includes(a)){const i=await chrome.tabs.sendMessage(e,n,{frameId:a}).catch(()=>{});if(i)return[i]}return I(e,t,n)}function zi(e){const t=new Map;for(const a of e){const n=a.locator.frameId;t.set(n,[...t.get(n)??[],a])}return t}async function Ki(e){switch(e.type){case"FILL_STATS_REPORT":{await Dt(e.run);return}case"DECIDE_FIELDS":return{type:"FIELD_DECISIONS",result:await xi(e.request)};case"GET_PROFILE":return{type:"PROFILE_DATA",profile:await z()};case"GET_JOB":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});if(!e.force&&(t!=null&&t.url)){const c=await Ut(t.url);if(c!=null&&c.position&&c.company)return{type:"JOB_DATA",job:c,sufficient:!0}}const a=await k(e.tabId),i=(await I(e.tabId,a,e)).filter(c=>c.type==="JOB_DATA");if(i.length===0)return;const s=i.find(c=>c.sufficient);if(s)return t!=null&&t.url&&qt(t.url,s.job),s;const r=i.reduce((c,u)=>u.job.description.length>c.job.description.length?u:c),o=i.map(c=>c.visibleText??"").filter(Boolean).join(`

`).slice(0,2e4);return{type:"JOB_DATA",job:r.job,sufficient:!1,visibleText:o||r.visibleText||"",pageUrl:t==null?void 0:t.url}}case"COMPLETE_JOB":{const{job:t,brief:a}=await Fa(e.job,e.text);return{type:"JOB_DATA",job:t,sufficient:!0,brief:a}}case"EXTRACT_JOB_FROM_TEXT":{const t=await chrome.tabs.get(e.tabId).catch(()=>{}),{job:a,brief:n}=await Ua(e.text,(t==null?void 0:t.url)??"");return{type:"JOB_DATA",job:a,sufficient:!0,brief:n}}case"AUTOFILL":{const t=await k(e.tabId),n=(await I(e.tabId,t,e)).filter(i=>i.type==="AUTOFILL_RESULT");return{type:"AUTOFILL_RESULT",filled:n.reduce((i,s)=>i+s.filled,0),total:n.reduce((i,s)=>i+s.total,0),generatedPassword:n.map(i=>i.generatedPassword).find(Boolean)??null}}case"GENERATE_COVER_LETTER":{const{tabId:t}=e,a=e.job.url;let n="",i=0;await Y(t,{jobUrl:a,status:"generating",content:""});let s;try{s=await Ta(e.job,e.postingLanguage,r=>{chrome.runtime.sendMessage({type:"COVER_LETTER_STREAM_CHUNK",tabId:t,delta:r}).catch(()=>{}),n+=r,Date.now()-i>400&&(i=Date.now(),Y(t,{jobUrl:a,status:"generating",content:n}).catch(()=>{}))})}catch(r){const o=r instanceof Error?r.message:String(r);throw await Y(t,{jobUrl:a,status:"error",content:"",error:o}).catch(()=>{}),r}return await Y(t,{jobUrl:a,status:"done",content:s.content,cleanedPatterns:s.cleaned?Array.from(new Set(s.slopFindings.map(r=>r.pattern))):[]}),await ee("lastCoverLetter",s.content),{type:"COVER_LETTER_RESULT",content:s.content,slopFindings:s.slopFindings,cleaned:s.cleaned}}case"UPLOAD_FILE":{const t=await k(e.tabId),n=(e.targetLocator?await Ae(e.tabId,t,e.targetLocator.frameId,e):await I(e.tabId,t,e)).filter(i=>i.type==="UPLOAD_FILE_RESULT");return{type:"UPLOAD_FILE_RESULT",nativeInputs:n.reduce((i,s)=>i+s.nativeInputs,0),dropZones:n.reduce((i,s)=>i+s.dropZones,0)}}case"REVISE_COVER_LETTER":{const t=await Va(e.content,e.instructions,e.job);return await ee("lastCoverLetter",t),{type:"REVISE_COVER_LETTER_RESULT",content:t}}case"TRANSLATE_COVER_LETTER":return{type:"TRANSLATE_COVER_LETTER_RESULT",content:await Ja(e.content,e.targetLanguage)};case"GENERATE_OUTREACH_MESSAGE":{const t=await S(),a=await Aa({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,outreachRules:t.outreachRules,job:e.job,contact:e.contact,postingLanguage:e.postingLanguage});return{type:"OUTREACH_MESSAGE_RESULT",subject:a.subject,body:a.body}}case"REVISE_OUTREACH_MESSAGE":{const t=await Ba({subject:e.subject,body:e.body},e.instructions,e.job);return{type:"OUTREACH_MESSAGE_RESULT",subject:t.subject,body:t.body}}case"GET_FRAME_ACCESS":return{type:"FRAME_ACCESS",blockedOrigins:await Gt(e.tabId)};case"DETECT_CUSTOM_QUESTIONS":{const t=await k(e.tabId),a=await I(e.tabId,t,e),n=new Set,i=[];for(const s of a)if(s.type==="CUSTOM_QUESTIONS_DATA")for(const r of s.questions)n.has(r.question)||(n.add(r.question),i.push({...r,id:`question-${i.length}`}));return{type:"CUSTOM_QUESTIONS_DATA",questions:i}}case"ANSWER_CUSTOM_QUESTION":{const t=await mi(e.question,e.job,e.options,e.numeric,e.dateKind,e.multi,e.postingLanguage,e.catchAll);return{type:"CUSTOM_QUESTION_ANSWER",question:e.question,answer:t.answer,sufficientInfo:t.sufficientInfo}}case"FILL_CUSTOM_QUESTION_ANSWERS":{const t=await k(e.tabId),a=await I(e.tabId,t,e);let n=0;const i=[];for(const s of a)s.type==="CUSTOM_QUESTION_FILL_RESULT"&&(n+=s.filled,i.push(...s.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:n,unfilled:i}}case"START_ELEMENT_PICKER":{const t=await k(e.tabId),a=t.map(i=>chrome.tabs.sendMessage(e.tabId,e,{frameId:i}).then(s=>s?{result:s,frameId:i}:void 0).catch(()=>{})),n=await new Promise(i=>{let s=a.length;s===0&&i(void 0);for(const r of a)r.then(o=>{s-=1,o?i(o):s===0&&i(void 0)})});return await Promise.all(t.map(i=>chrome.tabs.sendMessage(e.tabId,{type:"CANCEL_ELEMENT_PICKER",tabId:e.tabId},{frameId:i}).catch(()=>{}))),n?{...n.result,picked:n.result.picked.map(i=>({...i,locator:{...i.locator,frameId:n.frameId}}))}:{type:"ELEMENT_PICKER_RESULT",cancelled:!0,picked:[],blockText:"",semanticCount:0}}case"CANCEL_ELEMENT_PICKER":{await pt(e.tabId);return}case"DECOMPOSE_BLOCK":return{type:"BLOCK_QUESTIONS",questions:await vi(e.blockText,e.fields)};case"FILL_QUESTION_ANSWERS_BY_LOCATOR":{const t=await k(e.tabId),a=(await Promise.all([...zi(e.items)].map(([s,r])=>Ae(e.tabId,t,s,{...e,items:r})))).flat();let n=0;const i=[];for(const s of a)s.type==="CUSTOM_QUESTION_FILL_RESULT"&&(n+=s.filled,i.push(...s.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:n,unfilled:i}}case"DETECT_CHECKBOXES":{const t=await k(e.tabId),a=await I(e.tabId,t,e),n=new Set,i=[];for(const s of a)if(s.type==="CHECKBOXES_DATA")for(const r of s.checkboxes){const o=r.name||r.label;!o||n.has(o)||(n.add(o),i.push({...r,id:`checkbox-${i.length}`}))}return{type:"CHECKBOXES_DATA",checkboxes:i}}case"DECIDE_PAGE_CONTENT":{const{checkboxDecisions:t,questionAnswers:a}=await Li(e.checkboxes,e.questions,e.job,e.postingLanguage);return{type:"PAGE_CONTENT_DECISIONS",checkboxDecisions:t,questionAnswers:a}}case"APPLY_CHECKBOX_DECISIONS":{const t=await k(e.tabId),a=await I(e.tabId,t,e);let n=0;for(const i of a)i.type==="CHECKBOX_APPLY_RESULT"&&(n+=i.changed);return{type:"CHECKBOX_APPLY_RESULT",changed:n}}case"DETECT_JOB_BRIEF":{const t=await $i(e.job);return{type:"JOB_BRIEF_DATA",language:t.language,keywords:t.keywords,contact:t.contact}}case"HIGHLIGHT_KEYWORDS":{const t=await k(e.tabId);return{type:"KEYWORD_HIGHLIGHT_RESULT",matched:(await I(e.tabId,t,e)).reduce((i,s)=>s.type==="KEYWORD_HIGHLIGHT_RESULT"?i+s.matched:i,0)}}case"CLEAR_KEYWORD_HIGHLIGHTS":{const t=await k(e.tabId);await I(e.tabId,t,e);return}case"GENERATE_FAQ_ANSWERS":{const t=await Oe(),a=await sn(e.questions,t);try{await jt(a)}catch{}return{type:"FAQ_ANSWERS_RESULT",entries:a}}case"SEARCH_JOBS":{const{searchId:t}=e,a=t?i=>{chrome.runtime.sendMessage({type:"JOB_SEARCH_PROGRESS",searchId:t,results:i}).catch(()=>{})}:void 0,n=setInterval(()=>void chrome.runtime.getPlatformInfo().catch(()=>{}),2e4);try{return{type:"JOB_SEARCH_RESULTS",...await sa(e.query,{page:e.page,excludeResults:e.excludeResults,onResults:a})}}finally{clearInterval(n)}}case"SUGGEST_SEARCH_QUERY":{const{what:t,where:a,tags:n}=await Qe(e.provider==="adzuna");return{type:"SEARCH_QUERY_SUGGESTION",what:t,where:a,...e.provider==="adzuna"?{tags:n}:{}}}case"SUGGEST_CV_VALUES":return{type:"CV_VALUES",values:await Bi(e.job,e.template)};case"CHOOSE_CV":return{type:"CV_CHOICE",choice:await qi(e.job,e.cvs,e.postingLanguage)};default:return}}const Wi="src/sidepanel/index.html";chrome.runtime.onInstalled.addListener(()=>{Wt(),chrome.sidePanel.setOptions({enabled:!1})});chrome.contextMenus.onClicked.addListener((e,t)=>{Xt(e,t)});chrome.action.onClicked.addListener(e=>{if(e.id===void 0)return;const t=e.id;chrome.sidePanel.setOptions({tabId:t,path:`${Wi}?tabId=${t}`,enabled:!0}),chrome.sidePanel.open({tabId:t}).catch(a=>console.error("sidePanel.open failed",a)),Qi(t)});async function Qi(e){await k(e);const t={type:"TAB_ACCESS_GRANTED",tabId:e};await chrome.runtime.sendMessage(t).catch(()=>{})}chrome.tabs.onRemoved.addListener(e=>{Ft(e)});chrome.runtime.onMessage.addListener((e,t,a)=>(Ki(e).then(a).catch(n=>{a({type:"ERROR",error:n instanceof Error?n.message:String(n),code:n instanceof Error?n.name:void 0})}),!0));chrome.runtime.onConnect.addListener(e=>{const t=/^picker-(\d+)$/.exec(e.name);if(!t)return;const a=Number(t[1]);e.onDisconnect.addListener(()=>{pt(a)})});
