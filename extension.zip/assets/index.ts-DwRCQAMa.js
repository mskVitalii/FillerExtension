import{P as W,g as j,a as $,b as X,c as Z,s as ee,d as T,e as Y,f as te,h as ne,i as ae,j as F,r as h,t as I,k as D,M as H,A as B,l as se,m as oe,n as J,o as ie,p as re,q as ce,D as le,C as pe,u as ue,v as de,w as he,x as k,y as R,z as ge,B as C,E as fe,F as A,G as me}from"./template-DrlEioLn.js";import{c as ye,a as we}from"./phone-CZ16BBLi.js";const G={...W,cv:"CV",coverLetter:"Cover Letter",generatePassword:"Generated password"},be=Object.keys(G);async function d(e){try{const t=(await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:["content-script.js"]})).map(o=>o.frameId).filter(o=>typeof o=="number");if(t.length>0)return t}catch{}try{return await chrome.scripting.executeScript({target:{tabId:e},files:["content-script.js"]}),[0]}catch{return[0]}}async function ve(e,s){if(e==="cv"){const n=await j();return(n==null?void 0:n.text)??""}if(e==="coverLetter")return await $("lastCoverLetter")??"";if(e==="generatePassword"){const n=await X(s);if(n!=null&&n.generatedPassword)return n.generatedPassword;const a=Z();return n&&await ee(s,{...n,generatedPassword:a}),a}const t=await T(),o=t[e]??"";return e==="phone"&&o?ye(o,t.country):o}const E="job-app-assistant-insert",Ee={generatePassword:"Generate password"},Se=be.map(e=>({id:e,title:Ee[e]??G[e]}));function Te(){chrome.contextMenus.removeAll(()=>{chrome.contextMenus.create({id:E,title:"Insert",contexts:["editable"]});for(const e of Se)chrome.contextMenus.create({id:`${E}:${e.id}`,parentId:E,title:e.title,contexts:["editable"]})})}function _e(e){return e.startsWith(`${E}:`)?e.slice(E.length+1):null}async function Le(e,s){if(!(s!=null&&s.id)||typeof e.menuItemId!="string")return;const t=_e(e.menuItemId);if(!t)return;const o=await ve(t,s.id);await d(s.id);const n={type:"INSERT_VALUE",field:t,value:o};chrome.tabs.sendMessage(s.id,n,{frameId:e.frameId}).catch(()=>{})}const Ie=new Set(["profileCache","cvLibraryCache","legendLibraryCache","customFieldsCache","languageLevelsCache","faqAnswersCache","generationRulesCache"]);let w=null;function Pe(){return Promise.all([T(),j(),Y(),te(),ne(),ae(),F()]).then(([e,s,t,o,n,a,i])=>({profile:e,cvText:(s==null?void 0:s.text)??"",personalLegend:(t==null?void 0:t.content)??"",generationRules:(o==null?void 0:o.content)??"",languageLevels:n,customFields:a,faq:i}))}function m(){return w||(w=Pe(),w.catch(()=>{w=null})),w}var U;typeof chrome<"u"&&((U=chrome.storage)!=null&&U.onChanged)&&chrome.storage.onChanged.addListener((e,s)=>{s==="local"&&Object.keys(e).some(t=>Ie.has(t))&&(w=null)});const S=`Write like a specific person, not an AI assistant. These rules have no exceptions:

- NEVER use an em dash ("—"), a spaced en dash ("–") or "--" as punctuation. Real people don't write that way. Use a comma, a period, parentheses, or two sentences.
- Banned words: delve, foster, leverage, utilize, facilitate, empower, streamline, robust, cutting-edge, paradigm shift, game changer, tapestry, realm, beacon, multifaceted, meticulous, intricate, paramount, transformative, elevate, embark, supercharge, harness, ever-evolving. Say the plain thing.
- Cut empty phrases: "it's worth noting", "at the end of the day", "when it comes to", "at its core", "in today's world", "the reality is", "in order to", "going forward".
- No "not X, it's Y" / "the question isn't X, it's Y" / "not just X but Y" contrasts. State Y directly.
- No throat-clearing openers ("Here's the thing", "Let me be clear", "I'll be honest") and no faux-insight setups ("what most people get wrong", "here's what nobody tells you").
- No importance puffery ("stands as a testament", "marks a pivotal moment", "plays a vital role", "underscores its significance"). State the fact and stop.
- No colon reveals: a noun phrase, a colon, then a dramatic lowercase clause.
- No trailing "-ing" clauses that editorialize ("highlighting the commitment to...", "underscoring its importance", "showcasing", "reflecting"). End the sentence.
- No metadiscourse that tells the reader what to notice ("this matters", "this distinction matters", "in other words", "as you can see").
- No "In conclusion" / "Ultimately" / "Overall" recap ending and no cute one-line kicker. Stop on the last concrete point.
- No emoji, no mid-sentence bold, no rhetorical questions.
- Vary sentence shape; don't stack short punchy fragments.
- Be concrete: name the technology, project, number, or outcome instead of calling it "significant", "impactful" or "exciting". Use active voice.`;function f(e){return e.replace(/[ \t]*[—―][ \t]*/g,", ").replace(/[ \t]+--[ \t]+/g,", ").replace(/(\D)[ \t]+–[ \t]+(?=\D)/g,"$1, ").replace(/[ \t]+([,.;:!?])/g,"$1").replace(/,(\s*[.;:!?])/g,"$1").replace(/,[ \t]*,/g,",").replace(/^[ \t]*,[ \t]*/gm,"").replace(/([([{])[ \t]*,[ \t]*/g,"$1").replace(/[ \t]*,[ \t]*([)\]}])/g,"$1").replace(/,[ \t]*$/gm,"").replace(/[ \t]+$/gm,"")}const Oe=`You write the applicant's own answers to standard interview-FAQ
questions (spec_5 section B) — general-purpose answers meant to be reused, as-is or
lightly adapted, whenever a real application form asks a close variant of one of them.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend, and
  custom fields. Never invent experience, technologies, companies, education,
  achievements, or a concrete salary figure that wasn't actually given.
- If information needed for a good answer is missing (no CV, no Personal Legend
  content covering it), write a short, honest, generically true answer rather
  than fabricating specifics — the applicant can always sharpen it later.
- Keep each answer 2-5 sentences: concrete and confident, never generic
  corporate filler, no restating the question.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text per answer, no markdown, no numbering.

${S}`;function ke(e){return{type:"object",additionalProperties:!1,required:["answers"],properties:{answers:{type:"array",minItems:e,maxItems:e,items:{type:"string"}}}}}async function Re(e){if(e.length===0)return[];const{profile:s,cvText:t,personalLegend:o,generationRules:n,customFields:a}=await m(),i=JSON.stringify({profile:s,cvText:t,personalLegend:o,generationRules:n,customFields:a,questions:e},null,2),r=await h({schemaName:"faq_answers",schema:ke(e.length),systemPrompt:Oe,userPrompt:i,parse:l=>JSON.parse(l)});return e.map((l,c)=>({question:l,answer:f(r.answers[c]??"")}))}async function Ce(e,s){const t=new Map(s.map(a=>[a.question,a.answer])),o=e.filter(a=>{var i;return!((i=t.get(a))!=null&&i.trim())}),n=await Re(o);for(const a of n)t.set(a.question,a.answer);return e.map(a=>({question:a,answer:t.get(a)??""}))}async function b(e,s,t){const o=performance.now();try{return await t()}finally{e==null||e.push({label:s,ms:performance.now()-o})}}const Ae={type:"object",additionalProperties:!1,required:["jobs"],properties:{jobs:{type:"array",items:{type:"object",additionalProperties:!1,required:["title","company","location","url","salary","snippet","postedAt"],properties:{title:{type:"string"},company:{type:"string"},location:{type:"string"},url:{type:"string"},salary:{type:"string"},snippet:{type:"string"},postedAt:{type:"string"}}}}}};function Ne(e){return`You turn raw web-search results about job openings into a clean,
structured list. The input text was produced by a live internet search and may include
citations, markdown links, or unrelated surrounding prose — extract only genuine
individual job postings from it.

Rules:
- Only include entries that are clearly actual job postings with a real listing URL —
  never a company's generic careers-page homepage, a search-results page, or an
  aggregator's category page.
- "url" must be copied exactly from the source text (never invented).
- "salary" is "" when no figure was given — never guess one.
- "postedAt" is the date the posting was published, as YYYY-MM-DD, only when the text
  states it. Resolve relative dates ("posted 3 days ago", "2w") against today, ${e}.
  Use "" when no date is given — never guess one.
- Drop postings the text marks as closed, expired, filled or "no longer accepting
  applications", and postings published more than ${H} days before ${e}.
- "snippet" is a 1-2 sentence summary of the role; when a "candidate" background is given
  below, make it say *why this posting fits them* specifically (seniority match, matching
  skills, location/remote fit) rather than just restating the posting.
- If a "candidate" background is given, drop postings that are a poor fit for them (wrong
  seniority, unrelated field) even if they're genuine job postings — only surface ones
  actually worth their time.
- Deduplicate: the same posting linked twice becomes one entry.
- If nothing in the text is actually a job posting, return an empty "jobs" array.`}async function V(e,s,t){const o=t?`candidate:
${t}

---

${e.slice(0,4e4)}`:e.slice(0,4e4),n=await h({schemaName:"job_listings",schema:Ae,systemPrompt:Ne(I()),userPrompt:o,parse:a=>JSON.parse(a)});return D(n.jobs.filter(a=>a.url.trim()).map(a=>({...a,source:s})))}function K(e){return e.length===0?"":`

Already found and shown to the applicant — do NOT return any of these again,
find genuinely different postings instead:
${e.map(t=>`- ${t.title} at ${t.company} (${t.url})`).join(`
`)}`}async function xe(e,s,t=[],o){const n=e.remoteOnly?" Prefer remote-friendly roles.":"",a=[e.what?`Role/keywords focus: "${e.what}".`:"",e.where?`Location: "${e.where}".`:"",n].filter(Boolean).join(" "),i=`Search the web for current, actually open job postings that fit this
candidate:

${s||"(no candidate background available)"}

${a||"No further constraints — use the candidate's own background to pick a fitting role/location."}

Today is ${I()}. Only include postings published in the last ${H} days
that are still accepting applications — skip anything marked closed, expired or filled,
or shown with an older date.
Prefer the employer's own posting on its applicant tracking system (${B.join(", ")})
or career page over copies on aggregators, which often outlive the real posting.

Find real postings with their direct listing URL, not a search results page. List up to
15 of the best matches, each with its title, company, location, salary if stated, the date
it was posted when shown, and a short description of why it fits.${K(t)}`,r=await b(o,"Web search",()=>se(i));return b(o,"Parse results",()=>V(r,"openai",s))}const qe="https://api.tavily.com/search",Me=2e3;async function Ue(e,s,t,o=[],n){const a=e.remoteOnly?" Prefer remote-friendly roles.":"",r=`Find job postings from the last few weeks, still open, that fit this candidate.
${[e.what?`Role/keywords focus: "${e.what}".`:"",e.where?`Location: "${e.where}".`:"",a].filter(Boolean).join(" ")}

Candidate background: ${t||"(none available)"}${K(o)}`.trim().slice(0,Me),l=await b(n,"Tavily search",()=>fetch(qe,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({api_key:s,query:r,search_depth:"advanced",max_results:15,include_answer:!1,time_range:"month",include_published_date:!0,include_domains:B,include_domains_mode:"prefer"})}));if(!l.ok){const p=await l.text().catch(()=>"");throw new Error(`Tavily search failed (${l.status}): ${p.slice(0,300)}`)}const c=await l.json();if(c.results.length===0)return[];const u=c.results.map(p=>`Title: ${p.title}
URL: ${p.url}
${p.published_date?`Published: ${p.published_date}
`:""}${p.content}`).join(`

---

`);return b(n,"Parse results",()=>V(u,"tavily",t))}function je(e,s){return!e&&!s?"":oe({low:Math.round(e??s??0),high:Math.round(s??e??0)})}function $e(e){return new Promise(s=>setTimeout(s,e))}const Ye=350;async function Fe(e,s,t,o,n){const a=new URL(`https://api.adzuna.com/v1/api/jobs/${o}/search/${n}`);a.searchParams.set("app_id",t.appId),a.searchParams.set("app_key",t.appKey),a.searchParams.set("results_per_page","15"),a.searchParams.set("content-type","application/json"),e&&a.searchParams.set("what",e),s&&a.searchParams.set("where",s);const i=await fetch(a.toString());if(!i.ok){const c=await i.text().catch(()=>"");throw new Error(`Adzuna search failed (${i.status}): ${c.slice(0,300)}`)}const l=(await i.json()).results.map(c=>{var u,p;return{title:c.title,company:((u=c.company)==null?void 0:u.display_name)??"",location:((p=c.location)==null?void 0:p.display_name)??"",url:c.redirect_url,salary:je(c.salary_min,c.salary_max),snippet:(c.description??"").slice(0,300),postedAt:c.created??"",source:"adzuna",tag:e}});return D(l)}async function De(e,s,t,o=1){const n=e.tags&&e.tags.length>0?e.tags:[e.what],a=new Set,i=[],r=[];for(let l=0;l<n.length;l++){const c=n[l];try{const u=await Fe(c,e.where,s,t,o);for(const p of u)a.has(p.url)||(a.add(p.url),i.push(p))}catch(u){r.push(`"${c}" — ${u instanceof Error?u.message:"search failed"}`)}l<n.length-1&&await $e(Ye)}return{results:i,warnings:r}}const He=new Set(["AT","AU","BE","BR","CA","CH","DE","ES","FR","GB","IN","IT","MX","NL","NZ","PL","RU","SG","US","ZA"]);function Be(e){var t;const s=(t=we(e))==null?void 0:t.toUpperCase();return s&&He.has(s)?s.toLowerCase():"us"}const Je={type:"object",additionalProperties:!1,required:["what","where"],properties:{what:{type:"string"},where:{type:"string"}}},Ge=`You suggest a starting job-search query for the applicant described below.
"what" is a short role/keywords phrase (e.g. "senior backend engineer", "product designer") —
their most recent or clearly strongest role from the CV/Personal Legend. Pick ONE single title:
never join multiple roles or technologies with "/", "," or parentheses (e.g. never "Full-Stack
Developer / Backend Engineer (Go, Python, React)") — that reads as a combined AND-match to a
literal keyword search and returns nothing. "where" is a location (city, region, or country) —
their stated city/country if given, else "".
Output only the two fields, no explanation.`;async function L(){const{profile:e,cvText:s,personalLegend:t}=await m(),o=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:s,personalLegend:t},null,2),n=await h({schemaName:"job_search_query_suggestion",schema:Je,systemPrompt:Ge,userPrompt:o,parse:a=>JSON.parse(a)});return{what:n.what,where:n.where||[e.city,e.country].filter(Boolean).join(", ")}}const Ve={type:"object",additionalProperties:!1,required:["tags"],properties:{tags:{type:"array",items:{type:"string"}}}},Ke=`You generate keyword search tags for Adzuna's job-search API, grounded in
the candidate's real background below. Per Adzuna's own docs
(https://developer.adzuna.com/docs/search), "what" is a single literal keyword/phrase match, not
a semantic search and not a boolean query — so ONE combined tag naming several technologies or
role variants (e.g. "Full-Stack Developer / Backend Engineer (Go, Python, React)") matches
nothing. You compensate by generating a small cross-product of short, atomic tags instead, each
run as its own separate search and merged afterwards.

Method — build the tags as a cross-product, exactly like this worked example for a candidate
whose strongest stack is Go and who also does full-stack/backend work:
  golang developer, go developer, go engineer, golang engineer,
  backend engineer, backend developer, fullstack engineer, fullstack developer,
  software engineer, software developer
That is: {primary technology + its common short aliases} × {developer, engineer}, PLUS
{their role-shape words, e.g. backend / fullstack / frontend / mobile / data — whichever
genuinely apply, without a technology} × {developer, engineer}, PLUS a generic "software
developer" / "software engineer" fallback pair.

Rules:
- Base every tag on their actual, strongest-fitting technology/field from the CV/Personal
  Legend — never invent a technology, role-shape, or seniority they don't have.
- Identify the ONE primary technology (e.g. "Go") plus its common short aliases people actually
  search with (e.g. "Golang") — do not alias unrelated technologies together.
- Each tag pairs exactly one technology-or-role-shape word with exactly one of "developer" /
  "engineer" (add "programmer" only if that's a genuinely common term for that stack). Never put
  two technologies, or a technology and a role-shape, in the same tag.
- If the CV shows a clear secondary technology/stack, budget permitting, add its own couple of
  tags the same way — still never combined with the primary one in a single tag.
- For EACH language listed in "languages" below (skip English), also include ONE of the
  strongest-technology tags translated into that language using the natural job-title term a
  native speaker would search with (not a literal word-for-word translation).
- Each tag is 1-3 words, lowercase, and never contains "/", ",", "(", ")", or a seniority
  qualifier ("senior", "junior", etc.).
- Deduplicate. Return 6-12 tags total, most relevant first.
- Output only the tags, no explanation.`;async function N(){const{profile:e,cvText:s,personalLegend:t,languageLevels:o}=await m(),n=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:s,personalLegend:t,languages:o.map(i=>i.language)},null,2);return(await h({schemaName:"job_search_tags",schema:Ve,systemPrompt:Ke,userPrompt:n,parse:i=>JSON.parse(i)})).tags.map(i=>i.trim()).filter(Boolean)}const Qe={type:"object",additionalProperties:!1,required:["keyRequirements","relevantExperienceHints","suggestedTone","suggestedFocus"],properties:{keyRequirements:{type:"array",items:{type:"string"}},relevantExperienceHints:{type:"array",items:{type:"string"}},suggestedTone:{type:"string"},suggestedFocus:{type:"string"}}};async function ze(e){return h({schemaName:"job_analysis",schema:Qe,model:await J(),systemPrompt:"You analyze job postings for a job-application assistant. Identify the most important requirements and what an applicant should emphasize. Do not invent details that are not present in the posting.",userPrompt:JSON.stringify(e,null,2),parse:s=>JSON.parse(s)})}const We=`You write tailored cover letters for job applications.

The user message holds the applicant's data as JSON, and may end with an
"Applicant's rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and
   Personal Legend. Never invent experience, technologies, companies,
   education, or achievements, even if the applicant's rules ask for them.
   If information needed to be compelling is missing, write around it
   honestly rather than fabricating it.
2. The applicant's rules. Follow every instruction there on tone, length,
   structure, language, and what to include or avoid, including where it
   departs from the defaults below. Every rule there applies to the whole
   letter, not just the opening.
3. Language. If "postingLanguage" is given, write the entire letter in that
   language, using the salutation, register, and closing conventions native
   speakers of it would expect on a job application (e.g. formal
   "Sie"/"Herr"/"Frau" address and a "Sehr geehrte(r) ..." opening in German,
   not a literal English-to-German translation).
4. The house style below. Its "no exceptions" means no exceptions of your
   own; an explicit applicant rule still overrides it.
5. Tone and emphasis tailored to the job analysis provided.

Output plain prose paragraphs, no markdown headers.

${S}`;async function Xe(e,s){const o=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,analysis:e.analysis,postingLanguage:e.postingLanguage||void 0},null,2)+Q(e.generationRules),n=await ie(We,o,s??(()=>{}));return f(n)}function Q(e){const s=e.trim();return s?`

## Applicant's rules (highest priority after facts)

${s}
`:""}const Ze={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},et=`You are a sharp human editor cleaning up a cover letter draft.

Fix ONLY the flagged AI-writing patterns listed below. Make the minimum
effective edit — do not rewrite sentences that were not flagged, do not
change facts, experience, technologies, or claims, and do not add new
content. Replace banned words/clichés with plain, concrete language.
Rewrite "not X, it's Y" contrasts as a direct statement of Y. Cut
throat-clearing openers, weasel attribution, and importance-puffery instead
of softening them. If the ending is a generic summary/recap, end on the
letter's last concrete point instead. Replace every em dash ("—") with a
comma, a period, or parentheses.

The user message may end with the applicant's own rules for the letter. If a
flagged pattern is something those rules explicitly ask for, leave it as is:
the applicant's rules outrank the house style.

Do not introduce any new AI-slop while editing. For reference, the full
house style is:

${S}

Output plain prose paragraphs, no markdown headers.`;async function tt(e,s,t=""){const o=JSON.stringify({draft:e,flaggedPatterns:s.map(a=>`${a.pattern}: "${a.match}"`)},null,2)+Q(t),n=await h({schemaName:"cover_letter_polish",schema:Ze,systemPrompt:et,userPrompt:o,parse:a=>JSON.parse(a)});return f(n.content)}const nt=["delve","foster","leverage","utilize","facilitate","empower","streamline","robust","cutting-edge","paradigm shift","game changer","this is huge","this changes everything","tapestry","realm","beacon","multifaceted","meticulous","intricate","paramount","transformative","elevate","embark","supercharge","harness","ever-evolving"],at=["it's worth noting","it is worth noting","it's important to note","it is important to note","at the end of the day","when it comes to","at its core","in today's world","in the age of","in the world of","the reality is","the truth is","in terms of","with regard to","in order to","going forward"],st=["here's the thing","here's what i mean","let me be clear","i'll be honest","the uncomfortable truth is"],ot=["this is the part most people skip","what most people get wrong","here's what nobody tells you","the part everyone misses"],it=["stands as a testament","marks a pivotal moment","plays a vital role","solidifies its position","underscores its significance"],rt=["experts agree","industry reports suggest","many argue","widely regarded as","studies show"],ct=[/^in conclusion\b/i,/^ultimately\b/i,/^overall\b/i];function lt(e){const s=e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`\\b${s.replace(/ /g,"\\s+")}\\b`,"i")}function y(e,s,t){const o=[];for(const n of s){const a=lt(n).exec(e);a&&o.push({pattern:t,match:a[0]})}return o}function pt(e){const s=/\b(?:isn'?t|is not)\b[^.!?]{3,60}[,.]?\s*(?:it'?s|it is)\b[^.!?]{3,80}[.!?]/i,t=/\bnot just\b[^.!?]{3,60}(?:\bbut\b|[,.]?\s*(?:it'?s|it is)\b)[^.!?]{0,80}[.!?]/i,o=[],n=s.exec(e);n&&o.push({pattern:"binary-contrast",match:n[0].trim()});const a=t.exec(e);return a&&o.push({pattern:"binary-contrast",match:a[0].trim()}),o}function ut(e){const s=e.split(/\n{2,}/).map(o=>o.trim()).filter(Boolean),t=s[s.length-1];if(!t)return[];for(const o of ct)if(o.test(t))return[{pattern:"summary-recap-ending",match:t.slice(0,60)}];return[]}function dt(e){const s=(e.match(/—/g)??[]).length;return s===0?[]:[{pattern:"em-dash",match:s===1?"1 em dash":`${s} em dashes`}]}function ht(e){return[...y(e,nt,"banned-word"),...y(e,at,"empty-phrase"),...y(e,st,"throat-clearing-opener"),...y(e,ot,"faux-insight-setup"),...y(e,it,"importance-puffery"),...y(e,rt,"weasel-attribution"),...pt(e),...ut(e),...dt(e)]}async function gt(e,s,t){const o=await m(),n=await ze(e),a=await Xe({profile:o.profile,cvText:o.cvText,personalLegend:o.personalLegend,generationRules:o.generationRules,job:e,analysis:n,postingLanguage:s},t),i=ht(a);return i.length===0?{content:a,slopFindings:i,cleaned:!1}:{content:await tt(a,i,o.generationRules),slopFindings:i,cleaned:!0}}const ft={type:"object",additionalProperties:!1,required:["company","position","location","description","requirements","responsibilities","salary","techStack","contact"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},description:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]}}};async function x(e,s){return{...await h({schemaName:"job_extraction",schema:ft,model:await re(),systemPrompt:"Extract structured job posting fields from the visible page text below. Only use information present in the text; leave fields empty/null if unknown.",userPrompt:e.slice(0,12e3),parse:o=>JSON.parse(o)}),url:s}}const mt={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},yt=`You are editing an existing cover letter draft on the applicant's
instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the
  letter the instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements
  that aren't already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the
  instruction explicitly asks to change it.
- Output plain prose paragraphs, no markdown headers.
- Don't introduce AI-slop while editing, and clean it from any sentence you
  touch.

${S}`;async function wt(e,s,t){const o=JSON.stringify({draft:e,instructions:s,job:t},null,2),n=await h({schemaName:"cover_letter_revision",schema:mt,model:await ce(),systemPrompt:yt,userPrompt:o,parse:a=>JSON.parse(a)});return f(n.content)}const bt={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},vt=`You translate a cover letter for the applicant's own understanding —
not for submission. Translate faithfully, preserve paragraph breaks, and keep
names, companies, and technical terms as-is where translating them would be
unnatural. Do not use em dashes ("—"); use commas or periods. Output plain
prose paragraphs, no markdown headers, no notes about the translation itself.`;async function Et(e,s){const t=JSON.stringify({content:e,targetLanguage:s},null,2),o=await h({schemaName:"cover_letter_translation",schema:bt,systemPrompt:vt,userPrompt:t,parse:n=>JSON.parse(n)});return f(o.content)}const St={type:"object",additionalProperties:!1,required:["answer","sufficientInfo"],properties:{answer:{type:"string"},sufficientInfo:{type:"boolean"}}},q=`You answer a custom question from a job application form on the
applicant's behalf.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend,
  cover letter, custom fields, language levels, and job posting. Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, the
  "languageLevels" list is the authoritative answer (CEFR levels the
  applicant self-reported in Settings) — use it directly rather than
  guessing from the CV or defaulting to a low/neutral level.
- If the profile/CV/Personal Legend/etc genuinely lack what's needed to
  answer this question — not just a minor detail, but the actual substance
  being asked for — set "sufficientInfo" to false and "answer" to an empty
  string. Do NOT write a sentence explaining that you don't have the
  information (e.g. "I don't have this information available") — that text
  would otherwise get typed straight into the applicant's form field, which
  is worse than leaving it blank for the applicant to fill in themselves.
  Only do this when the information is truly absent; a question you can
  answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient —
  set sufficientInfo to true and give that honest answer.
- If "postingLanguage" is given, write the answer in that language, using
  the salutation/register conventions native speakers of it would expect on
  a job application (e.g. formal "Sie"/"Herr"/"Frau" address in German, not
  a literal English-to-German translation) — unless the question itself, or
  "generationRules", explicitly asks for a different language.
- If this question is a newsletter, marketing-email, or job-alert
  subscription opt-in phrased as a choice (e.g. "Would you like to
  subscribe to our newsletter? Yes/No"), always choose the option that
  declines it — the applicant never needs this to submit the application.
- "faq" is a set of pre-written answers to standard interview-FAQ questions
  (spec_5 section B). If the question being asked now is the same as, or a
  close variant of, one already in "faq", reuse its substance and phrasing —
  adapt only what the target field's length/format actually requires — so
  the applicant's answer stays consistent across different forms rather
  than being re-derived from scratch each time.
- Match the question's expected length: a short field gets a short answer, an
  open-ended "tell us about..." field gets a fuller one.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text, no markdown, no restating the question.

${S}`,Tt=/\b(?:please\s+(?:provide|specify|clarify)|could\s+you\s+(?:please\s+)?(?:provide|clarify|specify)|i\s+(?:don'?t|do\s+not)\s+see)\b.{0,40}?\b(?:question|prompt)\b|\bno\s+(?:specific\s+)?question\s+(?:was|is)?\s*(?:provided|given|specified|attached)\b/i;function _t(e){const s=e.trim();return s?s.length<220&&Tt.test(s):!0}const Lt=`
- This is a MULTIPLE-CHOICE question: "options" lists the allowed answers.
  Reply with EXACTLY ONE option, copied verbatim, and nothing else.
- Base the choice on the applicant's profile/CV/Personal Legend. If the
  needed fact is genuinely absent (e.g. pronouns not stated anywhere),
  prefer a neutral option, an explicit "prefer not to say", or the option
  that commits the applicant least.`,It=`
- This is a SELECT-ALL-THAT-APPLY question: "options" lists every allowed
  answer. Reply with every option that genuinely applies, each copied
  verbatim, joined by " | " (a single pipe surrounded by one space on each
  side) — nothing else. If none apply, reply with an empty string.
- Base each choice strictly on the applicant's profile/CV/Personal Legend —
  never include an option just because it's plausible or common; only ones
  the applicant's own material actually supports.`,Pt=`
- This field only accepts a plain number: reply with digits only (a single
  "." for a decimal if needed) — no currency symbol, no thousands
  separator, no unit, no words, no range. If a range genuinely fits best
  (e.g. a salary expectation given as "65-75k"), reply with one
  representative figure (its midpoint), not the range.`;function Ot(e){return`
- This field only accepts a date in the exact format "${le[e]}"
  — reply with ONLY that value, nothing else (no words, no explanation).
  "todayISO" in the data below is today's date: compute the answer from it
  — e.g. "available with one month's notice" → todayISO plus one month;
  "immediately" / "as soon as possible" / no stated constraint → todayISO
  itself. Never answer with a description of the notice period or
  availability instead of the date itself.`}async function kt(e,s,t,o,n,a,i){const[r,l]=await Promise.all([m(),$("lastCoverLetter")]),c=JSON.stringify({job:s,profile:r.profile,cvText:r.cvText,personalLegend:r.personalLegend,generationRules:r.generationRules,coverLetter:l??"",languageLevels:r.languageLevels,customFields:r.customFields,faq:r.faq.filter(v=>v.answer.trim()),todayISO:I(),postingLanguage:i||void 0,question:e,options:t&&t.length>0?t:void 0},null,2),u=[t&&t.length>0?a?It:Lt:"",o?Pt:"",n?Ot(n):""].filter(Boolean),p=await h({schemaName:"custom_question_answer",schema:St,systemPrompt:u.length>0?[q,...u].join(`
`):q,userPrompt:c,parse:v=>JSON.parse(v)});return!p.sufficientInfo||_t(p.answer)?{answer:"",sufficientInfo:p.sufficientInfo}:{answer:t&&t.length>0||o||!!n?p.answer:f(p.answer),sufficientInfo:!0}}const Rt={type:"object",additionalProperties:!1,required:["questions"],properties:{questions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","question"],properties:{index:{type:"integer"},question:{type:"string"}}}}}},Ct=`You are given a block of a job-application form: its visible text, and a
list of the input fields inside it. For each field that asks the applicant
something, return the question it is asking, phrased as a plain question.

Rules:
- Use ONLY the visible text provided. Never invent a question.
- Match each question to its field by "index".
- Omit a field that is not a real question (layout helper, hidden field,
  search box, honeypot, a plain "First name"-style profile field).
- A field with "options" is a multiple-choice question — still return only
  its question text, not the options.
- Output the question text only — no numbering, no "Question:" prefix.
- Questions may be in any language; keep the form's own language.`;async function At(e,s){if(s.length===0)return{};const t=JSON.stringify({blockText:e.slice(0,6e3),fields:s},null,2),o=await h({schemaName:"block_questions",schema:Rt,systemPrompt:Ct,userPrompt:t,parse:a=>JSON.parse(a)}),n={};for(const a of o.questions)a.question.trim()&&(n[a.index]=a.question.trim());return n}const Nt=/newsletter|marketing|subscribe|promotion|job\s*alert|career\s*news|werbung|benachrichtigung|abonnier|stellenausschreibung/i;function M(e){return Nt.test(e)}const xt={type:"object",additionalProperties:!1,required:["decisions"],properties:{decisions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","check","category","reason"],properties:{index:{type:"integer"},check:{type:"boolean"},category:{type:"string",enum:["required-consent","marketing","optional","unclear"]},reason:{type:"string"}}}}}},qt=`You decide, for each checkbox on a job-application form, whether the
applicant should tick it. The applicant has already chosen to submit this
application.

TICK (check: true) — things required to submit, or that a candidate is
normally expected to accept:
- privacy policy / data protection / GDPR / Datenschutz consent
- terms & conditions / AGB / Nutzungsbedingungen
- confirming the entered information is accurate / truthful
- consent to process and store the application data for THIS hiring process
- storing the data in a talent pool ONLY when the checkbox is marked required
- eligibility self-declarations that hold for any ordinary adult applying
  for a real job (e.g. "I am at least 18 years old", "I am legally
  entitled to work in [country]", "I have no undisclosed conflicts of
  interest") — assume true unless the profile/CV explicitly states
  otherwise; a genuine job applicant submitting this form is virtually
  always eligible, and leaving a required declaration like this unticked
  blocks submission for no real reason

DO NOT TICK (check: false) — optional and promotional:
- newsletters, marketing e-mails, "career news", event invitations
- job alerts / notifications about new postings
  (e.g. "Benachrichtigungen über neue Stellenausschreibungen erhalten")
- sharing data with third parties / partner companies for marketing
- joining a talent pool / candidate database when NOT required
- anything that benefits the applicant only beyond this one application

Rules:
- "required: true" means the form marks the field mandatory — a strong
  signal to tick, unless the text is clearly marketing.
- A newsletter/marketing-email/job-alert opt-in is NEVER ticked, even when
  the form marks it "required" — that flag is routinely misused by forms to
  guilt-trip applicants into subscribing, and applicants never actually need
  it to submit the application. When genuinely in doubt whether a required
  checkbox is a real submission requirement or a disguised newsletter
  opt-in, prefer NOT ticking it.
- If a checkbox is ambiguous AND not required, set check: false.
- Labels may be in any language; judge by meaning, not keywords.
- Return one decision per input item, using its "index".

category: "required-consent" (ticked, mandatory-type), "marketing" (left
off), "optional" (non-marketing but skippable, left off unless required),
"unclear" (left off). reason: one short phrase.`;async function Mt(e){if(e.length===0)return[];const s=JSON.stringify(e.map((n,a)=>({index:a,label:n.label,required:n.required,currentlyChecked:n.checked})),null,2),t=await h({schemaName:"checkbox_decisions",schema:xt,systemPrompt:qt,userPrompt:s,parse:n=>JSON.parse(n)}),o=new Map;for(const n of t.decisions)o.set(n.index,n);return e.map((n,a)=>{const i=o.get(a);if(i){const r=i.check&&M(n.label)?!1:i.check;return{name:n.name,label:n.label,check:r,category:i.category,reason:i.reason}}return M(n.label)?{name:n.name,label:n.label,check:!1,category:"marketing",reason:"No decision returned — looks like a newsletter/marketing opt-in"}:{name:n.name,label:n.label,check:n.required,category:n.required?"required-consent":"unclear",reason:n.required?"Marked required by the form":"No decision returned"}})}const Ut={type:"object",additionalProperties:!1,required:["postingLanguages","requirements","keywords"],properties:{postingLanguages:{type:"array",items:{type:"string"}},requirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...pe,null]}}}},keywords:{type:"array",items:{type:"object",additionalProperties:!1,required:["text","matchesProfile"],properties:{text:{type:"string"},matchesProfile:{type:"boolean"}}}}}},jt=`You read a job posting and report two independent things about it: its
language, and its notable keywords. Judge each against the applicant profile/CV/Personal
Legend given below.

LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- requirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or
  "Native" for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent",
  "professional working proficiency" -> "C1"; "conversational" -> "B1". If a language is
  mentioned but no level can be reasonably inferred, set level to null. Do not invent a
  requirement that isn't stated in the text. If nothing is stated, return an empty array.

KEYWORDS
- Pick the notable keywords/key phrases out of the posting — the skills, tools,
  technologies, qualifications, and requirements a candidate would want to notice at a
  glance.
- Every keyword's "text" MUST be copied VERBATIM from the posting text (job title,
  description, requirements, responsibilities) — the exact same characters and casing, not
  a paraphrase, synonym, or translation — because the extension re-finds this exact text on
  the page to highlight it. A keyword that doesn't appear verbatim in the text is useless.
- Prefer short phrases: single words or 2-3 word phrases (e.g. "TypeScript", "Kubernetes",
  "5+ years", "product management", "Bachelor's degree") — not full sentences.
- Pick 8-15 of the most important ones. Skip generic filler ("team player", "fast-paced
  environment") unless the posting has almost nothing more specific.
- No duplicates, and no two keywords where one is a substring of the other (keep the more
  specific/longer one).
- Set "matchesProfile" to true when the applicant's profile/cvText/personalLegend shows they
  already have, use, or meet that skill/tool/technology/qualification — false when the
  posting asks for it but nothing in the applicant's material supports it. Judge substance,
  not exact wording (e.g. "Kubernetes" counts as a match if the CV mentions "container
  orchestration with K8s" or "EKS"). When genuinely unsure, set it to false — this flags a
  possible gap for the applicant to address rather than silently hiding it.`;async function $t(e){const s=await m(),t=JSON.stringify({profile:s.profile,cvText:s.cvText,personalLegend:s.personalLegend,job:e},null,2),o=await h({schemaName:"job_brief",schema:Ut,model:await J(),systemPrompt:jt,userPrompt:t,parse:n=>JSON.parse(n)});return{language:{postingLanguages:o.postingLanguages,requirements:o.requirements},keywords:o.keywords}}const Yt={type:"object",additionalProperties:!1,required:["values"],properties:{values:{type:"array",items:{type:"object",additionalProperties:!1,required:["name","value","reason"],properties:{name:{type:"string"},value:{type:"string"},reason:{type:"string"}}}}}},Ft=`You adapt an applicant's CV template to one specific job posting by
choosing a value for each {{placeholder}} in it.

Each variable comes with:
- "description": the applicant's own instruction for what the placeholder means and
  how to choose it. Follow it.
- "mode": "choice" means "value" MUST be exactly one of "options", copied verbatim
  (same spelling, same case, same line breaks). "free" means "options" are only
  examples of the expected shape and length; write the value that fits this posting
  in that same shape (e.g. a city name, a comma-separated list).
- "foundInPosting": options that literally occur in the posting text, most frequent
  first. A strong hint, not an order: the role's actual focus matters more than a
  passing mention.

Rules:
- Pick what makes this CV the closest honest match for this posting: its title, its
  location, its main technology, the vocabulary it uses.
- Honesty: never make the CV claim a skill, technology or experience the applicant's
  CV text / Personal Legend doesn't support, unless the variable's description
  explicitly asks for it. For list-like values, prefer terms that are both in the
  posting and supported by the applicant's background.
- Write the value in the same language as the surrounding template text.
- Return one entry per variable given, using its exact "name".
- "reason": one short sentence (max ~15 words) on why this value fits the posting.
- Plain text only, no markdown, no em dashes.`;function Dt(e,s){const t=n=>n.trim().replace(/\s+/g," ").toLowerCase(),o=t(e);return s.options.find(n=>t(n)===o)??null}async function Ht(e,s){const t=new Set(ue(s.content)),o=s.variables.filter(r=>t.has(r.name));if(o.length===0)return[];const n=await m(),a={variables:o.map(r=>({name:r.name,mode:r.mode,description:r.description,options:r.options,foundInPosting:de(r.options,e)})),template:s.content.slice(0,12e3),job:{position:e.position,company:e.company,location:e.location,techStack:e.techStack,requirements:e.requirements,responsibilities:e.responsibilities,description:e.description.slice(0,8e3)},applicant:{cvText:n.cvText.slice(0,12e3),personalLegend:n.personalLegend.slice(0,8e3),city:n.profile.city,country:n.profile.country}},i=await h({schemaName:"cv_template_values",schema:Yt,model:await he(),systemPrompt:Ft,userPrompt:JSON.stringify(a,null,2),parse:r=>JSON.parse(r)});return o.map(r=>{const l=i.values.find(c=>c.name===r.name);if(!l)return{name:r.name,value:k(r,e),reason:""};if(r.mode==="choice"&&r.options.length>0){const c=Dt(l.value,r);return c?{name:r.name,value:c,reason:f(l.reason)}:{name:r.name,value:k(r,e),reason:""}}return{name:r.name,value:f(l.value),reason:f(l.reason)}})}async function z(e){const s=await d(e);await Promise.all(s.map(t=>chrome.tabs.sendMessage(e,{type:"CANCEL_ELEMENT_PICKER",tabId:e},{frameId:t}).catch(()=>{})))}async function g(e,s,t){return(await Promise.all(s.map(n=>chrome.tabs.sendMessage(e,t,{frameId:n}).catch(()=>{})))).filter(n=>!!n)}async function Bt(e){var s;switch(e.type){case"GET_PROFILE":return{type:"PROFILE_DATA",profile:await T()};case"GET_JOB":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});if(!e.force&&(t!=null&&t.url)){const c=await fe(t.url);if(c)return{type:"JOB_DATA",job:c,sufficient:!0}}const o=await d(e.tabId),a=(await g(e.tabId,o,e)).filter(c=>c.type==="JOB_DATA");if(a.length===0)return;const i=a.find(c=>c.sufficient);if(i)return t!=null&&t.url&&A(t.url,i.job),i;const r=a.reduce((c,u)=>u.job.description.length>c.job.description.length?u:c),l=a.map(c=>c.visibleText??"").filter(Boolean).join(`

`).slice(0,2e4);try{const c=await x(l||r.visibleText||"",r.job.url);return t!=null&&t.url&&A(t.url,c),{type:"JOB_DATA",job:c,sufficient:!0}}catch{return r}}case"EXTRACT_JOB_FROM_TEXT":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});return{type:"JOB_DATA",job:await x(e.text,(t==null?void 0:t.url)??""),sufficient:!0}}case"AUTOFILL":{const t=await d(e.tabId),n=(await g(e.tabId,t,e)).filter(a=>a.type==="AUTOFILL_RESULT");return{type:"AUTOFILL_RESULT",filled:n.reduce((a,i)=>a+i.filled,0),total:n.reduce((a,i)=>a+i.total,0),generatedPassword:n.map(a=>a.generatedPassword).find(Boolean)??null}}case"GENERATE_COVER_LETTER":{const{tabId:t}=e,o=await gt(e.job,e.postingLanguage,n=>{chrome.runtime.sendMessage({type:"COVER_LETTER_STREAM_CHUNK",tabId:t,delta:n}).catch(()=>{})});return await C("lastCoverLetter",o.content),{type:"COVER_LETTER_RESULT",content:o.content,slopFindings:o.slopFindings,cleaned:o.cleaned}}case"UPLOAD_FILE":{const t=await d(e.tabId),n=(await g(e.tabId,t,e)).filter(a=>a.type==="UPLOAD_FILE_RESULT");return{type:"UPLOAD_FILE_RESULT",nativeInputs:n.reduce((a,i)=>a+i.nativeInputs,0),dropZones:n.reduce((a,i)=>a+i.dropZones,0)}}case"REVISE_COVER_LETTER":{const t=await wt(e.content,e.instructions,e.job);return await C("lastCoverLetter",t),{type:"REVISE_COVER_LETTER_RESULT",content:t}}case"TRANSLATE_COVER_LETTER":return{type:"TRANSLATE_COVER_LETTER_RESULT",content:await Et(e.content,e.targetLanguage)};case"DETECT_CUSTOM_QUESTIONS":{const t=await d(e.tabId),o=await g(e.tabId,t,e),n=new Set,a=[];for(const i of o)if(i.type==="CUSTOM_QUESTIONS_DATA")for(const r of i.questions)n.has(r.question)||(n.add(r.question),a.push({...r,id:`question-${a.length}`}));return{type:"CUSTOM_QUESTIONS_DATA",questions:a}}case"ANSWER_CUSTOM_QUESTION":{const t=await kt(e.question,e.job,e.options,e.numeric,e.dateKind,e.multi,e.postingLanguage);return{type:"CUSTOM_QUESTION_ANSWER",question:e.question,answer:t.answer,sufficientInfo:t.sufficientInfo}}case"FILL_CUSTOM_QUESTION_ANSWERS":{const t=await d(e.tabId),o=await g(e.tabId,t,e);let n=0;const a=[];for(const i of o)i.type==="CUSTOM_QUESTION_FILL_RESULT"&&(n+=i.filled,a.push(...i.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:n,unfilled:a}}case"START_ELEMENT_PICKER":{const t=await d(e.tabId),o=t.map(a=>chrome.tabs.sendMessage(e.tabId,e,{frameId:a}).catch(()=>{})),n=await new Promise(a=>{let i=o.length;i===0&&a(void 0);for(const r of o)r.then(l=>{i-=1,l?a(l):i===0&&a(void 0)})});return await Promise.all(t.map(a=>chrome.tabs.sendMessage(e.tabId,{type:"CANCEL_ELEMENT_PICKER",tabId:e.tabId},{frameId:a}).catch(()=>{}))),n??{type:"ELEMENT_PICKER_RESULT",cancelled:!0,picked:[],blockText:"",semanticCount:0}}case"CANCEL_ELEMENT_PICKER":{await z(e.tabId);return}case"DECOMPOSE_BLOCK":return{type:"BLOCK_QUESTIONS",questions:await At(e.blockText,e.fields)};case"FILL_QUESTION_ANSWERS_BY_LOCATOR":{const t=await d(e.tabId),o=await g(e.tabId,t,e);let n=0;const a=[];for(const i of o)i.type==="CUSTOM_QUESTION_FILL_RESULT"&&(n+=i.filled,a.push(...i.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:n,unfilled:a}}case"DETECT_CHECKBOXES":{const t=await d(e.tabId),o=await g(e.tabId,t,e),n=new Set,a=[];for(const i of o)if(i.type==="CHECKBOXES_DATA")for(const r of i.checkboxes){const l=r.name||r.label;!l||n.has(l)||(n.add(l),a.push({...r,id:`checkbox-${a.length}`}))}return{type:"CHECKBOXES_DATA",checkboxes:a}}case"DECIDE_CHECKBOXES":return{type:"CHECKBOX_DECISIONS",decisions:await Mt(e.checkboxes)};case"APPLY_CHECKBOX_DECISIONS":{const t=await d(e.tabId),o=await g(e.tabId,t,e);let n=0;for(const a of o)a.type==="CHECKBOX_APPLY_RESULT"&&(n+=a.changed);return{type:"CHECKBOX_APPLY_RESULT",changed:n}}case"DETECT_JOB_BRIEF":{const t=await $t(e.job);return{type:"JOB_BRIEF_DATA",language:t.language,keywords:t.keywords}}case"HIGHLIGHT_KEYWORDS":{const t=await d(e.tabId);return{type:"KEYWORD_HIGHLIGHT_RESULT",matched:(await g(e.tabId,t,e)).reduce((a,i)=>i.type==="KEYWORD_HIGHLIGHT_RESULT"?a+i.matched:a,0)}}case"CLEAR_KEYWORD_HIGHLIGHTS":{const t=await d(e.tabId);await g(e.tabId,t,e);return}case"GENERATE_FAQ_ANSWERS":{const t=await F(),o=await Ce(e.questions,t);try{await ge(o)}catch{}return{type:"FAQ_ANSWERS_RESULT",entries:o}}case"SEARCH_JOBS":{const{provider:t}=e.query,o=performance.now(),n=[],a=()=>({totalMs:performance.now()-o,stages:n});if(t==="adzuna"){const[c,u]=await Promise.all([R(),T()]);if(!c.adzunaAppId||!c.adzunaAppKey)throw new Error("Add your Adzuna app_id and app_key in Settings first.");let p=e.query;if(!((s=p.tags)!=null&&s.length))if(p.what.trim())p={...p,tags:[p.what.trim()]};else{const[_,O]=await b(n,"Suggest tags",()=>Promise.all([L(),N()]));p={...p,what:_.what,where:p.where.trim()||_.where,tags:O.length>0?O:[_.what]}}const{results:P,warnings:v}=await b(n,"Adzuna search",()=>De(p,{appId:c.adzunaAppId,appKey:c.adzunaAppKey},Be(u.country),e.page??1));return{type:"JOB_SEARCH_RESULTS",results:P,resolvedQuery:p,warnings:v,...a()}}const i=await Y(),r=(i==null?void 0:i.content)??"";if(t==="tavily"){const c=await R();if(!c.tavilyApiKey)throw new Error("Add your Tavily API key in Settings first.");return{type:"JOB_SEARCH_RESULTS",results:await Ue(e.query,c.tavilyApiKey,r,e.excludeResults,n),resolvedQuery:e.query,...a()}}return{type:"JOB_SEARCH_RESULTS",results:await xe(e.query,r,e.excludeResults,n),resolvedQuery:e.query,...a()}}case"SUGGEST_SEARCH_QUERY":{if(e.provider==="adzuna"){const[o,n]=await Promise.all([L(),N()]);return{type:"SEARCH_QUERY_SUGGESTION",...o,tags:n}}return{type:"SEARCH_QUERY_SUGGESTION",...await L()}}case"SUGGEST_CV_VALUES":return{type:"CV_VALUES",values:await Ht(e.job,e.template)};default:return}}const Jt="src/sidepanel/index.html";chrome.runtime.onInstalled.addListener(()=>{Te(),chrome.sidePanel.setOptions({enabled:!1})});chrome.contextMenus.onClicked.addListener((e,s)=>{Le(e,s)});chrome.action.onClicked.addListener(e=>{if(e.id===void 0)return;const s=e.id;chrome.sidePanel.setOptions({tabId:s,path:Jt,enabled:!0}),chrome.sidePanel.open({tabId:s}).catch(t=>console.error("sidePanel.open failed",t)),d(s)});chrome.tabs.onRemoved.addListener(e=>{me(e)});chrome.runtime.onMessage.addListener((e,s,t)=>(Bt(e).then(t).catch(o=>{t({type:"ERROR",error:o instanceof Error?o.message:String(o),code:o instanceof Error?o.name:void 0})}),!0));chrome.runtime.onConnect.addListener(e=>{const s=/^picker-(\d+)$/.exec(e.name);if(!s)return;const t=Number(s[1]);e.onDisconnect.addListener(()=>{z(t)})});
