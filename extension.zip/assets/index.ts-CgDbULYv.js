import{P as ye,g as V,a as P,b as we,c as be,s as ve,d as x,e as K,f as Ee,h as Se,i as Te,j as Le,k as z,r as h,J as Q,n as W,t as C,l as q,M as X,m as ke,A as Z,o as Ie,p as _e,q as Oe,u as N,v as ee,w as Ae,x as te,C as Re,y as ne,z as xe,B as Pe,D as ae,E as Ce,F as se,G as Ne,H as je,I as qe,K as F,L as Me,N as D,O as Ue,Q as $e,R as Fe,S as De}from"./template-D2YKE7Tr.js";import{c as Ye,a as Je}from"./phone-D3SACKoL.js";const ie={...ye,cv:"CV",coverLetter:"Cover Letter",generatePassword:"Generated password"},Be=Object.keys(ie);async function f(e){try{const s=(await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:["content-script.js"]})).map(t=>t.frameId).filter(t=>typeof t=="number");if(s.length>0)return s}catch{}try{return await chrome.scripting.executeScript({target:{tabId:e},files:["content-script.js"]}),[0]}catch{return[0]}}function He(){const e=[];for(const n of Array.from(document.querySelectorAll("iframe, frame"))){const s=n.getBoundingClientRect(),t=s.width*s.height;n.src&&s.width>=200&&s.height>=150&&e.push({src:n.src,area:t})}return{origin:location.origin,children:e}}async function Ge(e){let n;try{n=await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},func:He})}catch{return[]}const s=new Set,t=new Map;for(const{result:i}of n)if(i){s.add(i.origin);for(const o of i.children){let r;try{const c=new URL(o.src);if(c.protocol!=="https:"&&c.protocol!=="http:")continue;r=c.origin}catch{continue}t.set(r,Math.max(t.get(r)??0,o.area))}}const a=[];for(const i of[...t.keys()].sort((o,r)=>t.get(r)-t.get(o))){if(s.has(i))continue;if(await chrome.permissions.contains({origins:[`${i}/*`]}).catch(()=>!1)||a.push(i),a.length===3)break}return a}async function Ve(e,n){if(e==="cv"){const a=await V();return(a==null?void 0:a.text)??""}if(e==="coverLetter")return await P("lastCoverLetter")??"";if(e==="generatePassword"){const a=await we(n);if(a!=null&&a.generatedPassword)return a.generatedPassword;const i=be();return a&&await ve(n,{...a,generatedPassword:i}),i}const s=await x(),t=s[e]??"";return e==="phone"&&t?Ye(t,s.country):t}const O="job-app-assistant-insert",Ke={generatePassword:"Generate password"},ze=Be.map(e=>({id:e,title:Ke[e]??ie[e]}));function Qe(){chrome.contextMenus.removeAll(()=>{chrome.contextMenus.create({id:O,title:"Insert",contexts:["editable"]});for(const e of ze)chrome.contextMenus.create({id:`${O}:${e.id}`,parentId:O,title:e.title,contexts:["editable"]})})}function We(e){return e.startsWith(`${O}:`)?e.slice(O.length+1):null}async function Xe(e,n){if(!(n!=null&&n.id)||typeof e.menuItemId!="string")return;const s=We(e.menuItemId);if(!s)return;const t=await Ve(s,n.id);await f(n.id);const a={type:"INSERT_VALUE",field:s,value:t};chrome.tabs.sendMessage(n.id,a,{frameId:e.frameId}).catch(()=>{})}const Ze=new Set(["profileCache","cvLibraryCache","legendLibraryCache","customFieldsCache","languageLevelsCache","faqAnswersCache","generationRulesCache","outreachRulesCache"]);let I=null;function et(){return Promise.all([x(),V(),K(),Ee(),Se(),Te(),Le(),z()]).then(([e,n,s,t,a,i,o,r])=>({profile:e,cvText:(n==null?void 0:n.text)??"",personalLegend:(s==null?void 0:s.content)??"",generationRules:(t==null?void 0:t.content)??"",outreachRules:(a==null?void 0:a.content)??"",languageLevels:i,customFields:o,faq:r}))}function y(){return I||(I=et(),I.catch(()=>{I=null})),I}var G;typeof chrome<"u"&&((G=chrome.storage)!=null&&G.onChanged)&&chrome.storage.onChanged.addListener((e,n)=>{n==="local"&&Object.keys(e).some(s=>Ze.has(s))&&(I=null)});const v=`Write like a specific person, not an AI assistant. These rules have no exceptions:

- NEVER use an em dash ("—"), a spaced en dash ("–") or "--" as punctuation. Real people don't write that way. Use a comma, a period, parentheses, or two sentences.
- Banned words: delve, foster, leverage, utilize, facilitate, empower, streamline, robust, cutting-edge, paradigm shift, game changer, tapestry, realm, beacon, multifaceted, meticulous, intricate, paramount, transformative, elevate, embark, supercharge, harness, ever-evolving. Say the plain thing.
- Cut empty phrases: "it's worth noting", "at the end of the day", "when it comes to", "at its core", "in today's world", "the reality is", "in order to", "going forward".
- No "not X, it's Y" / "the question isn't X, it's Y" / "not just X but Y" contrasts. State Y directly.
- No throat-clearing openers ("Here's the thing", "Let me be clear", "I'll be honest") and no faux-insight setups ("what most people get wrong", "here's what nobody tells you").
- No importance puffery ("stands as a testament", "marks a pivotal moment", "plays a vital role", "underscores its significance"). State the fact and stop.
- No colon reveals: a noun phrase, a colon, then a dramatic lowercase clause.
- No trailing "-ing" clauses that editorialize ("highlighting the commitment to...", "underscoring its importance", "showcasing", "reflecting"). End the sentence.
- No metadiscourse that tells the reader what to notice ("this matters", "this distinction matters", "in other words", "as you can see").
- No "In conclusion" / "Ultimately" / "Overall" recap ending and no cute one-line kicker. Stop on the last concrete point.
- No emoji, no mid-sentence bold, no rhetorical questions.
- Vary sentence shape; don't stack short punchy fragments.
- Be concrete: name the technology, project, number, or outcome instead of calling it "significant", "impactful" or "exciting". Use active voice.`;function m(e){return e.replace(/[ \t]*[—―][ \t]*/g,", ").replace(/[ \t]+--[ \t]+/g,", ").replace(/(\D)[ \t]+–[ \t]+(?=\D)/g,"$1, ").replace(/[ \t]+([,.;:!?])/g,"$1").replace(/,(\s*[.;:!?])/g,"$1").replace(/,[ \t]*,/g,",").replace(/^[ \t]*,[ \t]*/gm,"").replace(/([([{])[ \t]*,[ \t]*/g,"$1").replace(/[ \t]*,[ \t]*([)\]}])/g,"$1").replace(/,[ \t]*$/gm,"").replace(/[ \t]+$/gm,"")}const tt=`You write the applicant's own answers to standard interview-FAQ
questions (spec_5 section B) — general-purpose answers meant to be reused, as-is or
lightly adapted, whenever a real application form asks a close variant of one of them.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend, and
  custom fields. Never invent experience, technologies, companies, education,
  achievements, or a concrete salary figure that wasn't actually given.
- If information needed for a good answer is missing (no CV, no Personal Legend
  content covering it), write a short, honest, generically true answer rather
  than fabricating specifics — the applicant can always sharpen it later.
- Keep each answer 2-5 sentences: concrete and confident, never generic
  corporate filler, no restating the question.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text per answer, no markdown, no numbering.

${v}`;function nt(e){return{type:"object",additionalProperties:!1,required:["answers"],properties:{answers:{type:"array",minItems:e,maxItems:e,items:{type:"string"}}}}}async function at(e){if(e.length===0)return[];const{profile:n,cvText:s,personalLegend:t,generationRules:a,customFields:i}=await y(),o=JSON.stringify({profile:n,cvText:s,personalLegend:t,generationRules:a,customFields:i,questions:e},null,2),r=await h({schemaName:"faq_answers",schema:nt(e.length),systemPrompt:tt,userPrompt:o,parse:c=>JSON.parse(c)});return e.map((c,l)=>({question:c,answer:m(r.answers[l]??"")}))}async function st(e,n){const s=new Map(n.map(i=>[i.question,i.answer])),t=e.filter(i=>{var o;return!((o=s.get(i))!=null&&o.trim())}),a=await at(t);for(const i of a)s.set(i.question,i.answer);return e.map(i=>({question:i,answer:s.get(i)??""}))}async function A(e,n,s){const t=performance.now();try{return await s()}finally{e==null||e.push({label:n,ms:performance.now()-t})}}function it(e){return e!=null&&e.length?`Seniority levels to target: ${Q.filter(s=>e.includes(s.id)).map(s=>s.label.toLowerCase()).join(", ")}. Only include postings for these levels.`:""}function ot(e,n){const s=Q.filter(a=>n==null?void 0:n.includes(a.id));if(s.length===0)return e;const t=[];for(const a of e)for(const i of s)t.push(a.toLowerCase().includes(i.keyword)?a:`${i.keyword} ${a}`.trim());return[...new Set(t)]}function oe(e){return[e.what?`Role/keywords focus: "${e.what}".`:"",e.where?`Location: "${e.where}".`:"",it(e.grades),e.remoteOnly?"Prefer remote-friendly roles.":"",W(e.negative)].filter(Boolean).join(" ")}const rt={type:"object",additionalProperties:!1,required:["jobs"],properties:{jobs:{type:"array",items:{type:"object",additionalProperties:!1,required:["title","company","location","url","salary","snippet","postedAt"],properties:{title:{type:"string"},company:{type:"string"},location:{type:"string"},url:{type:"string"},salary:{type:"string"},snippet:{type:"string"},postedAt:{type:"string"}}}}}};function ct(e,n){const s=W(n);return`You turn raw web-search results about job openings into a clean,
structured list. The input text was produced by a live internet search and may include
citations, markdown links, or unrelated surrounding prose — extract only genuine
individual job postings from it.

Rules:
- Only include entries that are clearly actual job postings with a real listing URL —
  never a company's generic careers-page homepage, a search-results page, or an
  aggregator's category page.
- "url" must be copied exactly from the source text (never invented).
- "salary" is "" when no figure was given — never guess one.
- "postedAt" is the date the posting was published, as YYYY-MM-DD, only when the text
  states it. Resolve relative dates ("posted 3 days ago", "2w") against today, ${e}.
  Use "" when no date is given — never guess one.
- Drop postings the text marks as closed, expired, filled or "no longer accepting
  applications", and postings published more than ${X} days before ${e}.
- "snippet" is a 1-2 sentence summary of the role; when a "candidate" background is given
  below, make it say *why this posting fits them* specifically (seniority match, matching
  skills, location/remote fit) rather than just restating the posting.
- If a "candidate" background is given, drop postings that are a poor fit for them (wrong
  seniority, unrelated field) even if they're genuine job postings — only surface ones
  actually worth their time.
- Deduplicate: the same posting linked twice becomes one entry.${s?`
- ${s}`:""}
- If nothing in the text is actually a job posting, return an empty "jobs" array.`}async function re(e,n,s,t={}){const a=s?`candidate:
${s}

---

${e.slice(0,4e4)}`:e.slice(0,4e4),i=await h({schemaName:"job_listings",schema:rt,systemPrompt:ct(C(),t.negative),userPrompt:a,reasoningEffort:t.reasoningEffort,parse:o=>JSON.parse(o)});return q(i.jobs.filter(o=>o.url.trim()).map(o=>({...o,source:n})))}function ce(e){return e.length===0?"":`

Already found and shown to the applicant — do NOT return any of these again,
find genuinely different postings instead:
${e.map(s=>`- ${s.title} at ${s.company} (${s.url})`).join(`
`)}`}function E(e){return typeof e=="string"?e.trim():""}function lt(e){const n=e.trim().replace(/^(?:[-*•]|\d+[.)])\s+/u,"").replace(/,$/,"");if(!n.startsWith("{")||!n.endsWith("}"))return null;let s;try{s=JSON.parse(n)}catch{return null}const t=E(s.url),a=E(s.title);return!/^https?:\/\//i.test(t)||!a?null:{title:a,company:E(s.company),location:E(s.location),url:t,salary:E(s.salary),snippet:E(s.snippet),postedAt:E(s.postedAt)}}function pt(e){let n="";function s(t){const a=lt(t);a&&e(a)}return{push(t){n+=t;let a;for(;(a=n.indexOf(`
`))!==-1;)s(n.slice(0,a)),n=n.slice(a+1)},end(){s(n),n=""}}}const ut=10;function dt(e,n,s=[]){const t=oe(e),a=C();return`Search the web for current, actually open job postings that fit this
candidate:

${n||"(no candidate background available)"}

${t||"No further constraints — use the candidate's own background to pick a fitting role/location."}

Today is ${a}. Only include postings published in the last ${X} days
that are still accepting applications — skip anything marked closed, expired or filled,
or shown with an older date. Skip postings that are a poor fit for the candidate (wrong
seniority, unrelated field).
Prefer the employer's own posting on its applicant tracking system (${Z.join(", ")})
or career page over copies on aggregators, which often outlive the real posting.
Only real individual postings with their direct listing URL — never a search results page,
a generic careers homepage or an aggregator's category page.${ce(s)}

OUTPUT FORMAT — follow exactly. Up to ${ut} of the best matches, best first, as JSON
Lines: one JSON object per line, nothing else (no prose, no markdown, no code fences, no
citations). Each object has exactly these string keys:
{"title":"","company":"","location":"","url":"","salary":"","postedAt":"","snippet":""}
- "url": the posting's direct URL as found.
- "salary": as stated, or "" — never guess.
- "postedAt": YYYY-MM-DD when the posting states a date (resolve "3 days ago" against
  ${a}), else "".
- "snippet": one sentence, at most 25 words, on why it fits this candidate.
If you find no fitting posting, output nothing.`}async function ht(e,n,s=[],t,a){const i=dt(e,n,s),o=performance.now();let r=null;const c=[],l=new Set,p=pt(S=>{const[u]=q([{...S,source:"openai"}]);!u||l.has(u.url)||(l.add(u.url),c.push(u),r??(r=performance.now()),a==null||a([u]))}),d=await A(t,"Web search",()=>ke(i,p.push));return p.end(),r!==null&&(t==null||t.push({label:"First result",ms:r-o})),c.length>0||!d.trim()?c:A(t,"Parse results",()=>re(d,"openai",n,{negative:e.negative,reasoningEffort:"low"}))}const gt="https://api.tavily.com/search",ft=2e3;function mt(e,n,s,t=[]){const a=`Find job postings from the last few weeks, still open, that fit this candidate.
${oe(e)}

Candidate background: ${s||"(none available)"}${ce(t)}`.trim().slice(0,ft),i=Ie(e.negative);return{api_key:n,query:a,search_depth:"advanced",max_results:15,include_answer:!1,time_range:"month",include_published_date:!0,include_domains:Z,include_domains_mode:"prefer",...i.length>0?{exclude_domains:i}:{}}}async function yt(e,n,s,t=[],a){const i=mt(e,n,s,t),o=await A(a,"Tavily search",()=>fetch(gt,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(i)}));if(!o.ok){const l=await o.text().catch(()=>"");throw new Error(`Tavily search failed (${o.status}): ${l.slice(0,300)}`)}const r=await o.json();if(r.results.length===0)return[];const c=r.results.map(l=>`Title: ${l.title}
URL: ${l.url}
${l.published_date?`Published: ${l.published_date}
`:""}${l.content}`).join(`

---

`);return A(a,"Parse results",()=>re(c,"tavily",s,{negative:e.negative}))}function wt(e,n){return!e&&!n?"":Oe({low:Math.round(e??n??0),high:Math.round(n??e??0)})}function bt(e){return new Promise(n=>setTimeout(n,e))}const vt=350,Et=12;function St(e,n,s,t,a){const i=new URL(`https://api.adzuna.com/v1/api/jobs/${t}/search/${a}`);i.searchParams.set("app_id",s.appId),i.searchParams.set("app_key",s.appKey),i.searchParams.set("results_per_page","15"),i.searchParams.set("content-type","application/json"),e&&i.searchParams.set("what",e),n.where&&i.searchParams.set("where",n.where);const o=_e(n.negative);return o&&i.searchParams.set("what_exclude",o),i.toString()}async function Tt(e,n,s,t,a){const i=await fetch(St(e,n,s,t,a));if(!i.ok){const c=await i.text().catch(()=>"");throw new Error(`Adzuna search failed (${i.status}): ${c.slice(0,300)}`)}const r=(await i.json()).results.map(c=>{var l,p;return{title:c.title,company:((l=c.company)==null?void 0:l.display_name)??"",location:((p=c.location)==null?void 0:p.display_name)??"",url:c.redirect_url,salary:wt(c.salary_min,c.salary_max),snippet:(c.description??"").slice(0,300),postedAt:c.created??"",source:"adzuna",tag:e}});return q(r)}async function Lt(e,n,s,t=1,a){var S;const i=e.tags&&e.tags.length>0?e.tags:[e.what],o=Math.max(((S=e.grades)==null?void 0:S.length)??0,1),r=Math.max(1,Math.floor(Et/o)),c=ot(i.slice(0,r),e.grades),l=new Set,p=[],d=[];i.length>r&&d.push(`Only the first ${r} search terms were used with ${o} grades selected.`);for(let u=0;u<c.length;u++){const R=c[u];try{const T=(await Tt(R,e,n,s,t)).filter(_=>!l.has(_.url));for(const _ of T)l.add(_.url);p.push(...T),T.length>0&&(a==null||a(T))}catch(g){d.push(`"${R}" — ${g instanceof Error?g.message:"search failed"}`)}u<c.length-1&&await bt(vt)}return{results:p,warnings:d}}const kt=new Set(["AT","AU","BE","BR","CA","CH","DE","ES","FR","GB","IN","IT","MX","NL","NZ","PL","RU","SG","US","ZA"]);function It(e){var s;const n=(s=Je(e))==null?void 0:s.toUpperCase();return n&&kt.has(n)?n.toLowerCase():"us"}const _t={type:"object",additionalProperties:!1,required:["what","where"],properties:{what:{type:"string"},where:{type:"string"}}},Ot=`You suggest a starting job-search query for the applicant described below.
"what" is a short role/keywords phrase (e.g. "senior backend engineer", "product designer") —
their most recent or clearly strongest role from the CV/Personal Legend. Pick ONE single title:
never join multiple roles or technologies with "/", "," or parentheses (e.g. never "Full-Stack
Developer / Backend Engineer (Go, Python, React)") — that reads as a combined AND-match to a
literal keyword search and returns nothing. "where" is a location (city, region, or country) —
their stated city/country if given, else "".
Output only the two fields, no explanation.`;async function At(){const{profile:e,cvText:n,personalLegend:s}=await y(),t=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:n,personalLegend:s},null,2),a=await h({schemaName:"job_search_query_suggestion",schema:_t,systemPrompt:Ot,userPrompt:t,parse:i=>JSON.parse(i),reasoningEffort:"low"});return{what:a.what,where:a.where||[e.city,e.country].filter(Boolean).join(", ")}}const Rt={type:"object",additionalProperties:!1,required:["tags"],properties:{tags:{type:"array",items:{type:"string"}}}},xt=`You generate keyword search tags for Adzuna's job-search API, grounded in
the candidate's real background below. Per Adzuna's own docs
(https://developer.adzuna.com/docs/search), "what" is a single literal keyword/phrase match, not
a semantic search and not a boolean query — so ONE combined tag naming several technologies or
role variants (e.g. "Full-Stack Developer / Backend Engineer (Go, Python, React)") matches
nothing. You compensate by generating a small cross-product of short, atomic tags instead, each
run as its own separate search and merged afterwards.

Method — build the tags as a cross-product, exactly like this worked example for a candidate
whose strongest stack is Go and who also does full-stack/backend work:
  golang developer, go developer, go engineer, golang engineer,
  backend engineer, backend developer, fullstack engineer, fullstack developer,
  software engineer, software developer
That is: {primary technology + its common short aliases} × {developer, engineer}, PLUS
{their role-shape words, e.g. backend / fullstack / frontend / mobile / data — whichever
genuinely apply, without a technology} × {developer, engineer}, PLUS a generic "software
developer" / "software engineer" fallback pair.

Rules:
- Base every tag on their actual, strongest-fitting technology/field from the CV/Personal
  Legend — never invent a technology, role-shape, or seniority they don't have.
- Identify the ONE primary technology (e.g. "Go") plus its common short aliases people actually
  search with (e.g. "Golang") — do not alias unrelated technologies together.
- Each tag pairs exactly one technology-or-role-shape word with exactly one of "developer" /
  "engineer" (add "programmer" only if that's a genuinely common term for that stack). Never put
  two technologies, or a technology and a role-shape, in the same tag.
- If the CV shows a clear secondary technology/stack, budget permitting, add its own couple of
  tags the same way — still never combined with the primary one in a single tag.
- For EACH language listed in "languages" below (skip English), also include ONE of the
  strongest-technology tags translated into that language using the natural job-title term a
  native speaker would search with (not a literal word-for-word translation).
- Each tag is 1-3 words, lowercase, and never contains "/", ",", "(", ")", or a seniority
  qualifier ("senior", "junior", etc.).
- Deduplicate. Return 6-12 tags total, most relevant first.
- Output only the tags, no explanation.`;async function Pt(){const{profile:e,cvText:n,personalLegend:s,languageLevels:t}=await y(),a=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:n,personalLegend:s,languages:t.map(o=>o.language)},null,2);return(await h({schemaName:"job_search_tags",schema:Rt,systemPrompt:xt,userPrompt:a,parse:o=>JSON.parse(o),reasoningEffort:"low"})).tags.map(o=>o.trim()).filter(Boolean)}const Ct=4;function Nt(e){return JSON.stringify([e.profile.city,e.profile.country,e.cvText,e.personalLegend,e.languageLevels.map(n=>n.language)])}async function jt(e){const n=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(e));return[...new Uint8Array(n)].map(s=>s.toString(16).padStart(2,"0")).join("")}async function Y(e){var r;const n=await jt(Nt(await y())),s=await P("jobSearchSuggestionCache")??[],t=s.find(c=>c.key===n);if(t&&(!e||t.tags))return{what:t.what,where:t.where,tags:t.tags,cached:!0};const[a,i]=await Promise.all([t?{what:t.what,where:t.where}:At(),e?Pt():Promise.resolve(void 0)]),o={key:n,...a,tags:i!=null&&i.length?i:t==null?void 0:t.tags};return(o.what||(r=o.tags)!=null&&r.length)&&await N("jobSearchSuggestionCache",[o,...s.filter(c=>c.key!==n)].slice(0,Ct)),{what:o.what,where:o.where,tags:o.tags,cached:!1}}const qt={type:"object",additionalProperties:!1,required:["keyRequirements","relevantExperienceHints","suggestedTone","suggestedFocus"],properties:{keyRequirements:{type:"array",items:{type:"string"}},relevantExperienceHints:{type:"array",items:{type:"string"}},suggestedTone:{type:"string"},suggestedFocus:{type:"string"}}};async function Mt(e){return h({schemaName:"job_analysis",schema:qt,model:await ee(),systemPrompt:"You analyze job postings for a job-application assistant. Identify the most important requirements and what an applicant should emphasize. Do not invent details that are not present in the posting.",userPrompt:JSON.stringify(e,null,2),parse:n=>JSON.parse(n)})}const Ut=`You write tailored cover letters for job applications.

The user message holds the applicant's data as JSON, and may end with an
"Applicant's rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and
   Personal Legend. Never invent experience, technologies, companies,
   education, or achievements, even if the applicant's rules ask for them.
   If information needed to be compelling is missing, write around it
   honestly rather than fabricating it.
2. The applicant's rules. Follow every instruction there on tone, length,
   structure, language, and what to include or avoid, including where it
   departs from the defaults below. Every rule there applies to the whole
   letter, not just the opening.
3. Language. If "postingLanguage" is given, write the entire letter in that
   language, using the salutation, register, and closing conventions native
   speakers of it would expect on a job application (e.g. formal
   "Sie"/"Herr"/"Frau" address and a "Sehr geehrte(r) ..." opening in German,
   not a literal English-to-German translation).
4. The house style below. Its "no exceptions" means no exceptions of your
   own; an explicit applicant rule still overrides it.
5. Tone and emphasis tailored to the job analysis provided.

Output plain prose paragraphs, no markdown headers.

${v}`;async function $t(e,n){const t=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,analysis:e.analysis,postingLanguage:e.postingLanguage||void 0},null,2)+le(e.generationRules),a=await Ae(Ut,t,n??(()=>{}));return m(a)}function le(e){const n=e.trim();return n?`

## Applicant's rules (highest priority after facts)

${n}
`:""}const M={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},pe={type:"object",additionalProperties:!1,required:["subject","body"],properties:{subject:{type:["string","null"]},body:{type:"string"}}},Ft=`You are a sharp human editor cleaning up a cover letter draft.

Fix ONLY the flagged AI-writing patterns listed below. Make the minimum
effective edit — do not rewrite sentences that were not flagged, do not
change facts, experience, technologies, or claims, and do not add new
content. Replace banned words/clichés with plain, concrete language.
Rewrite "not X, it's Y" contrasts as a direct statement of Y. Cut
throat-clearing openers, weasel attribution, and importance-puffery instead
of softening them. If the ending is a generic summary/recap, end on the
letter's last concrete point instead. Replace every em dash ("—") with a
comma, a period, or parentheses.

The user message may end with the applicant's own rules for the letter. If a
flagged pattern is something those rules explicitly ask for, leave it as is:
the applicant's rules outrank the house style.

Do not introduce any new AI-slop while editing. For reference, the full
house style is:

${v}

Output plain prose paragraphs, no markdown headers.`;async function Dt(e,n,s=""){const t=JSON.stringify({draft:e,flaggedPatterns:n.map(i=>`${i.pattern}: "${i.match}"`)},null,2)+le(s),a=await h({schemaName:"cover_letter_polish",schema:M,systemPrompt:Ft,userPrompt:t,parse:i=>JSON.parse(i)});return m(a.content)}const Yt=["delve","foster","leverage","utilize","facilitate","empower","streamline","robust","cutting-edge","paradigm shift","game changer","this is huge","this changes everything","tapestry","realm","beacon","multifaceted","meticulous","intricate","paramount","transformative","elevate","embark","supercharge","harness","ever-evolving"],Jt=["it's worth noting","it is worth noting","it's important to note","it is important to note","at the end of the day","when it comes to","at its core","in today's world","in the age of","in the world of","the reality is","the truth is","in terms of","with regard to","in order to","going forward"],Bt=["here's the thing","here's what i mean","let me be clear","i'll be honest","the uncomfortable truth is"],Ht=["this is the part most people skip","what most people get wrong","here's what nobody tells you","the part everyone misses"],Gt=["stands as a testament","marks a pivotal moment","plays a vital role","solidifies its position","underscores its significance"],Vt=["experts agree","industry reports suggest","many argue","widely regarded as","studies show"],Kt=[/^in conclusion\b/i,/^ultimately\b/i,/^overall\b/i];function zt(e){const n=e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`\\b${n.replace(/ /g,"\\s+")}\\b`,"i")}function k(e,n,s){const t=[];for(const a of n){const i=zt(a).exec(e);i&&t.push({pattern:s,match:i[0]})}return t}function Qt(e){const n=/\b(?:isn'?t|is not)\b[^.!?]{3,60}[,.]?\s*(?:it'?s|it is)\b[^.!?]{3,80}[.!?]/i,s=/\bnot just\b[^.!?]{3,60}(?:\bbut\b|[,.]?\s*(?:it'?s|it is)\b)[^.!?]{0,80}[.!?]/i,t=[],a=n.exec(e);a&&t.push({pattern:"binary-contrast",match:a[0].trim()});const i=s.exec(e);return i&&t.push({pattern:"binary-contrast",match:i[0].trim()}),t}function Wt(e){const n=e.split(/\n{2,}/).map(t=>t.trim()).filter(Boolean),s=n[n.length-1];if(!s)return[];for(const t of Kt)if(t.test(s))return[{pattern:"summary-recap-ending",match:s.slice(0,60)}];return[]}function Xt(e){const n=(e.match(/—/g)??[]).length;return n===0?[]:[{pattern:"em-dash",match:n===1?"1 em dash":`${n} em dashes`}]}function Zt(e){return[...k(e,Yt,"banned-word"),...k(e,Jt,"empty-phrase"),...k(e,Bt,"throat-clearing-opener"),...k(e,Ht,"faux-insight-setup"),...k(e,Gt,"importance-puffery"),...k(e,Vt,"weasel-attribution"),...Qt(e),...Wt(e),...Xt(e)]}async function en(e,n,s){const t=await y(),a=await Mt(e),i=await $t({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,generationRules:t.generationRules,job:e,analysis:a,postingLanguage:n},s),o=Zt(i);return o.length===0?{content:i,slopFindings:o,cleaned:!1}:{content:await Dt(i,o,t.generationRules),slopFindings:o,cleaned:!0}}const tn=`You write a short outreach message an applicant sends to a named
recruiter/hiring contact BEFORE or alongside applying, to start a conversation about a specific
job posting — not a cover letter, and not addressed to "the hiring team".

The user message holds the applicant's data as JSON ("contact" is the email address or LinkedIn
URL found on the posting), and may end with an "Applicant's rules" section written by the
applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and Personal Legend. Never
   invent experience, technologies, companies, education, or achievements.
2. The applicant's rules. Follow every instruction there on tone, length, structure, language,
   and what to include or avoid, including where it departs from the defaults below.
3. Language. If "postingLanguage" is given, write the entire message in that language, using
   the salutation and register native speakers of it would expect.
4. Channel. If "contact" looks like an email address, write a short email: "subject" is a
   specific, non-generic subject line (name the role and company), "body" opens with a greeting
   and closes with a signature using the applicant's name. If "contact" is a LinkedIn URL,
   write a LinkedIn connection/message note instead: "subject" is null, "body" has no email
   greeting/signature and stays under LinkedIn's informal register.
5. The house style below. Its "no exceptions" means no exceptions of your own; an explicit
   applicant rule still overrides it.

Defaults (apply unless the applicant's rules say otherwise): under 120 words, state who the
applicant is and the one or two things that make them a fit for THIS role, and end with a clear,
low-pressure ask (a quick chat, or just flagging interest before applying). Never sound like a
mass-sent template.

${v}`;async function nn(e){const s=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,contact:e.contact,postingLanguage:e.postingLanguage||void 0},null,2)+an(e.outreachRules),t=await h({schemaName:"outreach_message",schema:pe,model:await te(),systemPrompt:tn,userPrompt:s,parse:a=>JSON.parse(a)});return{subject:t.subject,body:m(t.body)}}function an(e){const n=e.trim();return n?`

## Applicant's rules (highest priority after facts)

${n}
`:""}const ue={type:"array",items:{type:"object",additionalProperties:!1,required:["text","kind","matchesProfile"],properties:{text:{type:"string"},kind:{type:"string",enum:["hard","soft"]},matchesProfile:{type:"boolean"}}}};function U(e){return`KEYWORDS
- Pick the SKILLS the posting asks for, and nothing else. Each one is either:
  - "hard": a technical skill, tool, technology, programming language, framework, platform,
    method or domain expertise (e.g. "TypeScript", "Kubernetes", "C++", ".NET", "CI/CD",
    "SQL", "machine learning", "financial modelling", "Figma", "Scrum");
  - "soft": a real interpersonal/working skill (e.g. "communication", "mentoring",
    "stakeholder management", "problem-solving", "ownership").
- NEVER return anything that is not a skill. In particular, never return:
  - the company name, its products' brand names used as a name, or any other organization;
  - cities, countries, regions, addresses, time zones;
  - work modes and contract terms ("remote", "hybrid", "on-site", "full-time", "contract");
  - benefits and pay ("salary", "equity", "health insurance", "30 days vacation", "bonus");
  - job titles and seniority ("Senior Backend Engineer", "Team Lead", "junior");
  - years of experience, degrees, certificates as such ("5+ years", "Bachelor's degree");
  - spoken languages ("English", "German") — those are reported separately above;
  - generic words ("team", "experience", "work", "product", "environment", "opportunity",
    "fast-paced environment", "passion").
- Every keyword's "text" MUST be copied VERBATIM from ${e} — the exact same characters
  and casing, not a paraphrase, synonym, or translation — because the extension re-finds this
  exact text on the page to highlight it. A keyword that doesn't appear verbatim is useless.
- Prefer short phrases: single words or 2-3 word phrases, never sentences.
- Return up to 15, most important first. Fewer is fine: return an empty array rather than
  padding the list with anything from the NEVER list above.
- No duplicates, and no two keywords where one is a substring of the other (keep the more
  specific/longer one).
- Set "matchesProfile" to true when the applicant's profile/cvText/personalLegend shows they
  already have, use, or meet that skill — false when the posting asks for it but nothing in
  the applicant's material supports it. Judge substance, not exact wording (e.g.
  "Kubernetes" counts as a match if the CV mentions "container orchestration with K8s" or
  "EKS"). When genuinely unsure, set it to false — this flags a possible gap for the
  applicant to address rather than silently hiding it.`}const sn=new Set(["team","teams","experience","work","job","role","position","company","candidate","opportunity","environment","product","products","customer","customers","client","clients","project","projects","skills","knowledge","ability","responsibilities","requirements","tasks","career","growth","culture","mission","vision","values","impact","passion","motivation","startup","scale-up","industry","business","fast-paced environment","dynamic environment","nice to have","must have","plus","years","year","years of experience","professional experience","work experience","degree","bachelor","bachelor's degree","master","master's degree","university degree","diploma","phd","intern","internship","junior","middle","mid-level","senior","lead","principal","staff","head","manager","remote","fully remote","remote work","hybrid","on-site","onsite","office","in office","home office","homeoffice","relocation","visa sponsorship","full-time","full time","part-time","part time","contract","freelance","permanent","temporary","salary","competitive salary","bonus","equity","stock options","esop","benefits","vacation","paid time off","pto","holidays","health insurance","insurance","pension","gym","gym membership","free lunch","snacks","flexible hours","flexible working hours","learning budget","parental leave","erfahrung","berufserfahrung","aufgaben","anforderungen","unternehmen","vollzeit","teilzeit","festanstellung","gehalt","urlaub","vertrag","büro","mobiles arbeiten","команда","опыт","опыт работы","работа","компания","проект","проекты","задачи","требования","обязанности","удаленно","удаленка","удаленная работа","гибрид","офис","полный день","полная занятость","частичная занятость","зарплата","оклад","бонусы","дмс","отпуск","релокация"]),on=new Set(Re.map(e=>b(e))),rn=new RegExp("\\s*,?\\s*(?<![\\p{L}\\p{N}])(?:inc|ltd|llc|gmbh|ag|se|kg|ug|bv|nv|sa|sas|srl|plc|corp|corporation|co|company|oy|ab|as|ооо|ао)\\.?$","iu");function b(e){return e.normalize("NFC").toLowerCase().replace(/ё/g,"е").replace(/[’`]/g,"'").replace(/^[\s"'«».,:;!?()[\]-]+|[\s"'«».,:;!?()[\]-]+$/g,"").replace(/\s+/g," ")}function cn(e){const n=b(e);if(!n)return[];const s=b(n.replace(rn,""));return s&&s!==n?[n,s]:[n]}function ln(e){const n=b(e);if(!n)return[];const s=e.split(/[,/|·•()]/).map(b).filter(Boolean);return[n,...s]}function pn(e){return b(e.replace(/\((?:[mwfdx]\s*\/\s*)+[mwfdx]\)/gi,""))}const un=/^\d+(?:\s*[-–+]\s*\d*)?\+?\s*(?:years?|yrs?|jahre?n?|лет|года?|ans|años)(?![\p{L}\p{N}])/iu;function j(e,n){const s=e.trim();if([...s].length<2)return!new RegExp("^\\p{Lu}$","u").test(s);if(!new RegExp("\\p{L}","u").test(s)||/[$€£¥₽%]/u.test(s))return!0;const t=b(s);return!t||sn.has(t)||on.has(t)||un.test(t)||cn(n.company).includes(t)||ln(n.location).includes(t)?!0:t===pn(n.position)}function $(e,n){const s=new Set;return e.filter(t=>{const a=b(t.text);return s.has(a)||j(t.text,n)?!1:(s.add(a),!0)})}function dn(e,n){var a;const s=(a=e.match(/\s*[,;|·•]\s*/u))==null?void 0:a[0];if(!s)return j(e,n)?"":e;const t=new Set;return e.split(/\s*[,;|·•]\s*/u).filter(i=>{const o=b(i);return!i.trim()||t.has(o)||j(i,n)?!1:(t.add(o),!0)}).join(s)}const de={postingLanguages:{type:"array",items:{type:"string"}},languageRequirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...ae,null]}}}},keywords:ue},hn={type:"object",additionalProperties:!1,required:["company","position","location","description","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},description:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...de}},he=`LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- languageRequirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or "Native"
  for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent", "professional
  working proficiency" -> "C1"; "conversational" -> "B1". If a language is mentioned but no level
  can be reasonably inferred, set level to null. Do not invent a requirement that isn't stated in
  the text. If nothing is stated, return an empty array.`,gn=`You read the visible text of a job-posting page and do two things with it
in one pass: extract the structured posting fields, and analyze the result for language and
keywords — against the applicant profile/CV/Personal Legend given below.

EXTRACTION
- Only use information present in "pageText"; leave a field empty/null if unknown.
- For "contact", prefer a named recruiter/hiring manager's email address or LinkedIn
  profile/company URL if one is mentioned, copied VERBATIM (exact characters); otherwise null.

${he}

${U('"pageText"')}`;async function fn(e,n){const s=await y(),t=JSON.stringify({profile:s.profile,cvText:s.cvText,personalLegend:s.personalLegend,pageText:e.slice(0,12e3)},null,2),a=await h({schemaName:"job_extraction_and_brief",schema:hn,model:await ne(),reasoningEffort:"low",systemPrompt:gn,userPrompt:t,parse:r=>JSON.parse(r)}),i={company:a.company,position:a.position,location:a.location,description:a.description,requirements:a.requirements,responsibilities:a.responsibilities,salary:a.salary,techStack:a.techStack,contact:a.contact,url:n},o={language:{postingLanguages:a.postingLanguages,requirements:a.languageRequirements},keywords:$(a.keywords,i),contact:null};return{job:i,brief:o}}const mn={type:"object",additionalProperties:!1,required:["company","position","location","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...de}},yn=`You read the visible text of a job-posting page. It was already parsed
without AI: "knownFields" holds what that found. Fill in what it missed, and analyze the posting
for language and keywords — against the applicant profile/CV/Personal Legend given below.

FIELDS
- Fill only the fields named in "fieldsToFill". For every other posting field return "" / [] /
  null — those are kept from the page as they are. Never re-type the posting's description.
- position: the job title alone — no company, job board or "| LinkedIn"-style suffix.
- company: the hiring company, not the job board or recruiting platform hosting the page.
- location: as written in the posting; "" if none.
- requirements, responsibilities: at most 8 items each, each a short phrase (12 words or fewer),
  not copied paragraphs.
- techStack: technology names only.
- contact: a named recruiter/hiring manager's email address or LinkedIn profile/company URL,
  copied VERBATIM (exact characters); otherwise null.
- Only use information present in "pageText"; leave a field empty/null if unknown.

${he}

${U('"pageText"')}`;async function wn(e,n){const s=await y(),t=xe(e),a=n||e.description,i=JSON.stringify({profile:s.profile,cvText:s.cvText,personalLegend:s.personalLegend,knownFields:{position:e.position,company:e.company,location:e.location,salary:e.salary,contact:e.contact},fieldsToFill:t,pageText:a.slice(0,12e3)},null,2),o=await h({schemaName:"job_completion_and_brief",schema:mn,model:await ne(),reasoningEffort:"low",systemPrompt:yn,userPrompt:i,parse:l=>JSON.parse(l)}),r=Pe(e,o,t,a),c={language:{postingLanguages:o.postingLanguages,requirements:o.languageRequirements},keywords:$(o.keywords,r),contact:null};return{job:r,brief:c}}const bn=`You are editing an existing cover letter draft on the applicant's
instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the
  letter the instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements
  that aren't already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the
  instruction explicitly asks to change it.
- Output plain prose paragraphs, no markdown headers.
- Don't introduce AI-slop while editing, and clean it from any sentence you
  touch.

${v}`;async function vn(e,n,s){const t=JSON.stringify({draft:e,instructions:n,job:s},null,2),a=await h({schemaName:"cover_letter_revision",schema:M,model:await Ce(),systemPrompt:bn,userPrompt:t,parse:i=>JSON.parse(i)});return m(a.content)}const En=`You are editing an existing outreach message (an email or LinkedIn note
to a recruiter/hiring contact) on the applicant's instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the message the
  instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements that aren't
  already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the instruction explicitly
  asks to change it.
- If the draft's "subject" is null, keep it null (it's a LinkedIn note). Otherwise keep a
  specific subject line, changing it only if the instruction (or the edit) requires it.
- Don't introduce AI-slop while editing, and clean it from any sentence you touch.

${v}`;async function Sn(e,n,s){const t=JSON.stringify({draft:e,instructions:n,job:s},null,2),a=await h({schemaName:"outreach_message_revision",schema:pe,model:await te(),systemPrompt:En,userPrompt:t,parse:i=>JSON.parse(i)});return{subject:e.subject===null?null:a.subject,body:m(a.body)}}const Tn=`You translate a cover letter for the applicant's own understanding —
not for submission. Translate faithfully, preserve paragraph breaks, and keep
names, companies, and technical terms as-is where translating them would be
unnatural. Do not use em dashes ("—"); use commas or periods. Output plain
prose paragraphs, no markdown headers, no notes about the translation itself.`;async function Ln(e,n){const s=JSON.stringify({content:e,targetLanguage:n},null,2),t=await h({schemaName:"cover_letter_translation",schema:M,systemPrompt:Tn,userPrompt:s,parse:a=>JSON.parse(a)});return m(t.content)}const kn={type:"object",additionalProperties:!1,required:["answer","sufficientInfo"],properties:{answer:{type:"string"},sufficientInfo:{type:"boolean"}}},J=`You answer a custom question from a job application form on the
applicant's behalf.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend,
  cover letter, custom fields, language levels, and job posting. Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, the
  "languageLevels" list is the authoritative answer (CEFR levels the
  applicant self-reported in Settings) — use it directly rather than
  guessing from the CV or defaulting to a low/neutral level.
- If the profile/CV/Personal Legend/etc genuinely lack what's needed to
  answer this question — not just a minor detail, but the actual substance
  being asked for — set "sufficientInfo" to false and "answer" to an empty
  string. Do NOT write a sentence explaining that you don't have the
  information (e.g. "I don't have this information available") — that text
  would otherwise get typed straight into the applicant's form field, which
  is worse than leaving it blank for the applicant to fill in themselves.
  Only do this when the information is truly absent; a question you can
  answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient —
  set sufficientInfo to true and give that honest answer.
- If "postingLanguage" is given, write the answer in that language, using
  the salutation/register conventions native speakers of it would expect on
  a job application (e.g. formal "Sie"/"Herr"/"Frau" address in German, not
  a literal English-to-German translation) — unless the question itself, or
  "generationRules", explicitly asks for a different language.
- If this question is a newsletter, marketing-email, or job-alert
  subscription opt-in phrased as a choice (e.g. "Would you like to
  subscribe to our newsletter? Yes/No"), always choose the option that
  declines it — the applicant never needs this to submit the application.
- "faq" is a set of pre-written answers to standard interview-FAQ questions
  (spec_5 section B). If the question being asked now is the same as, or a
  close variant of, one already in "faq", reuse its substance and phrasing —
  adapt only what the target field's length/format actually requires — so
  the applicant's answer stays consistent across different forms rather
  than being re-derived from scratch each time.
- Match the question's expected length: a short field gets a short answer, an
  open-ended "tell us about..." field gets a fuller one.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text, no markdown, no restating the question.

${v}`,In=/\b(?:please\s+(?:provide|specify|clarify)|could\s+you\s+(?:please\s+)?(?:provide|clarify|specify)|i\s+(?:don'?t|do\s+not)\s+see)\b.{0,40}?\b(?:question|prompt)\b|\bno\s+(?:specific\s+)?question\s+(?:was|is)?\s*(?:provided|given|specified|attached)\b/i;function ge(e){const n=e.trim();return n?n.length<220&&In.test(n):!0}const _n=`
- This is a MULTIPLE-CHOICE question: "options" lists the allowed answers.
  Reply with EXACTLY ONE option, copied verbatim, and nothing else.
- Base the choice on the applicant's profile/CV/Personal Legend. If the
  needed fact is genuinely absent (e.g. pronouns not stated anywhere),
  prefer a neutral option, an explicit "prefer not to say", or the option
  that commits the applicant least.`,On=`
- This is a SELECT-ALL-THAT-APPLY question: "options" lists every allowed
  answer. Reply with every option that genuinely applies, each copied
  verbatim, joined by " | " (a single pipe surrounded by one space on each
  side) — nothing else. If none apply, reply with an empty string.
- Base each choice strictly on the applicant's profile/CV/Personal Legend —
  never include an option just because it's plausible or common; only ones
  the applicant's own material actually supports.`,An=`
- This field only accepts a plain number: reply with digits only (a single
  "." for a decimal if needed) — no currency symbol, no thousands
  separator, no unit, no words, no range. If a range genuinely fits best
  (e.g. a salary expectation given as "65-75k"), reply with one
  representative figure (its midpoint), not the range.`;function Rn(e){return`
- This field only accepts a date in the exact format "${se[e]}"
  — reply with ONLY that value, nothing else (no words, no explanation).
  "todayISO" in the data below is today's date: compute the answer from it
  — e.g. "available with one month's notice" → todayISO plus one month;
  "immediately" / "as soon as possible" / no stated constraint → todayISO
  itself. Never answer with a description of the notice period or
  availability instead of the date itself.`}async function xn(e,n,s,t,a,i,o){const[r,c]=await Promise.all([y(),P("lastCoverLetter")]),l=JSON.stringify({job:n,profile:r.profile,cvText:r.cvText,personalLegend:r.personalLegend,generationRules:r.generationRules,coverLetter:c??"",languageLevels:r.languageLevels,customFields:r.customFields,faq:r.faq.filter(u=>u.answer.trim()),todayISO:C(),postingLanguage:o||void 0,question:e,options:s&&s.length>0?s:void 0},null,2),p=[s&&s.length>0?i?On:_n:"",t?An:"",a?Rn(a):""].filter(Boolean),d=await h({schemaName:"custom_question_answer",schema:kn,systemPrompt:p.length>0?[J,...p].join(`
`):J,userPrompt:l,parse:u=>JSON.parse(u)});return!d.sufficientInfo||ge(d.answer)?{answer:"",sufficientInfo:d.sufficientInfo}:{answer:s&&s.length>0||t||!!a?d.answer:m(d.answer),sufficientInfo:!0}}const Pn={type:"object",additionalProperties:!1,required:["questions"],properties:{questions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","question"],properties:{index:{type:"integer"},question:{type:"string"}}}}}},Cn=`You are given a block of a job-application form: its visible text, and a
list of the input fields inside it. For each field that asks the applicant
something, return the question it is asking, phrased as a plain question.

Rules:
- Use ONLY the visible text provided. Never invent a question.
- Match each question to its field by "index".
- Omit a field that is not a real question (layout helper, hidden field,
  search box, honeypot, a plain "First name"-style profile field).
- A field with "options" is a multiple-choice question — still return only
  its question text, not the options.
- Output the question text only — no numbering, no "Question:" prefix.
- Questions may be in any language; keep the form's own language.`;async function Nn(e,n){if(n.length===0)return{};const s=JSON.stringify({blockText:e.slice(0,6e3),fields:n},null,2),t=await h({schemaName:"block_questions",schema:Pn,systemPrompt:Cn,userPrompt:s,parse:i=>JSON.parse(i)}),a={};for(const i of t.questions)i.question.trim()&&(a[i.index]=i.question.trim());return a}const jn=/newsletter|marketing|subscribe|promotion|job\s*alert|career\s*news|werbung|benachrichtigung|abonnier|stellenausschreibung/i;function B(e){return jn.test(e)}const qn={type:"object",additionalProperties:!1,required:["checkboxDecisions","questionAnswers"],properties:{checkboxDecisions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","check","category","reason"],properties:{index:{type:"integer"},check:{type:"boolean"},category:{type:"string",enum:["required-consent","marketing","optional","unclear"]},reason:{type:"string"}}}},questionAnswers:{type:"array",items:{type:"object",additionalProperties:!1,required:["id","answer","sufficientInfo"],properties:{id:{type:"string"},answer:{type:"string"},sufficientInfo:{type:"boolean"}}}}}},Mn=`You fill in two independent things found on a job-application form at once:
consent checkboxes to decide, and custom questions to answer on the applicant's behalf. The
applicant has already chosen to submit this application.

CHECKBOXES (one decision per item in "checkboxes", matched back by "index")

TICK (check: true) — things required to submit, or that a candidate is normally expected to
accept:
- privacy policy / data protection / GDPR / Datenschutz consent
- terms & conditions / AGB / Nutzungsbedingungen
- confirming the entered information is accurate / truthful
- consent to process and store the application data for THIS hiring process
- storing the data in a talent pool ONLY when the checkbox is marked required
- eligibility self-declarations that hold for any ordinary adult applying for a real job (e.g.
  "I am at least 18 years old", "I am legally entitled to work in [country]", "I have no
  undisclosed conflicts of interest") — assume true unless the profile/CV explicitly states
  otherwise; a genuine job applicant submitting this form is virtually always eligible, and
  leaving a required declaration like this unticked blocks submission for no real reason

DO NOT TICK (check: false) — optional and promotional:
- newsletters, marketing e-mails, "career news", event invitations
- job alerts / notifications about new postings (e.g. "Benachrichtigungen über neue
  Stellenausschreibungen erhalten")
- sharing data with third parties / partner companies for marketing
- joining a talent pool / candidate database when NOT required
- anything that benefits the applicant only beyond this one application

Rules:
- "required: true" means the form marks the field mandatory — a strong signal to tick, unless
  the text is clearly marketing.
- A newsletter/marketing-email/job-alert opt-in is NEVER ticked, even when the form marks it
  "required" — that flag is routinely misused by forms to guilt-trip applicants into
  subscribing, even though applicants never actually need it to submit. When genuinely in doubt
  whether a required checkbox is a real submission requirement or a disguised newsletter
  opt-in, prefer NOT ticking it.
- If a checkbox is ambiguous AND not required, set check: false.
- Labels may be in any language; judge by meaning, not keywords.
- category: "required-consent" (ticked, mandatory-type), "marketing" (left off), "optional"
  (non-marketing but skippable, left off unless required), "unclear" (left off). reason: one
  short phrase.
- Return one decision per input item in "checkboxes", using its "index". If "checkboxes" is
  empty, return an empty array.

QUESTIONS (one answer per item in "questions", matched back by "id")

Ground rules:
- Use ONLY facts present in the shared "profile"/"cvText"/"personalLegend"/"generationRules"/
  "coverLetter"/"languageLevels"/"customFields"/"faq" given below, plus "job". Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, "languageLevels" is the
  authoritative answer (CEFR levels the applicant self-reported in Settings) — use it directly
  rather than guessing from the CV or defaulting to a low/neutral level.
- If the shared material genuinely lacks what's needed to answer a given question — not just a
  minor detail, but the actual substance being asked for — set that item's "sufficientInfo" to
  false and "answer" to an empty string. Do NOT write a sentence explaining that you don't have
  the information — that text would otherwise get typed straight into the applicant's form
  field, which is worse than leaving it blank. Only do this when the information is truly
  absent; a question you can answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient.
- If "postingLanguage" is given, write answers in that language, using the salutation/register
  conventions native speakers of it would expect on a job application (e.g. formal
  "Sie"/"Herr"/"Frau" address in German) — unless the question itself, or "generationRules",
  explicitly asks for a different language.
- A newsletter/marketing-email/job-alert subscription opt-in phrased as a question (e.g. "Would
  you like to subscribe to our newsletter? Yes/No") always gets the option that declines it.
- "faq" is a set of pre-written answers to standard interview-FAQ questions. If a question being
  asked now is the same as, or a close variant of, one already in "faq", reuse its substance and
  phrasing — adapt only what the target field's length/format actually requires.
- Match each question's expected length: a short field gets a short answer, an open-ended
  "tell us about..." field gets a fuller one.
- Output plain text per answer, no markdown, no restating the question.
- Each item in "questions" may also carry:
  - "options" (and not "multi"): a single-choice question — reply with EXACTLY ONE option,
    copied verbatim, nothing else. If the needed fact is genuinely absent (e.g. pronouns not
    stated anywhere), prefer a neutral option or an explicit "prefer not to say".
  - "options" with "multi": true: a select-all-that-apply question — reply with every option
    that genuinely applies, each copied verbatim, joined by " | " (one pipe, one space each
    side). If none apply, reply with an empty string. Never include an option just because it's
    plausible — only ones the applicant's own material actually supports.
  - "numeric": true: the field only accepts a plain number — reply with digits only (a single
    "." for a decimal if needed), no currency symbol, no thousands separator, no unit, no words,
    no range. If a range genuinely fits best (e.g. "65-75k"), reply with one representative
    figure (its midpoint).
  - "dateFormat": the field only accepts a date in exactly that format — reply with ONLY that
    value, nothing else. "todayISO" below is today's date: compute the answer from it — e.g.
    "available with one month's notice" -> todayISO plus one month; "immediately"/"as soon as
    possible"/no stated constraint -> todayISO itself.
- Return one answer per input item in "questions", using its "id". If "questions" is empty,
  return an empty array.

${v}`;function Un(e,n){const s=new Map;for(const t of n)s.set(t.index,t);return e.map((t,a)=>{const i=s.get(a);if(i){const o=i.check&&B(t.label)?!1:i.check;return{name:t.name,label:t.label,check:o,category:i.category,reason:i.reason}}return B(t.label)?{name:t.name,label:t.label,check:!1,category:"marketing",reason:"No decision returned — looks like a newsletter/marketing opt-in"}:{name:t.name,label:t.label,check:t.required,category:t.required?"required-consent":"unclear",reason:t.required?"Marked required by the form":"No decision returned"}})}function $n(e,n){const s=new Map;for(const t of n)s.set(t.id,t);return e.map(t=>{const a=s.get(t.id);if(!a)return{id:t.id,answer:"",sufficientInfo:!0};if(!a.sufficientInfo||ge(a.answer))return{id:t.id,answer:"",sufficientInfo:a.sufficientInfo};const i=t.options&&t.options.length>0||t.numeric||!!t.dateKind;return{id:t.id,answer:i?a.answer:m(a.answer),sufficientInfo:!0}})}async function Fn(e,n,s,t){if(e.length===0&&n.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[a,i]=await Promise.all([y(),P("lastCoverLetter")]),o=JSON.stringify({job:s,profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,generationRules:a.generationRules,coverLetter:i??"",languageLevels:a.languageLevels,customFields:a.customFields,faq:a.faq.filter(c=>c.answer.trim()),todayISO:C(),postingLanguage:t||void 0,checkboxes:e.map((c,l)=>({index:l,label:c.label,required:c.required,currentlyChecked:c.checked})),questions:n.map(c=>({id:c.id,question:c.question,options:c.options&&c.options.length>0?c.options:void 0,multi:c.multi,numeric:c.numeric,dateFormat:c.dateKind?se[c.dateKind]:void 0}))},null,2),r=await h({schemaName:"page_content_decisions",schema:qn,systemPrompt:Mn,userPrompt:o,parse:c=>JSON.parse(c)});return{checkboxDecisions:Un(e,r.checkboxDecisions),questionAnswers:$n(n,r.questionAnswers)}}const Dn={type:"object",additionalProperties:!1,required:["postingLanguages","requirements","keywords","contact"],properties:{postingLanguages:{type:"array",items:{type:"string"}},requirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...ae,null]}}}},keywords:ue,contact:{type:["string","null"]}}},Yn=`You read a job posting and report three independent things about it: its
language, the skills it asks for (keywords), and (only if asked below) a recruiter/hiring
contact. Judge language and keywords against the applicant profile/CV/Personal Legend given
below.

LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- requirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or
  "Native" for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent",
  "professional working proficiency" -> "C1"; "conversational" -> "B1". If a language is
  mentioned but no level can be reasonably inferred, set level to null. Do not invent a
  requirement that isn't stated in the text. If nothing is stated, return an empty array.

${U("the posting text (job title, description, requirements, responsibilities)")}

CONTACT
- "job.contact" below is the recruiter/hiring contact already found elsewhere, or null if none
  was found yet.
- If it is already set (not null), ignore this entirely and return "contact": null — there is
  nothing to add.
- If it is null, look for one in the job's own text (description/requirements/responsibilities):
  a named recruiter/hiring manager's email address, or a LinkedIn profile/company URL. If you
  find one, copy it VERBATIM (exact characters) so it can be re-found on the page for
  highlighting — the same rule as for keywords. If none is mentioned, return "contact": null.`;async function Jn(e){const n=await y(),s=JSON.stringify({profile:n.profile,cvText:n.cvText,personalLegend:n.personalLegend,job:e},null,2),t=await h({schemaName:"job_brief",schema:Dn,model:await ee(),systemPrompt:Yn,userPrompt:s,parse:a=>JSON.parse(a)});return{language:{postingLanguages:t.postingLanguages,requirements:t.requirements},keywords:$(t.keywords,e),contact:t.contact}}const Bn={type:"object",additionalProperties:!1,required:["values"],properties:{values:{type:"array",items:{type:"object",additionalProperties:!1,required:["name","value","reason"],properties:{name:{type:"string"},value:{type:"string"},reason:{type:"string"}}}}}},Hn=`You adapt an applicant's CV template to one specific job posting by
choosing a value for each {{placeholder}} in it.

Each variable comes with:
- "description": the applicant's own instruction for what the placeholder means and
  how to choose it. Follow it.
- "mode": "choice" means "value" MUST be exactly one of "options", copied verbatim
  (same spelling, same case, same line breaks). "free" means "options" are only
  examples of the expected shape and length; write the value that fits this posting
  in that same shape (e.g. a city name, a comma-separated list).
- "foundInPosting": options that literally occur in the posting text, most frequent
  first. A strong hint, not an order: the role's actual focus matters more than a
  passing mention.

Rules:
- Pick what makes this CV the closest honest match for this posting: its title, its
  location, its main technology, the vocabulary it uses.
- Honesty: never make the CV claim a skill, technology or experience the applicant's
  CV text / Personal Legend doesn't support, unless the variable's description
  explicitly asks for it. For list-like values, prefer terms that are both in the
  posting and supported by the applicant's background.
- Write the value in the same language as the surrounding template text.
- Return one entry per variable given, using its exact "name".
- "reason": one short sentence (max ~15 words) on why this value fits the posting.
- Plain text only, no markdown, no em dashes.`;function Gn(e,n){const s=a=>a.trim().replace(/\s+/g," ").toLowerCase(),t=s(e);return n.options.find(a=>s(a)===t)??null}async function Vn(e,n){const s=new Set(Ne(n.content)),t=n.variables.filter(r=>s.has(r.name));if(t.length===0)return[];const a=await y(),i={variables:t.map(r=>({name:r.name,mode:r.mode,description:r.description,options:r.options,foundInPosting:je(r.options,e)})),template:n.content.slice(0,12e3),job:{position:e.position,company:e.company,location:e.location,techStack:e.techStack,requirements:e.requirements,responsibilities:e.responsibilities,description:e.description.slice(0,8e3)},applicant:{cvText:a.cvText.slice(0,12e3),personalLegend:a.personalLegend.slice(0,8e3),city:a.profile.city,country:a.profile.country}},o=await h({schemaName:"cv_template_values",schema:Bn,model:await qe(),systemPrompt:Hn,userPrompt:JSON.stringify(i,null,2),parse:r=>JSON.parse(r)});return t.map(r=>{const c=o.values.find(p=>p.name===r.name);if(!c)return{name:r.name,value:F(r,e),reason:""};if(r.mode==="choice"&&r.options.length>0){const p=Gn(c.value,r);return p?{name:r.name,value:p,reason:m(c.reason)}:{name:r.name,value:F(r,e),reason:""}}const l=m(c.value);return{name:r.name,value:Me(r.name)?dn(l,e):l,reason:m(c.reason)}})}async function fe(e){const n=await f(e);await Promise.all(n.map(s=>chrome.tabs.sendMessage(e,{type:"CANCEL_ELEMENT_PICKER",tabId:e},{frameId:s}).catch(()=>{})))}async function w(e,n,s){return(await Promise.all(n.map(a=>chrome.tabs.sendMessage(e,s,{frameId:a}).catch(()=>{})))).filter(a=>!!a)}async function H(e,n,s,t){if(s!==void 0&&n.includes(s)){const a=await chrome.tabs.sendMessage(e,t,{frameId:s}).catch(()=>{});if(a)return[a]}return w(e,n,t)}function Kn(e){const n=new Map;for(const s of e){const t=s.locator.frameId;n.set(t,[...n.get(t)??[],s])}return n}async function zn(e){var n,s;switch(e.type){case"GET_PROFILE":return{type:"PROFILE_DATA",profile:await x()};case"GET_JOB":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});if(!e.force&&(t!=null&&t.url)){const p=await $e(t.url);if(p)return{type:"JOB_DATA",job:p,sufficient:!0}}const a=await f(e.tabId),o=(await w(e.tabId,a,e)).filter(p=>p.type==="JOB_DATA");if(o.length===0)return;const r=o.find(p=>p.sufficient);if(r)return t!=null&&t.url&&Fe(t.url,r.job),r;const c=o.reduce((p,d)=>d.job.description.length>p.job.description.length?d:p),l=o.map(p=>p.visibleText??"").filter(Boolean).join(`

`).slice(0,2e4);return{type:"JOB_DATA",job:c.job,sufficient:!1,visibleText:l||c.visibleText||"",pageUrl:t==null?void 0:t.url}}case"COMPLETE_JOB":{const{job:t,brief:a}=await wn(e.job,e.text);return{type:"JOB_DATA",job:t,sufficient:!0,brief:a}}case"EXTRACT_JOB_FROM_TEXT":{const t=await chrome.tabs.get(e.tabId).catch(()=>{}),{job:a,brief:i}=await fn(e.text,(t==null?void 0:t.url)??"");return{type:"JOB_DATA",job:a,sufficient:!0,brief:i}}case"AUTOFILL":{const t=await f(e.tabId),i=(await w(e.tabId,t,e)).filter(o=>o.type==="AUTOFILL_RESULT");return{type:"AUTOFILL_RESULT",filled:i.reduce((o,r)=>o+r.filled,0),total:i.reduce((o,r)=>o+r.total,0),generatedPassword:i.map(o=>o.generatedPassword).find(Boolean)??null}}case"GENERATE_COVER_LETTER":{const{tabId:t}=e,a=await en(e.job,e.postingLanguage,i=>{chrome.runtime.sendMessage({type:"COVER_LETTER_STREAM_CHUNK",tabId:t,delta:i}).catch(()=>{})});return await N("lastCoverLetter",a.content),{type:"COVER_LETTER_RESULT",content:a.content,slopFindings:a.slopFindings,cleaned:a.cleaned}}case"UPLOAD_FILE":{const t=await f(e.tabId),i=(e.targetLocator?await H(e.tabId,t,e.targetLocator.frameId,e):await w(e.tabId,t,e)).filter(o=>o.type==="UPLOAD_FILE_RESULT");return{type:"UPLOAD_FILE_RESULT",nativeInputs:i.reduce((o,r)=>o+r.nativeInputs,0),dropZones:i.reduce((o,r)=>o+r.dropZones,0)}}case"REVISE_COVER_LETTER":{const t=await vn(e.content,e.instructions,e.job);return await N("lastCoverLetter",t),{type:"REVISE_COVER_LETTER_RESULT",content:t}}case"TRANSLATE_COVER_LETTER":return{type:"TRANSLATE_COVER_LETTER_RESULT",content:await Ln(e.content,e.targetLanguage)};case"GENERATE_OUTREACH_MESSAGE":{const t=await y(),a=await nn({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,outreachRules:t.outreachRules,job:e.job,contact:e.contact,postingLanguage:e.postingLanguage});return{type:"OUTREACH_MESSAGE_RESULT",subject:a.subject,body:a.body}}case"REVISE_OUTREACH_MESSAGE":{const t=await Sn({subject:e.subject,body:e.body},e.instructions,e.job);return{type:"OUTREACH_MESSAGE_RESULT",subject:t.subject,body:t.body}}case"GET_FRAME_ACCESS":return{type:"FRAME_ACCESS",blockedOrigins:await Ge(e.tabId)};case"DETECT_CUSTOM_QUESTIONS":{const t=await f(e.tabId),a=await w(e.tabId,t,e),i=new Set,o=[];for(const r of a)if(r.type==="CUSTOM_QUESTIONS_DATA")for(const c of r.questions)i.has(c.question)||(i.add(c.question),o.push({...c,id:`question-${o.length}`}));return{type:"CUSTOM_QUESTIONS_DATA",questions:o}}case"ANSWER_CUSTOM_QUESTION":{const t=await xn(e.question,e.job,e.options,e.numeric,e.dateKind,e.multi,e.postingLanguage);return{type:"CUSTOM_QUESTION_ANSWER",question:e.question,answer:t.answer,sufficientInfo:t.sufficientInfo}}case"FILL_CUSTOM_QUESTION_ANSWERS":{const t=await f(e.tabId),a=await w(e.tabId,t,e);let i=0;const o=[];for(const r of a)r.type==="CUSTOM_QUESTION_FILL_RESULT"&&(i+=r.filled,o.push(...r.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:i,unfilled:o}}case"START_ELEMENT_PICKER":{const t=await f(e.tabId),a=t.map(o=>chrome.tabs.sendMessage(e.tabId,e,{frameId:o}).then(r=>r?{result:r,frameId:o}:void 0).catch(()=>{})),i=await new Promise(o=>{let r=a.length;r===0&&o(void 0);for(const c of a)c.then(l=>{r-=1,l?o(l):r===0&&o(void 0)})});return await Promise.all(t.map(o=>chrome.tabs.sendMessage(e.tabId,{type:"CANCEL_ELEMENT_PICKER",tabId:e.tabId},{frameId:o}).catch(()=>{}))),i?{...i.result,picked:i.result.picked.map(o=>({...o,locator:{...o.locator,frameId:i.frameId}}))}:{type:"ELEMENT_PICKER_RESULT",cancelled:!0,picked:[],blockText:"",semanticCount:0}}case"CANCEL_ELEMENT_PICKER":{await fe(e.tabId);return}case"DECOMPOSE_BLOCK":return{type:"BLOCK_QUESTIONS",questions:await Nn(e.blockText,e.fields)};case"FILL_QUESTION_ANSWERS_BY_LOCATOR":{const t=await f(e.tabId),a=(await Promise.all([...Kn(e.items)].map(([r,c])=>H(e.tabId,t,r,{...e,items:c})))).flat();let i=0;const o=[];for(const r of a)r.type==="CUSTOM_QUESTION_FILL_RESULT"&&(i+=r.filled,o.push(...r.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:i,unfilled:o}}case"DETECT_CHECKBOXES":{const t=await f(e.tabId),a=await w(e.tabId,t,e),i=new Set,o=[];for(const r of a)if(r.type==="CHECKBOXES_DATA")for(const c of r.checkboxes){const l=c.name||c.label;!l||i.has(l)||(i.add(l),o.push({...c,id:`checkbox-${o.length}`}))}return{type:"CHECKBOXES_DATA",checkboxes:o}}case"DECIDE_PAGE_CONTENT":{const{checkboxDecisions:t,questionAnswers:a}=await Fn(e.checkboxes,e.questions,e.job,e.postingLanguage);return{type:"PAGE_CONTENT_DECISIONS",checkboxDecisions:t,questionAnswers:a}}case"APPLY_CHECKBOX_DECISIONS":{const t=await f(e.tabId),a=await w(e.tabId,t,e);let i=0;for(const o of a)o.type==="CHECKBOX_APPLY_RESULT"&&(i+=o.changed);return{type:"CHECKBOX_APPLY_RESULT",changed:i}}case"DETECT_JOB_BRIEF":{const t=await Jn(e.job);return{type:"JOB_BRIEF_DATA",language:t.language,keywords:t.keywords,contact:t.contact}}case"HIGHLIGHT_KEYWORDS":{const t=await f(e.tabId);return{type:"KEYWORD_HIGHLIGHT_RESULT",matched:(await w(e.tabId,t,e)).reduce((o,r)=>r.type==="KEYWORD_HIGHLIGHT_RESULT"?o+r.matched:o,0)}}case"CLEAR_KEYWORD_HIGHLIGHTS":{const t=await f(e.tabId);await w(e.tabId,t,e);return}case"GENERATE_FAQ_ANSWERS":{const t=await z(),a=await st(e.questions,t);try{await Ue(a)}catch{}return{type:"FAQ_ANSWERS_RESULT",entries:a}}case"SEARCH_JOBS":{const{provider:t}=e.query,a=performance.now(),i=[],o=()=>({totalMs:performance.now()-a,stages:i}),{searchId:r}=e,c=r?u=>{chrome.runtime.sendMessage({type:"JOB_SEARCH_PROGRESS",searchId:r,results:u}).catch(()=>{})}:void 0;if(t==="adzuna"){const[u,R]=await Promise.all([D(),x()]);if(!u.adzunaAppId||!u.adzunaAppKey)throw new Error("Add your Adzuna app_id and app_key in Settings first.");let g=e.query;if(!((n=g.tags)!=null&&n.length))if(g.what.trim())g={...g,tags:[g.what.trim()]};else{const me=performance.now(),L=await Y(!0);i.push({label:L.cached?"Suggest tags (cached)":"Suggest tags",ms:performance.now()-me}),g={...g,what:L.what,where:g.where.trim()||L.where,tags:(s=L.tags)!=null&&s.length?L.tags:[L.what]}}const{results:T,warnings:_}=await A(i,"Adzuna search",()=>Lt(g,{appId:u.adzunaAppId,appKey:u.adzunaAppKey},It(R.country),e.page??1,c));return{type:"JOB_SEARCH_RESULTS",results:T,resolvedQuery:g,warnings:_,...o()}}const[l,p]=await Promise.all([K(),D()]),d=(l==null?void 0:l.content)??"";if(t==="tavily"){if(!p.tavilyApiKey)throw new Error("Add your Tavily API key in Settings first.");return{type:"JOB_SEARCH_RESULTS",results:await yt(e.query,p.tavilyApiKey,d,e.excludeResults,i),resolvedQuery:e.query,...o()}}return{type:"JOB_SEARCH_RESULTS",results:await ht(e.query,d,e.excludeResults,i,c),resolvedQuery:e.query,...o()}}case"SUGGEST_SEARCH_QUERY":{const{what:t,where:a,tags:i}=await Y(e.provider==="adzuna");return{type:"SEARCH_QUERY_SUGGESTION",what:t,where:a,...e.provider==="adzuna"?{tags:i}:{}}}case"SUGGEST_CV_VALUES":return{type:"CV_VALUES",values:await Vn(e.job,e.template)};default:return}}const Qn="src/sidepanel/index.html";chrome.runtime.onInstalled.addListener(()=>{Qe(),chrome.sidePanel.setOptions({enabled:!1})});chrome.contextMenus.onClicked.addListener((e,n)=>{Xe(e,n)});chrome.action.onClicked.addListener(e=>{if(e.id===void 0)return;const n=e.id;chrome.sidePanel.setOptions({tabId:n,path:Qn,enabled:!0}),chrome.sidePanel.open({tabId:n}).catch(s=>console.error("sidePanel.open failed",s)),f(n)});chrome.tabs.onRemoved.addListener(e=>{De(e)});chrome.runtime.onMessage.addListener((e,n,s)=>(zn(e).then(s).catch(t=>{s({type:"ERROR",error:t instanceof Error?t.message:String(t),code:t instanceof Error?t.name:void 0})}),!0));chrome.runtime.onConnect.addListener(e=>{const n=/^picker-(\d+)$/.exec(e.name);if(!n)return;const s=Number(n[1]);e.onDisconnect.addListener(()=>{fe(s)})});
