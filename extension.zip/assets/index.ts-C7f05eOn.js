import{P as ae,g as $,a as P,b as se,c as oe,s as ie,d as k,e as Y,f as re,h as le,i as ce,j as pe,k as D,r as d,J as F,t as _,l as H,M as B,A as J,m as ue,n as de,o as G,p as he,q as V,u as ge,C as K,v as fe,D as Q,w as me,x as ye,y as we,z as R,B as x,E as be,F as A,G as ve,H as C,I as Ee}from"./template-CL0A9B7g.js";import{c as Se,a as Te}from"./phone-CZ16BBLi.js";const W={...ae,cv:"CV",coverLetter:"Cover Letter",generatePassword:"Generated password"},Le=Object.keys(W);async function h(e){try{const t=(await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:["content-script.js"]})).map(n=>n.frameId).filter(n=>typeof n=="number");if(t.length>0)return t}catch{}try{return await chrome.scripting.executeScript({target:{tabId:e},files:["content-script.js"]}),[0]}catch{return[0]}}async function Ie(e,o){if(e==="cv"){const a=await $();return(a==null?void 0:a.text)??""}if(e==="coverLetter")return await P("lastCoverLetter")??"";if(e==="generatePassword"){const a=await se(o);if(a!=null&&a.generatedPassword)return a.generatedPassword;const s=oe();return a&&await ie(o,{...a,generatedPassword:s}),s}const t=await k(),n=t[e]??"";return e==="phone"&&n?Se(n,t.country):n}const I="job-app-assistant-insert",ke={generatePassword:"Generate password"},_e=Le.map(e=>({id:e,title:ke[e]??W[e]}));function Oe(){chrome.contextMenus.removeAll(()=>{chrome.contextMenus.create({id:I,title:"Insert",contexts:["editable"]});for(const e of _e)chrome.contextMenus.create({id:`${I}:${e.id}`,parentId:I,title:e.title,contexts:["editable"]})})}function Pe(e){return e.startsWith(`${I}:`)?e.slice(I.length+1):null}async function Re(e,o){if(!(o!=null&&o.id)||typeof e.menuItemId!="string")return;const t=Pe(e.menuItemId);if(!t)return;const n=await Ie(t,o.id);await h(o.id);const a={type:"INSERT_VALUE",field:t,value:n};chrome.tabs.sendMessage(o.id,a,{frameId:e.frameId}).catch(()=>{})}const xe=new Set(["profileCache","cvLibraryCache","legendLibraryCache","customFieldsCache","languageLevelsCache","faqAnswersCache","generationRulesCache","outreachRulesCache"]);let T=null;function Ae(){return Promise.all([k(),$(),Y(),re(),le(),ce(),pe(),D()]).then(([e,o,t,n,a,s,i,r])=>({profile:e,cvText:(o==null?void 0:o.text)??"",personalLegend:(t==null?void 0:t.content)??"",generationRules:(n==null?void 0:n.content)??"",outreachRules:(a==null?void 0:a.content)??"",languageLevels:s,customFields:i,faq:r}))}function m(){return T||(T=Ae(),T.catch(()=>{T=null})),T}var U;typeof chrome<"u"&&((U=chrome.storage)!=null&&U.onChanged)&&chrome.storage.onChanged.addListener((e,o)=>{o==="local"&&Object.keys(e).some(t=>xe.has(t))&&(T=null)});const b=`Write like a specific person, not an AI assistant. These rules have no exceptions:

- NEVER use an em dash ("—"), a spaced en dash ("–") or "--" as punctuation. Real people don't write that way. Use a comma, a period, parentheses, or two sentences.
- Banned words: delve, foster, leverage, utilize, facilitate, empower, streamline, robust, cutting-edge, paradigm shift, game changer, tapestry, realm, beacon, multifaceted, meticulous, intricate, paramount, transformative, elevate, embark, supercharge, harness, ever-evolving. Say the plain thing.
- Cut empty phrases: "it's worth noting", "at the end of the day", "when it comes to", "at its core", "in today's world", "the reality is", "in order to", "going forward".
- No "not X, it's Y" / "the question isn't X, it's Y" / "not just X but Y" contrasts. State Y directly.
- No throat-clearing openers ("Here's the thing", "Let me be clear", "I'll be honest") and no faux-insight setups ("what most people get wrong", "here's what nobody tells you").
- No importance puffery ("stands as a testament", "marks a pivotal moment", "plays a vital role", "underscores its significance"). State the fact and stop.
- No colon reveals: a noun phrase, a colon, then a dramatic lowercase clause.
- No trailing "-ing" clauses that editorialize ("highlighting the commitment to...", "underscoring its importance", "showcasing", "reflecting"). End the sentence.
- No metadiscourse that tells the reader what to notice ("this matters", "this distinction matters", "in other words", "as you can see").
- No "In conclusion" / "Ultimately" / "Overall" recap ending and no cute one-line kicker. Stop on the last concrete point.
- No emoji, no mid-sentence bold, no rhetorical questions.
- Vary sentence shape; don't stack short punchy fragments.
- Be concrete: name the technology, project, number, or outcome instead of calling it "significant", "impactful" or "exciting". Use active voice.`;function g(e){return e.replace(/[ \t]*[—―][ \t]*/g,", ").replace(/[ \t]+--[ \t]+/g,", ").replace(/(\D)[ \t]+–[ \t]+(?=\D)/g,"$1, ").replace(/[ \t]+([,.;:!?])/g,"$1").replace(/,(\s*[.;:!?])/g,"$1").replace(/,[ \t]*,/g,",").replace(/^[ \t]*,[ \t]*/gm,"").replace(/([([{])[ \t]*,[ \t]*/g,"$1").replace(/[ \t]*,[ \t]*([)\]}])/g,"$1").replace(/,[ \t]*$/gm,"").replace(/[ \t]+$/gm,"")}const Ce=`You write the applicant's own answers to standard interview-FAQ
questions (spec_5 section B) — general-purpose answers meant to be reused, as-is or
lightly adapted, whenever a real application form asks a close variant of one of them.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend, and
  custom fields. Never invent experience, technologies, companies, education,
  achievements, or a concrete salary figure that wasn't actually given.
- If information needed for a good answer is missing (no CV, no Personal Legend
  content covering it), write a short, honest, generically true answer rather
  than fabricating specifics — the applicant can always sharpen it later.
- Keep each answer 2-5 sentences: concrete and confident, never generic
  corporate filler, no restating the question.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text per answer, no markdown, no numbering.

${b}`;function Ne(e){return{type:"object",additionalProperties:!1,required:["answers"],properties:{answers:{type:"array",minItems:e,maxItems:e,items:{type:"string"}}}}}async function qe(e){if(e.length===0)return[];const{profile:o,cvText:t,personalLegend:n,generationRules:a,customFields:s}=await m(),i=JSON.stringify({profile:o,cvText:t,personalLegend:n,generationRules:a,customFields:s,questions:e},null,2),r=await d({schemaName:"faq_answers",schema:Ne(e.length),systemPrompt:Ce,userPrompt:i,parse:c=>JSON.parse(c)});return e.map((c,l)=>({question:c,answer:g(r.answers[l]??"")}))}async function je(e,o){const t=new Map(o.map(s=>[s.question,s.answer])),n=e.filter(s=>{var i;return!((i=t.get(s))!=null&&i.trim())}),a=await qe(n);for(const s of a)t.set(s.question,s.answer);return e.map(s=>({question:s,answer:t.get(s)??""}))}async function L(e,o,t){const n=performance.now();try{return await t()}finally{e==null||e.push({label:o,ms:performance.now()-n})}}function z(e){return e!=null&&e.length?`Seniority levels to target: ${F.filter(t=>e.includes(t.id)).map(t=>t.label.toLowerCase()).join(", ")}. Only include postings for these levels.`:""}function Me(e,o){const t=F.filter(a=>o==null?void 0:o.includes(a.id));if(t.length===0)return e;const n=[];for(const a of e)for(const s of t)n.push(a.toLowerCase().includes(s.keyword)?a:`${s.keyword} ${a}`.trim());return[...new Set(n)]}const Ue={type:"object",additionalProperties:!1,required:["jobs"],properties:{jobs:{type:"array",items:{type:"object",additionalProperties:!1,required:["title","company","location","url","salary","snippet","postedAt"],properties:{title:{type:"string"},company:{type:"string"},location:{type:"string"},url:{type:"string"},salary:{type:"string"},snippet:{type:"string"},postedAt:{type:"string"}}}}}};function $e(e){return`You turn raw web-search results about job openings into a clean,
structured list. The input text was produced by a live internet search and may include
citations, markdown links, or unrelated surrounding prose — extract only genuine
individual job postings from it.

Rules:
- Only include entries that are clearly actual job postings with a real listing URL —
  never a company's generic careers-page homepage, a search-results page, or an
  aggregator's category page.
- "url" must be copied exactly from the source text (never invented).
- "salary" is "" when no figure was given — never guess one.
- "postedAt" is the date the posting was published, as YYYY-MM-DD, only when the text
  states it. Resolve relative dates ("posted 3 days ago", "2w") against today, ${e}.
  Use "" when no date is given — never guess one.
- Drop postings the text marks as closed, expired, filled or "no longer accepting
  applications", and postings published more than ${B} days before ${e}.
- "snippet" is a 1-2 sentence summary of the role; when a "candidate" background is given
  below, make it say *why this posting fits them* specifically (seniority match, matching
  skills, location/remote fit) rather than just restating the posting.
- If a "candidate" background is given, drop postings that are a poor fit for them (wrong
  seniority, unrelated field) even if they're genuine job postings — only surface ones
  actually worth their time.
- Deduplicate: the same posting linked twice becomes one entry.
- If nothing in the text is actually a job posting, return an empty "jobs" array.`}async function X(e,o,t){const n=t?`candidate:
${t}

---

${e.slice(0,4e4)}`:e.slice(0,4e4),a=await d({schemaName:"job_listings",schema:Ue,systemPrompt:$e(_()),userPrompt:n,parse:s=>JSON.parse(s)});return H(a.jobs.filter(s=>s.url.trim()).map(s=>({...s,source:o})))}function Z(e){return e.length===0?"":`

Already found and shown to the applicant — do NOT return any of these again,
find genuinely different postings instead:
${e.map(t=>`- ${t.title} at ${t.company} (${t.url})`).join(`
`)}`}async function Ye(e,o,t=[],n){const a=e.remoteOnly?" Prefer remote-friendly roles.":"",s=[e.what?`Role/keywords focus: "${e.what}".`:"",e.where?`Location: "${e.where}".`:"",z(e.grades),a].filter(Boolean).join(" "),i=`Search the web for current, actually open job postings that fit this
candidate:

${o||"(no candidate background available)"}

${s||"No further constraints — use the candidate's own background to pick a fitting role/location."}

Today is ${_()}. Only include postings published in the last ${B} days
that are still accepting applications — skip anything marked closed, expired or filled,
or shown with an older date.
Prefer the employer's own posting on its applicant tracking system (${J.join(", ")})
or career page over copies on aggregators, which often outlive the real posting.

Find real postings with their direct listing URL, not a search results page. List up to
15 of the best matches, each with its title, company, location, salary if stated, the date
it was posted when shown, and a short description of why it fits.${Z(t)}`,r=await L(n,"Web search",()=>ue(i));return L(n,"Parse results",()=>X(r,"openai",o))}const De="https://api.tavily.com/search",Fe=2e3;async function He(e,o,t,n=[],a){const s=e.remoteOnly?" Prefer remote-friendly roles.":"",r=`Find job postings from the last few weeks, still open, that fit this candidate.
${[e.what?`Role/keywords focus: "${e.what}".`:"",e.where?`Location: "${e.where}".`:"",z(e.grades),s].filter(Boolean).join(" ")}

Candidate background: ${t||"(none available)"}${Z(n)}`.trim().slice(0,Fe),c=await L(a,"Tavily search",()=>fetch(De,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({api_key:o,query:r,search_depth:"advanced",max_results:15,include_answer:!1,time_range:"month",include_published_date:!0,include_domains:J,include_domains_mode:"prefer"})}));if(!c.ok){const p=await c.text().catch(()=>"");throw new Error(`Tavily search failed (${c.status}): ${p.slice(0,300)}`)}const l=await c.json();if(l.results.length===0)return[];const u=l.results.map(p=>`Title: ${p.title}
URL: ${p.url}
${p.published_date?`Published: ${p.published_date}
`:""}${p.content}`).join(`

---

`);return L(a,"Parse results",()=>X(u,"tavily",t))}function Be(e,o){return!e&&!o?"":de({low:Math.round(e??o??0),high:Math.round(o??e??0)})}function Je(e){return new Promise(o=>setTimeout(o,e))}const Ge=350,Ve=12;async function Ke(e,o,t,n,a){const s=new URL(`https://api.adzuna.com/v1/api/jobs/${n}/search/${a}`);s.searchParams.set("app_id",t.appId),s.searchParams.set("app_key",t.appKey),s.searchParams.set("results_per_page","15"),s.searchParams.set("content-type","application/json"),e&&s.searchParams.set("what",e),o&&s.searchParams.set("where",o);const i=await fetch(s.toString());if(!i.ok){const l=await i.text().catch(()=>"");throw new Error(`Adzuna search failed (${i.status}): ${l.slice(0,300)}`)}const c=(await i.json()).results.map(l=>{var u,p;return{title:l.title,company:((u=l.company)==null?void 0:u.display_name)??"",location:((p=l.location)==null?void 0:p.display_name)??"",url:l.redirect_url,salary:Be(l.salary_min,l.salary_max),snippet:(l.description??"").slice(0,300),postedAt:l.created??"",source:"adzuna",tag:e}});return H(c)}async function Qe(e,o,t,n=1){var p;const a=e.tags&&e.tags.length>0?e.tags:[e.what],s=Math.max(((p=e.grades)==null?void 0:p.length)??0,1),i=Math.max(1,Math.floor(Ve/s)),r=Me(a.slice(0,i),e.grades),c=new Set,l=[],u=[];a.length>i&&u.push(`Only the first ${i} search terms were used with ${s} grades selected.`);for(let v=0;v<r.length;v++){const y=r[v];try{const w=await Ke(y,e.where,o,t,n);for(const E of w)c.has(E.url)||(c.add(E.url),l.push(E))}catch(w){u.push(`"${y}" — ${w instanceof Error?w.message:"search failed"}`)}v<r.length-1&&await Je(Ge)}return{results:l,warnings:u}}const We=new Set(["AT","AU","BE","BR","CA","CH","DE","ES","FR","GB","IN","IT","MX","NL","NZ","PL","RU","SG","US","ZA"]);function ze(e){var t;const o=(t=Te(e))==null?void 0:t.toUpperCase();return o&&We.has(o)?o.toLowerCase():"us"}const Xe={type:"object",additionalProperties:!1,required:["what","where"],properties:{what:{type:"string"},where:{type:"string"}}},Ze=`You suggest a starting job-search query for the applicant described below.
"what" is a short role/keywords phrase (e.g. "senior backend engineer", "product designer") —
their most recent or clearly strongest role from the CV/Personal Legend. Pick ONE single title:
never join multiple roles or technologies with "/", "," or parentheses (e.g. never "Full-Stack
Developer / Backend Engineer (Go, Python, React)") — that reads as a combined AND-match to a
literal keyword search and returns nothing. "where" is a location (city, region, or country) —
their stated city/country if given, else "".
Output only the two fields, no explanation.`;async function O(){const{profile:e,cvText:o,personalLegend:t}=await m(),n=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:o,personalLegend:t},null,2),a=await d({schemaName:"job_search_query_suggestion",schema:Xe,systemPrompt:Ze,userPrompt:n,parse:s=>JSON.parse(s)});return{what:a.what,where:a.where||[e.city,e.country].filter(Boolean).join(", ")}}const et={type:"object",additionalProperties:!1,required:["tags"],properties:{tags:{type:"array",items:{type:"string"}}}},tt=`You generate keyword search tags for Adzuna's job-search API, grounded in
the candidate's real background below. Per Adzuna's own docs
(https://developer.adzuna.com/docs/search), "what" is a single literal keyword/phrase match, not
a semantic search and not a boolean query — so ONE combined tag naming several technologies or
role variants (e.g. "Full-Stack Developer / Backend Engineer (Go, Python, React)") matches
nothing. You compensate by generating a small cross-product of short, atomic tags instead, each
run as its own separate search and merged afterwards.

Method — build the tags as a cross-product, exactly like this worked example for a candidate
whose strongest stack is Go and who also does full-stack/backend work:
  golang developer, go developer, go engineer, golang engineer,
  backend engineer, backend developer, fullstack engineer, fullstack developer,
  software engineer, software developer
That is: {primary technology + its common short aliases} × {developer, engineer}, PLUS
{their role-shape words, e.g. backend / fullstack / frontend / mobile / data — whichever
genuinely apply, without a technology} × {developer, engineer}, PLUS a generic "software
developer" / "software engineer" fallback pair.

Rules:
- Base every tag on their actual, strongest-fitting technology/field from the CV/Personal
  Legend — never invent a technology, role-shape, or seniority they don't have.
- Identify the ONE primary technology (e.g. "Go") plus its common short aliases people actually
  search with (e.g. "Golang") — do not alias unrelated technologies together.
- Each tag pairs exactly one technology-or-role-shape word with exactly one of "developer" /
  "engineer" (add "programmer" only if that's a genuinely common term for that stack). Never put
  two technologies, or a technology and a role-shape, in the same tag.
- If the CV shows a clear secondary technology/stack, budget permitting, add its own couple of
  tags the same way — still never combined with the primary one in a single tag.
- For EACH language listed in "languages" below (skip English), also include ONE of the
  strongest-technology tags translated into that language using the natural job-title term a
  native speaker would search with (not a literal word-for-word translation).
- Each tag is 1-3 words, lowercase, and never contains "/", ",", "(", ")", or a seniority
  qualifier ("senior", "junior", etc.).
- Deduplicate. Return 6-12 tags total, most relevant first.
- Output only the tags, no explanation.`;async function N(){const{profile:e,cvText:o,personalLegend:t,languageLevels:n}=await m(),a=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:o,personalLegend:t,languages:n.map(i=>i.language)},null,2);return(await d({schemaName:"job_search_tags",schema:et,systemPrompt:tt,userPrompt:a,parse:i=>JSON.parse(i)})).tags.map(i=>i.trim()).filter(Boolean)}const nt={type:"object",additionalProperties:!1,required:["keyRequirements","relevantExperienceHints","suggestedTone","suggestedFocus"],properties:{keyRequirements:{type:"array",items:{type:"string"}},relevantExperienceHints:{type:"array",items:{type:"string"}},suggestedTone:{type:"string"},suggestedFocus:{type:"string"}}};async function at(e){return d({schemaName:"job_analysis",schema:nt,model:await G(),systemPrompt:"You analyze job postings for a job-application assistant. Identify the most important requirements and what an applicant should emphasize. Do not invent details that are not present in the posting.",userPrompt:JSON.stringify(e,null,2),parse:o=>JSON.parse(o)})}const st=`You write tailored cover letters for job applications.

The user message holds the applicant's data as JSON, and may end with an
"Applicant's rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and
   Personal Legend. Never invent experience, technologies, companies,
   education, or achievements, even if the applicant's rules ask for them.
   If information needed to be compelling is missing, write around it
   honestly rather than fabricating it.
2. The applicant's rules. Follow every instruction there on tone, length,
   structure, language, and what to include or avoid, including where it
   departs from the defaults below. Every rule there applies to the whole
   letter, not just the opening.
3. Language. If "postingLanguage" is given, write the entire letter in that
   language, using the salutation, register, and closing conventions native
   speakers of it would expect on a job application (e.g. formal
   "Sie"/"Herr"/"Frau" address and a "Sehr geehrte(r) ..." opening in German,
   not a literal English-to-German translation).
4. The house style below. Its "no exceptions" means no exceptions of your
   own; an explicit applicant rule still overrides it.
5. Tone and emphasis tailored to the job analysis provided.

Output plain prose paragraphs, no markdown headers.

${b}`;async function ot(e,o){const n=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,analysis:e.analysis,postingLanguage:e.postingLanguage||void 0},null,2)+ee(e.generationRules),a=await he(st,n,o??(()=>{}));return g(a)}function ee(e){const o=e.trim();return o?`

## Applicant's rules (highest priority after facts)

${o}
`:""}const it={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},rt=`You are a sharp human editor cleaning up a cover letter draft.

Fix ONLY the flagged AI-writing patterns listed below. Make the minimum
effective edit — do not rewrite sentences that were not flagged, do not
change facts, experience, technologies, or claims, and do not add new
content. Replace banned words/clichés with plain, concrete language.
Rewrite "not X, it's Y" contrasts as a direct statement of Y. Cut
throat-clearing openers, weasel attribution, and importance-puffery instead
of softening them. If the ending is a generic summary/recap, end on the
letter's last concrete point instead. Replace every em dash ("—") with a
comma, a period, or parentheses.

The user message may end with the applicant's own rules for the letter. If a
flagged pattern is something those rules explicitly ask for, leave it as is:
the applicant's rules outrank the house style.

Do not introduce any new AI-slop while editing. For reference, the full
house style is:

${b}

Output plain prose paragraphs, no markdown headers.`;async function lt(e,o,t=""){const n=JSON.stringify({draft:e,flaggedPatterns:o.map(s=>`${s.pattern}: "${s.match}"`)},null,2)+ee(t),a=await d({schemaName:"cover_letter_polish",schema:it,systemPrompt:rt,userPrompt:n,parse:s=>JSON.parse(s)});return g(a.content)}const ct=["delve","foster","leverage","utilize","facilitate","empower","streamline","robust","cutting-edge","paradigm shift","game changer","this is huge","this changes everything","tapestry","realm","beacon","multifaceted","meticulous","intricate","paramount","transformative","elevate","embark","supercharge","harness","ever-evolving"],pt=["it's worth noting","it is worth noting","it's important to note","it is important to note","at the end of the day","when it comes to","at its core","in today's world","in the age of","in the world of","the reality is","the truth is","in terms of","with regard to","in order to","going forward"],ut=["here's the thing","here's what i mean","let me be clear","i'll be honest","the uncomfortable truth is"],dt=["this is the part most people skip","what most people get wrong","here's what nobody tells you","the part everyone misses"],ht=["stands as a testament","marks a pivotal moment","plays a vital role","solidifies its position","underscores its significance"],gt=["experts agree","industry reports suggest","many argue","widely regarded as","studies show"],ft=[/^in conclusion\b/i,/^ultimately\b/i,/^overall\b/i];function mt(e){const o=e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`\\b${o.replace(/ /g,"\\s+")}\\b`,"i")}function S(e,o,t){const n=[];for(const a of o){const s=mt(a).exec(e);s&&n.push({pattern:t,match:s[0]})}return n}function yt(e){const o=/\b(?:isn'?t|is not)\b[^.!?]{3,60}[,.]?\s*(?:it'?s|it is)\b[^.!?]{3,80}[.!?]/i,t=/\bnot just\b[^.!?]{3,60}(?:\bbut\b|[,.]?\s*(?:it'?s|it is)\b)[^.!?]{0,80}[.!?]/i,n=[],a=o.exec(e);a&&n.push({pattern:"binary-contrast",match:a[0].trim()});const s=t.exec(e);return s&&n.push({pattern:"binary-contrast",match:s[0].trim()}),n}function wt(e){const o=e.split(/\n{2,}/).map(n=>n.trim()).filter(Boolean),t=o[o.length-1];if(!t)return[];for(const n of ft)if(n.test(t))return[{pattern:"summary-recap-ending",match:t.slice(0,60)}];return[]}function bt(e){const o=(e.match(/—/g)??[]).length;return o===0?[]:[{pattern:"em-dash",match:o===1?"1 em dash":`${o} em dashes`}]}function vt(e){return[...S(e,ct,"banned-word"),...S(e,pt,"empty-phrase"),...S(e,ut,"throat-clearing-opener"),...S(e,dt,"faux-insight-setup"),...S(e,ht,"importance-puffery"),...S(e,gt,"weasel-attribution"),...yt(e),...wt(e),...bt(e)]}async function Et(e,o,t){const n=await m(),a=await at(e),s=await ot({profile:n.profile,cvText:n.cvText,personalLegend:n.personalLegend,generationRules:n.generationRules,job:e,analysis:a,postingLanguage:o},t),i=vt(s);return i.length===0?{content:s,slopFindings:i,cleaned:!1}:{content:await lt(s,i,n.generationRules),slopFindings:i,cleaned:!0}}const St={type:"object",additionalProperties:!1,required:["subject","body"],properties:{subject:{type:["string","null"]},body:{type:"string"}}},Tt=`You write a short outreach message an applicant sends to a named
recruiter/hiring contact BEFORE or alongside applying, to start a conversation about a specific
job posting — not a cover letter, and not addressed to "the hiring team".

The user message holds the applicant's data as JSON ("contact" is the email address or LinkedIn
URL found on the posting), and may end with an "Applicant's rules" section written by the
applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and Personal Legend. Never
   invent experience, technologies, companies, education, or achievements.
2. The applicant's rules. Follow every instruction there on tone, length, structure, language,
   and what to include or avoid, including where it departs from the defaults below.
3. Language. If "postingLanguage" is given, write the entire message in that language, using
   the salutation and register native speakers of it would expect.
4. Channel. If "contact" looks like an email address, write a short email: "subject" is a
   specific, non-generic subject line (name the role and company), "body" opens with a greeting
   and closes with a signature using the applicant's name. If "contact" is a LinkedIn URL,
   write a LinkedIn connection/message note instead: "subject" is null, "body" has no email
   greeting/signature and stays under LinkedIn's informal register.
5. The house style below. Its "no exceptions" means no exceptions of your own; an explicit
   applicant rule still overrides it.

Defaults (apply unless the applicant's rules say otherwise): under 120 words, state who the
applicant is and the one or two things that make them a fit for THIS role, and end with a clear,
low-pressure ask (a quick chat, or just flagging interest before applying). Never sound like a
mass-sent template.

${b}`;async function Lt(e){const t=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,contact:e.contact,postingLanguage:e.postingLanguage||void 0},null,2)+It(e.outreachRules),n=await d({schemaName:"outreach_message",schema:St,model:await V(),systemPrompt:Tt,userPrompt:t,parse:a=>JSON.parse(a)});return{subject:n.subject,body:g(n.body)}}function It(e){const o=e.trim();return o?`

## Applicant's rules (highest priority after facts)

${o}
`:""}const kt={type:"object",additionalProperties:!1,required:["company","position","location","description","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},description:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},postingLanguages:{type:"array",items:{type:"string"}},languageRequirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...K,null]}}}},keywords:{type:"array",items:{type:"object",additionalProperties:!1,required:["text","matchesProfile"],properties:{text:{type:"string"},matchesProfile:{type:"boolean"}}}}}},_t=`You read the visible text of a job-posting page and do two things with it
in one pass: extract the structured posting fields, and analyze the result for language and
keywords — against the applicant profile/CV/Personal Legend given below.

EXTRACTION
- Only use information present in "pageText"; leave a field empty/null if unknown.
- For "contact", prefer a named recruiter/hiring manager's email address or LinkedIn
  profile/company URL if one is mentioned, copied VERBATIM (exact characters); otherwise null.

LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- languageRequirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or "Native"
  for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent", "professional
  working proficiency" -> "C1"; "conversational" -> "B1". If a language is mentioned but no level
  can be reasonably inferred, set level to null. Do not invent a requirement that isn't stated in
  the text. If nothing is stated, return an empty array.

KEYWORDS
- Pick the notable keywords/key phrases out of the posting — the skills, tools, technologies,
  qualifications, and requirements a candidate would want to notice at a glance.
- Every keyword's "text" MUST be copied VERBATIM from "pageText" — the exact same characters and
  casing, not a paraphrase, synonym, or translation — because the extension re-finds this exact
  text on the page to highlight it. A keyword that doesn't appear verbatim in the text is useless.
- Prefer short phrases: single words or 2-3 word phrases (e.g. "TypeScript", "Kubernetes",
  "5+ years", "product management", "Bachelor's degree") — not full sentences.
- Pick 8-15 of the most important ones. Skip generic filler ("team player", "fast-paced
  environment") unless the posting has almost nothing more specific.
- No duplicates, and no two keywords where one is a substring of the other (keep the more
  specific/longer one).
- Set "matchesProfile" to true when the applicant's profile/cvText/personalLegend shows they
  already have, use, or meet that skill/tool/technology/qualification — false when the posting
  asks for it but nothing in the applicant's material supports it. Judge substance, not exact
  wording (e.g. "Kubernetes" counts as a match if the CV mentions "container orchestration with
  K8s" or "EKS"). When genuinely unsure, set it to false — this flags a possible gap for the
  applicant to address rather than silently hiding it.`;async function q(e,o){const t=await m(),n=JSON.stringify({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,pageText:e.slice(0,12e3)},null,2),a=await d({schemaName:"job_extraction_and_brief",schema:kt,model:await ge(),systemPrompt:_t,userPrompt:n,parse:r=>JSON.parse(r)}),s={company:a.company,position:a.position,location:a.location,description:a.description,requirements:a.requirements,responsibilities:a.responsibilities,salary:a.salary,techStack:a.techStack,contact:a.contact,url:o},i={language:{postingLanguages:a.postingLanguages,requirements:a.languageRequirements},keywords:a.keywords,contact:null};return{job:s,brief:i}}const Ot={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},Pt=`You are editing an existing cover letter draft on the applicant's
instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the
  letter the instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements
  that aren't already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the
  instruction explicitly asks to change it.
- Output plain prose paragraphs, no markdown headers.
- Don't introduce AI-slop while editing, and clean it from any sentence you
  touch.

${b}`;async function Rt(e,o,t){const n=JSON.stringify({draft:e,instructions:o,job:t},null,2),a=await d({schemaName:"cover_letter_revision",schema:Ot,model:await fe(),systemPrompt:Pt,userPrompt:n,parse:s=>JSON.parse(s)});return g(a.content)}const xt={type:"object",additionalProperties:!1,required:["subject","body"],properties:{subject:{type:["string","null"]},body:{type:"string"}}},At=`You are editing an existing outreach message (an email or LinkedIn note
to a recruiter/hiring contact) on the applicant's instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the message the
  instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements that aren't
  already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the instruction explicitly
  asks to change it.
- If the draft's "subject" is null, keep it null (it's a LinkedIn note). Otherwise keep a
  specific subject line, changing it only if the instruction (or the edit) requires it.
- Don't introduce AI-slop while editing, and clean it from any sentence you touch.

${b}`;async function Ct(e,o,t){const n=JSON.stringify({draft:e,instructions:o,job:t},null,2),a=await d({schemaName:"outreach_message_revision",schema:xt,model:await V(),systemPrompt:At,userPrompt:n,parse:s=>JSON.parse(s)});return{subject:e.subject===null?null:a.subject,body:g(a.body)}}const Nt={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},qt=`You translate a cover letter for the applicant's own understanding —
not for submission. Translate faithfully, preserve paragraph breaks, and keep
names, companies, and technical terms as-is where translating them would be
unnatural. Do not use em dashes ("—"); use commas or periods. Output plain
prose paragraphs, no markdown headers, no notes about the translation itself.`;async function jt(e,o){const t=JSON.stringify({content:e,targetLanguage:o},null,2),n=await d({schemaName:"cover_letter_translation",schema:Nt,systemPrompt:qt,userPrompt:t,parse:a=>JSON.parse(a)});return g(n.content)}const Mt={type:"object",additionalProperties:!1,required:["answer","sufficientInfo"],properties:{answer:{type:"string"},sufficientInfo:{type:"boolean"}}},j=`You answer a custom question from a job application form on the
applicant's behalf.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend,
  cover letter, custom fields, language levels, and job posting. Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, the
  "languageLevels" list is the authoritative answer (CEFR levels the
  applicant self-reported in Settings) — use it directly rather than
  guessing from the CV or defaulting to a low/neutral level.
- If the profile/CV/Personal Legend/etc genuinely lack what's needed to
  answer this question — not just a minor detail, but the actual substance
  being asked for — set "sufficientInfo" to false and "answer" to an empty
  string. Do NOT write a sentence explaining that you don't have the
  information (e.g. "I don't have this information available") — that text
  would otherwise get typed straight into the applicant's form field, which
  is worse than leaving it blank for the applicant to fill in themselves.
  Only do this when the information is truly absent; a question you can
  answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient —
  set sufficientInfo to true and give that honest answer.
- If "postingLanguage" is given, write the answer in that language, using
  the salutation/register conventions native speakers of it would expect on
  a job application (e.g. formal "Sie"/"Herr"/"Frau" address in German, not
  a literal English-to-German translation) — unless the question itself, or
  "generationRules", explicitly asks for a different language.
- If this question is a newsletter, marketing-email, or job-alert
  subscription opt-in phrased as a choice (e.g. "Would you like to
  subscribe to our newsletter? Yes/No"), always choose the option that
  declines it — the applicant never needs this to submit the application.
- "faq" is a set of pre-written answers to standard interview-FAQ questions
  (spec_5 section B). If the question being asked now is the same as, or a
  close variant of, one already in "faq", reuse its substance and phrasing —
  adapt only what the target field's length/format actually requires — so
  the applicant's answer stays consistent across different forms rather
  than being re-derived from scratch each time.
- Match the question's expected length: a short field gets a short answer, an
  open-ended "tell us about..." field gets a fuller one.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text, no markdown, no restating the question.

${b}`,Ut=/\b(?:please\s+(?:provide|specify|clarify)|could\s+you\s+(?:please\s+)?(?:provide|clarify|specify)|i\s+(?:don'?t|do\s+not)\s+see)\b.{0,40}?\b(?:question|prompt)\b|\bno\s+(?:specific\s+)?question\s+(?:was|is)?\s*(?:provided|given|specified|attached)\b/i;function te(e){const o=e.trim();return o?o.length<220&&Ut.test(o):!0}const $t=`
- This is a MULTIPLE-CHOICE question: "options" lists the allowed answers.
  Reply with EXACTLY ONE option, copied verbatim, and nothing else.
- Base the choice on the applicant's profile/CV/Personal Legend. If the
  needed fact is genuinely absent (e.g. pronouns not stated anywhere),
  prefer a neutral option, an explicit "prefer not to say", or the option
  that commits the applicant least.`,Yt=`
- This is a SELECT-ALL-THAT-APPLY question: "options" lists every allowed
  answer. Reply with every option that genuinely applies, each copied
  verbatim, joined by " | " (a single pipe surrounded by one space on each
  side) — nothing else. If none apply, reply with an empty string.
- Base each choice strictly on the applicant's profile/CV/Personal Legend —
  never include an option just because it's plausible or common; only ones
  the applicant's own material actually supports.`,Dt=`
- This field only accepts a plain number: reply with digits only (a single
  "." for a decimal if needed) — no currency symbol, no thousands
  separator, no unit, no words, no range. If a range genuinely fits best
  (e.g. a salary expectation given as "65-75k"), reply with one
  representative figure (its midpoint), not the range.`;function Ft(e){return`
- This field only accepts a date in the exact format "${Q[e]}"
  — reply with ONLY that value, nothing else (no words, no explanation).
  "todayISO" in the data below is today's date: compute the answer from it
  — e.g. "available with one month's notice" → todayISO plus one month;
  "immediately" / "as soon as possible" / no stated constraint → todayISO
  itself. Never answer with a description of the notice period or
  availability instead of the date itself.`}async function Ht(e,o,t,n,a,s,i){const[r,c]=await Promise.all([m(),P("lastCoverLetter")]),l=JSON.stringify({job:o,profile:r.profile,cvText:r.cvText,personalLegend:r.personalLegend,generationRules:r.generationRules,coverLetter:c??"",languageLevels:r.languageLevels,customFields:r.customFields,faq:r.faq.filter(y=>y.answer.trim()),todayISO:_(),postingLanguage:i||void 0,question:e,options:t&&t.length>0?t:void 0},null,2),u=[t&&t.length>0?s?Yt:$t:"",n?Dt:"",a?Ft(a):""].filter(Boolean),p=await d({schemaName:"custom_question_answer",schema:Mt,systemPrompt:u.length>0?[j,...u].join(`
`):j,userPrompt:l,parse:y=>JSON.parse(y)});return!p.sufficientInfo||te(p.answer)?{answer:"",sufficientInfo:p.sufficientInfo}:{answer:t&&t.length>0||n||!!a?p.answer:g(p.answer),sufficientInfo:!0}}const Bt={type:"object",additionalProperties:!1,required:["questions"],properties:{questions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","question"],properties:{index:{type:"integer"},question:{type:"string"}}}}}},Jt=`You are given a block of a job-application form: its visible text, and a
list of the input fields inside it. For each field that asks the applicant
something, return the question it is asking, phrased as a plain question.

Rules:
- Use ONLY the visible text provided. Never invent a question.
- Match each question to its field by "index".
- Omit a field that is not a real question (layout helper, hidden field,
  search box, honeypot, a plain "First name"-style profile field).
- A field with "options" is a multiple-choice question — still return only
  its question text, not the options.
- Output the question text only — no numbering, no "Question:" prefix.
- Questions may be in any language; keep the form's own language.`;async function Gt(e,o){if(o.length===0)return{};const t=JSON.stringify({blockText:e.slice(0,6e3),fields:o},null,2),n=await d({schemaName:"block_questions",schema:Bt,systemPrompt:Jt,userPrompt:t,parse:s=>JSON.parse(s)}),a={};for(const s of n.questions)s.question.trim()&&(a[s.index]=s.question.trim());return a}const Vt=/newsletter|marketing|subscribe|promotion|job\s*alert|career\s*news|werbung|benachrichtigung|abonnier|stellenausschreibung/i;function M(e){return Vt.test(e)}const Kt={type:"object",additionalProperties:!1,required:["checkboxDecisions","questionAnswers"],properties:{checkboxDecisions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","check","category","reason"],properties:{index:{type:"integer"},check:{type:"boolean"},category:{type:"string",enum:["required-consent","marketing","optional","unclear"]},reason:{type:"string"}}}},questionAnswers:{type:"array",items:{type:"object",additionalProperties:!1,required:["id","answer","sufficientInfo"],properties:{id:{type:"string"},answer:{type:"string"},sufficientInfo:{type:"boolean"}}}}}},Qt=`You fill in two independent things found on a job-application form at once:
consent checkboxes to decide, and custom questions to answer on the applicant's behalf. The
applicant has already chosen to submit this application.

CHECKBOXES (one decision per item in "checkboxes", matched back by "index")

TICK (check: true) — things required to submit, or that a candidate is normally expected to
accept:
- privacy policy / data protection / GDPR / Datenschutz consent
- terms & conditions / AGB / Nutzungsbedingungen
- confirming the entered information is accurate / truthful
- consent to process and store the application data for THIS hiring process
- storing the data in a talent pool ONLY when the checkbox is marked required
- eligibility self-declarations that hold for any ordinary adult applying for a real job (e.g.
  "I am at least 18 years old", "I am legally entitled to work in [country]", "I have no
  undisclosed conflicts of interest") — assume true unless the profile/CV explicitly states
  otherwise; a genuine job applicant submitting this form is virtually always eligible, and
  leaving a required declaration like this unticked blocks submission for no real reason

DO NOT TICK (check: false) — optional and promotional:
- newsletters, marketing e-mails, "career news", event invitations
- job alerts / notifications about new postings (e.g. "Benachrichtigungen über neue
  Stellenausschreibungen erhalten")
- sharing data with third parties / partner companies for marketing
- joining a talent pool / candidate database when NOT required
- anything that benefits the applicant only beyond this one application

Rules:
- "required: true" means the form marks the field mandatory — a strong signal to tick, unless
  the text is clearly marketing.
- A newsletter/marketing-email/job-alert opt-in is NEVER ticked, even when the form marks it
  "required" — that flag is routinely misused by forms to guilt-trip applicants into
  subscribing, even though applicants never actually need it to submit. When genuinely in doubt
  whether a required checkbox is a real submission requirement or a disguised newsletter
  opt-in, prefer NOT ticking it.
- If a checkbox is ambiguous AND not required, set check: false.
- Labels may be in any language; judge by meaning, not keywords.
- category: "required-consent" (ticked, mandatory-type), "marketing" (left off), "optional"
  (non-marketing but skippable, left off unless required), "unclear" (left off). reason: one
  short phrase.
- Return one decision per input item in "checkboxes", using its "index". If "checkboxes" is
  empty, return an empty array.

QUESTIONS (one answer per item in "questions", matched back by "id")

Ground rules:
- Use ONLY facts present in the shared "profile"/"cvText"/"personalLegend"/"generationRules"/
  "coverLetter"/"languageLevels"/"customFields"/"faq" given below, plus "job". Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, "languageLevels" is the
  authoritative answer (CEFR levels the applicant self-reported in Settings) — use it directly
  rather than guessing from the CV or defaulting to a low/neutral level.
- If the shared material genuinely lacks what's needed to answer a given question — not just a
  minor detail, but the actual substance being asked for — set that item's "sufficientInfo" to
  false and "answer" to an empty string. Do NOT write a sentence explaining that you don't have
  the information — that text would otherwise get typed straight into the applicant's form
  field, which is worse than leaving it blank. Only do this when the information is truly
  absent; a question you can answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient.
- If "postingLanguage" is given, write answers in that language, using the salutation/register
  conventions native speakers of it would expect on a job application (e.g. formal
  "Sie"/"Herr"/"Frau" address in German) — unless the question itself, or "generationRules",
  explicitly asks for a different language.
- A newsletter/marketing-email/job-alert subscription opt-in phrased as a question (e.g. "Would
  you like to subscribe to our newsletter? Yes/No") always gets the option that declines it.
- "faq" is a set of pre-written answers to standard interview-FAQ questions. If a question being
  asked now is the same as, or a close variant of, one already in "faq", reuse its substance and
  phrasing — adapt only what the target field's length/format actually requires.
- Match each question's expected length: a short field gets a short answer, an open-ended
  "tell us about..." field gets a fuller one.
- Output plain text per answer, no markdown, no restating the question.
- Each item in "questions" may also carry:
  - "options" (and not "multi"): a single-choice question — reply with EXACTLY ONE option,
    copied verbatim, nothing else. If the needed fact is genuinely absent (e.g. pronouns not
    stated anywhere), prefer a neutral option or an explicit "prefer not to say".
  - "options" with "multi": true: a select-all-that-apply question — reply with every option
    that genuinely applies, each copied verbatim, joined by " | " (one pipe, one space each
    side). If none apply, reply with an empty string. Never include an option just because it's
    plausible — only ones the applicant's own material actually supports.
  - "numeric": true: the field only accepts a plain number — reply with digits only (a single
    "." for a decimal if needed), no currency symbol, no thousands separator, no unit, no words,
    no range. If a range genuinely fits best (e.g. "65-75k"), reply with one representative
    figure (its midpoint).
  - "dateFormat": the field only accepts a date in exactly that format — reply with ONLY that
    value, nothing else. "todayISO" below is today's date: compute the answer from it — e.g.
    "available with one month's notice" -> todayISO plus one month; "immediately"/"as soon as
    possible"/no stated constraint -> todayISO itself.
- Return one answer per input item in "questions", using its "id". If "questions" is empty,
  return an empty array.

${b}`;function Wt(e,o){const t=new Map;for(const n of o)t.set(n.index,n);return e.map((n,a)=>{const s=t.get(a);if(s){const i=s.check&&M(n.label)?!1:s.check;return{name:n.name,label:n.label,check:i,category:s.category,reason:s.reason}}return M(n.label)?{name:n.name,label:n.label,check:!1,category:"marketing",reason:"No decision returned — looks like a newsletter/marketing opt-in"}:{name:n.name,label:n.label,check:n.required,category:n.required?"required-consent":"unclear",reason:n.required?"Marked required by the form":"No decision returned"}})}function zt(e,o){const t=new Map;for(const n of o)t.set(n.id,n);return e.map(n=>{const a=t.get(n.id);if(!a)return{id:n.id,answer:"",sufficientInfo:!0};if(!a.sufficientInfo||te(a.answer))return{id:n.id,answer:"",sufficientInfo:a.sufficientInfo};const s=n.options&&n.options.length>0||n.numeric||!!n.dateKind;return{id:n.id,answer:s?a.answer:g(a.answer),sufficientInfo:!0}})}async function Xt(e,o,t,n){if(e.length===0&&o.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[a,s]=await Promise.all([m(),P("lastCoverLetter")]),i=JSON.stringify({job:t,profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,generationRules:a.generationRules,coverLetter:s??"",languageLevels:a.languageLevels,customFields:a.customFields,faq:a.faq.filter(c=>c.answer.trim()),todayISO:_(),postingLanguage:n||void 0,checkboxes:e.map((c,l)=>({index:l,label:c.label,required:c.required,currentlyChecked:c.checked})),questions:o.map(c=>({id:c.id,question:c.question,options:c.options&&c.options.length>0?c.options:void 0,multi:c.multi,numeric:c.numeric,dateFormat:c.dateKind?Q[c.dateKind]:void 0}))},null,2),r=await d({schemaName:"page_content_decisions",schema:Kt,systemPrompt:Qt,userPrompt:i,parse:c=>JSON.parse(c)});return{checkboxDecisions:Wt(e,r.checkboxDecisions),questionAnswers:zt(o,r.questionAnswers)}}const Zt={type:"object",additionalProperties:!1,required:["postingLanguages","requirements","keywords","contact"],properties:{postingLanguages:{type:"array",items:{type:"string"}},requirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...K,null]}}}},keywords:{type:"array",items:{type:"object",additionalProperties:!1,required:["text","matchesProfile"],properties:{text:{type:"string"},matchesProfile:{type:"boolean"}}}},contact:{type:["string","null"]}}},en=`You read a job posting and report three independent things about it: its
language, its notable keywords, and (only if asked below) a recruiter/hiring contact. Judge
language and keywords against the applicant profile/CV/Personal Legend given below.

LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- requirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or
  "Native" for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent",
  "professional working proficiency" -> "C1"; "conversational" -> "B1". If a language is
  mentioned but no level can be reasonably inferred, set level to null. Do not invent a
  requirement that isn't stated in the text. If nothing is stated, return an empty array.

KEYWORDS
- Pick the notable keywords/key phrases out of the posting — the skills, tools,
  technologies, qualifications, and requirements a candidate would want to notice at a
  glance.
- Every keyword's "text" MUST be copied VERBATIM from the posting text (job title,
  description, requirements, responsibilities) — the exact same characters and casing, not
  a paraphrase, synonym, or translation — because the extension re-finds this exact text on
  the page to highlight it. A keyword that doesn't appear verbatim in the text is useless.
- Prefer short phrases: single words or 2-3 word phrases (e.g. "TypeScript", "Kubernetes",
  "5+ years", "product management", "Bachelor's degree") — not full sentences.
- Pick 8-15 of the most important ones. Skip generic filler ("team player", "fast-paced
  environment") unless the posting has almost nothing more specific.
- No duplicates, and no two keywords where one is a substring of the other (keep the more
  specific/longer one).
- Set "matchesProfile" to true when the applicant's profile/cvText/personalLegend shows they
  already have, use, or meet that skill/tool/technology/qualification — false when the
  posting asks for it but nothing in the applicant's material supports it. Judge substance,
  not exact wording (e.g. "Kubernetes" counts as a match if the CV mentions "container
  orchestration with K8s" or "EKS"). When genuinely unsure, set it to false — this flags a
  possible gap for the applicant to address rather than silently hiding it.

CONTACT
- "job.contact" below is the recruiter/hiring contact already found elsewhere, or null if none
  was found yet.
- If it is already set (not null), ignore this entirely and return "contact": null — there is
  nothing to add.
- If it is null, look for one in the job's own text (description/requirements/responsibilities):
  a named recruiter/hiring manager's email address, or a LinkedIn profile/company URL. If you
  find one, copy it VERBATIM (exact characters) so it can be re-found on the page for
  highlighting — the same rule as for keywords. If none is mentioned, return "contact": null.`;async function tn(e){const o=await m(),t=JSON.stringify({profile:o.profile,cvText:o.cvText,personalLegend:o.personalLegend,job:e},null,2),n=await d({schemaName:"job_brief",schema:Zt,model:await G(),systemPrompt:en,userPrompt:t,parse:a=>JSON.parse(a)});return{language:{postingLanguages:n.postingLanguages,requirements:n.requirements},keywords:n.keywords,contact:n.contact}}const nn={type:"object",additionalProperties:!1,required:["values"],properties:{values:{type:"array",items:{type:"object",additionalProperties:!1,required:["name","value","reason"],properties:{name:{type:"string"},value:{type:"string"},reason:{type:"string"}}}}}},an=`You adapt an applicant's CV template to one specific job posting by
choosing a value for each {{placeholder}} in it.

Each variable comes with:
- "description": the applicant's own instruction for what the placeholder means and
  how to choose it. Follow it.
- "mode": "choice" means "value" MUST be exactly one of "options", copied verbatim
  (same spelling, same case, same line breaks). "free" means "options" are only
  examples of the expected shape and length; write the value that fits this posting
  in that same shape (e.g. a city name, a comma-separated list).
- "foundInPosting": options that literally occur in the posting text, most frequent
  first. A strong hint, not an order: the role's actual focus matters more than a
  passing mention.

Rules:
- Pick what makes this CV the closest honest match for this posting: its title, its
  location, its main technology, the vocabulary it uses.
- Honesty: never make the CV claim a skill, technology or experience the applicant's
  CV text / Personal Legend doesn't support, unless the variable's description
  explicitly asks for it. For list-like values, prefer terms that are both in the
  posting and supported by the applicant's background.
- Write the value in the same language as the surrounding template text.
- Return one entry per variable given, using its exact "name".
- "reason": one short sentence (max ~15 words) on why this value fits the posting.
- Plain text only, no markdown, no em dashes.`;function sn(e,o){const t=a=>a.trim().replace(/\s+/g," ").toLowerCase(),n=t(e);return o.options.find(a=>t(a)===n)??null}async function on(e,o){const t=new Set(me(o.content)),n=o.variables.filter(r=>t.has(r.name));if(n.length===0)return[];const a=await m(),s={variables:n.map(r=>({name:r.name,mode:r.mode,description:r.description,options:r.options,foundInPosting:ye(r.options,e)})),template:o.content.slice(0,12e3),job:{position:e.position,company:e.company,location:e.location,techStack:e.techStack,requirements:e.requirements,responsibilities:e.responsibilities,description:e.description.slice(0,8e3)},applicant:{cvText:a.cvText.slice(0,12e3),personalLegend:a.personalLegend.slice(0,8e3),city:a.profile.city,country:a.profile.country}},i=await d({schemaName:"cv_template_values",schema:nn,model:await we(),systemPrompt:an,userPrompt:JSON.stringify(s,null,2),parse:r=>JSON.parse(r)});return n.map(r=>{const c=i.values.find(l=>l.name===r.name);if(!c)return{name:r.name,value:R(r,e),reason:""};if(r.mode==="choice"&&r.options.length>0){const l=sn(c.value,r);return l?{name:r.name,value:l,reason:g(c.reason)}:{name:r.name,value:R(r,e),reason:""}}return{name:r.name,value:g(c.value),reason:g(c.reason)}})}async function ne(e){const o=await h(e);await Promise.all(o.map(t=>chrome.tabs.sendMessage(e,{type:"CANCEL_ELEMENT_PICKER",tabId:e},{frameId:t}).catch(()=>{})))}async function f(e,o,t){return(await Promise.all(o.map(a=>chrome.tabs.sendMessage(e,t,{frameId:a}).catch(()=>{})))).filter(a=>!!a)}async function rn(e){var o;switch(e.type){case"GET_PROFILE":return{type:"PROFILE_DATA",profile:await k()};case"GET_JOB":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});if(!e.force&&(t!=null&&t.url)){const l=await ve(t.url);if(l)return{type:"JOB_DATA",job:l,sufficient:!0}}const n=await h(e.tabId),s=(await f(e.tabId,n,e)).filter(l=>l.type==="JOB_DATA");if(s.length===0)return;const i=s.find(l=>l.sufficient);if(i)return t!=null&&t.url&&C(t.url,i.job),i;const r=s.reduce((l,u)=>u.job.description.length>l.job.description.length?u:l),c=s.map(l=>l.visibleText??"").filter(Boolean).join(`

`).slice(0,2e4);try{const{job:l,brief:u}=await q(c||r.visibleText||"",r.job.url);return t!=null&&t.url&&C(t.url,l),{type:"JOB_DATA",job:l,sufficient:!0,brief:u}}catch{return r}}case"EXTRACT_JOB_FROM_TEXT":{const t=await chrome.tabs.get(e.tabId).catch(()=>{}),{job:n,brief:a}=await q(e.text,(t==null?void 0:t.url)??"");return{type:"JOB_DATA",job:n,sufficient:!0,brief:a}}case"AUTOFILL":{const t=await h(e.tabId),a=(await f(e.tabId,t,e)).filter(s=>s.type==="AUTOFILL_RESULT");return{type:"AUTOFILL_RESULT",filled:a.reduce((s,i)=>s+i.filled,0),total:a.reduce((s,i)=>s+i.total,0),generatedPassword:a.map(s=>s.generatedPassword).find(Boolean)??null}}case"GENERATE_COVER_LETTER":{const{tabId:t}=e,n=await Et(e.job,e.postingLanguage,a=>{chrome.runtime.sendMessage({type:"COVER_LETTER_STREAM_CHUNK",tabId:t,delta:a}).catch(()=>{})});return await A("lastCoverLetter",n.content),{type:"COVER_LETTER_RESULT",content:n.content,slopFindings:n.slopFindings,cleaned:n.cleaned}}case"UPLOAD_FILE":{const t=await h(e.tabId),a=(await f(e.tabId,t,e)).filter(s=>s.type==="UPLOAD_FILE_RESULT");return{type:"UPLOAD_FILE_RESULT",nativeInputs:a.reduce((s,i)=>s+i.nativeInputs,0),dropZones:a.reduce((s,i)=>s+i.dropZones,0)}}case"REVISE_COVER_LETTER":{const t=await Rt(e.content,e.instructions,e.job);return await A("lastCoverLetter",t),{type:"REVISE_COVER_LETTER_RESULT",content:t}}case"TRANSLATE_COVER_LETTER":return{type:"TRANSLATE_COVER_LETTER_RESULT",content:await jt(e.content,e.targetLanguage)};case"GENERATE_OUTREACH_MESSAGE":{const t=await m(),n=await Lt({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,outreachRules:t.outreachRules,job:e.job,contact:e.contact,postingLanguage:e.postingLanguage});return{type:"OUTREACH_MESSAGE_RESULT",subject:n.subject,body:n.body}}case"REVISE_OUTREACH_MESSAGE":{const t=await Ct({subject:e.subject,body:e.body},e.instructions,e.job);return{type:"OUTREACH_MESSAGE_RESULT",subject:t.subject,body:t.body}}case"DETECT_CUSTOM_QUESTIONS":{const t=await h(e.tabId),n=await f(e.tabId,t,e),a=new Set,s=[];for(const i of n)if(i.type==="CUSTOM_QUESTIONS_DATA")for(const r of i.questions)a.has(r.question)||(a.add(r.question),s.push({...r,id:`question-${s.length}`}));return{type:"CUSTOM_QUESTIONS_DATA",questions:s}}case"ANSWER_CUSTOM_QUESTION":{const t=await Ht(e.question,e.job,e.options,e.numeric,e.dateKind,e.multi,e.postingLanguage);return{type:"CUSTOM_QUESTION_ANSWER",question:e.question,answer:t.answer,sufficientInfo:t.sufficientInfo}}case"FILL_CUSTOM_QUESTION_ANSWERS":{const t=await h(e.tabId),n=await f(e.tabId,t,e);let a=0;const s=[];for(const i of n)i.type==="CUSTOM_QUESTION_FILL_RESULT"&&(a+=i.filled,s.push(...i.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:a,unfilled:s}}case"START_ELEMENT_PICKER":{const t=await h(e.tabId),n=t.map(s=>chrome.tabs.sendMessage(e.tabId,e,{frameId:s}).catch(()=>{})),a=await new Promise(s=>{let i=n.length;i===0&&s(void 0);for(const r of n)r.then(c=>{i-=1,c?s(c):i===0&&s(void 0)})});return await Promise.all(t.map(s=>chrome.tabs.sendMessage(e.tabId,{type:"CANCEL_ELEMENT_PICKER",tabId:e.tabId},{frameId:s}).catch(()=>{}))),a??{type:"ELEMENT_PICKER_RESULT",cancelled:!0,picked:[],blockText:"",semanticCount:0}}case"CANCEL_ELEMENT_PICKER":{await ne(e.tabId);return}case"DECOMPOSE_BLOCK":return{type:"BLOCK_QUESTIONS",questions:await Gt(e.blockText,e.fields)};case"FILL_QUESTION_ANSWERS_BY_LOCATOR":{const t=await h(e.tabId),n=await f(e.tabId,t,e);let a=0;const s=[];for(const i of n)i.type==="CUSTOM_QUESTION_FILL_RESULT"&&(a+=i.filled,s.push(...i.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:a,unfilled:s}}case"DETECT_CHECKBOXES":{const t=await h(e.tabId),n=await f(e.tabId,t,e),a=new Set,s=[];for(const i of n)if(i.type==="CHECKBOXES_DATA")for(const r of i.checkboxes){const c=r.name||r.label;!c||a.has(c)||(a.add(c),s.push({...r,id:`checkbox-${s.length}`}))}return{type:"CHECKBOXES_DATA",checkboxes:s}}case"DECIDE_PAGE_CONTENT":{const{checkboxDecisions:t,questionAnswers:n}=await Xt(e.checkboxes,e.questions,e.job,e.postingLanguage);return{type:"PAGE_CONTENT_DECISIONS",checkboxDecisions:t,questionAnswers:n}}case"APPLY_CHECKBOX_DECISIONS":{const t=await h(e.tabId),n=await f(e.tabId,t,e);let a=0;for(const s of n)s.type==="CHECKBOX_APPLY_RESULT"&&(a+=s.changed);return{type:"CHECKBOX_APPLY_RESULT",changed:a}}case"DETECT_JOB_BRIEF":{const t=await tn(e.job);return{type:"JOB_BRIEF_DATA",language:t.language,keywords:t.keywords,contact:t.contact}}case"HIGHLIGHT_KEYWORDS":{const t=await h(e.tabId);return{type:"KEYWORD_HIGHLIGHT_RESULT",matched:(await f(e.tabId,t,e)).reduce((s,i)=>i.type==="KEYWORD_HIGHLIGHT_RESULT"?s+i.matched:s,0)}}case"CLEAR_KEYWORD_HIGHLIGHTS":{const t=await h(e.tabId);await f(e.tabId,t,e);return}case"GENERATE_FAQ_ANSWERS":{const t=await D(),n=await je(e.questions,t);try{await be(n)}catch{}return{type:"FAQ_ANSWERS_RESULT",entries:n}}case"SEARCH_JOBS":{const{provider:t}=e.query,n=performance.now(),a=[],s=()=>({totalMs:performance.now()-n,stages:a});if(t==="adzuna"){const[l,u]=await Promise.all([x(),k()]);if(!l.adzunaAppId||!l.adzunaAppKey)throw new Error("Add your Adzuna app_id and app_key in Settings first.");let p=e.query;if(!((o=p.tags)!=null&&o.length))if(p.what.trim())p={...p,tags:[p.what.trim()]};else{const[w,E]=await L(a,"Suggest tags",()=>Promise.all([O(),N()]));p={...p,what:w.what,where:p.where.trim()||w.where,tags:E.length>0?E:[w.what]}}const{results:v,warnings:y}=await L(a,"Adzuna search",()=>Qe(p,{appId:l.adzunaAppId,appKey:l.adzunaAppKey},ze(u.country),e.page??1));return{type:"JOB_SEARCH_RESULTS",results:v,resolvedQuery:p,warnings:y,...s()}}const i=await Y(),r=(i==null?void 0:i.content)??"";if(t==="tavily"){const l=await x();if(!l.tavilyApiKey)throw new Error("Add your Tavily API key in Settings first.");return{type:"JOB_SEARCH_RESULTS",results:await He(e.query,l.tavilyApiKey,r,e.excludeResults,a),resolvedQuery:e.query,...s()}}return{type:"JOB_SEARCH_RESULTS",results:await Ye(e.query,r,e.excludeResults,a),resolvedQuery:e.query,...s()}}case"SUGGEST_SEARCH_QUERY":{if(e.provider==="adzuna"){const[n,a]=await Promise.all([O(),N()]);return{type:"SEARCH_QUERY_SUGGESTION",...n,tags:a}}return{type:"SEARCH_QUERY_SUGGESTION",...await O()}}case"SUGGEST_CV_VALUES":return{type:"CV_VALUES",values:await on(e.job,e.template)};default:return}}const ln="src/sidepanel/index.html";chrome.runtime.onInstalled.addListener(()=>{Oe(),chrome.sidePanel.setOptions({enabled:!1})});chrome.contextMenus.onClicked.addListener((e,o)=>{Re(e,o)});chrome.action.onClicked.addListener(e=>{if(e.id===void 0)return;const o=e.id;chrome.sidePanel.setOptions({tabId:o,path:ln,enabled:!0}),chrome.sidePanel.open({tabId:o}).catch(t=>console.error("sidePanel.open failed",t)),h(o)});chrome.tabs.onRemoved.addListener(e=>{Ee(e)});chrome.runtime.onMessage.addListener((e,o,t)=>(rn(e).then(t).catch(n=>{t({type:"ERROR",error:n instanceof Error?n.message:String(n),code:n instanceof Error?n.name:void 0})}),!0));chrome.runtime.onConnect.addListener(e=>{const o=/^picker-(\d+)$/.exec(e.name);if(!o)return;const t=Number(o[1]);e.onDisconnect.addListener(()=>{ne(t)})});
