import{P as X,g as m,a as U,b as W,c as Z,s as ee,d as g,e as j,f as w,h as L,i as P,j as A,k as te,t as ne,D as ae,C as se,l as $,m as C,n as re,o as R,p as oe,q as N,r as ie,u as ce,v as le}from"./language-level-CeNn-fuN.js";import{c as pe,a as de}from"./phone-CZ16BBLi.js";const D={...X,cv:"CV",coverLetter:"Cover Letter",generatePassword:"Generated password"},ue=Object.keys(D);async function u(e){try{const t=(await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:["content-script.js"]})).map(r=>r.frameId).filter(r=>typeof r=="number");if(t.length>0)return t}catch{}try{return await chrome.scripting.executeScript({target:{tabId:e},files:["content-script.js"]}),[0]}catch{return[0]}}async function he(e,a){if(e==="cv"){const s=await m();return(s==null?void 0:s.text)??""}if(e==="coverLetter")return await U("lastCoverLetter")??"";if(e==="generatePassword"){const s=await W(a);if(s!=null&&s.generatedPassword)return s.generatedPassword;const n=Z();return s&&await ee(a,{...s,generatedPassword:n}),n}const t=await g(),r=t[e]??"";return e==="phone"&&r?pe(r,t.country):r}const E="job-app-assistant-insert",ge={generatePassword:"Generate password"},fe=ue.map(e=>({id:e,title:ge[e]??D[e]}));function me(){chrome.contextMenus.removeAll(()=>{chrome.contextMenus.create({id:E,title:"Insert",contexts:["editable"]});for(const e of fe)chrome.contextMenus.create({id:`${E}:${e.id}`,parentId:E,title:e.title,contexts:["editable"]})})}function ye(e){return e.startsWith(`${E}:`)?e.slice(E.length+1):null}async function we(e,a){if(!(a!=null&&a.id)||typeof e.menuItemId!="string")return;const t=ye(e.menuItemId);if(!t)return;const r=await he(t,a.id);await u(a.id);const s={type:"INSERT_VALUE",field:t,value:r};chrome.tabs.sendMessage(a.id,s,{frameId:e.frameId}).catch(()=>{})}const F="https://api.openai.com/v1/responses",Y="gpt-5.6-terra",h="gpt-5.6-luna",be=Y;class S extends Error{constructor(a,t){super(a),this.status=t,this.name="OpenAiError"}}class B extends S{constructor(){super("No OpenAI API key is configured. Add your key in the extension settings."),this.name="MissingApiKeyError"}}async function d(e){var o,c;const a=await j();if(!a)throw new B;const t=await fetch(F,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${a}`},body:JSON.stringify({model:e.model??be,input:[{role:"system",content:e.systemPrompt},{role:"user",content:e.userPrompt}],text:{format:{type:"json_schema",name:e.schemaName,strict:!0,schema:e.schema}}})});if(!t.ok){const i=await t.text().catch(()=>"");throw new S(`OpenAI request failed (${t.status}): ${i.slice(0,300)}`,t.status)}const s=(await t.json()).output.find(i=>i.type==="message"),n=(c=(o=s==null?void 0:s.content)==null?void 0:o.find(i=>i.type==="output_text"))==null?void 0:c.text;if(!n)throw new S("OpenAI response had no content.");return e.parse(n)}async function Ee(e,a=h){var c,i;const t=await j();if(!t)throw new B;const r=await fetch(F,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({model:a,tools:[{type:"web_search"}],input:[{role:"user",content:e}]})});if(!r.ok){const l=await r.text().catch(()=>"");throw new S(`OpenAI web search request failed (${r.status}): ${l.slice(0,300)}`,r.status)}const n=(await r.json()).output.find(l=>l.type==="message"),o=(i=(c=n==null?void 0:n.content)==null?void 0:c.find(l=>l.type==="output_text"))==null?void 0:i.text;if(!o)throw new S("OpenAI web search response had no content.");return o}const v=`Write like a specific person, not an AI assistant. These rules have no exceptions:

- NEVER use an em dash ("—"), a spaced en dash ("–") or "--" as punctuation. Real people don't write that way. Use a comma, a period, parentheses, or two sentences.
- Banned words: delve, foster, leverage, utilize, facilitate, empower, streamline, robust, cutting-edge, paradigm shift, game changer, tapestry, realm, beacon, multifaceted, meticulous, intricate, paramount, transformative, elevate, embark, supercharge, harness, ever-evolving. Say the plain thing.
- Cut empty phrases: "it's worth noting", "at the end of the day", "when it comes to", "at its core", "in today's world", "the reality is", "in order to", "going forward".
- No "not X, it's Y" / "the question isn't X, it's Y" / "not just X but Y" contrasts. State Y directly.
- No throat-clearing openers ("Here's the thing", "Let me be clear", "I'll be honest") and no faux-insight setups ("what most people get wrong", "here's what nobody tells you").
- No importance puffery ("stands as a testament", "marks a pivotal moment", "plays a vital role", "underscores its significance"). State the fact and stop.
- No colon reveals: a noun phrase, a colon, then a dramatic lowercase clause.
- No trailing "-ing" clauses that editorialize ("highlighting the commitment to...", "underscoring its importance", "showcasing", "reflecting"). End the sentence.
- No metadiscourse that tells the reader what to notice ("this matters", "this distinction matters", "in other words", "as you can see").
- No "In conclusion" / "Ultimately" / "Overall" recap ending and no cute one-line kicker. Stop on the last concrete point.
- No emoji, no mid-sentence bold, no rhetorical questions.
- Vary sentence shape; don't stack short punchy fragments.
- Be concrete: name the technology, project, number, or outcome instead of calling it "significant", "impactful" or "exciting". Use active voice.`;function b(e){return e.replace(/[ \t]*[—―][ \t]*/g,", ").replace(/[ \t]+--[ \t]+/g,", ").replace(/(\D)[ \t]+–[ \t]+(?=\D)/g,"$1, ").replace(/[ \t]+([,.;:!?])/g,"$1").replace(/,(\s*[.;:!?])/g,"$1").replace(/,[ \t]*,/g,",").replace(/^[ \t]*,[ \t]*/gm,"").replace(/([([{])[ \t]*,[ \t]*/g,"$1").replace(/[ \t]*,[ \t]*([)\]}])/g,"$1").replace(/,[ \t]*$/gm,"").replace(/[ \t]+$/gm,"")}const Se=`You write the applicant's own answers to standard interview-FAQ
questions (spec_5 section B) — general-purpose answers meant to be reused, as-is or
lightly adapted, whenever a real application form asks a close variant of one of them.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend, and
  custom fields. Never invent experience, technologies, companies, education,
  achievements, or a concrete salary figure that wasn't actually given.
- If information needed for a good answer is missing (no CV, no Personal Legend
  content covering it), write a short, honest, generically true answer rather
  than fabricating specifics — the applicant can always sharpen it later.
- Keep each answer 2-5 sentences: concrete and confident, never generic
  corporate filler, no restating the question.
- Output plain text per answer, no markdown, no numbering.

${v}`;function ve(e){return{type:"object",additionalProperties:!1,required:["answers"],properties:{answers:{type:"array",minItems:e,maxItems:e,items:{type:"string"}}}}}async function Te(e){if(e.length===0)return[];const[a,t,r,s]=await Promise.all([g(),m(),w(),L()]),n=JSON.stringify({questions:e,profile:a,cvText:(t==null?void 0:t.text)??"",personalLegend:(r==null?void 0:r.content)??"",customFields:s},null,2),o=await d({schemaName:"faq_answers",schema:ve(e.length),model:h,systemPrompt:Se,userPrompt:n,parse:c=>JSON.parse(c)});return e.map((c,i)=>({question:c,answer:b(o.answers[i]??"")}))}async function _e(e,a){const t=new Map(a.map(n=>[n.question,n.answer])),r=e.filter(n=>{var o;return!((o=t.get(n))!=null&&o.trim())}),s=await Te(r);for(const n of s)t.set(n.question,n.answer);return e.map(n=>({question:n,answer:t.get(n)??""}))}const Oe={type:"object",additionalProperties:!1,required:["summary"],properties:{summary:{type:"string"}}},Le=`You write an internal candidate briefing — never shown to an employer,
used only to ground this applicant's own job search. Given their full profile, CV text,
Personal Legend, custom fields, language levels, and pre-written FAQ answers, distill
everything genuinely useful for matching them to open roles into one dense paragraph-form
summary: current/most recent title and seniority, years of experience, core skills and
technologies, industries worked in, standout achievements (with concrete numbers where the
source material has them), education, languages spoken and level, location and remote/
relocation stance, and salary expectation if stated.

Rules:
- Use ONLY facts present in the supplied data — never invent employers, titles, numbers,
  or skills.
- Be complete rather than brief: this is a grounding document for search, not a cover
  letter — include everything that could plausibly help match a job posting, even minor
  details, rather than trimming for concision. Do not pad with generic filler that carries
  no matching signal, but do not omit real facts either.
- Plain prose, no markdown, no headers, no restating these instructions.`;async function J(){const[e,a,t,r,s,n]=await Promise.all([g(),m(),w(),L(),P(),A()]),o=JSON.stringify({profile:e,cvText:(a==null?void 0:a.text)??"",personalLegend:(t==null?void 0:t.content)??"",customFields:r,languageLevels:s,faq:n.filter(i=>i.answer.trim())},null,2);return(await d({schemaName:"candidate_summary",schema:Oe,model:h,systemPrompt:Le,userPrompt:o,parse:i=>JSON.parse(i)})).summary}const Pe={type:"object",additionalProperties:!1,required:["jobs"],properties:{jobs:{type:"array",items:{type:"object",additionalProperties:!1,required:["title","company","location","url","salary","snippet"],properties:{title:{type:"string"},company:{type:"string"},location:{type:"string"},url:{type:"string"},salary:{type:"string"},snippet:{type:"string"}}}}}},Ae=`You turn raw web-search results about job openings into a clean,
structured list. The input text was produced by a live internet search and may include
citations, markdown links, or unrelated surrounding prose — extract only genuine
individual job postings from it.

Rules:
- Only include entries that are clearly actual job postings with a real listing URL —
  never a company's generic careers-page homepage, a search-results page, or an
  aggregator's category page.
- "url" must be copied exactly from the source text (never invented).
- "salary" is "" when no figure was given — never guess one.
- "snippet" is a 1-2 sentence summary of the role; when a "candidate" background is given
  below, make it say *why this posting fits them* specifically (seniority match, matching
  skills, location/remote fit) rather than just restating the posting.
- If a "candidate" background is given, drop postings that are a poor fit for them (wrong
  seniority, unrelated field) even if they're genuine job postings — only surface ones
  actually worth their time.
- Deduplicate: the same posting linked twice becomes one entry.
- If nothing in the text is actually a job posting, return an empty "jobs" array.`;async function H(e,a,t){const r=t?`candidate:
${t}

---

${e.slice(0,4e4)}`:e.slice(0,4e4);return(await d({schemaName:"job_listings",schema:Pe,model:h,systemPrompt:Ae,userPrompt:r,parse:n=>JSON.parse(n)})).jobs.filter(n=>n.url.trim()).map(n=>({...n,source:a}))}function G(e){return e.length===0?"":`

Already found and shown to the applicant — do NOT return any of these again,
find genuinely different postings instead:
${e.map(t=>`- ${t.title} at ${t.company} (${t.url})`).join(`
`)}`}async function Ie(e,a,t=[]){const r=e.remoteOnly?" Prefer remote-friendly roles.":"",s=[e.what?`Role/keywords focus: "${e.what}".`:"",e.where?`Location: "${e.where}".`:"",r].filter(Boolean).join(" "),n=`Search the web for current, actually open job postings that fit this
candidate:

${a||"(no candidate background available)"}

${s||"No further constraints — use the candidate's own background to pick a fitting role/location."}

Find real postings (company career pages, LinkedIn, job boards) with their direct
listing URL, not a search results page. List up to 15 of the best matches, each with
its title, company, location, salary if stated, and a short description of why it fits.${G(t)}`,o=await Ee(n);return H(o,"openai",a)}const Ce="https://api.tavily.com/search",Re=2e3;async function Ne(e,a,t,r=[]){const s=e.remoteOnly?" Prefer remote-friendly roles.":"",o=`Find current, open job postings that fit this candidate.
${[e.what?`Role/keywords focus: "${e.what}".`:"",e.where?`Location: "${e.where}".`:"",s].filter(Boolean).join(" ")}

Candidate background: ${t||"(none available)"}${G(r)}`.trim().slice(0,Re),c=await fetch(Ce,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({api_key:a,query:o,search_depth:"advanced",max_results:15,include_answer:!1})});if(!c.ok){const p=await c.text().catch(()=>"");throw new Error(`Tavily search failed (${c.status}): ${p.slice(0,300)}`)}const i=await c.json();if(i.results.length===0)return[];const l=i.results.map(p=>`Title: ${p.title}
URL: ${p.url}
${p.content}`).join(`

---

`);return H(l,"tavily",t)}function ke(e,a){return!e&&!a?"":te({low:Math.round(e??a??0),high:Math.round(a??e??0)})}async function xe(e,a,t,r,s){const n=new URL(`https://api.adzuna.com/v1/api/jobs/${r}/search/${s}`);n.searchParams.set("app_id",t.appId),n.searchParams.set("app_key",t.appKey),n.searchParams.set("results_per_page","15"),n.searchParams.set("content-type","application/json"),e&&n.searchParams.set("what",e),a&&n.searchParams.set("where",a);const o=await fetch(n.toString());if(!o.ok){const i=await o.text().catch(()=>"");throw new Error(`Adzuna search failed (${o.status}): ${i.slice(0,300)}`)}return(await o.json()).results.map(i=>{var l,p;return{title:i.title,company:((l=i.company)==null?void 0:l.display_name)??"",location:((p=i.location)==null?void 0:p.display_name)??"",url:i.redirect_url,salary:ke(i.salary_min,i.salary_max),snippet:(i.description??"").slice(0,300),source:"adzuna"}})}async function Me(e,a,t,r=1){const s=e.tags&&e.tags.length>0?e.tags:[e.what],n=await Promise.all(s.map(i=>xe(i,e.where,a,t,r))),o=new Set,c=[];for(const i of n.flat())o.has(i.url)||(o.add(i.url),c.push(i));return c}const qe=new Set(["AT","AU","BE","BR","CA","CH","DE","ES","FR","GB","IN","IT","MX","NL","NZ","PL","RU","SG","US","ZA"]);function Ue(e){var t;const a=(t=de(e))==null?void 0:t.toUpperCase();return a&&qe.has(a)?a.toLowerCase():"us"}const je={type:"object",additionalProperties:!1,required:["what","where"],properties:{what:{type:"string"},where:{type:"string"}}},$e=`You suggest a starting job-search query for the applicant described below.
"what" is a short role/keywords phrase (e.g. "senior backend engineer", "product designer") —
their most recent or clearly strongest role from the CV/Personal Legend. Pick ONE single title:
never join multiple roles or technologies with "/", "," or parentheses (e.g. never "Full-Stack
Developer / Backend Engineer (Go, Python, React)") — that reads as a combined AND-match to a
literal keyword search and returns nothing. "where" is a location (city, region, or country) —
their stated city/country if given, else "".
Output only the two fields, no explanation.`;async function O(){const[e,a,t]=await Promise.all([g(),m(),w()]),r=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:(a==null?void 0:a.text)??"",personalLegend:(t==null?void 0:t.content)??""},null,2),s=await d({schemaName:"job_search_query_suggestion",schema:je,model:h,systemPrompt:$e,userPrompt:r,parse:n=>JSON.parse(n)});return{what:s.what,where:s.where||[e.city,e.country].filter(Boolean).join(", ")}}const De={type:"object",additionalProperties:!1,required:["tags"],properties:{tags:{type:"array",items:{type:"string"}}}},Fe=`You generate keyword search tags for Adzuna's job-search API, grounded in
the candidate's real background below. Per Adzuna's own docs
(https://developer.adzuna.com/docs/search), "what" is a single literal keyword/phrase match, not
a semantic search and not a boolean query — so ONE combined tag naming several technologies or
role variants (e.g. "Full-Stack Developer / Backend Engineer (Go, Python, React)") matches
nothing. You compensate by generating a small cross-product of short, atomic tags instead, each
run as its own separate search and merged afterwards.

Method — build the tags as a cross-product, exactly like this worked example for a candidate
whose strongest stack is Go and who also does full-stack/backend work:
  golang developer, go developer, go engineer, golang engineer,
  backend engineer, backend developer, fullstack engineer, fullstack developer,
  software engineer, software developer
That is: {primary technology + its common short aliases} × {developer, engineer}, PLUS
{their role-shape words, e.g. backend / fullstack / frontend / mobile / data — whichever
genuinely apply, without a technology} × {developer, engineer}, PLUS a generic "software
developer" / "software engineer" fallback pair.

Rules:
- Base every tag on their actual, strongest-fitting technology/field from the CV/Personal
  Legend — never invent a technology, role-shape, or seniority they don't have.
- Identify the ONE primary technology (e.g. "Go") plus its common short aliases people actually
  search with (e.g. "Golang") — do not alias unrelated technologies together.
- Each tag pairs exactly one technology-or-role-shape word with exactly one of "developer" /
  "engineer" (add "programmer" only if that's a genuinely common term for that stack). Never put
  two technologies, or a technology and a role-shape, in the same tag.
- If the CV shows a clear secondary technology/stack, budget permitting, add its own couple of
  tags the same way — still never combined with the primary one in a single tag.
- For EACH language listed in "languages" below (skip English), also include ONE of the
  strongest-technology tags translated into that language using the natural job-title term a
  native speaker would search with (not a literal word-for-word translation).
- Each tag is 1-3 words, lowercase, and never contains "/", ",", "(", ")", or a seniority
  qualifier ("senior", "junior", etc.).
- Deduplicate. Return 6-12 tags total, most relevant first.
- Output only the tags, no explanation.`;async function k(){const[e,a,t,r]=await Promise.all([g(),m(),w(),P()]),s=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:(a==null?void 0:a.text)??"",personalLegend:(t==null?void 0:t.content)??"",languages:r.map(o=>o.language)},null,2);return(await d({schemaName:"job_search_tags",schema:De,model:h,systemPrompt:Fe,userPrompt:s,parse:o=>JSON.parse(o)})).tags.map(o=>o.trim()).filter(Boolean)}const Ye={type:"object",additionalProperties:!1,required:["keyRequirements","relevantExperienceHints","suggestedTone","suggestedFocus"],properties:{keyRequirements:{type:"array",items:{type:"string"}},relevantExperienceHints:{type:"array",items:{type:"string"}},suggestedTone:{type:"string"},suggestedFocus:{type:"string"}}};async function Be(e){return d({schemaName:"job_analysis",schema:Ye,model:h,systemPrompt:"You analyze job postings for a job-application assistant. Identify the most important requirements and what an applicant should emphasize. Do not invent details that are not present in the posting.",userPrompt:JSON.stringify(e,null,2),parse:a=>JSON.parse(a)})}const Je={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},He=`You write tailored cover letters for job applications.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, and Personal Legend.
- Never invent experience, technologies, companies, education, or achievements.
- If information needed to be compelling is missing, write around it honestly
  rather than fabricating it.
- Tailor tone and emphasis to the job analysis provided.
- Output plain prose paragraphs, no markdown headers.

${v}`;async function Ge(e){const a=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,analysis:e.analysis},null,2),t=await d({schemaName:"cover_letter",schema:Je,systemPrompt:He,userPrompt:a,parse:r=>JSON.parse(r)});return b(t.content)}const Ke={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},Qe=`You are a sharp human editor cleaning up a cover letter draft.

Fix ONLY the flagged AI-writing patterns listed below. Make the minimum
effective edit — do not rewrite sentences that were not flagged, do not
change facts, experience, technologies, or claims, and do not add new
content. Replace banned words/clichés with plain, concrete language.
Rewrite "not X, it's Y" contrasts as a direct statement of Y. Cut
throat-clearing openers, weasel attribution, and importance-puffery instead
of softening them. If the ending is a generic summary/recap, end on the
letter's last concrete point instead. Replace every em dash ("—") with a
comma, a period, or parentheses.

Do not introduce any new AI-slop while editing. For reference, the full
house style is:

${v}

Output plain prose paragraphs, no markdown headers.`;async function Ve(e,a){const t=JSON.stringify({draft:e,flaggedPatterns:a.map(s=>`${s.pattern}: "${s.match}"`)},null,2),r=await d({schemaName:"cover_letter_polish",schema:Ke,systemPrompt:Qe,userPrompt:t,parse:s=>JSON.parse(s)});return b(r.content)}const ze=["delve","foster","leverage","utilize","facilitate","empower","streamline","robust","cutting-edge","paradigm shift","game changer","this is huge","this changes everything","tapestry","realm","beacon","multifaceted","meticulous","intricate","paramount","transformative","elevate","embark","supercharge","harness","ever-evolving"],Xe=["it's worth noting","it is worth noting","it's important to note","it is important to note","at the end of the day","when it comes to","at its core","in today's world","in the age of","in the world of","the reality is","the truth is","in terms of","with regard to","in order to","going forward"],We=["here's the thing","here's what i mean","let me be clear","i'll be honest","the uncomfortable truth is"],Ze=["this is the part most people skip","what most people get wrong","here's what nobody tells you","the part everyone misses"],et=["stands as a testament","marks a pivotal moment","plays a vital role","solidifies its position","underscores its significance"],tt=["experts agree","industry reports suggest","many argue","widely regarded as","studies show"],nt=[/^in conclusion\b/i,/^ultimately\b/i,/^overall\b/i];function at(e){const a=e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`\\b${a.replace(/ /g,"\\s+")}\\b`,"i")}function y(e,a,t){const r=[];for(const s of a){const n=at(s).exec(e);n&&r.push({pattern:t,match:n[0]})}return r}function st(e){const a=/\b(?:isn'?t|is not)\b[^.!?]{3,60}[,.]?\s*(?:it'?s|it is)\b[^.!?]{3,80}[.!?]/i,t=/\bnot just\b[^.!?]{3,60}(?:\bbut\b|[,.]?\s*(?:it'?s|it is)\b)[^.!?]{0,80}[.!?]/i,r=[],s=a.exec(e);s&&r.push({pattern:"binary-contrast",match:s[0].trim()});const n=t.exec(e);return n&&r.push({pattern:"binary-contrast",match:n[0].trim()}),r}function rt(e){const a=e.split(/\n{2,}/).map(r=>r.trim()).filter(Boolean),t=a[a.length-1];if(!t)return[];for(const r of nt)if(r.test(t))return[{pattern:"summary-recap-ending",match:t.slice(0,60)}];return[]}function ot(e){const a=(e.match(/—/g)??[]).length;return a===0?[]:[{pattern:"em-dash",match:a===1?"1 em dash":`${a} em dashes`}]}function it(e){return[...y(e,ze,"banned-word"),...y(e,Xe,"empty-phrase"),...y(e,We,"throat-clearing-opener"),...y(e,Ze,"faux-insight-setup"),...y(e,et,"importance-puffery"),...y(e,tt,"weasel-attribution"),...st(e),...rt(e),...ot(e)]}async function ct(e){const[a,t,r]=await Promise.all([g(),m(),w()]),s=await Be(e),n=await Ge({profile:a,cvText:(t==null?void 0:t.text)??"",personalLegend:(r==null?void 0:r.content)??"",job:e,analysis:s}),o=it(n);return o.length===0?{content:n,slopFindings:o,cleaned:!1}:{content:await Ve(n,o),slopFindings:o,cleaned:!0}}const lt={type:"object",additionalProperties:!1,required:["company","position","location","description","requirements","responsibilities","salary","techStack","contact"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},description:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]}}};async function x(e,a){return{...await d({schemaName:"job_extraction",schema:lt,systemPrompt:"Extract structured job posting fields from the visible page text below. Only use information present in the text; leave fields empty/null if unknown.",userPrompt:e.slice(0,12e3),parse:r=>JSON.parse(r)}),url:a}}const pt={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},dt=`You are editing an existing cover letter draft on the applicant's
instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the
  letter the instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements
  that aren't already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the
  instruction explicitly asks to change it.
- Output plain prose paragraphs, no markdown headers.
- Don't introduce AI-slop while editing, and clean it from any sentence you
  touch.

${v}`;async function ut(e,a,t){const r=JSON.stringify({draft:e,instructions:a,job:t},null,2),s=await d({schemaName:"cover_letter_revision",schema:pt,model:Y,systemPrompt:dt,userPrompt:r,parse:n=>JSON.parse(n)});return b(s.content)}const ht={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},gt=`You translate a cover letter for the applicant's own understanding —
not for submission. Translate faithfully, preserve paragraph breaks, and keep
names, companies, and technical terms as-is where translating them would be
unnatural. Do not use em dashes ("—"); use commas or periods. Output plain
prose paragraphs, no markdown headers, no notes about the translation itself.`;async function ft(e,a){const t=JSON.stringify({content:e,targetLanguage:a},null,2),r=await d({schemaName:"cover_letter_translation",schema:ht,model:h,systemPrompt:gt,userPrompt:t,parse:s=>JSON.parse(s)});return b(r.content)}const mt={type:"object",additionalProperties:!1,required:["answer"],properties:{answer:{type:"string"}}},M=`You answer a custom question from a job application form on the
applicant's behalf.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend,
  cover letter, custom fields, language levels, and job posting. Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, the
  "languageLevels" list is the authoritative answer (CEFR levels the
  applicant self-reported in Settings) — use it directly rather than
  guessing from the CV or defaulting to a low/neutral level.
- If information needed to answer well is missing, answer honestly and
  briefly rather than fabricating it.
- "faq" is a set of pre-written answers to standard interview-FAQ questions
  (spec_5 section B). If the question being asked now is the same as, or a
  close variant of, one already in "faq", reuse its substance and phrasing —
  adapt only what the target field's length/format actually requires — so
  the applicant's answer stays consistent across different forms rather
  than being re-derived from scratch each time.
- Match the question's expected length: a short field gets a short answer, an
  open-ended "tell us about..." field gets a fuller one.
- Output plain text, no markdown, no restating the question.

${v}`,yt=/\b(?:please\s+(?:provide|specify|clarify)|could\s+you\s+(?:please\s+)?(?:provide|clarify|specify)|i\s+(?:don'?t|do\s+not)\s+see)\b.{0,40}?\b(?:question|prompt)\b|\bno\s+(?:specific\s+)?question\s+(?:was|is)?\s*(?:provided|given|specified|attached)\b/i;function wt(e){const a=e.trim();return a?a.length<220&&yt.test(a):!0}const bt=`
- This is a MULTIPLE-CHOICE question: "options" lists the allowed answers.
  Reply with EXACTLY ONE option, copied verbatim, and nothing else.
- Base the choice on the applicant's profile/CV/Personal Legend. If the
  needed fact is genuinely absent (e.g. pronouns not stated anywhere),
  prefer a neutral option, an explicit "prefer not to say", or the option
  that commits the applicant least.`,Et=`
- This is a SELECT-ALL-THAT-APPLY question: "options" lists every allowed
  answer. Reply with every option that genuinely applies, each copied
  verbatim, joined by " | " (a single pipe surrounded by one space on each
  side) — nothing else. If none apply, reply with an empty string.
- Base each choice strictly on the applicant's profile/CV/Personal Legend —
  never include an option just because it's plausible or common; only ones
  the applicant's own material actually supports.`,St=`
- This field only accepts a plain number: reply with digits only (a single
  "." for a decimal if needed) — no currency symbol, no thousands
  separator, no unit, no words, no range. If a range genuinely fits best
  (e.g. a salary expectation given as "65-75k"), reply with one
  representative figure (its midpoint), not the range.`;function vt(e){return`
- This field only accepts a date in the exact format "${ae[e]}"
  — reply with ONLY that value, nothing else (no words, no explanation).
  "todayISO" in the data below is today's date: compute the answer from it
  — e.g. "available with one month's notice" → todayISO plus one month;
  "immediately" / "as soon as possible" / no stated constraint → todayISO
  itself. Never answer with a description of the notice period or
  availability instead of the date itself.`}async function Tt(e,a,t,r,s,n){const[o,c,i,l,p,Q,V]=await Promise.all([g(),m(),w(),U("lastCoverLetter"),P(),L(),A()]),z=JSON.stringify({question:e,options:t&&t.length>0?t:void 0,todayISO:ne(),job:a,profile:o,cvText:(c==null?void 0:c.text)??"",personalLegend:(i==null?void 0:i.content)??"",coverLetter:l??"",languageLevels:p,customFields:Q,faq:V.filter(_=>_.answer.trim())},null,2),I=[t&&t.length>0?n?Et:bt:"",r?St:"",s?vt(s):""].filter(Boolean),T=await d({schemaName:"custom_question_answer",schema:mt,model:h,systemPrompt:I.length>0?[M,...I].join(`
`):M,userPrompt:z,parse:_=>JSON.parse(_)});return wt(T.answer)?"":t&&t.length>0||r||!!s?T.answer:b(T.answer)}const _t={type:"object",additionalProperties:!1,required:["questions"],properties:{questions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","question"],properties:{index:{type:"integer"},question:{type:"string"}}}}}},Ot=`You are given a block of a job-application form: its visible text, and a
list of the input fields inside it. For each field that asks the applicant
something, return the question it is asking, phrased as a plain question.

Rules:
- Use ONLY the visible text provided. Never invent a question.
- Match each question to its field by "index".
- Omit a field that is not a real question (layout helper, hidden field,
  search box, honeypot, a plain "First name"-style profile field).
- A field with "options" is a multiple-choice question — still return only
  its question text, not the options.
- Output the question text only — no numbering, no "Question:" prefix.
- Questions may be in any language; keep the form's own language.`;async function Lt(e,a){if(a.length===0)return{};const t=JSON.stringify({blockText:e.slice(0,6e3),fields:a},null,2),r=await d({schemaName:"block_questions",schema:_t,model:h,systemPrompt:Ot,userPrompt:t,parse:n=>JSON.parse(n)}),s={};for(const n of r.questions)n.question.trim()&&(s[n.index]=n.question.trim());return s}const Pt={type:"object",additionalProperties:!1,required:["decisions"],properties:{decisions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","check","category","reason"],properties:{index:{type:"integer"},check:{type:"boolean"},category:{type:"string",enum:["required-consent","marketing","optional","unclear"]},reason:{type:"string"}}}}}},At=`You decide, for each checkbox on a job-application form, whether the
applicant should tick it. The applicant has already chosen to submit this
application.

TICK (check: true) — things required to submit, or that a candidate is
normally expected to accept:
- privacy policy / data protection / GDPR / Datenschutz consent
- terms & conditions / AGB / Nutzungsbedingungen
- confirming the entered information is accurate / truthful
- consent to process and store the application data for THIS hiring process
- storing the data in a talent pool ONLY when the checkbox is marked required
- eligibility self-declarations that hold for any ordinary adult applying
  for a real job (e.g. "I am at least 18 years old", "I am legally
  entitled to work in [country]", "I have no undisclosed conflicts of
  interest") — assume true unless the profile/CV explicitly states
  otherwise; a genuine job applicant submitting this form is virtually
  always eligible, and leaving a required declaration like this unticked
  blocks submission for no real reason

DO NOT TICK (check: false) — optional and promotional:
- newsletters, marketing e-mails, "career news", event invitations
- job alerts / notifications about new postings
  (e.g. "Benachrichtigungen über neue Stellenausschreibungen erhalten")
- sharing data with third parties / partner companies for marketing
- joining a talent pool / candidate database when NOT required
- anything that benefits the applicant only beyond this one application

Rules:
- "required: true" means the form marks the field mandatory — a strong
  signal to tick, unless the text is clearly marketing.
- If a checkbox is ambiguous AND not required, set check: false.
- Labels may be in any language; judge by meaning, not keywords.
- Return one decision per input item, using its "index".

category: "required-consent" (ticked, mandatory-type), "marketing" (left
off), "optional" (non-marketing but skippable, left off unless required),
"unclear" (left off). reason: one short phrase.`;async function It(e){if(e.length===0)return[];const a=JSON.stringify(e.map((s,n)=>({index:n,label:s.label,required:s.required,currentlyChecked:s.checked})),null,2),t=await d({schemaName:"checkbox_decisions",schema:Pt,model:h,systemPrompt:At,userPrompt:a,parse:s=>JSON.parse(s)}),r=new Map;for(const s of t.decisions)r.set(s.index,s);return e.map((s,n)=>{const o=r.get(n);return o?{name:s.name,label:s.label,check:o.check,category:o.category,reason:o.reason}:{name:s.name,label:s.label,check:s.required,category:s.required?"required-consent":"unclear",reason:s.required?"Marked required by the form":"No decision returned"}})}const Ct={type:"object",additionalProperties:!1,required:["postingLanguages","requirements"],properties:{postingLanguages:{type:"array",items:{type:"string"}},requirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...se,null]}}}}}},Rt=`You read a job posting and report its language(s) and any explicit
language-proficiency requirement it states.

- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- requirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or
  "Native" for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent",
  "professional working proficiency" -> "C1"; "conversational" -> "B1". If a language is
  mentioned but no level can be reasonably inferred, set level to null. Do not invent a
  requirement that isn't stated in the text. If nothing is stated, return an empty array.`;async function Nt(e){return d({schemaName:"job_language",schema:Ct,model:h,systemPrompt:Rt,userPrompt:JSON.stringify(e,null,2),parse:a=>JSON.parse(a)})}async function K(e){const a=await u(e);await Promise.all(a.map(t=>chrome.tabs.sendMessage(e,{type:"CANCEL_ELEMENT_PICKER",tabId:e},{frameId:t}).catch(()=>{})))}async function q(){const e=await ie();if(e!=null&&e.content)return e.content;const a=await J();try{await $(a)}catch{}return a}async function f(e,a,t){return(await Promise.all(a.map(s=>chrome.tabs.sendMessage(e,t,{frameId:s}).catch(()=>{})))).filter(s=>!!s)}async function kt(e){var a;switch(e.type){case"GET_PROFILE":return{type:"PROFILE_DATA",profile:await g()};case"GET_JOB":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});if(!e.force&&(t!=null&&t.url)){const l=await oe(t.url);if(l)return{type:"JOB_DATA",job:l,sufficient:!0}}const r=await u(e.tabId),n=(await f(e.tabId,r,e)).filter(l=>l.type==="JOB_DATA");if(n.length===0)return;const o=n.find(l=>l.sufficient);if(o)return t!=null&&t.url&&N(t.url,o.job),o;const c=n.reduce((l,p)=>p.job.description.length>l.job.description.length?p:l),i=n.map(l=>l.visibleText??"").filter(Boolean).join(`

`).slice(0,2e4);try{const l=await x(i||c.visibleText||"",c.job.url);return t!=null&&t.url&&N(t.url,l),{type:"JOB_DATA",job:l,sufficient:!0}}catch{return c}}case"EXTRACT_JOB_FROM_TEXT":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});return{type:"JOB_DATA",job:await x(e.text,(t==null?void 0:t.url)??""),sufficient:!0}}case"AUTOFILL":{const t=await u(e.tabId),s=(await f(e.tabId,t,e)).filter(n=>n.type==="AUTOFILL_RESULT");return{type:"AUTOFILL_RESULT",filled:s.reduce((n,o)=>n+o.filled,0),total:s.reduce((n,o)=>n+o.total,0),generatedPassword:s.map(n=>n.generatedPassword).find(Boolean)??null}}case"GENERATE_COVER_LETTER":{const t=await ct(e.job);return await R("lastCoverLetter",t.content),{type:"COVER_LETTER_RESULT",content:t.content,slopFindings:t.slopFindings,cleaned:t.cleaned}}case"UPLOAD_FILE":{const t=await u(e.tabId),s=(await f(e.tabId,t,e)).filter(n=>n.type==="UPLOAD_FILE_RESULT");return{type:"UPLOAD_FILE_RESULT",nativeInputs:s.reduce((n,o)=>n+o.nativeInputs,0),dropZones:s.reduce((n,o)=>n+o.dropZones,0)}}case"REVISE_COVER_LETTER":{const t=await ut(e.content,e.instructions,e.job);return await R("lastCoverLetter",t),{type:"REVISE_COVER_LETTER_RESULT",content:t}}case"TRANSLATE_COVER_LETTER":return{type:"TRANSLATE_COVER_LETTER_RESULT",content:await ft(e.content,e.targetLanguage)};case"DETECT_CUSTOM_QUESTIONS":{const t=await u(e.tabId),r=await f(e.tabId,t,e),s=new Set,n=[];for(const o of r)if(o.type==="CUSTOM_QUESTIONS_DATA")for(const c of o.questions)s.has(c.question)||(s.add(c.question),n.push({...c,id:`question-${n.length}`}));return{type:"CUSTOM_QUESTIONS_DATA",questions:n}}case"ANSWER_CUSTOM_QUESTION":{const t=await Tt(e.question,e.job,e.options,e.numeric,e.dateKind,e.multi);return{type:"CUSTOM_QUESTION_ANSWER",question:e.question,answer:t}}case"FILL_CUSTOM_QUESTION_ANSWERS":{const t=await u(e.tabId),r=await f(e.tabId,t,e);let s=0;const n=[];for(const o of r)o.type==="CUSTOM_QUESTION_FILL_RESULT"&&(s+=o.filled,n.push(...o.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:s,unfilled:n}}case"START_ELEMENT_PICKER":{const t=await u(e.tabId),r=t.map(n=>chrome.tabs.sendMessage(e.tabId,e,{frameId:n}).catch(()=>{})),s=await new Promise(n=>{let o=r.length;o===0&&n(void 0);for(const c of r)c.then(i=>{o-=1,i&&!i.cancelled&&i.picked.length>0||i!=null&&i.cancelled?n(i):o===0&&n(i??void 0)})});return await Promise.all(t.map(n=>chrome.tabs.sendMessage(e.tabId,{type:"CANCEL_ELEMENT_PICKER",tabId:e.tabId},{frameId:n}).catch(()=>{}))),s??{type:"ELEMENT_PICKER_RESULT",cancelled:!0,picked:[],blockText:"",semanticCount:0}}case"CANCEL_ELEMENT_PICKER":{await K(e.tabId);return}case"DECOMPOSE_BLOCK":return{type:"BLOCK_QUESTIONS",questions:await Lt(e.blockText,e.fields)};case"FILL_QUESTION_ANSWERS_BY_LOCATOR":{const t=await u(e.tabId),r=await f(e.tabId,t,e);let s=0;const n=[];for(const o of r)o.type==="CUSTOM_QUESTION_FILL_RESULT"&&(s+=o.filled,n.push(...o.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:s,unfilled:n}}case"DETECT_CHECKBOXES":{const t=await u(e.tabId),r=await f(e.tabId,t,e),s=new Set,n=[];for(const o of r)if(o.type==="CHECKBOXES_DATA")for(const c of o.checkboxes){const i=c.name||c.label;!i||s.has(i)||(s.add(i),n.push({...c,id:`checkbox-${n.length}`}))}return{type:"CHECKBOXES_DATA",checkboxes:n}}case"DECIDE_CHECKBOXES":return{type:"CHECKBOX_DECISIONS",decisions:await It(e.checkboxes)};case"APPLY_CHECKBOX_DECISIONS":{const t=await u(e.tabId),r=await f(e.tabId,t,e);let s=0;for(const n of r)n.type==="CHECKBOX_APPLY_RESULT"&&(s+=n.changed);return{type:"CHECKBOX_APPLY_RESULT",changed:s}}case"DETECT_JOB_LANGUAGE":return{type:"JOB_LANGUAGE_DATA",info:await Nt(e.job)};case"GENERATE_FAQ_ANSWERS":{const t=await A(),r=await _e(e.questions,t);try{await re(r)}catch{}return{type:"FAQ_ANSWERS_RESULT",entries:r}}case"SEARCH_JOBS":{const{provider:t}=e.query;if(t==="adzuna"){const[n,o]=await Promise.all([C(),g()]);if(!n.adzunaAppId||!n.adzunaAppKey)throw new Error("Add your Adzuna app_id and app_key in Settings first.");let c=e.query;if(!((a=c.tags)!=null&&a.length))if(c.what.trim())c={...c,tags:[c.what.trim()]};else{const[l,p]=await Promise.all([O(),k()]);c={...c,what:l.what,where:c.where.trim()||l.where,tags:p.length>0?p:[l.what]}}return{type:"JOB_SEARCH_RESULTS",results:await Me(c,{appId:n.adzunaAppId,appKey:n.adzunaAppKey},Ue(o.country),e.page??1),resolvedQuery:c}}if(t==="tavily"){const n=await C();if(!n.tavilyApiKey)throw new Error("Add your Tavily API key in Settings first.");const o=await q();return{type:"JOB_SEARCH_RESULTS",results:await Ne(e.query,n.tavilyApiKey,o,e.excludeResults),resolvedQuery:e.query}}const r=await q();return{type:"JOB_SEARCH_RESULTS",results:await Ie(e.query,r,e.excludeResults),resolvedQuery:e.query}}case"SUGGEST_SEARCH_QUERY":{if(e.provider==="adzuna"){const[r,s]=await Promise.all([O(),k()]);return{type:"SEARCH_QUERY_SUGGESTION",...r,tags:s}}return{type:"SEARCH_QUERY_SUGGESTION",...await O()}}case"GENERATE_CANDIDATE_SUMMARY":{const t=await J();try{await $(t)}catch{}return{type:"CANDIDATE_SUMMARY_RESULT",content:t}}default:return}}const xt="src/sidepanel/index.html";chrome.runtime.onInstalled.addListener(()=>{me(),chrome.sidePanel.setOptions({enabled:!1})});chrome.contextMenus.onClicked.addListener((e,a)=>{we(e,a)});chrome.action.onClicked.addListener(e=>{if(e.id===void 0)return;const a=e.id;chrome.sidePanel.setOptions({tabId:a,path:xt,enabled:!0}),chrome.sidePanel.open({tabId:a}).catch(t=>console.error("sidePanel.open failed",t)),u(a),e.url&&ce(e.url)});chrome.tabs.onRemoved.addListener(e=>{le(e)});chrome.runtime.onMessage.addListener((e,a,t)=>(kt(e).then(t).catch(r=>{t({type:"ERROR",error:r instanceof Error?r.message:String(r),code:r instanceof Error?r.name:void 0})}),!0));chrome.runtime.onConnect.addListener(e=>{const a=/^picker-(\d+)$/.exec(e.name);if(!a)return;const t=Number(a[1]);e.onDisconnect.addListener(()=>{K(t)})});
