import{P as Qe,g as he,a as _,b as Xe,c as Ze,s as et,d as U,e as fe,f as tt,h as nt,i as at,j as it,k as ge,r as b,J as me,n as ye,t as F,l as D,M as we,m as st,A as z,o as ot,p as rt,q as lt,u as J,v as te,w as be,x as ct,y as ne,z as ve,C as ut,B as Ee,D as pt,E as dt,F as ht,G as Se,H as ft,I as Q,K as N,L as C,N as gt,O as M,Q as B,R as ke,S as Te,T as Le,U as Ie,V as Ae,W as mt,X as yt,Y as ae,Z as j,_ as _e,$ as Oe,a0 as Re,a1 as wt,a2 as bt,a3 as Ce,a4 as vt,a5 as Et,a6 as St,a7 as $,a8 as kt,a9 as Tt,aa as Lt,ab as It}from"./template-CqiGRpL-.js";import{c as At,a as _t}from"./phone-D3SACKoL.js";const Pe={...Qe,cv:"CV",coverLetter:"Cover Letter",generatePassword:"Generated password"},Ot=Object.keys(Pe);async function S(e){try{const n=(await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:["content-script.js"]})).map(a=>a.frameId).filter(a=>typeof a=="number");if(n.length>0)return n}catch{}try{return await chrome.scripting.executeScript({target:{tabId:e},files:["content-script.js"]}),[0]}catch{return[0]}}function Rt(){const e=[];for(const t of Array.from(document.querySelectorAll("iframe, frame"))){const n=t.getBoundingClientRect(),a=n.width*n.height;t.src&&n.width>=200&&n.height>=150&&e.push({src:t.src,area:a})}return{origin:location.origin,children:e}}async function Ct(e){let t;try{t=await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},func:Rt})}catch{return[]}const n=new Set,a=new Map;for(const{result:s}of t)if(s){n.add(s.origin);for(const o of s.children){let r;try{const l=new URL(o.src);if(l.protocol!=="https:"&&l.protocol!=="http:")continue;r=l.origin}catch{continue}a.set(r,Math.max(a.get(r)??0,o.area))}}const i=[];for(const s of[...a.keys()].sort((o,r)=>a.get(r)-a.get(o))){if(n.has(s))continue;if(await chrome.permissions.contains({origins:[`${s}/*`]}).catch(()=>!1)||i.push(s),i.length===3)break}return i}async function Pt(e,t){if(e==="cv"){const i=await he();return(i==null?void 0:i.text)??""}if(e==="coverLetter")return await _("lastCoverLetter")??"";if(e==="generatePassword"){const i=await Xe(t);if(i!=null&&i.generatedPassword)return i.generatedPassword;const s=Ze();return i&&await et(t,{...i,generatedPassword:s}),s}const n=await U(),a=n[e]??"";return e==="phone"&&a?At(a,n.country):a}const x="job-app-assistant-insert",xt={generatePassword:"Generate password"},Nt=Ot.map(e=>({id:e,title:xt[e]??Pe[e]}));function Mt(){chrome.contextMenus.removeAll(()=>{chrome.contextMenus.create({id:x,title:"Insert",contexts:["editable"]});for(const e of Nt)chrome.contextMenus.create({id:`${x}:${e.id}`,parentId:x,title:e.title,contexts:["editable"]})})}function $t(e){return e.startsWith(`${x}:`)?e.slice(x.length+1):null}async function jt(e,t){if(!(t!=null&&t.id)||typeof e.menuItemId!="string")return;const n=$t(e.menuItemId);if(!n)return;const a=await Pt(n,t.id);await S(t.id);const i={type:"INSERT_VALUE",field:n,value:a};chrome.tabs.sendMessage(t.id,i,{frameId:e.frameId}).catch(()=>{})}const qt=new Set(["profileCache","cvLibraryCache","legendLibraryCache","customFieldsCache","languageLevelsCache","faqAnswersCache","generationRulesCache","outreachRulesCache"]);let R=null;function Ut(){return Promise.all([U(),he(),fe(),tt(),nt(),at(),it(),ge()]).then(([e,t,n,a,i,s,o,r])=>({profile:e,cvText:(t==null?void 0:t.text)??"",personalLegend:(n==null?void 0:n.content)??"",generationRules:(a==null?void 0:a.content)??"",outreachRules:(i==null?void 0:i.content)??"",languageLevels:s,customFields:o,faq:r}))}function E(){return R||(R=Ut(),R.catch(()=>{R=null})),R}var de;typeof chrome<"u"&&((de=chrome.storage)!=null&&de.onChanged)&&chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&Object.keys(e).some(n=>qt.has(n))&&(R=null)});const I=`Write like a specific person, not an AI assistant. These rules have no exceptions:

- NEVER use an em dash ("—"), a spaced en dash ("–") or "--" as punctuation. Real people don't write that way. Use a comma, a period, parentheses, or two sentences.
- Banned words: delve, foster, leverage, utilize, facilitate, empower, streamline, robust, cutting-edge, paradigm shift, game changer, tapestry, realm, beacon, multifaceted, meticulous, intricate, paramount, transformative, elevate, embark, supercharge, harness, ever-evolving. Say the plain thing.
- Cut empty phrases: "it's worth noting", "at the end of the day", "when it comes to", "at its core", "in today's world", "the reality is", "in order to", "going forward".
- No "not X, it's Y" / "the question isn't X, it's Y" / "not just X but Y" contrasts. State Y directly.
- No throat-clearing openers ("Here's the thing", "Let me be clear", "I'll be honest") and no faux-insight setups ("what most people get wrong", "here's what nobody tells you").
- No importance puffery ("stands as a testament", "marks a pivotal moment", "plays a vital role", "underscores its significance"). State the fact and stop.
- No colon reveals: a noun phrase, a colon, then a dramatic lowercase clause.
- No trailing "-ing" clauses that editorialize ("highlighting the commitment to...", "underscoring its importance", "showcasing", "reflecting"). End the sentence.
- No metadiscourse that tells the reader what to notice ("this matters", "this distinction matters", "in other words", "as you can see").
- No "In conclusion" / "Ultimately" / "Overall" recap ending and no cute one-line kicker. Stop on the last concrete point.
- No emoji, no mid-sentence bold, no rhetorical questions.
- Vary sentence shape; don't stack short punchy fragments.
- Be concrete: name the technology, project, number, or outcome instead of calling it "significant", "impactful" or "exciting". Use active voice.`;function k(e){return e.replace(/[ \t]*[—―][ \t]*/g,", ").replace(/[ \t]+--[ \t]+/g,", ").replace(/(\D)[ \t]+–[ \t]+(?=\D)/g,"$1, ").replace(/[ \t]+([,.;:!?])/g,"$1").replace(/,(\s*[.;:!?])/g,"$1").replace(/,[ \t]*,/g,",").replace(/^[ \t]*,[ \t]*/gm,"").replace(/([([{])[ \t]*,[ \t]*/g,"$1").replace(/[ \t]*,[ \t]*([)\]}])/g,"$1").replace(/,[ \t]*$/gm,"").replace(/[ \t]+$/gm,"")}const Ft=`You write the applicant's own answers to standard interview-FAQ
questions (spec_5 section B) — general-purpose answers meant to be reused, as-is or
lightly adapted, whenever a real application form asks a close variant of one of them.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend, and
  custom fields. Never invent experience, technologies, companies, education,
  achievements, or a concrete salary figure that wasn't actually given.
- If information needed for a good answer is missing (no CV, no Personal Legend
  content covering it), write a short, honest, generically true answer rather
  than fabricating specifics — the applicant can always sharpen it later.
- Keep each answer 2-5 sentences: concrete and confident, never generic
  corporate filler, no restating the question.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text per answer, no markdown, no numbering.

${I}`;function Dt(e){return{type:"object",additionalProperties:!1,required:["answers"],properties:{answers:{type:"array",minItems:e,maxItems:e,items:{type:"string"}}}}}async function Yt(e){if(e.length===0)return[];const{profile:t,cvText:n,personalLegend:a,generationRules:i,customFields:s}=await E(),o=JSON.stringify({profile:t,cvText:n,personalLegend:a,generationRules:i,customFields:s,questions:e},null,2),r=await b({schemaName:"faq_answers",schema:Dt(e.length),systemPrompt:Ft,userPrompt:o,parse:l=>JSON.parse(l)});return e.map((l,u)=>({question:l,answer:k(r.answers[u]??"")}))}async function Vt(e,t){const n=new Map(t.map(s=>[s.question,s.answer])),a=e.filter(s=>{var o;return!((o=n.get(s))!=null&&o.trim())}),i=await Yt(a);for(const s of i)n.set(s.question,s.answer);return e.map(s=>({question:s,answer:n.get(s)??""}))}async function q(e,t,n){const a=performance.now();try{return await n()}finally{e==null||e.push({label:t,ms:performance.now()-a})}}function Ht(e){return e!=null&&e.length?`Seniority levels to target: ${me.filter(n=>e.includes(n.id)).map(n=>n.label.toLowerCase()).join(", ")}. Only include postings for these levels.`:""}function Jt(e,t){const n=me.filter(i=>t==null?void 0:t.includes(i.id));if(n.length===0)return e;const a=[];for(const i of e)for(const s of n)a.push(i.toLowerCase().includes(s.keyword)?i:`${s.keyword} ${i}`.trim());return[...new Set(a)]}function xe(e){return[e.what?`Role/keywords focus: "${e.what}".`:"",e.where?`Location: "${e.where}".`:"",Ht(e.grades),e.remoteOnly?"Prefer remote-friendly roles.":"",ye(e.negative)].filter(Boolean).join(" ")}const Bt={type:"object",additionalProperties:!1,required:["jobs"],properties:{jobs:{type:"array",items:{type:"object",additionalProperties:!1,required:["title","company","location","url","salary","snippet","postedAt"],properties:{title:{type:"string"},company:{type:"string"},location:{type:"string"},url:{type:"string"},salary:{type:"string"},snippet:{type:"string"},postedAt:{type:"string"}}}}}};function Gt(e,t){const n=ye(t);return`You turn raw web-search results about job openings into a clean,
structured list. The input text was produced by a live internet search and may include
citations, markdown links, or unrelated surrounding prose — extract only genuine
individual job postings from it.

Rules:
- Only include entries that are clearly actual job postings with a real listing URL —
  never a company's generic careers-page homepage, a search-results page, or an
  aggregator's category page.
- "url" must be copied exactly from the source text (never invented).
- "salary" is "" when no figure was given — never guess one.
- "postedAt" is the date the posting was published, as YYYY-MM-DD, only when the text
  states it. Resolve relative dates ("posted 3 days ago", "2w") against today, ${e}.
  Use "" when no date is given — never guess one.
- Drop postings the text marks as closed, expired, filled or "no longer accepting
  applications", and postings published more than ${we} days before ${e}.
- "snippet" is a 1-2 sentence summary of the role; when a "candidate" background is given
  below, make it say *why this posting fits them* specifically (seniority match, matching
  skills, location/remote fit) rather than just restating the posting.
- If a "candidate" background is given, drop postings that are a poor fit for them (wrong
  seniority, unrelated field) even if they're genuine job postings — only surface ones
  actually worth their time.
- Deduplicate: the same posting linked twice becomes one entry.${n?`
- ${n}`:""}
- If nothing in the text is actually a job posting, return an empty "jobs" array.`}async function Ne(e,t,n,a={}){const i=n?`candidate:
${n}

---

${e.slice(0,4e4)}`:e.slice(0,4e4),s=await b({schemaName:"job_listings",schema:Bt,systemPrompt:Gt(F(),a.negative),userPrompt:i,reasoningEffort:a.reasoningEffort,timeoutMs:a.timeoutMs,signal:a.signal,label:"Parsing search results",parse:o=>JSON.parse(o)});return D(s.jobs.filter(o=>o.url.trim()).map(o=>({...o,source:t})))}function Me(e){return e.length===0?"":`

Already found and shown to the applicant — do NOT return any of these again,
find genuinely different postings instead:
${e.map(n=>`- ${n.title} at ${n.company} (${n.url})`).join(`
`)}`}function A(e){return typeof e=="string"?e.trim():""}function Kt(e){const t=e.trim().replace(/^(?:[-*•]|\d+[.)])\s+/u,"").replace(/,$/,"");if(!t.startsWith("{")||!t.endsWith("}"))return null;let n;try{n=JSON.parse(t)}catch{return null}const a=A(n.url),i=A(n.title);return!/^https?:\/\//i.test(a)||!i?null:{title:i,company:A(n.company),location:A(n.location),url:a,salary:A(n.salary),snippet:A(n.snippet),postedAt:A(n.postedAt)}}function Wt(e){let t="";function n(a){const i=Kt(a);i&&e(i)}return{push(a){t+=a;let i;for(;(i=t.indexOf(`
`))!==-1;)n(t.slice(0,i)),t=t.slice(i+1)},end(){n(t),t=""}}}const zt=6,ie=[{id:"ats",focus:`Look on applicant tracking systems: ${z.join(", ")}.`},{id:"careers",focus:"Look on the hiring companies' own career pages (company websites, not job boards)."},{id:"boards",focus:"Look on job boards and aggregators (LinkedIn, Indeed, StepStone, Glassdoor, Welcome to the Jungle, Wellfound, Arbeitnow and similar); when the board links to the employer's own posting, give that URL."}];function Qt(e,t,n=[],a){const i=xe(e),s=F();return`Search the web for current, actually open job postings that fit this
candidate:

${t||"(no candidate background available)"}

${i||"No further constraints — use the candidate's own background to pick a fitting role/location."}

Today is ${s}. Only include postings published in the last ${we} days
that are still accepting applications — skip anything marked closed, expired or filled,
or shown with an older date. Skip postings that are a poor fit for the candidate (wrong
seniority, unrelated field).
Prefer the employer's own posting on its applicant tracking system (${z.join(", ")})
or career page over copies on aggregators, which often outlive the real posting.
Only real individual postings with their direct listing URL — never a search results page,
a generic careers homepage or an aggregator's category page.${a?`
${a}`:""}${Me(n)}

OUTPUT FORMAT — follow exactly. Up to ${zt} of the best matches, best first, as JSON
Lines: one JSON object per line, nothing else (no prose, no markdown, no code fences, no
citations). Each object has exactly these string keys:
{"title":"","company":"","location":"","url":"","salary":"","postedAt":"","snippet":""}
- "url": the posting's direct URL as found.
- "salary": as stated, or "" — never guess.
- "postedAt": YYYY-MM-DD when the posting states a date (resolve "3 days ago" against
  ${s}), else "".
- "snippet": one sentence, at most 25 words, on why it fits this candidate.
If you find no fitting posting, output nothing.`}const H={timeoutMs:9e4,idleMs:4e4,parseTimeoutMs:3e4};function se(e){const t=n=>n.toLowerCase().replace(/[^a-z0-9]+/g," ").trim();return e.company?`${t(e.company)}|${t(e.title)}`:e.url}async function Xt(e,t,n=[],a,i,s){const o=performance.now();let r=null;const l=[],u=new Set,c=d=>u.has(d.url)||u.has(se(d))?!1:(u.add(d.url),u.add(se(d)),l.push(d),!0),h=await Promise.allSettled(ie.map(async d=>{const y=Qt(e,t,n,d.focus),v=Wt(Y=>{const[V]=D([{...Y,source:"openai"}]);!V||!c(V)||(r??(r=performance.now()),i==null||i([V]))}),P=performance.now();try{const Y=await st(y,v.push,{reasoningEffort:"low",timeoutMs:H.timeoutMs,idleMs:H.idleMs,signal:s});return v.end(),Y}finally{a==null||a.push({label:`Web search (${d.id})`,ms:performance.now()-P})}}));a==null||a.push({label:"Web search",ms:performance.now()-o}),r!==null&&(a==null||a.push({label:"First result",ms:r-o}));const m=h.flatMap((d,y)=>d.status==="rejected"?[{id:ie[y].id,err:d.reason}]:[]),f=d=>d instanceof Error?d.message:"the search failed";if(m.length===h.length&&l.length===0)throw m[0].err;const w=m.map(d=>`Web search (${d.id}) stopped: ${f(d.err)}`);if(l.length>0)return{results:l,warnings:w};const g=h.map(d=>d.status==="fulfilled"?d.value:"").filter(d=>d.trim()).join(`

---

`);return g?{results:await q(a,"Parse results",()=>Ne(g,"openai",t,{negative:e.negative,reasoningEffort:"low",timeoutMs:H.parseTimeoutMs,signal:s})),warnings:w}:{results:l,warnings:w}}const Zt="https://api.tavily.com/search",en=2e3;function tn(e,t,n,a=[]){const i=`Find job postings from the last few weeks, still open, that fit this candidate.
${xe(e)}

Candidate background: ${n||"(none available)"}${Me(a)}`.trim().slice(0,en),s=ot(e.negative);return{api_key:t,query:i,search_depth:"advanced",max_results:15,include_answer:!1,time_range:"month",include_published_date:!0,include_domains:z,include_domains_mode:"prefer",...s.length>0?{exclude_domains:s}:{}}}const G={searchTimeoutMs:25e3,parseTimeoutMs:4e4};async function nn(e,t){for(let n=1;;n++){const a=AbortSignal.timeout(G.searchTimeoutMs);let i;try{i=await fetch(Zt,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e),signal:t?AbortSignal.any([t,a]):a})}catch(o){if(a.aborted)throw new Error(`Tavily search timed out after ${G.searchTimeoutMs/1e3} s.`);if(t!=null&&t.aborted||n>=2)throw o;continue}if(i.ok)return await i.json();const s=await i.text().catch(()=>"");if(n>=2||!(i.status===429||i.status>=500))throw new Error(`Tavily search failed (${i.status}): ${s.slice(0,300)}`);await new Promise(o=>setTimeout(o,1500))}}function an(e){return D(e.map(t=>{var n;return{title:t.title,company:"",location:"",url:t.url,salary:"",snippet:t.content.slice(0,240),postedAt:((n=t.published_date)==null?void 0:n.slice(0,10))??"",source:"tavily"}}))}async function sn(e,t,n,a=[],i,s){var u;const o=tn(e,t,n,a),r=await q(i,"Tavily search",()=>nn(o,s));if(!((u=r.results)!=null&&u.length))return{results:[],warnings:[]};const l=r.results.map(c=>`Title: ${c.title}
URL: ${c.url}
${c.published_date?`Published: ${c.published_date}
`:""}${c.content}`).join(`

---

`);try{return{results:await q(i,"Parse results",()=>Ne(l,"tavily",n,{negative:e.negative,reasoningEffort:"low",timeoutMs:G.parseTimeoutMs,signal:s})),warnings:[]}}catch(c){if(s!=null&&s.aborted)throw c;const h=c instanceof Error?c.message:"parse failed";return{results:an(r.results),warnings:[`Couldn't sort Tavily's results (${h}) — showing them unfiltered.`]}}}function on(e,t){return!e&&!t?"":lt({low:Math.round(e??t??0),high:Math.round(t??e??0)})}function rn(e){return new Promise(t=>setTimeout(t,e))}const ln=350,cn=12,oe=15e3;function un(e,t,n,a,i){const s=new URL(`https://api.adzuna.com/v1/api/jobs/${a}/search/${i}`);s.searchParams.set("app_id",n.appId),s.searchParams.set("app_key",n.appKey),s.searchParams.set("results_per_page","15"),s.searchParams.set("content-type","application/json"),e&&s.searchParams.set("what",e),t.where&&s.searchParams.set("where",t.where);const o=rt(t.negative);return o&&s.searchParams.set("what_exclude",o),s.toString()}async function pn(e,t,n,a,i,s){const o=AbortSignal.timeout(oe);let r;try{r=await fetch(un(e,t,n,a,i),{signal:s?AbortSignal.any([s,o]):o})}catch(c){throw o.aborted?new Error(`timed out after ${oe/1e3} s`):c}if(!r.ok){const c=await r.text().catch(()=>"");throw new Error(`Adzuna search failed (${r.status}): ${c.slice(0,300)}`)}const u=(await r.json()).results.map(c=>{var h,m;return{title:c.title,company:((h=c.company)==null?void 0:h.display_name)??"",location:((m=c.location)==null?void 0:m.display_name)??"",url:c.redirect_url,salary:on(c.salary_min,c.salary_max),snippet:(c.description??"").slice(0,300),postedAt:c.created??"",source:"adzuna",tag:e}});return D(u)}async function dn(e,t,n,a=1,i,s){var g;const o=e.tags&&e.tags.length>0?e.tags:[e.what],r=Math.max(((g=e.grades)==null?void 0:g.length)??0,1),l=Math.max(1,Math.floor(cn/r)),u=Jt(o.slice(0,l),e.grades),c=new Set,h=[],m=[];o.length>l&&m.push(`Only the first ${l} search terms were used with ${r} grades selected.`);let f=0,w=null;for(let p=0;p<u.length&&!(s!=null&&s.aborted);p++){const d=u[p];try{const v=(await pn(d,e,t,n,a,s)).filter(P=>!c.has(P.url));for(const P of v)c.add(P.url);h.push(...v),v.length>0&&(i==null||i(v))}catch(y){f++,w??(w=y),m.push(`"${d}" — ${y instanceof Error?y.message:"search failed"}`)}p<u.length-1&&await rn(ln)}if(f===u.length&&w)throw w;return{results:h,warnings:m}}const hn=new Set(["AT","AU","BE","BR","CA","CH","DE","ES","FR","GB","IN","IT","MX","NL","NZ","PL","RU","SG","US","ZA"]);function fn(e){var n;const t=(n=_t(e))==null?void 0:n.toUpperCase();return t&&hn.has(t)?t.toLowerCase():"us"}const gn={type:"object",additionalProperties:!1,required:["what","where"],properties:{what:{type:"string"},where:{type:"string"}}},mn=`You suggest a starting job-search query for the applicant described below.
"what" is a short role/keywords phrase (e.g. "senior backend engineer", "product designer") —
their most recent or clearly strongest role from the CV/Personal Legend. Pick ONE single title:
never join multiple roles or technologies with "/", "," or parentheses (e.g. never "Full-Stack
Developer / Backend Engineer (Go, Python, React)") — that reads as a combined AND-match to a
literal keyword search and returns nothing. "where" is a location (city, region, or country) —
their stated city/country if given, else "".
Output only the two fields, no explanation.`;async function yn(){const{profile:e,cvText:t,personalLegend:n}=await E(),a=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:n},null,2),i=await b({schemaName:"job_search_query_suggestion",schema:gn,systemPrompt:mn,userPrompt:a,parse:s=>JSON.parse(s),reasoningEffort:"low"});return{what:i.what,where:i.where||[e.city,e.country].filter(Boolean).join(", ")}}const wn={type:"object",additionalProperties:!1,required:["tags"],properties:{tags:{type:"array",items:{type:"string"}}}},bn=`You generate keyword search tags for Adzuna's job-search API, grounded in
the candidate's real background below. Per Adzuna's own docs
(https://developer.adzuna.com/docs/search), "what" is a single literal keyword/phrase match, not
a semantic search and not a boolean query — so ONE combined tag naming several technologies or
role variants (e.g. "Full-Stack Developer / Backend Engineer (Go, Python, React)") matches
nothing. You compensate by generating a small cross-product of short, atomic tags instead, each
run as its own separate search and merged afterwards.

Method — build the tags as a cross-product, exactly like this worked example for a candidate
whose strongest stack is Go and who also does full-stack/backend work:
  golang developer, go developer, go engineer, golang engineer,
  backend engineer, backend developer, fullstack engineer, fullstack developer,
  software engineer, software developer
That is: {primary technology + its common short aliases} × {developer, engineer}, PLUS
{their role-shape words, e.g. backend / fullstack / frontend / mobile / data — whichever
genuinely apply, without a technology} × {developer, engineer}, PLUS a generic "software
developer" / "software engineer" fallback pair.

Rules:
- Base every tag on their actual, strongest-fitting technology/field from the CV/Personal
  Legend — never invent a technology, role-shape, or seniority they don't have.
- Identify the ONE primary technology (e.g. "Go") plus its common short aliases people actually
  search with (e.g. "Golang") — do not alias unrelated technologies together.
- Each tag pairs exactly one technology-or-role-shape word with exactly one of "developer" /
  "engineer" (add "programmer" only if that's a genuinely common term for that stack). Never put
  two technologies, or a technology and a role-shape, in the same tag.
- If the CV shows a clear secondary technology/stack, budget permitting, add its own couple of
  tags the same way — still never combined with the primary one in a single tag.
- For EACH language listed in "languages" below (skip English), also include ONE of the
  strongest-technology tags translated into that language using the natural job-title term a
  native speaker would search with (not a literal word-for-word translation).
- Each tag is 1-3 words, lowercase, and never contains "/", ",", "(", ")", or a seniority
  qualifier ("senior", "junior", etc.).
- Deduplicate. Return 6-12 tags total, most relevant first.
- Output only the tags, no explanation.`;async function vn(){const{profile:e,cvText:t,personalLegend:n,languageLevels:a}=await E(),i=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:n,languages:a.map(o=>o.language)},null,2);return(await b({schemaName:"job_search_tags",schema:wn,systemPrompt:bn,userPrompt:i,parse:o=>JSON.parse(o),reasoningEffort:"low"})).tags.map(o=>o.trim()).filter(Boolean)}const En=4;function Sn(e){return JSON.stringify([e.profile.city,e.profile.country,e.cvText,e.personalLegend,e.languageLevels.map(t=>t.language)])}async function kn(e){const t=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(e));return[...new Uint8Array(t)].map(n=>n.toString(16).padStart(2,"0")).join("")}async function $e(e){var r;const t=await kn(Sn(await E())),n=await _("jobSearchSuggestionCache")??[],a=n.find(l=>l.key===t);if(a&&(!e||a.tags))return{what:a.what,where:a.where,tags:a.tags,cached:!0};const[i,s]=await Promise.all([a?{what:a.what,where:a.where}:yn(),e?vn():Promise.resolve(void 0)]),o={key:t,...i,tags:s!=null&&s.length?s:a==null?void 0:a.tags};return(o.what||(r=o.tags)!=null&&r.length)&&await J("jobSearchSuggestionCache",[o,...n.filter(l=>l.key!==t)].slice(0,En)),{what:o.what,where:o.where,tags:o.tags,cached:!1}}async function Tn(e,t={}){var c,h,m;const n=performance.now(),a=[],i=()=>({totalMs:performance.now()-n,stages:a});if(e.provider==="adzuna"){const[f,w]=await Promise.all([te(),U()]);if(!f.adzunaAppId||!f.adzunaAppKey)throw new Error("Add your Adzuna app_id and app_key in Settings first.");let g=e;if(!((c=g.tags)!=null&&c.length))if(g.what.trim())g={...g,tags:[g.what.trim()]};else{const y=performance.now(),v=await $e(!0);a.push({label:v.cached?"Suggest tags (cached)":"Suggest tags",ms:performance.now()-y}),g={...g,what:v.what,where:g.where.trim()||v.where,tags:(h=v.tags)!=null&&h.length?v.tags:[v.what]}}const{results:p,warnings:d}=await q(a,"Adzuna search",()=>dn(g,{appId:f.adzunaAppId,appKey:f.adzunaAppKey},fn(w.country),t.page??1,t.onResults,t.signal));return{results:p,resolvedQuery:g,warnings:d,...i()}}const[s,o]=await Promise.all([fe(),te()]),r=(s==null?void 0:s.content)??"";if(e.provider==="tavily"){if(!o.tavilyApiKey)throw new Error("Add your Tavily API key in Settings first.");const{results:f,warnings:w}=await sn(e,o.tavilyApiKey,r,t.excludeResults,a,t.signal);return f.length>0&&((m=t.onResults)==null||m.call(t,f)),{results:f,resolvedQuery:e,...w.length?{warnings:w}:{},...i()}}const{results:l,warnings:u}=await Xt(e,r,t.excludeResults,a,t.onResults,t.signal);return{results:l,resolvedQuery:e,...u.length?{warnings:u}:{},...i()}}const Ln={type:"object",additionalProperties:!1,required:["keyRequirements","relevantExperienceHints","suggestedTone","suggestedFocus"],properties:{keyRequirements:{type:"array",items:{type:"string"}},relevantExperienceHints:{type:"array",items:{type:"string"}},suggestedTone:{type:"string"},suggestedFocus:{type:"string"}}};async function In(e){return b({schemaName:"job_analysis",schema:Ln,model:await be(),systemPrompt:"You analyze job postings for a job-application assistant. Identify the most important requirements and what an applicant should emphasize. Do not invent details that are not present in the posting.",userPrompt:JSON.stringify(e,null,2),parse:t=>JSON.parse(t)})}const An=`You write tailored cover letters for job applications.

The user message holds the applicant's data as JSON, and may end with an
"Applicant's rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and
   Personal Legend. Never invent experience, technologies, companies,
   education, or achievements, even if the applicant's rules ask for them.
   If information needed to be compelling is missing, write around it
   honestly rather than fabricating it.
2. The applicant's rules. Follow every instruction there on tone, length,
   structure, language, and what to include or avoid, including where it
   departs from the defaults below. Every rule there applies to the whole
   letter, not just the opening.
3. Language. If "postingLanguage" is given, write the entire letter in that
   language, using the salutation, register, and closing conventions native
   speakers of it would expect on a job application (e.g. formal
   "Sie"/"Herr"/"Frau" address and a "Sehr geehrte(r) ..." opening in German,
   not a literal English-to-German translation).
4. The house style below. Its "no exceptions" means no exceptions of your
   own; an explicit applicant rule still overrides it.
5. Tone and emphasis tailored to the job analysis provided.

Output plain prose paragraphs, no markdown headers.

${I}`;async function _n(e,t){const a=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,analysis:e.analysis,postingLanguage:e.postingLanguage||void 0},null,2)+je(e.generationRules),i=await ct(An,a,t??(()=>{}));return k(i)}function je(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const X={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},qe={type:"object",additionalProperties:!1,required:["subject","body"],properties:{subject:{type:["string","null"]},body:{type:"string"}}},On=`You are a sharp human editor cleaning up a cover letter draft.

Fix ONLY the flagged AI-writing patterns listed below. Make the minimum
effective edit — do not rewrite sentences that were not flagged, do not
change facts, experience, technologies, or claims, and do not add new
content. Replace banned words/clichés with plain, concrete language.
Rewrite "not X, it's Y" contrasts as a direct statement of Y. Cut
throat-clearing openers, weasel attribution, and importance-puffery instead
of softening them. If the ending is a generic summary/recap, end on the
letter's last concrete point instead. Replace every em dash ("—") with a
comma, a period, or parentheses.

The user message may end with the applicant's own rules for the letter. If a
flagged pattern is something those rules explicitly ask for, leave it as is:
the applicant's rules outrank the house style.

Do not introduce any new AI-slop while editing. For reference, the full
house style is:

${I}

Output plain prose paragraphs, no markdown headers.`;async function Rn(e,t,n=""){const a=JSON.stringify({draft:e,flaggedPatterns:t.map(s=>`${s.pattern}: "${s.match}"`)},null,2)+je(n),i=await b({schemaName:"cover_letter_polish",schema:X,systemPrompt:On,userPrompt:a,parse:s=>JSON.parse(s)});return k(i.content)}const Cn=["delve","foster","leverage","utilize","facilitate","empower","streamline","robust","cutting-edge","paradigm shift","game changer","this is huge","this changes everything","tapestry","realm","beacon","multifaceted","meticulous","intricate","paramount","transformative","elevate","embark","supercharge","harness","ever-evolving"],Pn=["it's worth noting","it is worth noting","it's important to note","it is important to note","at the end of the day","when it comes to","at its core","in today's world","in the age of","in the world of","the reality is","the truth is","in terms of","with regard to","in order to","going forward"],xn=["here's the thing","here's what i mean","let me be clear","i'll be honest","the uncomfortable truth is"],Nn=["this is the part most people skip","what most people get wrong","here's what nobody tells you","the part everyone misses"],Mn=["stands as a testament","marks a pivotal moment","plays a vital role","solidifies its position","underscores its significance"],$n=["experts agree","industry reports suggest","many argue","widely regarded as","studies show"],jn=[/^in conclusion\b/i,/^ultimately\b/i,/^overall\b/i];function qn(e){const t=e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`\\b${t.replace(/ /g,"\\s+")}\\b`,"i")}function O(e,t,n){const a=[];for(const i of t){const s=qn(i).exec(e);s&&a.push({pattern:n,match:s[0]})}return a}function Un(e){const t=/\b(?:isn'?t|is not)\b[^.!?]{3,60}[,.]?\s*(?:it'?s|it is)\b[^.!?]{3,80}[.!?]/i,n=/\bnot just\b[^.!?]{3,60}(?:\bbut\b|[,.]?\s*(?:it'?s|it is)\b)[^.!?]{0,80}[.!?]/i,a=[],i=t.exec(e);i&&a.push({pattern:"binary-contrast",match:i[0].trim()});const s=n.exec(e);return s&&a.push({pattern:"binary-contrast",match:s[0].trim()}),a}function Fn(e){const t=e.split(/\n{2,}/).map(a=>a.trim()).filter(Boolean),n=t[t.length-1];if(!n)return[];for(const a of jn)if(a.test(n))return[{pattern:"summary-recap-ending",match:n.slice(0,60)}];return[]}function Dn(e){const t=(e.match(/—/g)??[]).length;return t===0?[]:[{pattern:"em-dash",match:t===1?"1 em dash":`${t} em dashes`}]}function Yn(e){return[...O(e,Cn,"banned-word"),...O(e,Pn,"empty-phrase"),...O(e,xn,"throat-clearing-opener"),...O(e,Nn,"faux-insight-setup"),...O(e,Mn,"importance-puffery"),...O(e,$n,"weasel-attribution"),...Un(e),...Fn(e),...Dn(e)]}async function Vn(e,t,n){const a=await E(),i=await In(e),s=await _n({profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,generationRules:a.generationRules,job:e,analysis:i,postingLanguage:t},n),o=Yn(s);return o.length===0?{content:s,slopFindings:o,cleaned:!1}:{content:await Rn(s,o,a.generationRules),slopFindings:o,cleaned:!0}}const Hn=`You write a short outreach message an applicant sends to a named
recruiter/hiring contact BEFORE or alongside applying, to start a conversation about a specific
job posting — not a cover letter, and not addressed to "the hiring team".

The user message holds the applicant's data as JSON ("contact" is the email address or LinkedIn
URL found on the posting, "channel" is "email" or "linkedin"), and may end with an "Applicant's
rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and Personal Legend. Never
   invent experience, technologies, companies, education, or achievements.
2. The applicant's rules. Follow every instruction there on tone, length, structure, language,
   and what to include or avoid, including where it departs from the defaults below.
3. Language. If "postingLanguage" is given, write the entire message in that language, using
   the salutation and register native speakers of it would expect.
4. Channel. If "channel" is "email", write a short email: "subject" is REQUIRED, never null or
   empty: a specific, non-generic subject line under 80 characters that names the role and the
   company (and, if it fits, the applicant's strongest match), in the message's language. "body"
   opens with a greeting and closes with a signature using the applicant's name; it does not
   repeat the subject. If "channel" is "linkedin", write a LinkedIn connection/message note
   instead: "subject" is null, "body" has no email greeting/signature and stays under LinkedIn's
   informal register.
5. The house style below. Its "no exceptions" means no exceptions of your own; an explicit
   applicant rule still overrides it.

Defaults (apply unless the applicant's rules say otherwise): under 120 words, state who the
applicant is and the one or two things that make them a fit for THIS role, and end with a clear,
low-pressure ask (a quick chat, or just flagging interest before applying). Never sound like a
mass-sent template.

${I}`;async function Jn(e){const n=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,contact:e.contact,channel:ne(e.contact)?"email":"linkedin",postingLanguage:e.postingLanguage||void 0},null,2)+Bn(e.outreachRules),a=await b({schemaName:"outreach_message",schema:qe,model:await ve(),systemPrompt:Hn,userPrompt:n,parse:i=>JSON.parse(i)});return{subject:ne(e.contact)?Ue(a.subject,e.job):null,body:k(a.body)}}function Ue(e,t){const n=k((e??"").replace(/^\s*subject\s*:\s*/i,"").replace(/\s+/g," ").trim());if(n)return n;const a=t.position.trim(),i=t.company.trim();return a&&i?`${a} at ${i}`:a||i||"Job application"}function Bn(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const Fe={type:"array",items:{type:"object",additionalProperties:!1,required:["text","kind","matchesProfile"],properties:{text:{type:"string"},kind:{type:"string",enum:["hard","soft"]},matchesProfile:{type:"boolean"}}}};function Z(e){return`KEYWORDS
- Pick the SKILLS the posting asks for, and nothing else. Each one is either:
  - "hard": a technical skill, tool, technology, programming language, framework, platform,
    method or domain expertise (e.g. "TypeScript", "Kubernetes", "C++", ".NET", "CI/CD",
    "SQL", "machine learning", "financial modelling", "Figma", "Scrum");
  - "soft": a real interpersonal/working skill (e.g. "communication", "mentoring",
    "stakeholder management", "problem-solving", "ownership").
- NEVER return anything that is not a skill. In particular, never return:
  - the company name, its products' brand names used as a name, or any other organization;
  - cities, countries, regions, addresses, time zones;
  - work modes and contract terms ("remote", "hybrid", "on-site", "full-time", "contract");
  - benefits and pay ("salary", "equity", "health insurance", "30 days vacation", "bonus");
  - job titles and seniority ("Senior Backend Engineer", "Team Lead", "junior");
  - years of experience, degrees, certificates as such ("5+ years", "Bachelor's degree");
  - spoken languages ("English", "German") — those are reported separately above;
  - generic words ("team", "experience", "work", "product", "environment", "opportunity",
    "fast-paced environment", "passion").
- Every keyword's "text" MUST be copied VERBATIM from ${e} — the exact same characters
  and casing, not a paraphrase, synonym, or translation — because the extension re-finds this
  exact text on the page to highlight it. A keyword that doesn't appear verbatim is useless.
- Prefer short phrases: single words or 2-3 word phrases, never sentences.
- Return up to 15, most important first. Fewer is fine: return an empty array rather than
  padding the list with anything from the NEVER list above.
- No duplicates, and no two keywords where one is a substring of the other (keep the more
  specific/longer one).
- Set "matchesProfile" to true when the applicant's profile/cvText/personalLegend shows they
  already have, use, or meet that skill — false when the posting asks for it but nothing in
  the applicant's material supports it. Judge substance, not exact wording (e.g.
  "Kubernetes" counts as a match if the CV mentions "container orchestration with K8s" or
  "EKS"). When genuinely unsure, set it to false — this flags a possible gap for the
  applicant to address rather than silently hiding it.`}const Gn=new Set(["team","teams","experience","work","job","role","position","company","candidate","opportunity","environment","product","products","customer","customers","client","clients","project","projects","skills","knowledge","ability","responsibilities","requirements","tasks","career","growth","culture","mission","vision","values","impact","passion","motivation","startup","scale-up","industry","business","fast-paced environment","dynamic environment","nice to have","must have","plus","years","year","years of experience","professional experience","work experience","degree","bachelor","bachelor's degree","master","master's degree","university degree","diploma","phd","intern","internship","junior","middle","mid-level","senior","lead","principal","staff","head","manager","remote","fully remote","remote work","hybrid","on-site","onsite","office","in office","home office","homeoffice","relocation","visa sponsorship","full-time","full time","part-time","part time","contract","freelance","permanent","temporary","salary","competitive salary","bonus","equity","stock options","esop","benefits","vacation","paid time off","pto","holidays","health insurance","insurance","pension","gym","gym membership","free lunch","snacks","flexible hours","flexible working hours","learning budget","parental leave","erfahrung","berufserfahrung","aufgaben","anforderungen","unternehmen","vollzeit","teilzeit","festanstellung","gehalt","urlaub","vertrag","büro","mobiles arbeiten","команда","опыт","опыт работы","работа","компания","проект","проекты","задачи","требования","обязанности","удаленно","удаленка","удаленная работа","гибрид","офис","полный день","полная занятость","частичная занятость","зарплата","оклад","бонусы","дмс","отпуск","релокация"]),Kn=new Set(ut.map(e=>L(e))),Wn=new RegExp("\\s*,?\\s*(?<![\\p{L}\\p{N}])(?:inc|ltd|llc|gmbh|ag|se|kg|ug|bv|nv|sa|sas|srl|plc|corp|corporation|co|company|oy|ab|as|ооо|ао)\\.?$","iu");function L(e){return e.normalize("NFC").toLowerCase().replace(/ё/g,"е").replace(/[’`]/g,"'").replace(/^[\s"'«».,:;!?()[\]-]+|[\s"'«».,:;!?()[\]-]+$/g,"").replace(/\s+/g," ")}function zn(e){const t=L(e);if(!t)return[];const n=L(t.replace(Wn,""));return n&&n!==t?[t,n]:[t]}function Qn(e){const t=L(e);if(!t)return[];const n=e.split(/[,/|·•()]/).map(L).filter(Boolean);return[t,...n]}function Xn(e){return L(e.replace(/\((?:[mwfdx]\s*\/\s*)+[mwfdx]\)/gi,""))}const Zn=/^\d+(?:\s*[-–+]\s*\d*)?\+?\s*(?:years?|yrs?|jahre?n?|лет|года?|ans|años)(?![\p{L}\p{N}])/iu;function K(e,t){const n=e.trim();if([...n].length<2)return!new RegExp("^\\p{Lu}$","u").test(n);if(!new RegExp("\\p{L}","u").test(n)||/[$€£¥₽%]/u.test(n))return!0;const a=L(n);return!a||Gn.has(a)||Kn.has(a)||Zn.test(a)||zn(t.company).includes(a)||Qn(t.location).includes(a)?!0:a===Xn(t.position)}function ee(e,t){const n=new Set;return e.filter(a=>{const i=L(a.text);return n.has(i)||K(a.text,t)?!1:(n.add(i),!0)})}function ea(e,t){var i;const n=(i=e.match(/\s*[,;|·•]\s*/u))==null?void 0:i[0];if(!n)return K(e,t)?"":e;const a=new Set;return e.split(/\s*[,;|·•]\s*/u).filter(s=>{const o=L(s);return!s.trim()||a.has(o)||K(s,t)?!1:(a.add(o),!0)}).join(n)}const De={postingLanguages:{type:"array",items:{type:"string"}},languageRequirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...Se,null]}}}},keywords:Fe},ta={type:"object",additionalProperties:!1,required:["company","position","location","description","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},description:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...De}},Ye=`LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- languageRequirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or "Native"
  for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent", "professional
  working proficiency" -> "C1"; "conversational" -> "B1". If a language is mentioned but no level
  can be reasonably inferred, set level to null. Do not invent a requirement that isn't stated in
  the text. If nothing is stated, return an empty array.`,na=`You read the visible text of a job-posting page and do two things with it
in one pass: extract the structured posting fields, and analyze the result for language and
keywords — against the applicant profile/CV/Personal Legend given below.

EXTRACTION
- Only use information present in "pageText"; leave a field empty/null if unknown.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- For "contact", prefer a named recruiter/hiring manager's email address or LinkedIn
  profile/company URL if one is mentioned, copied VERBATIM (exact characters); otherwise null.

${Ye}

${Z('"pageText"')}`;async function aa(e,t){const n=await E(),a=JSON.stringify({profile:n.profile,cvText:n.cvText,personalLegend:n.personalLegend,pageText:e.slice(0,12e3)},null,2),i=await b({schemaName:"job_extraction_and_brief",schema:ta,model:await Ee(),reasoningEffort:"low",systemPrompt:na,userPrompt:a,parse:r=>JSON.parse(r)}),s={company:i.company,position:pt(i.position),location:i.location,description:i.description,requirements:i.requirements,responsibilities:i.responsibilities,salary:i.salary,techStack:i.techStack,contact:i.contact,url:t},o={language:{postingLanguages:i.postingLanguages,requirements:i.languageRequirements},keywords:ee(i.keywords,s),contact:null};return{job:s,brief:o}}const ia={type:"object",additionalProperties:!1,required:["company","position","location","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...De}},sa=`You read the visible text of a job-posting page. It was already parsed
without AI: "knownFields" holds what that found. Fill in what it missed, and analyze the posting
for language and keywords — against the applicant profile/CV/Personal Legend given below.

FIELDS
- Fill only the fields named in "fieldsToFill". For every other posting field return "" / [] /
  null — those are kept from the page as they are. Never re-type the posting's description.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- company: the hiring company, not the job board or recruiting platform hosting the page.
- location: as written in the posting; "" if none.
- requirements, responsibilities: at most 8 items each, each a short phrase (12 words or fewer),
  not copied paragraphs.
- techStack: technology names only.
- contact: a named recruiter/hiring manager's email address or LinkedIn profile/company URL,
  copied VERBATIM (exact characters); otherwise null.
- Only use information present in "pageText"; leave a field empty/null if unknown.

${Ye}

${Z('"pageText"')}`;async function oa(e,t){const n=await E(),a=dt(e),i=t||e.description,s=JSON.stringify({profile:n.profile,cvText:n.cvText,personalLegend:n.personalLegend,knownFields:{position:e.position,company:e.company,location:e.location,salary:e.salary,contact:e.contact},fieldsToFill:a,pageText:i.slice(0,12e3)},null,2),o=await b({schemaName:"job_completion_and_brief",schema:ia,model:await Ee(),reasoningEffort:"low",systemPrompt:sa,userPrompt:s,parse:u=>JSON.parse(u)}),r=ht(e,o,a,i),l={language:{postingLanguages:o.postingLanguages,requirements:o.languageRequirements},keywords:ee(o.keywords,r),contact:null};return{job:r,brief:l}}const ra=`You are editing an existing cover letter draft on the applicant's
instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the
  letter the instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements
  that aren't already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the
  instruction explicitly asks to change it.
- Output plain prose paragraphs, no markdown headers.
- Don't introduce AI-slop while editing, and clean it from any sentence you
  touch.

${I}`;async function la(e,t,n){const a=JSON.stringify({draft:e,instructions:t,job:n},null,2),i=await b({schemaName:"cover_letter_revision",schema:X,model:await ft(),systemPrompt:ra,userPrompt:a,parse:s=>JSON.parse(s)});return k(i.content)}const ca=`You are editing an existing outreach message (an email or LinkedIn note
to a recruiter/hiring contact) on the applicant's instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the message the
  instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements that aren't
  already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the instruction explicitly
  asks to change it.
- If the draft's "subject" is null, keep it null (it's a LinkedIn note). Otherwise keep a
  specific subject line, changing it only if the instruction (or the edit) requires it.
- Don't introduce AI-slop while editing, and clean it from any sentence you touch.

${I}`;async function ua(e,t,n){const a=JSON.stringify({draft:e,instructions:t,job:n},null,2),i=await b({schemaName:"outreach_message_revision",schema:qe,model:await ve(),systemPrompt:ca,userPrompt:a,parse:s=>JSON.parse(s)});return{subject:e.subject===null?null:Ue(i.subject||e.subject,n),body:k(i.body)}}const pa=`You translate a cover letter for the applicant's own understanding —
not for submission. Translate faithfully, preserve paragraph breaks, and keep
names, companies, and technical terms as-is where translating them would be
unnatural. Do not use em dashes ("—"); use commas or periods. Output plain
prose paragraphs, no markdown headers, no notes about the translation itself.`;async function da(e,t){const n=JSON.stringify({content:e,targetLanguage:t},null,2),a=await b({schemaName:"cover_letter_translation",schema:X,systemPrompt:pa,userPrompt:n,parse:i=>JSON.parse(i)});return k(a.content)}const re=new RegExp([String.raw`(?:additional|further|other|more|extra|supplementary)\s+(?:information|info|details|comments?|remarks?|notes?|thoughts)`,String.raw`anything\s+else`,String.raw`is\s+there\s+anything(?:\s+else)?`,String.raw`any(?:thing)?\s+(?:other|further|additional|final)\s+(?:comments?|remarks?|notes?|information|thoughts)`,String.raw`(?:any|final)\s+(?:comments?|remarks?|notes?|thoughts)`,String.raw`(?:a\s+)?(?:message|note)\s+(?:to|for)\s+(?:the\s+|our\s+)?(?:hiring\s+(?:team|manager)|recruit(?:er|ing\s+team|ment\s+team)|team|us|company|employer)`,String.raw`(?:weitere|zus[aä]tzliche|sonstige|erg[aä]nzende|andere)\s+(?:informationen|infos?|angaben|anmerkungen|hinweise|bemerkungen|mitteilungen|kommentare)`,String.raw`sonstiges`,String.raw`(?:m[oö]chten|willst|m[oö]chtest)\s+(?:sie|du)\s+uns\s+(?:sonst\s+)?noch\s+(?:etwas|was)`,String.raw`gibt\s+es\s+(?:sonst\s+)?noch\s+(?:etwas|was)`,String.raw`(?:nachricht|mitteilung)\s+an\s+(?:uns|das\s+team|den\s+recruiter|die\s+personalabteilung)`,String.raw`informations?\s+compl[ée]mentaires?`,String.raw`informaci[oó]n\s+adicional`,String.raw`дополнительн(?:ая|ые)\s+(?:информация|сведения|комментари[йи])`].join("|"),"iu"),ha=/^(?:your\s+|ihre?\s+|deine?\s+|persönliche\s+)?(?:messages?|comments?|remarks?|notes?|nachricht|anmerkungen?|bemerkungen?|kommentare?|hinweise?|mitteilung|commentaires?|comentarios?|комментари[йи]|сообщение)$/iu,fa=/^(?:your\s+|ihr\s+)?(?:cover\s+letter|motivation(?:al)?\s+letter|anschreiben|motivationsschreiben|lettre\s+de\s+motivation|carta\s+de\s+presentaci[oó]n|сопроводительное\s+письмо)$/iu,ga=new RegExp(String.raw`\b(?:optional|freiwillig|facultatif|opcional|необязательно|please|bitte|here|hier|you|you'?d|would|like|to|share|add|tell|let|us|know|mention|with|about|yourself|we|should|that|the|a|an|and|or|for|me|your|our|any|on|in|of|this|application|role|position|job|team|hiring|sie|du|uns|noch|etwas|was|mitteilen|teilen|sagen|zu|ihrer|ihre|deiner|bewerbung|stelle|möchten|möchtest|gibt|es|sonst|und|oder|für|die|der|das|den|dem|an|mit|über|is|there|else|do|have|want|wish|feel|free|e\.?\s?g\.?|z\.?\s?b\.?)\b`,"giu");function ma(e){return e.replace(/[*✱:?!.…]+/g," ").replace(/\((?:optional|freiwillig|facultatif|opcional|необязательно)\)/giu," ").replace(/\s+/g," ").trim()}function ya(e,t){return e.replace(t," ").replace(/[()[\],;/\-–—"'„“”]+/g," ").replace(ga," ").split(/\s+/).filter(a=>new RegExp("\\p{L}{2}","u").test(a))}function wa(e){const t=ma(e);return t?fa.test(t)?"coverLetter":ha.test(t)?"weak":new RegExp(re.source,"giu").test(t)?ya(t,new RegExp(re.source,"giu")).length>=3?null:"strong":null:null}const ba=[/\b(?:please|kindly)\b[^.!?\n]{0,100}\b(?:mention|include|state|indicate|tell\s+us|let\s+us\s+know|add|note|specify|quote|answer)\b[^.!?\n]{0,100}\b(?:application|cover\s+letter|message|submission)\b[^.!?\n]*/iu,/\bin\s+your\s+(?:application|cover\s+letter|message)\b[^.!?\n]{0,100}\b(?:mention|include|state|tell\s+us|let\s+us\s+know|answer|describe)\b[^.!?\n]*/iu,/\b(?:code\s?word|keyword|reference\s+(?:number|code)|kennwort|kennziffer|referenznummer|stichwort)\b[^.!?\n]*/iu,/\b(?:geben|nennen|teilen|erw[aä]hnen|beantworten)\s+sie\b[^.!?\n]{0,120}\b(?:bewerbung|anschreiben|nachricht)\b[^.!?\n]*/iu,/\bin\s+ihrer\s+bewerbung\b[^.!?\n]{0,120}\b(?:an|nennen|angeben|mitteilen|erw[aä]hnen|beantworten)\b[^.!?\n]*/iu];function le(e){const t=[e.description??"",...e.requirements??[],...e.responsibilities??[]].join(`
`);for(const n of ba){const a=n.exec(t);if(a)return a[0].trim().slice(0,300)}return null}function va(e,t){if(t.required===!0)return{action:"write",reason:"required",postingAsk:le(e)??void 0};const n=le(e);return n?{action:"write",reason:"posting",postingAsk:n}:t.required===!1?{action:"skip"}:{action:"write",reason:"asked"}}const Ea={type:"object",additionalProperties:!1,required:["skip","answer"],properties:{skip:{type:"boolean"},answer:{type:"string"}}},Sa=`You decide what, if anything, goes into the open catch-all field at the end of a
job application form ("Additional information", "Anything else you'd like to share?", "Weitere
Informationen", "Sonstiges", "Message to the hiring team"). The recruiter already has everything
in "formValues", "otherAnswers", the attached CV ("cvText"), the cover letter ("coverLetter") and
the profile. Repeating any of it wastes their time and makes the application look padded.

Rules:
- "skip": true, "answer": "" is the normal result. Choose it whenever there is nothing NEW and
  relevant to add. An empty field is fine.
- Never repeat or paraphrase: contact data (name, email, phone, address, city), links (LinkedIn,
  GitHub, portfolio, website), salary expectations, start date / notice period / availability,
  work permit / visa / relocation, language levels, a summary of the CV or the experience, or the
  motivation already given in the cover letter or other answers.
- "postingAsk" (when present) is what the job posting explicitly asks applicants to include.
  Answer exactly that, from the applicant's data, if it isn't already in the form. If the data
  doesn't have it, skip.
- "required": true means the form won't submit with the field empty. Then don't skip: write ONE
  short sentence with something new from the Personal Legend or custom fields, or, if there is
  truly nothing new, one plain neutral sentence (e.g. that you look forward to hearing from them).
- Otherwise ("required" false or unknown), write only when there is a genuinely new, relevant fact
  (e.g. a constraint the recruiter must know that appears nowhere else).
- At most 2 sentences, plain text, no greeting, no sign-off, no lists, no markdown.
- Never invent facts. Use ONLY the applicant data given.
- If "postingLanguage" is given, write in that language with its native application register.

${I}`,ka=/\b(?:https?:\/\/|www\.)\S+|\b[\w.-]+\.(?:com|de|io|dev|net|org|me)\/\S*/i,Ta=/\b[\w.+-]+@[\w-]+\.[\w.-]+\b/,La=/(?:\+|\b00)\d[\d\s/().-]{6,}\d|\b0\d{2,4}[\s/-]?\d{3,}[\s-]?\d{2,}\b/;function Ia(e){return e.replace(/\s+/g," ").trim().split(new RegExp("(?<=[.!?])\\s+(?=\\S)","u")).filter(n=>n&&!ka.test(n)&&!Ta.test(n)&&!La.test(n)).slice(0,2).join(" ").trim()}const Ve="catchAllAdds";function Aa(e){return{type:"predicate",name:Ve,instructions:`The application form has an open catch-all field ("field"), not marked required: "Additional information", "Anything else?".
The recruiter already has the applicant's CV, cover letter, profile and every value in "formValues"
and "otherAnswers". Should the applicant write anything in it?
- Yes only if ${e?`the applicant's data covers what the posting explicitly asks applicants to include ("postingAsk") and the form doesn't already hold it, or if `:""}the applicant's data holds a genuinely NEW fact relevant to this application that appears nowhere else (e.g. a constraint the recruiter must know).
- No for anything already in the CV, cover letter, profile or form: contact data, links, salary, start date /
  notice period / availability, work permit / visa / relocation, language levels, a summary of the
  experience, the motivation.
- No when in doubt: an empty field is the normal, good outcome.`}}async function _a(e,t,n,a){try{const i=[...e.input,{role:"user",content:[{type:"input_json",data:{formValues:(n.formValues??[]).filter(o=>o.value.trim()),otherAnswers:(n.otherAnswers??[]).filter(o=>o.answer.trim()),coverLetterAttached:n.coverLetterAttached||void 0,postingAsk:a??null,field:t}}]}],s=await C({input:i,promptCacheKey:e.promptCacheKey,questions:[Aa(a)]});return gt(s,Ve)}catch(i){if(i instanceof M)throw i;return console.warn("[Filler] Decisions API failed, writing the catch-all via Responses:",i),null}}async function He(e,t,n,a){const i=va(t,n);if(i.action==="skip")return{answer:"",sufficientInfo:!0,skipped:!0};const[s,o]=await Promise.all([E(),_("lastCoverLetter")]);if(n.required!==!0){const c=Q(s,o??"",t,a),h=await _a(c,e,n,i.postingAsk);if(h!==null&&h<N.catchAllWrite)return{answer:"",sufficientInfo:!0,skipped:!0}}const r=JSON.stringify({job:t,profile:s.profile,cvText:s.cvText,coverLetter:o??"",coverLetterAttached:n.coverLetterAttached||void 0,personalLegend:s.personalLegend,customFields:s.customFields,languageLevels:s.languageLevels,generationRules:s.generationRules,postingLanguage:a||void 0,formValues:(n.formValues??[]).filter(c=>c.value.trim()),otherAnswers:(n.otherAnswers??[]).filter(c=>c.answer.trim()),postingAsk:i.postingAsk,required:n.required??"unknown",question:e},null,2),l=await b({schemaName:"catch_all_answer",schema:Ea,systemPrompt:Sa,userPrompt:r,label:"Catch-all answer",parse:c=>JSON.parse(c)}),u=l.skip?"":Ia(k(l.answer));return u?{answer:u,sufficientInfo:!0,skipped:!1}:{answer:"",sufficientInfo:n.required!==!0,skipped:!0}}const Oa={type:"object",additionalProperties:!1,required:["answer","sufficientInfo"],properties:{answer:{type:"string"},sufficientInfo:{type:"boolean"}}},ce=`You answer a custom question from a job application form on the
applicant's behalf.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend,
  cover letter, custom fields, language levels, and job posting. Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, the
  "languageLevels" list is the authoritative answer (CEFR levels the
  applicant self-reported in Settings) — use it directly rather than
  guessing from the CV or defaulting to a low/neutral level.
- If the profile/CV/Personal Legend/etc genuinely lack what's needed to
  answer this question — not just a minor detail, but the actual substance
  being asked for — set "sufficientInfo" to false and "answer" to an empty
  string. Do NOT write a sentence explaining that you don't have the
  information (e.g. "I don't have this information available") — that text
  would otherwise get typed straight into the applicant's form field, which
  is worse than leaving it blank for the applicant to fill in themselves.
  Only do this when the information is truly absent; a question you can
  answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient —
  set sufficientInfo to true and give that honest answer.
- If "postingLanguage" is given, write the answer in that language, using
  the salutation/register conventions native speakers of it would expect on
  a job application (e.g. formal "Sie"/"Herr"/"Frau" address in German, not
  a literal English-to-German translation) — unless the question itself, or
  "generationRules", explicitly asks for a different language.
- If this question is a newsletter, marketing-email, or job-alert
  subscription opt-in phrased as a choice (e.g. "Would you like to
  subscribe to our newsletter? Yes/No"), always choose the option that
  declines it — the applicant never needs this to submit the application.
- "faq" is a set of pre-written answers to standard interview-FAQ questions
  (spec_5 section B). If the question being asked now is the same as, or a
  close variant of, one already in "faq", reuse its substance and phrasing —
  adapt only what the target field's length/format actually requires — so
  the applicant's answer stays consistent across different forms rather
  than being re-derived from scratch each time.
- Match the question's expected length: a short field gets a short answer, an
  open-ended "tell us about..." field gets a fuller one.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text, no markdown, no restating the question.

${I}`,Ra=/\b(?:please\s+(?:provide|specify|clarify)|could\s+you\s+(?:please\s+)?(?:provide|clarify|specify)|i\s+(?:don'?t|do\s+not)\s+see)\b.{0,40}?\b(?:question|prompt)\b|\bno\s+(?:specific\s+)?question\s+(?:was|is)?\s*(?:provided|given|specified|attached)\b/i;function Je(e){const t=e.trim();return t?t.length<220&&Ra.test(t):!0}const Ca=`
- This is a MULTIPLE-CHOICE question: "options" lists the allowed answers.
  Reply with EXACTLY ONE option, copied verbatim, and nothing else.
- Base the choice on the applicant's profile/CV/Personal Legend. If the
  needed fact is genuinely absent (e.g. pronouns not stated anywhere),
  prefer a neutral option, an explicit "prefer not to say", or the option
  that commits the applicant least.`,Pa=`
- This is a SELECT-ALL-THAT-APPLY question: "options" lists every allowed
  answer. Reply with every option that genuinely applies, each copied
  verbatim, joined by " | " (a single pipe surrounded by one space on each
  side) — nothing else. If none apply, reply with an empty string.
- Base each choice strictly on the applicant's profile/CV/Personal Legend —
  never include an option just because it's plausible or common; only ones
  the applicant's own material actually supports.`,xa=`
- This field only accepts a plain number: reply with digits only (a single
  "." for a decimal if needed) — no currency symbol, no thousands
  separator, no unit, no words, no range. If a range genuinely fits best
  (e.g. a salary expectation given as "65-75k"), reply with one
  representative figure (its midpoint), not the range.`;function Na(e){return`
- This field only accepts a date in the exact format "${Ae[e]}"
  — reply with ONLY that value, nothing else (no words, no explanation).
  "todayISO" in the data below is today's date: compute the answer from it
  — e.g. "available with one month's notice" → todayISO plus one month;
  "immediately" / "as soon as possible" / no stated constraint → todayISO
  itself. Never answer with a description of the notice period or
  availability instead of the date itself.`}async function Ma(e,t,n,a,i,s,o,r){if(!(n&&n.length>0)&&!a&&!i&&(r||r===void 0&&wa(e)==="strong"))return He(e,t,r??{},o);const[u,c]=await Promise.all([E(),_("lastCoverLetter")]),{input:h,promptCacheKey:m}=Q(u,c??"",t,o),f={question:e,options:n,multi:s,numeric:a,dateKind:i},w=B(f);try{const g=await C({input:h,promptCacheKey:m,questions:w?ke(f,0):[Te(f,0)]});if(w){const p=Le(f,0,g);if(p)return p}else if(Ie(0,g)===!1)return{answer:"",sufficientInfo:!1}}catch(g){if(g instanceof M)throw g;console.warn("[Filler] Decisions API failed, answering via Responses:",g)}return $a(e,t,n,a,i,s,o)}async function $a(e,t,n,a,i,s,o){const[r,l]=await Promise.all([E(),_("lastCoverLetter")]),u=JSON.stringify({job:t,profile:r.profile,cvText:r.cvText,personalLegend:r.personalLegend,generationRules:r.generationRules,coverLetter:l??"",languageLevels:r.languageLevels,customFields:r.customFields,faq:r.faq.filter(f=>f.answer.trim()),todayISO:F(),postingLanguage:o||void 0,question:e,options:n&&n.length>0?n:void 0},null,2),c=[n&&n.length>0?s?Pa:Ca:"",a?xa:"",i?Na(i):""].filter(Boolean),h=await b({schemaName:"custom_question_answer",schema:Oa,systemPrompt:c.length>0?[ce,...c].join(`
`):ce,userPrompt:u,parse:f=>JSON.parse(f)});return!h.sufficientInfo||Je(h.answer)?{answer:"",sufficientInfo:h.sufficientInfo}:{answer:n&&n.length>0||a||!!i?h.answer:k(h.answer),sufficientInfo:!0}}const ja={type:"object",additionalProperties:!1,required:["questions"],properties:{questions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","question"],properties:{index:{type:"integer"},question:{type:"string"}}}}}},qa=`You are given a block of a job-application form: its visible text, and a
list of the input fields inside it. For each field that asks the applicant
something, return the question it is asking, phrased as a plain question.

Rules:
- Use ONLY the visible text provided. Never invent a question.
- Match each question to its field by "index".
- Omit a field that is not a real question (layout helper, hidden field,
  search box, honeypot, a plain "First name"-style profile field).
- A field with "options" is a multiple-choice question — still return only
  its question text, not the options.
- Output the question text only — no numbering, no "Question:" prefix.
- Questions may be in any language; keep the form's own language.`;async function Ua(e,t){if(t.length===0)return{};const n=JSON.stringify({blockText:e.slice(0,6e3),fields:t},null,2),a=await b({schemaName:"block_questions",schema:ja,systemPrompt:qa,userPrompt:n,parse:s=>JSON.parse(s)}),i={};for(const s of a.questions)s.question.trim()&&(i[s.index]=s.question.trim());return i}const Fa={type:"object",additionalProperties:!1,required:["checkboxDecisions","questionAnswers"],properties:{checkboxDecisions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","check","category","reason"],properties:{index:{type:"integer"},check:{type:"boolean"},category:{type:"string",enum:["required-consent","marketing","optional","unclear"]},reason:{type:"string"}}}},questionAnswers:{type:"array",items:{type:"object",additionalProperties:!1,required:["id","answer","sufficientInfo"],properties:{id:{type:"string"},answer:{type:"string"},sufficientInfo:{type:"boolean"}}}}}},Da=`You fill in two independent things found on a job-application form at once:
consent checkboxes to decide, and custom questions to answer on the applicant's behalf. The
applicant has already chosen to submit this application.

CHECKBOXES (one decision per item in "checkboxes", matched back by "index")

TICK (check: true) — things required to submit, or that a candidate is normally expected to
accept:
- privacy policy / data protection / GDPR / Datenschutz consent
- terms & conditions / AGB / Nutzungsbedingungen
- confirming the entered information is accurate / truthful
- consent to process and store the application data for THIS hiring process
- storing the data in a talent pool ONLY when the checkbox is marked required
- eligibility self-declarations that hold for any ordinary adult applying for a real job (e.g.
  "I am at least 18 years old", "I am legally entitled to work in [country]", "I have no
  undisclosed conflicts of interest") — assume true unless the profile/CV explicitly states
  otherwise; a genuine job applicant submitting this form is virtually always eligible, and
  leaving a required declaration like this unticked blocks submission for no real reason

DO NOT TICK (check: false) — optional and promotional:
- newsletters, marketing e-mails, "career news", event invitations
- job alerts / notifications about new postings (e.g. "Benachrichtigungen über neue
  Stellenausschreibungen erhalten")
- sharing data with third parties / partner companies for marketing
- joining a talent pool / candidate database when NOT required
- anything that benefits the applicant only beyond this one application

Rules:
- "required: true" means the form marks the field mandatory — a strong signal to tick, unless
  the text is clearly marketing.
- A newsletter/marketing-email/job-alert opt-in is NEVER ticked, even when the form marks it
  "required" — that flag is routinely misused by forms to guilt-trip applicants into
  subscribing, even though applicants never actually need it to submit. When genuinely in doubt
  whether a required checkbox is a real submission requirement or a disguised newsletter
  opt-in, prefer NOT ticking it.
- If a checkbox is ambiguous AND not required, set check: false.
- Labels may be in any language; judge by meaning, not keywords.
- category: "required-consent" (ticked, mandatory-type), "marketing" (left off), "optional"
  (non-marketing but skippable, left off unless required), "unclear" (left off). reason: one
  short phrase.
- Return one decision per input item in "checkboxes", using its "index". If "checkboxes" is
  empty, return an empty array.

QUESTIONS (one answer per item in "questions", matched back by "id")

Ground rules:
- Use ONLY facts present in the shared "profile"/"cvText"/"personalLegend"/"generationRules"/
  "coverLetter"/"languageLevels"/"customFields"/"faq" given below, plus "job". Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, "languageLevels" is the
  authoritative answer (CEFR levels the applicant self-reported in Settings) — use it directly
  rather than guessing from the CV or defaulting to a low/neutral level.
- If the shared material genuinely lacks what's needed to answer a given question — not just a
  minor detail, but the actual substance being asked for — set that item's "sufficientInfo" to
  false and "answer" to an empty string. Do NOT write a sentence explaining that you don't have
  the information — that text would otherwise get typed straight into the applicant's form
  field, which is worse than leaving it blank. Only do this when the information is truly
  absent; a question you can answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient.
- If "postingLanguage" is given, write answers in that language, using the salutation/register
  conventions native speakers of it would expect on a job application (e.g. formal
  "Sie"/"Herr"/"Frau" address in German) — unless the question itself, or "generationRules",
  explicitly asks for a different language.
- A newsletter/marketing-email/job-alert subscription opt-in phrased as a question (e.g. "Would
  you like to subscribe to our newsletter? Yes/No") always gets the option that declines it.
- "faq" is a set of pre-written answers to standard interview-FAQ questions. If a question being
  asked now is the same as, or a close variant of, one already in "faq", reuse its substance and
  phrasing — adapt only what the target field's length/format actually requires.
- Match each question's expected length: a short field gets a short answer, an open-ended
  "tell us about..." field gets a fuller one.
- Output plain text per answer, no markdown, no restating the question.
- Each item in "questions" may also carry:
  - "options" (and not "multi"): a single-choice question — reply with EXACTLY ONE option,
    copied verbatim, nothing else. If the needed fact is genuinely absent (e.g. pronouns not
    stated anywhere), prefer a neutral option or an explicit "prefer not to say".
  - "options" with "multi": true: a select-all-that-apply question — reply with every option
    that genuinely applies, each copied verbatim, joined by " | " (one pipe, one space each
    side). If none apply, reply with an empty string. Never include an option just because it's
    plausible — only ones the applicant's own material actually supports.
  - "numeric": true: the field only accepts a plain number — reply with digits only (a single
    "." for a decimal if needed), no currency symbol, no thousands separator, no unit, no words,
    no range. If a range genuinely fits best (e.g. "65-75k"), reply with one representative
    figure (its midpoint).
  - "dateFormat": the field only accepts a date in exactly that format — reply with ONLY that
    value, nothing else. "todayISO" below is today's date: compute the answer from it — e.g.
    "available with one month's notice" -> todayISO plus one month; "immediately"/"as soon as
    possible"/no stated constraint -> todayISO itself.
- Return one answer per input item in "questions", using its "id". If "questions" is empty,
  return an empty array.

${I}`;function Ya(e,t){const n=new Map;for(const a of t)n.set(a.index,a);return e.map((a,i)=>{const s=n.get(i);if(s){const o=s.check&&ae(a.label)?!1:s.check;return{name:a.name,label:a.label,check:o,category:s.category,reason:s.reason}}return ae(a.label)?{name:a.name,label:a.label,check:!1,category:"marketing",reason:"No decision returned — looks like a newsletter/marketing opt-in"}:{name:a.name,label:a.label,check:a.required,category:a.required?"required-consent":"unclear",reason:a.required?"Marked required by the form":"No decision returned"}})}function Va(e,t){const n=new Map;for(const a of t)n.set(a.id,a);return e.map(a=>{const i=n.get(a.id);if(!i)return{id:a.id,answer:"",sufficientInfo:!0};if(!i.sufficientInfo||Je(i.answer))return{id:a.id,answer:"",sufficientInfo:i.sufficientInfo};const s=a.options&&a.options.length>0||a.numeric||!!a.dateKind;return{id:a.id,answer:s?i.answer:k(i.answer),sufficientInfo:!0}})}async function ue(e,t,n,a){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[i,s]=await Promise.all([E(),_("lastCoverLetter")]),o=JSON.stringify({job:n,profile:i.profile,cvText:i.cvText,personalLegend:i.personalLegend,generationRules:i.generationRules,coverLetter:s??"",languageLevels:i.languageLevels,customFields:i.customFields,faq:i.faq.filter(l=>l.answer.trim()),todayISO:F(),postingLanguage:a||void 0,checkboxes:e.map((l,u)=>({index:u,label:l.label,required:l.required,currentlyChecked:l.checked})),questions:t.map(l=>({id:l.id,question:l.question,options:l.options&&l.options.length>0?l.options:void 0,multi:l.multi,numeric:l.numeric,dateFormat:l.dateKind?Ae[l.dateKind]:void 0}))},null,2),r=await b({schemaName:"page_content_decisions",schema:Fa,systemPrompt:Da,userPrompt:o,parse:l=>JSON.parse(l)});return{checkboxDecisions:Ya(e,r.checkboxDecisions),questionAnswers:Va(t,r.questionAnswers)}}async function Ha(e,t,n,a){const i=t.filter(c=>c.catchAll),s=i.length>0?t.filter(c=>!c.catchAll):t,o=await Ja(e,s,n,a);if(i.length===0)return o;const r=s.flatMap(c=>{var m;const h=((m=o.questionAnswers.find(f=>f.id===c.id))==null?void 0:m.answer)??"";return h?[{question:c.question,answer:h}]:[]}),l=await Promise.all(i.map(async c=>{const{answer:h,sufficientInfo:m}=await He(c.question,n,{required:c.required??!1,formValues:c.formValues,otherAnswers:r,coverLetterAttached:c.coverLetterAttached},a);return{id:c.id,answer:h,sufficientInfo:m}})),u=new Map([...o.questionAnswers,...l].map(c=>[c.id,c]));return{checkboxDecisions:o.checkboxDecisions,questionAnswers:t.map(c=>u.get(c.id)??{id:c.id,answer:"",sufficientInfo:!0})}}async function Ja(e,t,n,a){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[i,s]=await Promise.all([E(),_("lastCoverLetter")]),{input:o,promptCacheKey:r}=Q(i,s??"",n,a),l=t.map((p,d)=>({q:p,i:d})),u=l.filter(({q:p})=>B(p)),c=l.filter(({q:p})=>!B(p));let h;try{h=await C({input:o,promptCacheKey:r,questions:[...mt(e),...u.flatMap(({q:p,i:d})=>ke(p,d)),...c.map(({q:p,i:d})=>Te(p,d))]})}catch(p){if(p instanceof M)throw p;return console.warn("[Filler] Decisions API failed, falling back to Responses:",p),ue(e,t,n,a)}const m=e.map((p,d)=>yt(p,d,h)),f=e.filter((p,d)=>!m[d]),w=new Map,g=[];for(const{q:p,i:d}of u){const y=Le(p,d,h);y?w.set(p.id,{id:p.id,...y}):g.push(p)}for(const{q:p,i:d}of c)Ie(d,h)===!1?w.set(p.id,{id:p.id,answer:"",sufficientInfo:!1}):g.push(p);if(f.length>0||g.length>0){const p=await ue(f,g,n,a);for(const y of p.questionAnswers)w.set(y.id,y);const d=new Map(p.checkboxDecisions.map(y=>[y.name+"\0"+y.label,y]));e.forEach((y,v)=>{m[v]||(m[v]=d.get(y.name+"\0"+y.label)??null)})}return{checkboxDecisions:m.filter(p=>p!==null),questionAnswers:t.map(p=>w.get(p.id)??{id:p.id,answer:"",sufficientInfo:!0})}}const W="(none of these)",Be="(not a profile field)",Ge={salutation:"Salutation / title / gender as a form of address (Mr, Ms, Frau, Herr).",pronouns:"Preferred pronouns (she/her, he/him).",firstName:"The applicant's first / given name only.",lastName:"The applicant's last / family name only.",fullName:"The applicant's full name in one box.",email:"The applicant's e-mail address.",phone:"The applicant's phone / mobile number.",address:"Street and house number.",city:"City / town the applicant lives in.",postalCode:"Postal / ZIP code.",country:"Country the applicant lives in (not nationality, not where they want to work).",linkedin:"LinkedIn profile URL.",github:"GitHub profile URL.",website:"Personal website or portfolio URL.",expectedSalary:"The applicant's salary expectation as an amount (not a currency or period picker)."},Ba=[...Object.entries(Ge).map(([e,t])=>({value:e,description:t})),{value:Be,description:"Anything else: an application question, a date, a company, a job title, a free comment, or a field about somebody else (a referrer, a reference, an emergency contact)."}],Ga=`You help autofill a job-application form from the applicant's saved profile.
Two kinds of questions follow, each about one field of the form and independent of the others:
- Option questions: the field must be set to a value the applicant already gave, but its options word it differently
  (another language, an official name, a region added, an amount written as a range). Pick the option that means
  the same thing — the same country, the same city, the range containing the amount. When no option does, pick
  "${W}"; never pick a merely similar one.
- Field questions: from what the page says about a field (label, name, placeholder…), which profile value does it ask
  for? Only the applicant's own data counts; when unsure, "${Be}".
Labels may be in any language: judge by meaning.`;function Ka(e){var n,a;return[`label "${e.label}"`,`type ${e.kind}`,e.name&&`name "${e.name}"`,e.id&&`id "${e.id}"`,e.placeholder&&`placeholder "${e.placeholder}"`,e.ariaLabel&&`aria-label "${e.ariaLabel}"`,e.autocomplete&&`autocomplete "${e.autocomplete}"`,((n=e.other)==null?void 0:n.length)&&`nearby text ${e.other.map(i=>`"${i}"`).join(", ")}`,((a=e.options)==null?void 0:a.length)&&`options ${e.options.map(i=>`"${i}"`).join(", ")}`].filter(Boolean).join("; ")}function Wa(e){return{type:"choice",name:e.id,instructions:`Form field labelled "${e.label}" (the applicant's ${e.field}). The applicant's value: "${e.value}". Which option is that value?`,choices:[...new Set(e.options)].filter(t=>t!==W).map(t=>({value:t})).concat({value:W})}}function za(e){return[...e.optionPicks.filter(t=>t.options.length>0).map(Wa),...e.fieldKinds.map(t=>({type:"choice",name:t.id,instructions:`A form field with ${Ka(t.signals)}. Which of the applicant's profile values does it ask for?`,choices:Ba}))]}function Qa(e,t){return{optionPicks:e.optionPicks.filter(n=>t.has(n.id)).map(n=>{const a=j(t,n.id),i=a&&a.confidence>=N.optionMatch&&n.options.includes(a.choice);return{id:n.id,choice:i?a.choice:null}}),fieldKinds:e.fieldKinds.filter(n=>t.has(n.id)).map(n=>{const a=j(t,n.id),i=a&&a.confidence>=N.profileField&&a.choice in Ge;return{id:n.id,field:i?a.choice:null}})}}async function Xa(e){const t=za(e);if(t.length===0)return{optionPicks:[],fieldKinds:[]};const n=await C({input:Ga,questions:t,promptCacheKey:"filler-field-decisions"});return Qa(e,n)}const Za={type:"object",additionalProperties:!1,required:["postingLanguages","requirements","keywords","contact"],properties:{postingLanguages:{type:"array",items:{type:"string"}},requirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...Se,null]}}}},keywords:Fe,contact:{type:["string","null"]}}},ei=`You read a job posting and report three independent things about it: its
language, the skills it asks for (keywords), and (only if asked below) a recruiter/hiring
contact. Judge language and keywords against the applicant profile/CV/Personal Legend given
below.

LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- requirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or
  "Native" for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent",
  "professional working proficiency" -> "C1"; "conversational" -> "B1". If a language is
  mentioned but no level can be reasonably inferred, set level to null. Do not invent a
  requirement that isn't stated in the text. If nothing is stated, return an empty array.

${Z("the posting text (job title, description, requirements, responsibilities)")}

CONTACT
- "job.contact" below is the recruiter/hiring contact already found elsewhere, or null if none
  was found yet.
- If it is already set (not null), ignore this entirely and return "contact": null — there is
  nothing to add.
- If it is null, look for one in the job's own text (description/requirements/responsibilities):
  a named recruiter/hiring manager's email address, or a LinkedIn profile/company URL. If you
  find one, copy it VERBATIM (exact characters) so it can be re-found on the page for
  highlighting — the same rule as for keywords. If none is mentioned, return "contact": null.`;async function ti(e){const t=await E(),n=JSON.stringify({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,job:e},null,2),a=await b({schemaName:"job_brief",schema:Za,model:await be(),systemPrompt:ei,userPrompt:n,parse:i=>JSON.parse(i)});return{language:{postingLanguages:a.postingLanguages,requirements:a.requirements},keywords:ee(a.keywords,e),contact:a.contact}}const ni={type:"object",additionalProperties:!1,required:["cvId","reason"],properties:{cvId:{type:"string"},reason:{type:"string"}}},ai=`You pick which of an applicant's CVs to send to one job posting.
Each CV has an id, a name, the language it's written in, the applicant's own rules for which
postings it's for, and the start of its text.
- Prefer a CV written in the posting's language; if none, an English one.
- Then follow the applicant's rules: the CV whose rules fit this posting best.
- Then the one marked default for that language.
Return the chosen CV's exact "id" and a reason of at most 10 words. Plain text, no em dashes.`;async function ii(e,t,n){if(t.length<2)return null;const a=t.map((i,s)=>`cv${s+1}`);try{const i=await C({input:[{role:"user",content:[{type:"input_text",text:"A job posting the applicant is applying to:"},{type:"input_json",data:{position:e.position,company:e.company,location:e.location,language:n??null,techStack:e.techStack,description:e.description.slice(0,4e3)}}]}],questions:[{type:"choice",name:"cv",instructions:"Which of the applicant's CVs should be sent to this posting? Prefer a CV written in the posting's language (else an English one), then the one whose rules fit the posting best, then the one marked default for that language.",choices:t.map((r,l)=>({value:a[l],description:si(r)}))}]}),s=j(i,"cv"),o=s?a.indexOf(s.choice):-1;return!s||o<0||s.confidence<N.cvChoice?null:{cvId:t[o].id,reason:"",source:"ai",confidence:s.confidence}}catch(i){if(i instanceof M)throw i;return console.warn("[Filler] Decisions API failed, choosing the CV via Responses:",i),oi(e,t,n)}}function si(e){var t;return[`Name: ${_e(e)}.`,`Language: ${e.language?Oe(e.language):"not set"}${e.isDefaultForLanguage?" (default CV for that language)":""}.`,(t=e.rules)!=null&&t.trim()?`Applicant's rules for it: ${e.rules.trim()}`:"",`Starts: ${e.text.slice(0,600).replace(/\s+/g," ")}`].filter(Boolean).join(" ")}async function oi(e,t,n){if(t.length<2)return null;const a={posting:{position:e.position,company:e.company,location:e.location,language:n??null,techStack:e.techStack,description:e.description.slice(0,4e3)},cvs:t.map(s=>({id:s.id,name:_e(s),language:s.language?Oe(s.language):null,defaultForLanguage:!!s.isDefaultForLanguage,rules:s.rules??"",textStart:s.text.slice(0,1200)}))},i=await b({schemaName:"cv_choice",schema:ni,model:await Re(),reasoningEffort:"low",systemPrompt:ai,userPrompt:JSON.stringify(a,null,2),parse:s=>JSON.parse(s)});return t.some(s=>s.id===i.cvId)?{cvId:i.cvId,reason:i.reason.replace(/—/g,",").trim()||"AI pick",source:"ai"}:null}const ri={type:"object",additionalProperties:!1,required:["values"],properties:{values:{type:"array",items:{type:"object",additionalProperties:!1,required:["name","value","reason"],properties:{name:{type:"string"},value:{type:"string"},reason:{type:"string"}}}}}},li=`You adapt an applicant's CV template to one specific job posting by
choosing a value for each {{placeholder}} in it.

Each variable comes with:
- "description": the applicant's own instruction for what the placeholder means and
  how to choose it. Follow it.
- "mode": "choice" means "value" MUST be exactly one of "options", copied verbatim
  (same spelling, same case, same line breaks). "free" means "options" are only
  examples of the expected shape and length; write the value that fits this posting
  in that same shape (e.g. a city name, a comma-separated list).
- "foundInPosting": options that literally occur in the posting text, most frequent
  first. A strong hint, not an order: the role's actual focus matters more than a
  passing mention.

Rules:
- Pick what makes this CV the closest honest match for this posting: its title, its
  location, its main technology, the vocabulary it uses.
- A job title / position value is the bare role name: no bracketed asides like (m/w/d),
  (f/m/d) or (Remote), no seniority level (Senior, Middle, Junior, Sr., Staff, Principal),
  no team, location or contract qualifiers. "Senior Backend Engineer (m/f/d)" -> "Backend Engineer".
- Honesty: never make the CV claim a skill, technology or experience the applicant's
  CV text / Personal Legend doesn't support, unless the variable's description
  explicitly asks for it. For list-like values, prefer terms that are both in the
  posting and supported by the applicant's background.
- Write the value in the same language as the surrounding template text.
- Return one entry per variable given, using its exact "name".
- "reason": one short sentence (max ~15 words) on why this value fits the posting.
- Plain text only, no markdown, no em dashes.`;function ci(e,t){const n=i=>i.trim().replace(/\s+/g," ").toLowerCase(),a=n(e);return t.options.find(i=>n(i)===a)??null}async function ui(e,t){const n=new Set(wt(t.content)),a=t.variables.filter(u=>n.has(u.name));if(a.length===0)return[];const i=await E(),s=a.filter(u=>u.mode==="choice"&&u.options.length>=2),o=a.filter(u=>!(u.mode==="choice"&&u.options.length>0)),[r,l]=await Promise.all([s.length>0?di(e,t,s,i):new Map,o.length>0?We(e,t,o,i):new Map]);return a.map(u=>r.get(u.name)??l.get(u.name)??{name:u.name,value:bt(u,e),reason:""})}const pi=`You adapt an applicant's CV template to one specific job posting: for each {{placeholder}}
pick the variant that makes this CV the closest honest match for the posting (its title, its location,
its main technology, the vocabulary it uses). Follow the applicant's own instruction for the placeholder.
Variants that literally occur in the posting are a strong hint, not an order: the role's actual focus
matters more than a passing mention. Never pick a variant that claims a skill, technology or experience
the applicant's CV text / Personal Legend doesn't support, unless the instruction explicitly asks for it.`;async function di(e,t,n,a){const i=o=>`o${o+1}`,s=n.map((o,r)=>{const l=Ce(o.options,e).map(u=>`${i(o.options.indexOf(u))} ("${u}")`);return{type:"choice",name:`v${r}`,instructions:[`CV placeholder {{${o.name}}}. Which variant should fill it for this posting?`,o.description.trim()?`The applicant's instruction for it: ${o.description.trim()}`:"",l.length>0?`Variants found verbatim in the posting, most frequent first: ${l.join(", ")}.`:""].filter(Boolean).join(`
`),choices:o.options.map((u,c)=>({value:i(c),description:u}))}});try{const o=await C({input:[{role:"developer",content:pi},{role:"user",content:[{type:"input_json",data:{applicant:{cvText:a.cvText.slice(0,12e3),personalLegend:a.personalLegend.slice(0,8e3),city:a.profile.city,country:a.profile.country}}},{type:"input_json",data:{job:Ke(e)}}]}],promptCacheKey:`filler-cv-values-${vt(a.cvText+a.personalLegend)}`,questions:s}),r=new Map;return n.forEach((l,u)=>{const c=j(o,`v${u}`),h=c?l.options.findIndex((m,f)=>i(f)===c.choice):-1;!c||h<0||c.confidence<N.cvVariableChoice||r.set(l.name,{name:l.name,value:l.options[h],reason:`AI pick, ${Math.round(c.confidence*100)}% sure`})}),r}catch(o){if(o instanceof M)throw o;return console.warn("[Filler] Decisions API failed, picking CV variants via Responses:",o),We(e,t,n,a)}}function Ke(e){return{position:e.position,company:e.company,location:e.location,techStack:e.techStack,requirements:e.requirements,responsibilities:e.responsibilities,description:e.description.slice(0,8e3)}}async function We(e,t,n,a){const i={variables:n.map(r=>({name:r.name,mode:r.mode,description:r.description,options:r.options,foundInPosting:Ce(r.options,e)})),template:t.content.slice(0,12e3),job:Ke(e),applicant:{cvText:a.cvText.slice(0,12e3),personalLegend:a.personalLegend.slice(0,8e3),city:a.profile.city,country:a.profile.country}},s=await b({schemaName:"cv_template_values",schema:ri,model:await Re(),systemPrompt:li,userPrompt:JSON.stringify(i,null,2),parse:r=>JSON.parse(r)}),o=new Map;for(const r of n){const l=s.values.find(c=>c.name===r.name);if(!l)continue;if(r.mode==="choice"&&r.options.length>0){const c=ci(l.value,r);c&&o.set(r.name,{name:r.name,value:c,reason:k(l.reason)});continue}const u=k(l.value);o.set(r.name,{name:r.name,value:Et(r.name)?ea(u,e):u,reason:k(l.reason)})}return o}async function ze(e){const t=await S(e);await Promise.all(t.map(n=>chrome.tabs.sendMessage(e,{type:"CANCEL_ELEMENT_PICKER",tabId:e},{frameId:n}).catch(()=>{})))}async function T(e,t,n){return(await Promise.all(t.map(i=>chrome.tabs.sendMessage(e,n,{frameId:i}).catch(()=>{})))).filter(i=>!!i)}async function pe(e,t,n,a){if(n!==void 0&&t.includes(n)){const i=await chrome.tabs.sendMessage(e,a,{frameId:n}).catch(()=>{});if(i)return[i]}return T(e,t,a)}function hi(e){const t=new Map;for(const n of e){const a=n.locator.frameId;t.set(a,[...t.get(a)??[],n])}return t}async function fi(e){switch(e.type){case"FILL_STATS_REPORT":{await Lt(e.run);return}case"DECIDE_FIELDS":return{type:"FIELD_DECISIONS",result:await Xa(e.request)};case"GET_PROFILE":return{type:"PROFILE_DATA",profile:await U()};case"GET_JOB":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});if(!e.force&&(t!=null&&t.url)){const l=await kt(t.url);if(l!=null&&l.position&&l.company)return{type:"JOB_DATA",job:l,sufficient:!0}}const n=await S(e.tabId),i=(await T(e.tabId,n,e)).filter(l=>l.type==="JOB_DATA");if(i.length===0)return;const s=i.find(l=>l.sufficient);if(s)return t!=null&&t.url&&Tt(t.url,s.job),s;const o=i.reduce((l,u)=>u.job.description.length>l.job.description.length?u:l),r=i.map(l=>l.visibleText??"").filter(Boolean).join(`

`).slice(0,2e4);return{type:"JOB_DATA",job:o.job,sufficient:!1,visibleText:r||o.visibleText||"",pageUrl:t==null?void 0:t.url}}case"COMPLETE_JOB":{const{job:t,brief:n}=await oa(e.job,e.text);return{type:"JOB_DATA",job:t,sufficient:!0,brief:n}}case"EXTRACT_JOB_FROM_TEXT":{const t=await chrome.tabs.get(e.tabId).catch(()=>{}),{job:n,brief:a}=await aa(e.text,(t==null?void 0:t.url)??"");return{type:"JOB_DATA",job:n,sufficient:!0,brief:a}}case"AUTOFILL":{const t=await S(e.tabId),a=(await T(e.tabId,t,e)).filter(i=>i.type==="AUTOFILL_RESULT");return{type:"AUTOFILL_RESULT",filled:a.reduce((i,s)=>i+s.filled,0),total:a.reduce((i,s)=>i+s.total,0),generatedPassword:a.map(i=>i.generatedPassword).find(Boolean)??null}}case"GENERATE_COVER_LETTER":{const{tabId:t}=e,n=e.job.url;let a="",i=0;await $(t,{jobUrl:n,status:"generating",content:""});let s;try{s=await Vn(e.job,e.postingLanguage,o=>{chrome.runtime.sendMessage({type:"COVER_LETTER_STREAM_CHUNK",tabId:t,delta:o}).catch(()=>{}),a+=o,Date.now()-i>400&&(i=Date.now(),$(t,{jobUrl:n,status:"generating",content:a}).catch(()=>{}))})}catch(o){const r=o instanceof Error?o.message:String(o);throw await $(t,{jobUrl:n,status:"error",content:"",error:r}).catch(()=>{}),o}return await $(t,{jobUrl:n,status:"done",content:s.content,cleanedPatterns:s.cleaned?Array.from(new Set(s.slopFindings.map(o=>o.pattern))):[]}),await J("lastCoverLetter",s.content),{type:"COVER_LETTER_RESULT",content:s.content,slopFindings:s.slopFindings,cleaned:s.cleaned}}case"UPLOAD_FILE":{const t=await S(e.tabId),a=(e.targetLocator?await pe(e.tabId,t,e.targetLocator.frameId,e):await T(e.tabId,t,e)).filter(i=>i.type==="UPLOAD_FILE_RESULT");return{type:"UPLOAD_FILE_RESULT",nativeInputs:a.reduce((i,s)=>i+s.nativeInputs,0),dropZones:a.reduce((i,s)=>i+s.dropZones,0)}}case"REVISE_COVER_LETTER":{const t=await la(e.content,e.instructions,e.job);return await J("lastCoverLetter",t),{type:"REVISE_COVER_LETTER_RESULT",content:t}}case"TRANSLATE_COVER_LETTER":return{type:"TRANSLATE_COVER_LETTER_RESULT",content:await da(e.content,e.targetLanguage)};case"GENERATE_OUTREACH_MESSAGE":{const t=await E(),n=await Jn({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,outreachRules:t.outreachRules,job:e.job,contact:e.contact,postingLanguage:e.postingLanguage});return{type:"OUTREACH_MESSAGE_RESULT",subject:n.subject,body:n.body}}case"REVISE_OUTREACH_MESSAGE":{const t=await ua({subject:e.subject,body:e.body},e.instructions,e.job);return{type:"OUTREACH_MESSAGE_RESULT",subject:t.subject,body:t.body}}case"GET_FRAME_ACCESS":return{type:"FRAME_ACCESS",blockedOrigins:await Ct(e.tabId)};case"DETECT_CUSTOM_QUESTIONS":{const t=await S(e.tabId),n=await T(e.tabId,t,e),a=new Set,i=[];for(const s of n)if(s.type==="CUSTOM_QUESTIONS_DATA")for(const o of s.questions)a.has(o.question)||(a.add(o.question),i.push({...o,id:`question-${i.length}`}));return{type:"CUSTOM_QUESTIONS_DATA",questions:i}}case"ANSWER_CUSTOM_QUESTION":{const t=await Ma(e.question,e.job,e.options,e.numeric,e.dateKind,e.multi,e.postingLanguage,e.catchAll);return{type:"CUSTOM_QUESTION_ANSWER",question:e.question,answer:t.answer,sufficientInfo:t.sufficientInfo}}case"FILL_CUSTOM_QUESTION_ANSWERS":{const t=await S(e.tabId),n=await T(e.tabId,t,e);let a=0;const i=[];for(const s of n)s.type==="CUSTOM_QUESTION_FILL_RESULT"&&(a+=s.filled,i.push(...s.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:a,unfilled:i}}case"START_ELEMENT_PICKER":{const t=await S(e.tabId),n=t.map(i=>chrome.tabs.sendMessage(e.tabId,e,{frameId:i}).then(s=>s?{result:s,frameId:i}:void 0).catch(()=>{})),a=await new Promise(i=>{let s=n.length;s===0&&i(void 0);for(const o of n)o.then(r=>{s-=1,r?i(r):s===0&&i(void 0)})});return await Promise.all(t.map(i=>chrome.tabs.sendMessage(e.tabId,{type:"CANCEL_ELEMENT_PICKER",tabId:e.tabId},{frameId:i}).catch(()=>{}))),a?{...a.result,picked:a.result.picked.map(i=>({...i,locator:{...i.locator,frameId:a.frameId}}))}:{type:"ELEMENT_PICKER_RESULT",cancelled:!0,picked:[],blockText:"",semanticCount:0}}case"CANCEL_ELEMENT_PICKER":{await ze(e.tabId);return}case"DECOMPOSE_BLOCK":return{type:"BLOCK_QUESTIONS",questions:await Ua(e.blockText,e.fields)};case"FILL_QUESTION_ANSWERS_BY_LOCATOR":{const t=await S(e.tabId),n=(await Promise.all([...hi(e.items)].map(([s,o])=>pe(e.tabId,t,s,{...e,items:o})))).flat();let a=0;const i=[];for(const s of n)s.type==="CUSTOM_QUESTION_FILL_RESULT"&&(a+=s.filled,i.push(...s.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:a,unfilled:i}}case"DETECT_CHECKBOXES":{const t=await S(e.tabId),n=await T(e.tabId,t,e),a=new Set,i=[];for(const s of n)if(s.type==="CHECKBOXES_DATA")for(const o of s.checkboxes){const r=o.name||o.label;!r||a.has(r)||(a.add(r),i.push({...o,id:`checkbox-${i.length}`}))}return{type:"CHECKBOXES_DATA",checkboxes:i}}case"DECIDE_PAGE_CONTENT":{const{checkboxDecisions:t,questionAnswers:n}=await Ha(e.checkboxes,e.questions,e.job,e.postingLanguage);return{type:"PAGE_CONTENT_DECISIONS",checkboxDecisions:t,questionAnswers:n}}case"APPLY_CHECKBOX_DECISIONS":{const t=await S(e.tabId),n=await T(e.tabId,t,e);let a=0;for(const i of n)i.type==="CHECKBOX_APPLY_RESULT"&&(a+=i.changed);return{type:"CHECKBOX_APPLY_RESULT",changed:a}}case"DETECT_JOB_BRIEF":{const t=await ti(e.job);return{type:"JOB_BRIEF_DATA",language:t.language,keywords:t.keywords,contact:t.contact}}case"HIGHLIGHT_KEYWORDS":{const t=await S(e.tabId);return{type:"KEYWORD_HIGHLIGHT_RESULT",matched:(await T(e.tabId,t,e)).reduce((i,s)=>s.type==="KEYWORD_HIGHLIGHT_RESULT"?i+s.matched:i,0)}}case"CLEAR_KEYWORD_HIGHLIGHTS":{const t=await S(e.tabId);await T(e.tabId,t,e);return}case"GENERATE_FAQ_ANSWERS":{const t=await ge(),n=await Vt(e.questions,t);try{await St(n)}catch{}return{type:"FAQ_ANSWERS_RESULT",entries:n}}case"SEARCH_JOBS":{const{searchId:t}=e,n=t?i=>{chrome.runtime.sendMessage({type:"JOB_SEARCH_PROGRESS",searchId:t,results:i}).catch(()=>{})}:void 0,a=setInterval(()=>void chrome.runtime.getPlatformInfo().catch(()=>{}),2e4);try{return{type:"JOB_SEARCH_RESULTS",...await Tn(e.query,{page:e.page,excludeResults:e.excludeResults,onResults:n})}}finally{clearInterval(a)}}case"SUGGEST_SEARCH_QUERY":{const{what:t,where:n,tags:a}=await $e(e.provider==="adzuna");return{type:"SEARCH_QUERY_SUGGESTION",what:t,where:n,...e.provider==="adzuna"?{tags:a}:{}}}case"SUGGEST_CV_VALUES":return{type:"CV_VALUES",values:await ui(e.job,e.template)};case"CHOOSE_CV":return{type:"CV_CHOICE",choice:await ii(e.job,e.cvs,e.postingLanguage)};default:return}}const gi="src/sidepanel/index.html";chrome.runtime.onInstalled.addListener(()=>{Mt(),chrome.sidePanel.setOptions({enabled:!1})});chrome.contextMenus.onClicked.addListener((e,t)=>{jt(e,t)});chrome.action.onClicked.addListener(e=>{if(e.id===void 0)return;const t=e.id;chrome.sidePanel.setOptions({tabId:t,path:`${gi}?tabId=${t}`,enabled:!0}),chrome.sidePanel.open({tabId:t}).catch(n=>console.error("sidePanel.open failed",n)),mi(t)});async function mi(e){await S(e);const t={type:"TAB_ACCESS_GRANTED",tabId:e};await chrome.runtime.sendMessage(t).catch(()=>{})}chrome.tabs.onRemoved.addListener(e=>{It(e)});chrome.runtime.onMessage.addListener((e,t,n)=>(fi(e).then(n).catch(a=>{n({type:"ERROR",error:a instanceof Error?a.message:String(a),code:a instanceof Error?a.name:void 0})}),!0));chrome.runtime.onConnect.addListener(e=>{const t=/^picker-(\d+)$/.exec(e.name);if(!t)return;const n=Number(t[1]);e.onDisconnect.addListener(()=>{ze(n)})});
