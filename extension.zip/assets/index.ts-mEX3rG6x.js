import{P as K,g as j,a as U,b as Q,c as z,s as W,d as T,e as $,f as X,h as Z,i as ee,j as F,r as d,k as te,l as ne,m as Y,n as ae,o as se,p as D,t as oe,D as re,C as ie,q as H,u as ce,v as le,w as k,x as pe,y as C,z as ue,A as O,B as de,E as R,F as he}from"./markdown-CBdGxCXG.js";import{c as ge,a as fe}from"./phone-CZ16BBLi.js";const B={...K,cv:"CV",coverLetter:"Cover Letter",generatePassword:"Generated password"},me=Object.keys(B);async function h(e){try{const t=(await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:["content-script.js"]})).map(a=>a.frameId).filter(a=>typeof a=="number");if(t.length>0)return t}catch{}try{return await chrome.scripting.executeScript({target:{tabId:e},files:["content-script.js"]}),[0]}catch{return[0]}}async function ye(e,s){if(e==="cv"){const n=await j();return(n==null?void 0:n.text)??""}if(e==="coverLetter")return await U("lastCoverLetter")??"";if(e==="generatePassword"){const n=await Q(s);if(n!=null&&n.generatedPassword)return n.generatedPassword;const o=z();return n&&await W(s,{...n,generatedPassword:o}),o}const t=await T(),a=t[e]??"";return e==="phone"&&a?ge(a,t.country):a}const E="job-app-assistant-insert",we={generatePassword:"Generate password"},be=me.map(e=>({id:e,title:we[e]??B[e]}));function ve(){chrome.contextMenus.removeAll(()=>{chrome.contextMenus.create({id:E,title:"Insert",contexts:["editable"]});for(const e of be)chrome.contextMenus.create({id:`${E}:${e.id}`,parentId:E,title:e.title,contexts:["editable"]})})}function Ee(e){return e.startsWith(`${E}:`)?e.slice(E.length+1):null}async function Se(e,s){if(!(s!=null&&s.id)||typeof e.menuItemId!="string")return;const t=Ee(e.menuItemId);if(!t)return;const a=await ye(t,s.id);await h(s.id);const n={type:"INSERT_VALUE",field:t,value:a};chrome.tabs.sendMessage(s.id,n,{frameId:e.frameId}).catch(()=>{})}const Te=new Set(["profileCache","cvLibraryCache","legendLibraryCache","customFieldsCache","languageLevelsCache","faqAnswersCache","generationRulesCache"]);let w=null;function _e(){return Promise.all([T(),j(),$(),X(),Z(),ee(),F()]).then(([e,s,t,a,n,o,r])=>({profile:e,cvText:(s==null?void 0:s.text)??"",personalLegend:(t==null?void 0:t.content)??"",generationRules:(a==null?void 0:a.content)??"",languageLevels:n,customFields:o,faq:r}))}function m(){return w||(w=_e(),w.catch(()=>{w=null})),w}var M;typeof chrome<"u"&&((M=chrome.storage)!=null&&M.onChanged)&&chrome.storage.onChanged.addListener((e,s)=>{s==="local"&&Object.keys(e).some(t=>Te.has(t))&&(w=null)});const S=`Write like a specific person, not an AI assistant. These rules have no exceptions:

- NEVER use an em dash ("—"), a spaced en dash ("–") or "--" as punctuation. Real people don't write that way. Use a comma, a period, parentheses, or two sentences.
- Banned words: delve, foster, leverage, utilize, facilitate, empower, streamline, robust, cutting-edge, paradigm shift, game changer, tapestry, realm, beacon, multifaceted, meticulous, intricate, paramount, transformative, elevate, embark, supercharge, harness, ever-evolving. Say the plain thing.
- Cut empty phrases: "it's worth noting", "at the end of the day", "when it comes to", "at its core", "in today's world", "the reality is", "in order to", "going forward".
- No "not X, it's Y" / "the question isn't X, it's Y" / "not just X but Y" contrasts. State Y directly.
- No throat-clearing openers ("Here's the thing", "Let me be clear", "I'll be honest") and no faux-insight setups ("what most people get wrong", "here's what nobody tells you").
- No importance puffery ("stands as a testament", "marks a pivotal moment", "plays a vital role", "underscores its significance"). State the fact and stop.
- No colon reveals: a noun phrase, a colon, then a dramatic lowercase clause.
- No trailing "-ing" clauses that editorialize ("highlighting the commitment to...", "underscoring its importance", "showcasing", "reflecting"). End the sentence.
- No metadiscourse that tells the reader what to notice ("this matters", "this distinction matters", "in other words", "as you can see").
- No "In conclusion" / "Ultimately" / "Overall" recap ending and no cute one-line kicker. Stop on the last concrete point.
- No emoji, no mid-sentence bold, no rhetorical questions.
- Vary sentence shape; don't stack short punchy fragments.
- Be concrete: name the technology, project, number, or outcome instead of calling it "significant", "impactful" or "exciting". Use active voice.`;function f(e){return e.replace(/[ \t]*[—―][ \t]*/g,", ").replace(/[ \t]+--[ \t]+/g,", ").replace(/(\D)[ \t]+–[ \t]+(?=\D)/g,"$1, ").replace(/[ \t]+([,.;:!?])/g,"$1").replace(/,(\s*[.;:!?])/g,"$1").replace(/,[ \t]*,/g,",").replace(/^[ \t]*,[ \t]*/gm,"").replace(/([([{])[ \t]*,[ \t]*/g,"$1").replace(/[ \t]*,[ \t]*([)\]}])/g,"$1").replace(/,[ \t]*$/gm,"").replace(/[ \t]+$/gm,"")}const Le=`You write the applicant's own answers to standard interview-FAQ
questions (spec_5 section B) — general-purpose answers meant to be reused, as-is or
lightly adapted, whenever a real application form asks a close variant of one of them.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend, and
  custom fields. Never invent experience, technologies, companies, education,
  achievements, or a concrete salary figure that wasn't actually given.
- If information needed for a good answer is missing (no CV, no Personal Legend
  content covering it), write a short, honest, generically true answer rather
  than fabricating specifics — the applicant can always sharpen it later.
- Keep each answer 2-5 sentences: concrete and confident, never generic
  corporate filler, no restating the question.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text per answer, no markdown, no numbering.

${S}`;function Ie(e){return{type:"object",additionalProperties:!1,required:["answers"],properties:{answers:{type:"array",minItems:e,maxItems:e,items:{type:"string"}}}}}async function Pe(e){if(e.length===0)return[];const{profile:s,cvText:t,personalLegend:a,generationRules:n,customFields:o}=await m(),r=JSON.stringify({profile:s,cvText:t,personalLegend:a,generationRules:n,customFields:o,questions:e},null,2),i=await d({schemaName:"faq_answers",schema:Ie(e.length),systemPrompt:Le,userPrompt:r,parse:c=>JSON.parse(c)});return e.map((c,l)=>({question:c,answer:f(i.answers[l]??"")}))}async function ke(e,s){const t=new Map(s.map(o=>[o.question,o.answer])),a=e.filter(o=>{var r;return!((r=t.get(o))!=null&&r.trim())}),n=await Pe(a);for(const o of n)t.set(o.question,o.answer);return e.map(o=>({question:o,answer:t.get(o)??""}))}async function b(e,s,t){const a=performance.now();try{return await t()}finally{e==null||e.push({label:s,ms:performance.now()-a})}}const Ce={type:"object",additionalProperties:!1,required:["jobs"],properties:{jobs:{type:"array",items:{type:"object",additionalProperties:!1,required:["title","company","location","url","salary","snippet"],properties:{title:{type:"string"},company:{type:"string"},location:{type:"string"},url:{type:"string"},salary:{type:"string"},snippet:{type:"string"}}}}}},Oe=`You turn raw web-search results about job openings into a clean,
structured list. The input text was produced by a live internet search and may include
citations, markdown links, or unrelated surrounding prose — extract only genuine
individual job postings from it.

Rules:
- Only include entries that are clearly actual job postings with a real listing URL —
  never a company's generic careers-page homepage, a search-results page, or an
  aggregator's category page.
- "url" must be copied exactly from the source text (never invented).
- "salary" is "" when no figure was given — never guess one.
- "snippet" is a 1-2 sentence summary of the role; when a "candidate" background is given
  below, make it say *why this posting fits them* specifically (seniority match, matching
  skills, location/remote fit) rather than just restating the posting.
- If a "candidate" background is given, drop postings that are a poor fit for them (wrong
  seniority, unrelated field) even if they're genuine job postings — only surface ones
  actually worth their time.
- Deduplicate: the same posting linked twice becomes one entry.
- If nothing in the text is actually a job posting, return an empty "jobs" array.`;async function J(e,s,t){const a=t?`candidate:
${t}

---

${e.slice(0,4e4)}`:e.slice(0,4e4);return(await d({schemaName:"job_listings",schema:Ce,systemPrompt:Oe,userPrompt:a,parse:o=>JSON.parse(o)})).jobs.filter(o=>o.url.trim()).map(o=>({...o,source:s}))}function V(e){return e.length===0?"":`

Already found and shown to the applicant — do NOT return any of these again,
find genuinely different postings instead:
${e.map(t=>`- ${t.title} at ${t.company} (${t.url})`).join(`
`)}`}async function Re(e,s,t=[],a){const n=e.remoteOnly?" Prefer remote-friendly roles.":"",o=[e.what?`Role/keywords focus: "${e.what}".`:"",e.where?`Location: "${e.where}".`:"",n].filter(Boolean).join(" "),r=`Search the web for current, actually open job postings that fit this
candidate:

${s||"(no candidate background available)"}

${o||"No further constraints — use the candidate's own background to pick a fitting role/location."}

Find real postings (company career pages, LinkedIn, job boards) with their direct
listing URL, not a search results page. List up to 15 of the best matches, each with
its title, company, location, salary if stated, and a short description of why it fits.${V(t)}`,i=await b(a,"Web search",()=>te(r));return b(a,"Parse results",()=>J(i,"openai",s))}const Ae="https://api.tavily.com/search",Ne=2e3;async function xe(e,s,t,a=[],n){const o=e.remoteOnly?" Prefer remote-friendly roles.":"",i=`Find current, open job postings that fit this candidate.
${[e.what?`Role/keywords focus: "${e.what}".`:"",e.where?`Location: "${e.where}".`:"",o].filter(Boolean).join(" ")}

Candidate background: ${t||"(none available)"}${V(a)}`.trim().slice(0,Ne),c=await b(n,"Tavily search",()=>fetch(Ae,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({api_key:s,query:i,search_depth:"advanced",max_results:15,include_answer:!1})}));if(!c.ok){const p=await c.text().catch(()=>"");throw new Error(`Tavily search failed (${c.status}): ${p.slice(0,300)}`)}const l=await c.json();if(l.results.length===0)return[];const u=l.results.map(p=>`Title: ${p.title}
URL: ${p.url}
${p.content}`).join(`

---

`);return b(n,"Parse results",()=>J(u,"tavily",t))}function qe(e,s){return!e&&!s?"":ne({low:Math.round(e??s??0),high:Math.round(s??e??0)})}function Me(e){return new Promise(s=>setTimeout(s,e))}const je=350;async function Ue(e,s,t,a,n){const o=new URL(`https://api.adzuna.com/v1/api/jobs/${a}/search/${n}`);o.searchParams.set("app_id",t.appId),o.searchParams.set("app_key",t.appKey),o.searchParams.set("results_per_page","15"),o.searchParams.set("content-type","application/json"),e&&o.searchParams.set("what",e),s&&o.searchParams.set("where",s);const r=await fetch(o.toString());if(!r.ok){const c=await r.text().catch(()=>"");throw new Error(`Adzuna search failed (${r.status}): ${c.slice(0,300)}`)}return(await r.json()).results.map(c=>{var l,u;return{title:c.title,company:((l=c.company)==null?void 0:l.display_name)??"",location:((u=c.location)==null?void 0:u.display_name)??"",url:c.redirect_url,salary:qe(c.salary_min,c.salary_max),snippet:(c.description??"").slice(0,300),source:"adzuna",tag:e}})}async function $e(e,s,t,a=1){const n=e.tags&&e.tags.length>0?e.tags:[e.what],o=new Set,r=[],i=[];for(let c=0;c<n.length;c++){const l=n[c];try{const u=await Ue(l,e.where,s,t,a);for(const p of u)o.has(p.url)||(o.add(p.url),r.push(p))}catch(u){i.push(`"${l}" — ${u instanceof Error?u.message:"search failed"}`)}c<n.length-1&&await Me(je)}return{results:r,warnings:i}}const Fe=new Set(["AT","AU","BE","BR","CA","CH","DE","ES","FR","GB","IN","IT","MX","NL","NZ","PL","RU","SG","US","ZA"]);function Ye(e){var t;const s=(t=fe(e))==null?void 0:t.toUpperCase();return s&&Fe.has(s)?s.toLowerCase():"us"}const De={type:"object",additionalProperties:!1,required:["what","where"],properties:{what:{type:"string"},where:{type:"string"}}},He=`You suggest a starting job-search query for the applicant described below.
"what" is a short role/keywords phrase (e.g. "senior backend engineer", "product designer") —
their most recent or clearly strongest role from the CV/Personal Legend. Pick ONE single title:
never join multiple roles or technologies with "/", "," or parentheses (e.g. never "Full-Stack
Developer / Backend Engineer (Go, Python, React)") — that reads as a combined AND-match to a
literal keyword search and returns nothing. "where" is a location (city, region, or country) —
their stated city/country if given, else "".
Output only the two fields, no explanation.`;async function L(){const{profile:e,cvText:s,personalLegend:t}=await m(),a=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:s,personalLegend:t},null,2),n=await d({schemaName:"job_search_query_suggestion",schema:De,systemPrompt:He,userPrompt:a,parse:o=>JSON.parse(o)});return{what:n.what,where:n.where||[e.city,e.country].filter(Boolean).join(", ")}}const Be={type:"object",additionalProperties:!1,required:["tags"],properties:{tags:{type:"array",items:{type:"string"}}}},Je=`You generate keyword search tags for Adzuna's job-search API, grounded in
the candidate's real background below. Per Adzuna's own docs
(https://developer.adzuna.com/docs/search), "what" is a single literal keyword/phrase match, not
a semantic search and not a boolean query — so ONE combined tag naming several technologies or
role variants (e.g. "Full-Stack Developer / Backend Engineer (Go, Python, React)") matches
nothing. You compensate by generating a small cross-product of short, atomic tags instead, each
run as its own separate search and merged afterwards.

Method — build the tags as a cross-product, exactly like this worked example for a candidate
whose strongest stack is Go and who also does full-stack/backend work:
  golang developer, go developer, go engineer, golang engineer,
  backend engineer, backend developer, fullstack engineer, fullstack developer,
  software engineer, software developer
That is: {primary technology + its common short aliases} × {developer, engineer}, PLUS
{their role-shape words, e.g. backend / fullstack / frontend / mobile / data — whichever
genuinely apply, without a technology} × {developer, engineer}, PLUS a generic "software
developer" / "software engineer" fallback pair.

Rules:
- Base every tag on their actual, strongest-fitting technology/field from the CV/Personal
  Legend — never invent a technology, role-shape, or seniority they don't have.
- Identify the ONE primary technology (e.g. "Go") plus its common short aliases people actually
  search with (e.g. "Golang") — do not alias unrelated technologies together.
- Each tag pairs exactly one technology-or-role-shape word with exactly one of "developer" /
  "engineer" (add "programmer" only if that's a genuinely common term for that stack). Never put
  two technologies, or a technology and a role-shape, in the same tag.
- If the CV shows a clear secondary technology/stack, budget permitting, add its own couple of
  tags the same way — still never combined with the primary one in a single tag.
- For EACH language listed in "languages" below (skip English), also include ONE of the
  strongest-technology tags translated into that language using the natural job-title term a
  native speaker would search with (not a literal word-for-word translation).
- Each tag is 1-3 words, lowercase, and never contains "/", ",", "(", ")", or a seniority
  qualifier ("senior", "junior", etc.).
- Deduplicate. Return 6-12 tags total, most relevant first.
- Output only the tags, no explanation.`;async function A(){const{profile:e,cvText:s,personalLegend:t,languageLevels:a}=await m(),n=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:s,personalLegend:t,languages:a.map(r=>r.language)},null,2);return(await d({schemaName:"job_search_tags",schema:Be,systemPrompt:Je,userPrompt:n,parse:r=>JSON.parse(r)})).tags.map(r=>r.trim()).filter(Boolean)}const Ve={type:"object",additionalProperties:!1,required:["keyRequirements","relevantExperienceHints","suggestedTone","suggestedFocus"],properties:{keyRequirements:{type:"array",items:{type:"string"}},relevantExperienceHints:{type:"array",items:{type:"string"}},suggestedTone:{type:"string"},suggestedFocus:{type:"string"}}};async function Ge(e){return d({schemaName:"job_analysis",schema:Ve,model:await Y(),systemPrompt:"You analyze job postings for a job-application assistant. Identify the most important requirements and what an applicant should emphasize. Do not invent details that are not present in the posting.",userPrompt:JSON.stringify(e,null,2),parse:s=>JSON.parse(s)})}const Ke=`You write tailored cover letters for job applications.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, and Personal Legend.
- Never invent experience, technologies, companies, education, or achievements.
- If information needed to be compelling is missing, write around it honestly
  rather than fabricating it.
- Tailor tone and emphasis to the job analysis provided.
- If "postingLanguage" is given, write the entire letter in that language,
  using the salutation, register, and closing conventions native speakers of
  it would expect on a job application (e.g. formal "Sie"/"Herr"/"Frau"
  address and a "Sehr geehrte(r) ..." opening in German, not a literal
  English-to-German translation) — unless "generationRules" explicitly asks
  for a different language.
- If "generationRules" contains applicant-specified instructions for how to
  write this letter (tone, length, structure, things to include/avoid),
  follow them as long as they don't conflict with the Ground rules above.
- Output plain prose paragraphs, no markdown headers.

${S}`;async function Qe(e,s){const t=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,generationRules:e.generationRules,job:e.job,analysis:e.analysis,postingLanguage:e.postingLanguage||void 0},null,2),a=await ae(Ke,t,s??(()=>{}));return f(a)}const ze={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},We=`You are a sharp human editor cleaning up a cover letter draft.

Fix ONLY the flagged AI-writing patterns listed below. Make the minimum
effective edit — do not rewrite sentences that were not flagged, do not
change facts, experience, technologies, or claims, and do not add new
content. Replace banned words/clichés with plain, concrete language.
Rewrite "not X, it's Y" contrasts as a direct statement of Y. Cut
throat-clearing openers, weasel attribution, and importance-puffery instead
of softening them. If the ending is a generic summary/recap, end on the
letter's last concrete point instead. Replace every em dash ("—") with a
comma, a period, or parentheses.

Do not introduce any new AI-slop while editing. For reference, the full
house style is:

${S}

Output plain prose paragraphs, no markdown headers.`;async function Xe(e,s){const t=JSON.stringify({draft:e,flaggedPatterns:s.map(n=>`${n.pattern}: "${n.match}"`)},null,2),a=await d({schemaName:"cover_letter_polish",schema:ze,systemPrompt:We,userPrompt:t,parse:n=>JSON.parse(n)});return f(a.content)}const Ze=["delve","foster","leverage","utilize","facilitate","empower","streamline","robust","cutting-edge","paradigm shift","game changer","this is huge","this changes everything","tapestry","realm","beacon","multifaceted","meticulous","intricate","paramount","transformative","elevate","embark","supercharge","harness","ever-evolving"],et=["it's worth noting","it is worth noting","it's important to note","it is important to note","at the end of the day","when it comes to","at its core","in today's world","in the age of","in the world of","the reality is","the truth is","in terms of","with regard to","in order to","going forward"],tt=["here's the thing","here's what i mean","let me be clear","i'll be honest","the uncomfortable truth is"],nt=["this is the part most people skip","what most people get wrong","here's what nobody tells you","the part everyone misses"],at=["stands as a testament","marks a pivotal moment","plays a vital role","solidifies its position","underscores its significance"],st=["experts agree","industry reports suggest","many argue","widely regarded as","studies show"],ot=[/^in conclusion\b/i,/^ultimately\b/i,/^overall\b/i];function rt(e){const s=e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`\\b${s.replace(/ /g,"\\s+")}\\b`,"i")}function y(e,s,t){const a=[];for(const n of s){const o=rt(n).exec(e);o&&a.push({pattern:t,match:o[0]})}return a}function it(e){const s=/\b(?:isn'?t|is not)\b[^.!?]{3,60}[,.]?\s*(?:it'?s|it is)\b[^.!?]{3,80}[.!?]/i,t=/\bnot just\b[^.!?]{3,60}(?:\bbut\b|[,.]?\s*(?:it'?s|it is)\b)[^.!?]{0,80}[.!?]/i,a=[],n=s.exec(e);n&&a.push({pattern:"binary-contrast",match:n[0].trim()});const o=t.exec(e);return o&&a.push({pattern:"binary-contrast",match:o[0].trim()}),a}function ct(e){const s=e.split(/\n{2,}/).map(a=>a.trim()).filter(Boolean),t=s[s.length-1];if(!t)return[];for(const a of ot)if(a.test(t))return[{pattern:"summary-recap-ending",match:t.slice(0,60)}];return[]}function lt(e){const s=(e.match(/—/g)??[]).length;return s===0?[]:[{pattern:"em-dash",match:s===1?"1 em dash":`${s} em dashes`}]}function pt(e){return[...y(e,Ze,"banned-word"),...y(e,et,"empty-phrase"),...y(e,tt,"throat-clearing-opener"),...y(e,nt,"faux-insight-setup"),...y(e,at,"importance-puffery"),...y(e,st,"weasel-attribution"),...it(e),...ct(e),...lt(e)]}async function ut(e,s,t){const a=await m(),n=await Ge(e),o=await Qe({profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,generationRules:a.generationRules,job:e,analysis:n,postingLanguage:s},t),r=pt(o);return r.length===0?{content:o,slopFindings:r,cleaned:!1}:{content:await Xe(o,r),slopFindings:r,cleaned:!0}}const dt={type:"object",additionalProperties:!1,required:["company","position","location","description","requirements","responsibilities","salary","techStack","contact"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},description:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]}}};async function N(e,s){return{...await d({schemaName:"job_extraction",schema:dt,model:await se(),systemPrompt:"Extract structured job posting fields from the visible page text below. Only use information present in the text; leave fields empty/null if unknown.",userPrompt:e.slice(0,12e3),parse:a=>JSON.parse(a)}),url:s}}const ht={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},gt=`You are editing an existing cover letter draft on the applicant's
instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the
  letter the instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements
  that aren't already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the
  instruction explicitly asks to change it.
- Output plain prose paragraphs, no markdown headers.
- Don't introduce AI-slop while editing, and clean it from any sentence you
  touch.

${S}`;async function ft(e,s,t){const a=JSON.stringify({draft:e,instructions:s,job:t},null,2),n=await d({schemaName:"cover_letter_revision",schema:ht,model:await D(),systemPrompt:gt,userPrompt:a,parse:o=>JSON.parse(o)});return f(n.content)}const mt={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},yt=`You translate a cover letter for the applicant's own understanding —
not for submission. Translate faithfully, preserve paragraph breaks, and keep
names, companies, and technical terms as-is where translating them would be
unnatural. Do not use em dashes ("—"); use commas or periods. Output plain
prose paragraphs, no markdown headers, no notes about the translation itself.`;async function wt(e,s){const t=JSON.stringify({content:e,targetLanguage:s},null,2),a=await d({schemaName:"cover_letter_translation",schema:mt,systemPrompt:yt,userPrompt:t,parse:n=>JSON.parse(n)});return f(a.content)}const bt={type:"object",additionalProperties:!1,required:["answer","sufficientInfo"],properties:{answer:{type:"string"},sufficientInfo:{type:"boolean"}}},x=`You answer a custom question from a job application form on the
applicant's behalf.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend,
  cover letter, custom fields, language levels, and job posting. Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, the
  "languageLevels" list is the authoritative answer (CEFR levels the
  applicant self-reported in Settings) — use it directly rather than
  guessing from the CV or defaulting to a low/neutral level.
- If the profile/CV/Personal Legend/etc genuinely lack what's needed to
  answer this question — not just a minor detail, but the actual substance
  being asked for — set "sufficientInfo" to false and "answer" to an empty
  string. Do NOT write a sentence explaining that you don't have the
  information (e.g. "I don't have this information available") — that text
  would otherwise get typed straight into the applicant's form field, which
  is worse than leaving it blank for the applicant to fill in themselves.
  Only do this when the information is truly absent; a question you can
  answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient —
  set sufficientInfo to true and give that honest answer.
- If "postingLanguage" is given, write the answer in that language, using
  the salutation/register conventions native speakers of it would expect on
  a job application (e.g. formal "Sie"/"Herr"/"Frau" address in German, not
  a literal English-to-German translation) — unless the question itself, or
  "generationRules", explicitly asks for a different language.
- If this question is a newsletter, marketing-email, or job-alert
  subscription opt-in phrased as a choice (e.g. "Would you like to
  subscribe to our newsletter? Yes/No"), always choose the option that
  declines it — the applicant never needs this to submit the application.
- "faq" is a set of pre-written answers to standard interview-FAQ questions
  (spec_5 section B). If the question being asked now is the same as, or a
  close variant of, one already in "faq", reuse its substance and phrasing —
  adapt only what the target field's length/format actually requires — so
  the applicant's answer stays consistent across different forms rather
  than being re-derived from scratch each time.
- Match the question's expected length: a short field gets a short answer, an
  open-ended "tell us about..." field gets a fuller one.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text, no markdown, no restating the question.

${S}`,vt=/\b(?:please\s+(?:provide|specify|clarify)|could\s+you\s+(?:please\s+)?(?:provide|clarify|specify)|i\s+(?:don'?t|do\s+not)\s+see)\b.{0,40}?\b(?:question|prompt)\b|\bno\s+(?:specific\s+)?question\s+(?:was|is)?\s*(?:provided|given|specified|attached)\b/i;function Et(e){const s=e.trim();return s?s.length<220&&vt.test(s):!0}const St=`
- This is a MULTIPLE-CHOICE question: "options" lists the allowed answers.
  Reply with EXACTLY ONE option, copied verbatim, and nothing else.
- Base the choice on the applicant's profile/CV/Personal Legend. If the
  needed fact is genuinely absent (e.g. pronouns not stated anywhere),
  prefer a neutral option, an explicit "prefer not to say", or the option
  that commits the applicant least.`,Tt=`
- This is a SELECT-ALL-THAT-APPLY question: "options" lists every allowed
  answer. Reply with every option that genuinely applies, each copied
  verbatim, joined by " | " (a single pipe surrounded by one space on each
  side) — nothing else. If none apply, reply with an empty string.
- Base each choice strictly on the applicant's profile/CV/Personal Legend —
  never include an option just because it's plausible or common; only ones
  the applicant's own material actually supports.`,_t=`
- This field only accepts a plain number: reply with digits only (a single
  "." for a decimal if needed) — no currency symbol, no thousands
  separator, no unit, no words, no range. If a range genuinely fits best
  (e.g. a salary expectation given as "65-75k"), reply with one
  representative figure (its midpoint), not the range.`;function Lt(e){return`
- This field only accepts a date in the exact format "${re[e]}"
  — reply with ONLY that value, nothing else (no words, no explanation).
  "todayISO" in the data below is today's date: compute the answer from it
  — e.g. "available with one month's notice" → todayISO plus one month;
  "immediately" / "as soon as possible" / no stated constraint → todayISO
  itself. Never answer with a description of the notice period or
  availability instead of the date itself.`}async function It(e,s,t,a,n,o,r){const[i,c]=await Promise.all([m(),U("lastCoverLetter")]),l=JSON.stringify({job:s,profile:i.profile,cvText:i.cvText,personalLegend:i.personalLegend,generationRules:i.generationRules,coverLetter:c??"",languageLevels:i.languageLevels,customFields:i.customFields,faq:i.faq.filter(v=>v.answer.trim()),todayISO:oe(),postingLanguage:r||void 0,question:e,options:t&&t.length>0?t:void 0},null,2),u=[t&&t.length>0?o?Tt:St:"",a?_t:"",n?Lt(n):""].filter(Boolean),p=await d({schemaName:"custom_question_answer",schema:bt,systemPrompt:u.length>0?[x,...u].join(`
`):x,userPrompt:l,parse:v=>JSON.parse(v)});return!p.sufficientInfo||Et(p.answer)?{answer:"",sufficientInfo:p.sufficientInfo}:{answer:t&&t.length>0||a||!!n?p.answer:f(p.answer),sufficientInfo:!0}}const Pt={type:"object",additionalProperties:!1,required:["questions"],properties:{questions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","question"],properties:{index:{type:"integer"},question:{type:"string"}}}}}},kt=`You are given a block of a job-application form: its visible text, and a
list of the input fields inside it. For each field that asks the applicant
something, return the question it is asking, phrased as a plain question.

Rules:
- Use ONLY the visible text provided. Never invent a question.
- Match each question to its field by "index".
- Omit a field that is not a real question (layout helper, hidden field,
  search box, honeypot, a plain "First name"-style profile field).
- A field with "options" is a multiple-choice question — still return only
  its question text, not the options.
- Output the question text only — no numbering, no "Question:" prefix.
- Questions may be in any language; keep the form's own language.`;async function Ct(e,s){if(s.length===0)return{};const t=JSON.stringify({blockText:e.slice(0,6e3),fields:s},null,2),a=await d({schemaName:"block_questions",schema:Pt,systemPrompt:kt,userPrompt:t,parse:o=>JSON.parse(o)}),n={};for(const o of a.questions)o.question.trim()&&(n[o.index]=o.question.trim());return n}const Ot=/newsletter|marketing|subscribe|promotion|job\s*alert|career\s*news|werbung|benachrichtigung|abonnier|stellenausschreibung/i;function q(e){return Ot.test(e)}const Rt={type:"object",additionalProperties:!1,required:["decisions"],properties:{decisions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","check","category","reason"],properties:{index:{type:"integer"},check:{type:"boolean"},category:{type:"string",enum:["required-consent","marketing","optional","unclear"]},reason:{type:"string"}}}}}},At=`You decide, for each checkbox on a job-application form, whether the
applicant should tick it. The applicant has already chosen to submit this
application.

TICK (check: true) — things required to submit, or that a candidate is
normally expected to accept:
- privacy policy / data protection / GDPR / Datenschutz consent
- terms & conditions / AGB / Nutzungsbedingungen
- confirming the entered information is accurate / truthful
- consent to process and store the application data for THIS hiring process
- storing the data in a talent pool ONLY when the checkbox is marked required
- eligibility self-declarations that hold for any ordinary adult applying
  for a real job (e.g. "I am at least 18 years old", "I am legally
  entitled to work in [country]", "I have no undisclosed conflicts of
  interest") — assume true unless the profile/CV explicitly states
  otherwise; a genuine job applicant submitting this form is virtually
  always eligible, and leaving a required declaration like this unticked
  blocks submission for no real reason

DO NOT TICK (check: false) — optional and promotional:
- newsletters, marketing e-mails, "career news", event invitations
- job alerts / notifications about new postings
  (e.g. "Benachrichtigungen über neue Stellenausschreibungen erhalten")
- sharing data with third parties / partner companies for marketing
- joining a talent pool / candidate database when NOT required
- anything that benefits the applicant only beyond this one application

Rules:
- "required: true" means the form marks the field mandatory — a strong
  signal to tick, unless the text is clearly marketing.
- A newsletter/marketing-email/job-alert opt-in is NEVER ticked, even when
  the form marks it "required" — that flag is routinely misused by forms to
  guilt-trip applicants into subscribing, and applicants never actually need
  it to submit the application. When genuinely in doubt whether a required
  checkbox is a real submission requirement or a disguised newsletter
  opt-in, prefer NOT ticking it.
- If a checkbox is ambiguous AND not required, set check: false.
- Labels may be in any language; judge by meaning, not keywords.
- Return one decision per input item, using its "index".

category: "required-consent" (ticked, mandatory-type), "marketing" (left
off), "optional" (non-marketing but skippable, left off unless required),
"unclear" (left off). reason: one short phrase.`;async function Nt(e){if(e.length===0)return[];const s=JSON.stringify(e.map((n,o)=>({index:o,label:n.label,required:n.required,currentlyChecked:n.checked})),null,2),t=await d({schemaName:"checkbox_decisions",schema:Rt,systemPrompt:At,userPrompt:s,parse:n=>JSON.parse(n)}),a=new Map;for(const n of t.decisions)a.set(n.index,n);return e.map((n,o)=>{const r=a.get(o);if(r){const i=r.check&&q(n.label)?!1:r.check;return{name:n.name,label:n.label,check:i,category:r.category,reason:r.reason}}return q(n.label)?{name:n.name,label:n.label,check:!1,category:"marketing",reason:"No decision returned — looks like a newsletter/marketing opt-in"}:{name:n.name,label:n.label,check:n.required,category:n.required?"required-consent":"unclear",reason:n.required?"Marked required by the form":"No decision returned"}})}const xt={type:"object",additionalProperties:!1,required:["postingLanguages","requirements","keywords"],properties:{postingLanguages:{type:"array",items:{type:"string"}},requirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...ie,null]}}}},keywords:{type:"array",items:{type:"object",additionalProperties:!1,required:["text","matchesProfile"],properties:{text:{type:"string"},matchesProfile:{type:"boolean"}}}}}},qt=`You read a job posting and report two independent things about it: its
language, and its notable keywords. Judge each against the applicant profile/CV/Personal
Legend given below.

LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- requirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or
  "Native" for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent",
  "professional working proficiency" -> "C1"; "conversational" -> "B1". If a language is
  mentioned but no level can be reasonably inferred, set level to null. Do not invent a
  requirement that isn't stated in the text. If nothing is stated, return an empty array.

KEYWORDS
- Pick the notable keywords/key phrases out of the posting — the skills, tools,
  technologies, qualifications, and requirements a candidate would want to notice at a
  glance.
- Every keyword's "text" MUST be copied VERBATIM from the posting text (job title,
  description, requirements, responsibilities) — the exact same characters and casing, not
  a paraphrase, synonym, or translation — because the extension re-finds this exact text on
  the page to highlight it. A keyword that doesn't appear verbatim in the text is useless.
- Prefer short phrases: single words or 2-3 word phrases (e.g. "TypeScript", "Kubernetes",
  "5+ years", "product management", "Bachelor's degree") — not full sentences.
- Pick 8-15 of the most important ones. Skip generic filler ("team player", "fast-paced
  environment") unless the posting has almost nothing more specific.
- No duplicates, and no two keywords where one is a substring of the other (keep the more
  specific/longer one).
- Set "matchesProfile" to true when the applicant's profile/cvText/personalLegend shows they
  already have, use, or meet that skill/tool/technology/qualification — false when the
  posting asks for it but nothing in the applicant's material supports it. Judge substance,
  not exact wording (e.g. "Kubernetes" counts as a match if the CV mentions "container
  orchestration with K8s" or "EKS"). When genuinely unsure, set it to false — this flags a
  possible gap for the applicant to address rather than silently hiding it.`;async function Mt(e){const s=await m(),t=JSON.stringify({profile:s.profile,cvText:s.cvText,personalLegend:s.personalLegend,job:e},null,2),a=await d({schemaName:"job_brief",schema:xt,model:await Y(),systemPrompt:qt,userPrompt:t,parse:n=>JSON.parse(n)});return{language:{postingLanguages:a.postingLanguages,requirements:a.requirements},keywords:a.keywords}}const jt={type:"object",additionalProperties:!1,required:["values"],properties:{values:{type:"array",items:{type:"object",additionalProperties:!1,required:["name","value","reason"],properties:{name:{type:"string"},value:{type:"string"},reason:{type:"string"}}}}}},Ut=`You adapt an applicant's CV template to one specific job posting by
choosing a value for each {{placeholder}} in it.

Each variable comes with:
- "description": the applicant's own instruction for what the placeholder means and
  how to choose it. Follow it.
- "mode": "choice" means "value" MUST be exactly one of "options", copied verbatim
  (same spelling, same case, same line breaks). "free" means "options" are only
  examples of the expected shape and length; write the value that fits this posting
  in that same shape (e.g. a city name, a comma-separated list).
- "foundInPosting": options that literally occur in the posting text, most frequent
  first. A strong hint, not an order: the role's actual focus matters more than a
  passing mention.

Rules:
- Pick what makes this CV the closest honest match for this posting: its title, its
  location, its main technology, the vocabulary it uses.
- Honesty: never make the CV claim a skill, technology or experience the applicant's
  CV text / Personal Legend doesn't support, unless the variable's description
  explicitly asks for it. For list-like values, prefer terms that are both in the
  posting and supported by the applicant's background.
- Write the value in the same language as the surrounding template text.
- Return one entry per variable given, using its exact "name".
- "reason": one short sentence (max ~15 words) on why this value fits the posting.
- Plain text only, no markdown, no em dashes.`;function $t(e,s){const t=n=>n.trim().replace(/\s+/g," ").toLowerCase(),a=t(e);return s.options.find(n=>t(n)===a)??null}async function Ft(e,s){const t=new Set(H(s.content)),a=s.variables.filter(i=>t.has(i.name));if(a.length===0)return[];const n=await m(),o={variables:a.map(i=>({name:i.name,mode:i.mode,description:i.description,options:i.options,foundInPosting:ce(i.options,e)})),template:s.content.slice(0,12e3),job:{position:e.position,company:e.company,location:e.location,techStack:e.techStack,requirements:e.requirements,responsibilities:e.responsibilities,description:e.description.slice(0,8e3)},applicant:{cvText:n.cvText.slice(0,12e3),personalLegend:n.personalLegend.slice(0,8e3),city:n.profile.city,country:n.profile.country}},r=await d({schemaName:"cv_template_values",schema:jt,model:await le(),systemPrompt:Ut,userPrompt:JSON.stringify(o,null,2),parse:i=>JSON.parse(i)});return a.map(i=>{const c=r.values.find(l=>l.name===i.name);if(!c)return{name:i.name,value:k(i,e),reason:""};if(i.mode==="choice"&&i.options.length>0){const l=$t(c.value,i);return l?{name:i.name,value:l,reason:f(c.reason)}:{name:i.name,value:k(i,e),reason:""}}return{name:i.name,value:f(c.value),reason:f(c.reason)}})}const Yt={type:"object",additionalProperties:!1,required:["content","variables"],properties:{content:{type:"string"},variables:{type:"array",items:{type:"object",additionalProperties:!1,required:["name","description","options","mode"],properties:{name:{type:"string"},description:{type:"string"},options:{type:"array",items:{type:"string"}},mode:{type:"string",enum:["choice","free"]}}}}}},Dt=`You turn an applicant's CV (plain text extracted from a PDF, so line
breaks and spacing may be broken) into an adaptable CV template.

Output "content" in exactly this syntax:
${pe}

Rules for "content":
- Keep every fact, date, company, number and wording of the original. Only restore
  structure (headings, bullets, "left || right" for dates/locations) and fix broken
  line wrapping. Do not add, embellish, shorten or reorder content.
- Replace the parts that should change per job posting with {{placeholders}}:
  - {{city}}: the applicant's own location in the header/contacts.
  - {{job_position}}: the headline/target title (e.g. under the name, in the summary).
    Leave past job titles in the experience section as they are unless the applicant
    asks otherwise.
  - {{main_language}}: wherever the CV names the applicant's primary programming
    language in a way that can be swapped for another one they also know (summary,
    headline, skills line).
  - {{keywords}}: a skills/technologies line that should be tuned per posting.
  Add other placeholders only if something clearly varies per application. Use
  snake_case names. Use the same placeholder everywhere the same thing appears.

Rules for "variables" (one per placeholder used in "content"):
- "description": one or two sentences telling a later AI step how to choose the value
  from a job posting.
- "options": realistic variants taken from the CV itself (e.g. the programming
  languages the applicant actually lists; title variants built from roles they have
  held, like "Backend Engineer", "Full-Stack Developer"). First option = what the
  original CV says.
- "mode": "choice" when the value must be one of the options (main_language,
  job_position); "free" when options are only examples (city, keywords).`;async function Ht(e){const s=await d({schemaName:"cv_template",schema:Yt,model:await D(),systemPrompt:Dt,userPrompt:e.slice(0,3e4),parse:a=>JSON.parse(a)}),t=new Set(H(s.content));return{content:s.content,variables:s.variables.filter(a=>t.has(a.name))}}async function G(e){const s=await h(e);await Promise.all(s.map(t=>chrome.tabs.sendMessage(e,{type:"CANCEL_ELEMENT_PICKER",tabId:e},{frameId:t}).catch(()=>{})))}async function g(e,s,t){return(await Promise.all(s.map(n=>chrome.tabs.sendMessage(e,t,{frameId:n}).catch(()=>{})))).filter(n=>!!n)}async function Bt(e){var s;switch(e.type){case"GET_PROFILE":return{type:"PROFILE_DATA",profile:await T()};case"GET_JOB":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});if(!e.force&&(t!=null&&t.url)){const l=await de(t.url);if(l)return{type:"JOB_DATA",job:l,sufficient:!0}}const a=await h(e.tabId),o=(await g(e.tabId,a,e)).filter(l=>l.type==="JOB_DATA");if(o.length===0)return;const r=o.find(l=>l.sufficient);if(r)return t!=null&&t.url&&R(t.url,r.job),r;const i=o.reduce((l,u)=>u.job.description.length>l.job.description.length?u:l),c=o.map(l=>l.visibleText??"").filter(Boolean).join(`

`).slice(0,2e4);try{const l=await N(c||i.visibleText||"",i.job.url);return t!=null&&t.url&&R(t.url,l),{type:"JOB_DATA",job:l,sufficient:!0}}catch{return i}}case"EXTRACT_JOB_FROM_TEXT":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});return{type:"JOB_DATA",job:await N(e.text,(t==null?void 0:t.url)??""),sufficient:!0}}case"AUTOFILL":{const t=await h(e.tabId),n=(await g(e.tabId,t,e)).filter(o=>o.type==="AUTOFILL_RESULT");return{type:"AUTOFILL_RESULT",filled:n.reduce((o,r)=>o+r.filled,0),total:n.reduce((o,r)=>o+r.total,0),generatedPassword:n.map(o=>o.generatedPassword).find(Boolean)??null}}case"GENERATE_COVER_LETTER":{const{tabId:t}=e,a=await ut(e.job,e.postingLanguage,n=>{chrome.runtime.sendMessage({type:"COVER_LETTER_STREAM_CHUNK",tabId:t,delta:n}).catch(()=>{})});return await O("lastCoverLetter",a.content),{type:"COVER_LETTER_RESULT",content:a.content,slopFindings:a.slopFindings,cleaned:a.cleaned}}case"UPLOAD_FILE":{const t=await h(e.tabId),n=(await g(e.tabId,t,e)).filter(o=>o.type==="UPLOAD_FILE_RESULT");return{type:"UPLOAD_FILE_RESULT",nativeInputs:n.reduce((o,r)=>o+r.nativeInputs,0),dropZones:n.reduce((o,r)=>o+r.dropZones,0)}}case"REVISE_COVER_LETTER":{const t=await ft(e.content,e.instructions,e.job);return await O("lastCoverLetter",t),{type:"REVISE_COVER_LETTER_RESULT",content:t}}case"TRANSLATE_COVER_LETTER":return{type:"TRANSLATE_COVER_LETTER_RESULT",content:await wt(e.content,e.targetLanguage)};case"DETECT_CUSTOM_QUESTIONS":{const t=await h(e.tabId),a=await g(e.tabId,t,e),n=new Set,o=[];for(const r of a)if(r.type==="CUSTOM_QUESTIONS_DATA")for(const i of r.questions)n.has(i.question)||(n.add(i.question),o.push({...i,id:`question-${o.length}`}));return{type:"CUSTOM_QUESTIONS_DATA",questions:o}}case"ANSWER_CUSTOM_QUESTION":{const t=await It(e.question,e.job,e.options,e.numeric,e.dateKind,e.multi,e.postingLanguage);return{type:"CUSTOM_QUESTION_ANSWER",question:e.question,answer:t.answer,sufficientInfo:t.sufficientInfo}}case"FILL_CUSTOM_QUESTION_ANSWERS":{const t=await h(e.tabId),a=await g(e.tabId,t,e);let n=0;const o=[];for(const r of a)r.type==="CUSTOM_QUESTION_FILL_RESULT"&&(n+=r.filled,o.push(...r.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:n,unfilled:o}}case"START_ELEMENT_PICKER":{const t=await h(e.tabId),a=t.map(o=>chrome.tabs.sendMessage(e.tabId,e,{frameId:o}).catch(()=>{})),n=await new Promise(o=>{let r=a.length;r===0&&o(void 0);for(const i of a)i.then(c=>{r-=1,c?o(c):r===0&&o(void 0)})});return await Promise.all(t.map(o=>chrome.tabs.sendMessage(e.tabId,{type:"CANCEL_ELEMENT_PICKER",tabId:e.tabId},{frameId:o}).catch(()=>{}))),n??{type:"ELEMENT_PICKER_RESULT",cancelled:!0,picked:[],blockText:"",semanticCount:0}}case"CANCEL_ELEMENT_PICKER":{await G(e.tabId);return}case"DECOMPOSE_BLOCK":return{type:"BLOCK_QUESTIONS",questions:await Ct(e.blockText,e.fields)};case"FILL_QUESTION_ANSWERS_BY_LOCATOR":{const t=await h(e.tabId),a=await g(e.tabId,t,e);let n=0;const o=[];for(const r of a)r.type==="CUSTOM_QUESTION_FILL_RESULT"&&(n+=r.filled,o.push(...r.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:n,unfilled:o}}case"DETECT_CHECKBOXES":{const t=await h(e.tabId),a=await g(e.tabId,t,e),n=new Set,o=[];for(const r of a)if(r.type==="CHECKBOXES_DATA")for(const i of r.checkboxes){const c=i.name||i.label;!c||n.has(c)||(n.add(c),o.push({...i,id:`checkbox-${o.length}`}))}return{type:"CHECKBOXES_DATA",checkboxes:o}}case"DECIDE_CHECKBOXES":return{type:"CHECKBOX_DECISIONS",decisions:await Nt(e.checkboxes)};case"APPLY_CHECKBOX_DECISIONS":{const t=await h(e.tabId),a=await g(e.tabId,t,e);let n=0;for(const o of a)o.type==="CHECKBOX_APPLY_RESULT"&&(n+=o.changed);return{type:"CHECKBOX_APPLY_RESULT",changed:n}}case"DETECT_JOB_BRIEF":{const t=await Mt(e.job);return{type:"JOB_BRIEF_DATA",language:t.language,keywords:t.keywords}}case"HIGHLIGHT_KEYWORDS":{const t=await h(e.tabId);return{type:"KEYWORD_HIGHLIGHT_RESULT",matched:(await g(e.tabId,t,e)).reduce((o,r)=>r.type==="KEYWORD_HIGHLIGHT_RESULT"?o+r.matched:o,0)}}case"CLEAR_KEYWORD_HIGHLIGHTS":{const t=await h(e.tabId);await g(e.tabId,t,e);return}case"GENERATE_FAQ_ANSWERS":{const t=await F(),a=await ke(e.questions,t);try{await ue(a)}catch{}return{type:"FAQ_ANSWERS_RESULT",entries:a}}case"SEARCH_JOBS":{const{provider:t}=e.query,a=performance.now(),n=[],o=()=>({totalMs:performance.now()-a,stages:n});if(t==="adzuna"){const[l,u]=await Promise.all([C(),T()]);if(!l.adzunaAppId||!l.adzunaAppKey)throw new Error("Add your Adzuna app_id and app_key in Settings first.");let p=e.query;if(!((s=p.tags)!=null&&s.length))if(p.what.trim())p={...p,tags:[p.what.trim()]};else{const[_,P]=await b(n,"Suggest tags",()=>Promise.all([L(),A()]));p={...p,what:_.what,where:p.where.trim()||_.where,tags:P.length>0?P:[_.what]}}const{results:I,warnings:v}=await b(n,"Adzuna search",()=>$e(p,{appId:l.adzunaAppId,appKey:l.adzunaAppKey},Ye(u.country),e.page??1));return{type:"JOB_SEARCH_RESULTS",results:I,resolvedQuery:p,warnings:v,...o()}}const r=await $(),i=(r==null?void 0:r.content)??"";if(t==="tavily"){const l=await C();if(!l.tavilyApiKey)throw new Error("Add your Tavily API key in Settings first.");return{type:"JOB_SEARCH_RESULTS",results:await xe(e.query,l.tavilyApiKey,i,e.excludeResults,n),resolvedQuery:e.query,...o()}}return{type:"JOB_SEARCH_RESULTS",results:await Re(e.query,i,e.excludeResults,n),resolvedQuery:e.query,...o()}}case"SUGGEST_SEARCH_QUERY":{if(e.provider==="adzuna"){const[a,n]=await Promise.all([L(),A()]);return{type:"SEARCH_QUERY_SUGGESTION",...a,tags:n}}return{type:"SEARCH_QUERY_SUGGESTION",...await L()}}case"SUGGEST_CV_VALUES":return{type:"CV_VALUES",values:await Ft(e.job,e.template)};case"TEMPLATIZE_CV":return{type:"CV_TEMPLATE_DRAFT",...await Ht(e.cvText)};default:return}}const Jt="src/sidepanel/index.html";chrome.runtime.onInstalled.addListener(()=>{ve(),chrome.sidePanel.setOptions({enabled:!1})});chrome.contextMenus.onClicked.addListener((e,s)=>{Se(e,s)});chrome.action.onClicked.addListener(e=>{if(e.id===void 0)return;const s=e.id;chrome.sidePanel.setOptions({tabId:s,path:Jt,enabled:!0}),chrome.sidePanel.open({tabId:s}).catch(t=>console.error("sidePanel.open failed",t)),h(s)});chrome.tabs.onRemoved.addListener(e=>{he(e)});chrome.runtime.onMessage.addListener((e,s,t)=>(Bt(e).then(t).catch(a=>{t({type:"ERROR",error:a instanceof Error?a.message:String(a),code:a instanceof Error?a.name:void 0})}),!0));chrome.runtime.onConnect.addListener(e=>{const s=/^picker-(\d+)$/.exec(e.name);if(!s)return;const t=Number(s[1]);e.onDisconnect.addListener(()=>{G(t)})});
