import{P as x,g as b,a as O,b as q,c as U,s as j,d as g,e as D,f as I,h as $,i as F,C as Y,j as T,k as B}from"./language-level-C7mm71J4.js";import{canonicalPhone as J}from"./phone-CYwD4Zak.js";const P={...x,cv:"CV",coverLetter:"Cover Letter",generatePassword:"Generated password"},H=Object.keys(P);async function c(e){try{const o=(await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:["content-script.js"]})).map(a=>a.frameId).filter(a=>typeof a=="number");if(o.length>0)return o}catch{}try{return await chrome.scripting.executeScript({target:{tabId:e},files:["content-script.js"]}),[0]}catch{return[0]}}async function K(e,t){if(e==="cv"){const n=await b();return(n==null?void 0:n.text)??""}if(e==="coverLetter")return await O("lastCoverLetter")??"";if(e==="generatePassword"){const n=await q(t);if(n!=null&&n.generatedPassword)return n.generatedPassword;const s=U();return n&&await j(t,{...n,generatedPassword:s}),s}const o=await g(),a=o[e]??"";return e==="phone"&&a?J(a,o.country):a}const f="job-app-assistant-insert",V={generatePassword:"Generate password"},X=H.map(e=>({id:e,title:V[e]??P[e]}));function G(){chrome.contextMenus.removeAll(()=>{chrome.contextMenus.create({id:f,title:"Insert",contexts:["editable"]});for(const e of X)chrome.contextMenus.create({id:`${f}:${e.id}`,parentId:f,title:e.title,contexts:["editable"]})})}function Q(e){return e.startsWith(`${f}:`)?e.slice(f.length+1):null}async function W(e,t){if(!(t!=null&&t.id)||typeof e.menuItemId!="string")return;const o=Q(e.menuItemId);if(!o)return;const a=await K(o,t.id);await c(t.id);const n={type:"INSERT_VALUE",field:o,value:a};chrome.tabs.sendMessage(t.id,n,{frameId:e.frameId}).catch(()=>{})}const z="https://api.openai.com/v1/responses",C="gpt-5.6-terra",h="gpt-5.6-luna",Z=C;class w extends Error{constructor(t,o){super(t),this.status=o,this.name="OpenAiError"}}class ee extends w{constructor(){super("No OpenAI API key is configured. Add your key in the extension settings."),this.name="MissingApiKeyError"}}async function p(e){var i,r;const t=await D();if(!t)throw new ee;const o=await fetch(z,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({model:e.model??Z,input:[{role:"system",content:e.systemPrompt},{role:"user",content:e.userPrompt}],text:{format:{type:"json_schema",name:e.schemaName,strict:!0,schema:e.schema}}})});if(!o.ok){const l=await o.text().catch(()=>"");throw new w(`OpenAI request failed (${o.status}): ${l.slice(0,300)}`,o.status)}const n=(await o.json()).output.find(l=>l.type==="message"),s=(r=(i=n==null?void 0:n.content)==null?void 0:i.find(l=>l.type==="output_text"))==null?void 0:r.text;if(!s)throw new w("OpenAI response had no content.");return e.parse(s)}const te={type:"object",additionalProperties:!1,required:["keyRequirements","relevantExperienceHints","suggestedTone","suggestedFocus"],properties:{keyRequirements:{type:"array",items:{type:"string"}},relevantExperienceHints:{type:"array",items:{type:"string"}},suggestedTone:{type:"string"},suggestedFocus:{type:"string"}}};async function ne(e){return p({schemaName:"job_analysis",schema:te,model:h,systemPrompt:"You analyze job postings for a job-application assistant. Identify the most important requirements and what an applicant should emphasize. Do not invent details that are not present in the posting.",userPrompt:JSON.stringify(e,null,2),parse:t=>JSON.parse(t)})}const y=`Write like a specific person, not an AI assistant. These rules have no exceptions:

- NEVER use an em dash ("—"), a spaced en dash ("–") or "--" as punctuation. Real people don't write that way. Use a comma, a period, parentheses, or two sentences.
- Banned words: delve, foster, leverage, utilize, facilitate, empower, streamline, robust, cutting-edge, paradigm shift, game changer, tapestry, realm, beacon, multifaceted, meticulous, intricate, paramount, transformative, elevate, embark, supercharge, harness, ever-evolving. Say the plain thing.
- Cut empty phrases: "it's worth noting", "at the end of the day", "when it comes to", "at its core", "in today's world", "the reality is", "in order to", "going forward".
- No "not X, it's Y" / "the question isn't X, it's Y" / "not just X but Y" contrasts. State Y directly.
- No throat-clearing openers ("Here's the thing", "Let me be clear", "I'll be honest") and no faux-insight setups ("what most people get wrong", "here's what nobody tells you").
- No importance puffery ("stands as a testament", "marks a pivotal moment", "plays a vital role", "underscores its significance"). State the fact and stop.
- No colon reveals: a noun phrase, a colon, then a dramatic lowercase clause.
- No trailing "-ing" clauses that editorialize ("highlighting the commitment to...", "underscoring its importance", "showcasing", "reflecting"). End the sentence.
- No metadiscourse that tells the reader what to notice ("this matters", "this distinction matters", "in other words", "as you can see").
- No "In conclusion" / "Ultimately" / "Overall" recap ending and no cute one-line kicker. Stop on the last concrete point.
- No emoji, no mid-sentence bold, no rhetorical questions.
- Vary sentence shape; don't stack short punchy fragments.
- Be concrete: name the technology, project, number, or outcome instead of calling it "significant", "impactful" or "exciting". Use active voice.`;function m(e){return e.replace(/[ \t]*[—―][ \t]*/g,", ").replace(/[ \t]+--[ \t]+/g,", ").replace(/(\D)[ \t]+–[ \t]+(?=\D)/g,"$1, ").replace(/[ \t]+([,.;:!?])/g,"$1").replace(/,(\s*[.;:!?])/g,"$1").replace(/,[ \t]*,/g,",").replace(/^[ \t]*,[ \t]*/gm,"").replace(/([([{])[ \t]*,[ \t]*/g,"$1").replace(/[ \t]*,[ \t]*([)\]}])/g,"$1").replace(/,[ \t]*$/gm,"").replace(/[ \t]+$/gm,"")}const ae={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},oe=`You write tailored cover letters for job applications.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, and Personal Legend.
- Never invent experience, technologies, companies, education, or achievements.
- If information needed to be compelling is missing, write around it honestly
  rather than fabricating it.
- Tailor tone and emphasis to the job analysis provided.
- Output plain prose paragraphs, no markdown headers.

${y}`;async function se(e){const t=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,analysis:e.analysis},null,2),o=await p({schemaName:"cover_letter",schema:ae,systemPrompt:oe,userPrompt:t,parse:a=>JSON.parse(a)});return m(o.content)}const re={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},ie=`You are a sharp human editor cleaning up a cover letter draft.

Fix ONLY the flagged AI-writing patterns listed below. Make the minimum
effective edit — do not rewrite sentences that were not flagged, do not
change facts, experience, technologies, or claims, and do not add new
content. Replace banned words/clichés with plain, concrete language.
Rewrite "not X, it's Y" contrasts as a direct statement of Y. Cut
throat-clearing openers, weasel attribution, and importance-puffery instead
of softening them. If the ending is a generic summary/recap, end on the
letter's last concrete point instead. Replace every em dash ("—") with a
comma, a period, or parentheses.

Do not introduce any new AI-slop while editing. For reference, the full
house style is:

${y}

Output plain prose paragraphs, no markdown headers.`;async function ce(e,t){const o=JSON.stringify({draft:e,flaggedPatterns:t.map(n=>`${n.pattern}: "${n.match}"`)},null,2),a=await p({schemaName:"cover_letter_polish",schema:re,systemPrompt:ie,userPrompt:o,parse:n=>JSON.parse(n)});return m(a.content)}const le=["delve","foster","leverage","utilize","facilitate","empower","streamline","robust","cutting-edge","paradigm shift","game changer","this is huge","this changes everything","tapestry","realm","beacon","multifaceted","meticulous","intricate","paramount","transformative","elevate","embark","supercharge","harness","ever-evolving"],pe=["it's worth noting","it is worth noting","it's important to note","it is important to note","at the end of the day","when it comes to","at its core","in today's world","in the age of","in the world of","the reality is","the truth is","in terms of","with regard to","in order to","going forward"],de=["here's the thing","here's what i mean","let me be clear","i'll be honest","the uncomfortable truth is"],ue=["this is the part most people skip","what most people get wrong","here's what nobody tells you","the part everyone misses"],he=["stands as a testament","marks a pivotal moment","plays a vital role","solidifies its position","underscores its significance"],fe=["experts agree","industry reports suggest","many argue","widely regarded as","studies show"],me=[/^in conclusion\b/i,/^ultimately\b/i,/^overall\b/i];function ge(e){const t=e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`\\b${t.replace(/ /g,"\\s+")}\\b`,"i")}function u(e,t,o){const a=[];for(const n of t){const s=ge(n).exec(e);s&&a.push({pattern:o,match:s[0]})}return a}function ye(e){const t=/\b(?:isn'?t|is not)\b[^.!?]{3,60}[,.]?\s*(?:it'?s|it is)\b[^.!?]{3,80}[.!?]/i,o=/\bnot just\b[^.!?]{3,60}(?:\bbut\b|[,.]?\s*(?:it'?s|it is)\b)[^.!?]{0,80}[.!?]/i,a=[],n=t.exec(e);n&&a.push({pattern:"binary-contrast",match:n[0].trim()});const s=o.exec(e);return s&&a.push({pattern:"binary-contrast",match:s[0].trim()}),a}function Ee(e){const t=e.split(/\n{2,}/).map(a=>a.trim()).filter(Boolean),o=t[t.length-1];if(!o)return[];for(const a of me)if(a.test(o))return[{pattern:"summary-recap-ending",match:o.slice(0,60)}];return[]}function we(e){const t=(e.match(/—/g)??[]).length;return t===0?[]:[{pattern:"em-dash",match:t===1?"1 em dash":`${t} em dashes`}]}function be(e){return[...u(e,le,"banned-word"),...u(e,pe,"empty-phrase"),...u(e,de,"throat-clearing-opener"),...u(e,ue,"faux-insight-setup"),...u(e,he,"importance-puffery"),...u(e,fe,"weasel-attribution"),...ye(e),...Ee(e),...we(e)]}async function Se(e){const[t,o,a]=await Promise.all([g(),b(),I()]),n=await ne(e),s=await se({profile:t,cvText:(o==null?void 0:o.text)??"",personalLegend:(a==null?void 0:a.content)??"",job:e,analysis:n}),i=be(s);return i.length===0?{content:s,slopFindings:i,cleaned:!1}:{content:await ce(s,i),slopFindings:i,cleaned:!0}}const Te={type:"object",additionalProperties:!1,required:["company","position","location","description","requirements","responsibilities","salary","techStack","contact"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},description:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]}}};async function _(e,t){return{...await p({schemaName:"job_extraction",schema:Te,systemPrompt:"Extract structured job posting fields from the visible page text below. Only use information present in the text; leave fields empty/null if unknown.",userPrompt:e.slice(0,12e3),parse:a=>JSON.parse(a)}),url:t}}const _e={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},ve=`You are editing an existing cover letter draft on the applicant's
instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the
  letter the instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements
  that aren't already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the
  instruction explicitly asks to change it.
- Output plain prose paragraphs, no markdown headers.
- Don't introduce AI-slop while editing, and clean it from any sentence you
  touch.

${y}`;async function Le(e,t,o){const a=JSON.stringify({draft:e,instructions:t,job:o},null,2),n=await p({schemaName:"cover_letter_revision",schema:_e,model:C,systemPrompt:ve,userPrompt:a,parse:s=>JSON.parse(s)});return m(n.content)}const Oe={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},Ie=`You translate a cover letter for the applicant's own understanding —
not for submission. Translate faithfully, preserve paragraph breaks, and keep
names, companies, and technical terms as-is where translating them would be
unnatural. Do not use em dashes ("—"); use commas or periods. Output plain
prose paragraphs, no markdown headers, no notes about the translation itself.`;async function Pe(e,t){const o=JSON.stringify({content:e,targetLanguage:t},null,2),a=await p({schemaName:"cover_letter_translation",schema:Oe,model:h,systemPrompt:Ie,userPrompt:o,parse:n=>JSON.parse(n)});return m(a.content)}function v(e){return String(e).padStart(2,"0")}const Ce={date:"2026-09-05",month:"2026-09",week:"2026-W36",time:"09:30","datetime-local":"2026-09-05T09:30"};function Ne(){const e=new Date;return`${e.getFullYear()}-${v(e.getMonth()+1)}-${v(e.getDate())}`}const Re={type:"object",additionalProperties:!1,required:["answer"],properties:{answer:{type:"string"}}},L=`You answer a custom question from a job application form on the
applicant's behalf.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend,
  cover letter, custom fields, language levels, and job posting. Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, the
  "languageLevels" list is the authoritative answer (CEFR levels the
  applicant self-reported in Settings) — use it directly rather than
  guessing from the CV or defaulting to a low/neutral level.
- If information needed to answer well is missing, answer honestly and
  briefly rather than fabricating it.
- Match the question's expected length: a short field gets a short answer, an
  open-ended "tell us about..." field gets a fuller one.
- Output plain text, no markdown, no restating the question.

${y}`,Ae=/\b(?:please\s+(?:provide|specify|clarify)|could\s+you\s+(?:please\s+)?(?:provide|clarify|specify)|i\s+(?:don'?t|do\s+not)\s+see)\b.{0,40}?\b(?:question|prompt)\b|\bno\s+(?:specific\s+)?question\s+(?:was|is)?\s*(?:provided|given|specified|attached)\b/i;function ke(e){const t=e.trim();return t?t.length<220&&Ae.test(t):!0}const Me=`
- This is a MULTIPLE-CHOICE question: "options" lists the allowed answers.
  Reply with EXACTLY ONE option, copied verbatim, and nothing else.
- Base the choice on the applicant's profile/CV/Personal Legend. If the
  needed fact is genuinely absent (e.g. pronouns not stated anywhere),
  prefer a neutral option, an explicit "prefer not to say", or the option
  that commits the applicant least.`,xe=`
- This field only accepts a plain number: reply with digits only (a single
  "." for a decimal if needed) — no currency symbol, no thousands
  separator, no unit, no words, no range. If a range genuinely fits best
  (e.g. a salary expectation given as "65-75k"), reply with one
  representative figure (its midpoint), not the range.`;function qe(e){return`
- This field only accepts a date in the exact format "${Ce[e]}"
  — reply with ONLY that value, nothing else (no words, no explanation).
  "todayISO" in the data below is today's date: compute the answer from it
  — e.g. "available with one month's notice" → todayISO plus one month;
  "immediately" / "as soon as possible" / no stated constraint → todayISO
  itself. Never answer with a description of the notice period or
  availability instead of the date itself.`}async function Ue(e,t,o,a,n){const[s,i,r,l,R,A]=await Promise.all([g(),b(),I(),O("lastCoverLetter"),$(),F()]),k=JSON.stringify({question:e,options:o&&o.length>0?o:void 0,todayISO:Ne(),job:t,profile:s,cvText:(i==null?void 0:i.text)??"",personalLegend:(r==null?void 0:r.content)??"",coverLetter:l??"",languageLevels:R,customFields:A},null,2),S=[o&&o.length>0?Me:"",a?xe:"",n?qe(n):""].filter(Boolean),E=await p({schemaName:"custom_question_answer",schema:Re,model:h,systemPrompt:S.length>0?[L,...S].join(`
`):L,userPrompt:k,parse:M=>JSON.parse(M)});return ke(E.answer)?"":o&&o.length>0||a||!!n?E.answer:m(E.answer)}const je={type:"object",additionalProperties:!1,required:["questions"],properties:{questions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","question"],properties:{index:{type:"integer"},question:{type:"string"}}}}}},De=`You are given a block of a job-application form: its visible text, and a
list of the input fields inside it. For each field that asks the applicant
something, return the question it is asking, phrased as a plain question.

Rules:
- Use ONLY the visible text provided. Never invent a question.
- Match each question to its field by "index".
- Omit a field that is not a real question (layout helper, hidden field,
  search box, honeypot, a plain "First name"-style profile field).
- A field with "options" is a multiple-choice question — still return only
  its question text, not the options.
- Output the question text only — no numbering, no "Question:" prefix.
- Questions may be in any language; keep the form's own language.`;async function $e(e,t){if(t.length===0)return{};const o=JSON.stringify({blockText:e.slice(0,6e3),fields:t},null,2),a=await p({schemaName:"block_questions",schema:je,model:h,systemPrompt:De,userPrompt:o,parse:s=>JSON.parse(s)}),n={};for(const s of a.questions)s.question.trim()&&(n[s.index]=s.question.trim());return n}const Fe={type:"object",additionalProperties:!1,required:["decisions"],properties:{decisions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","check","category","reason"],properties:{index:{type:"integer"},check:{type:"boolean"},category:{type:"string",enum:["required-consent","marketing","optional","unclear"]},reason:{type:"string"}}}}}},Ye=`You decide, for each checkbox on a job-application form, whether the
applicant should tick it. The applicant has already chosen to submit this
application.

TICK (check: true) — things required to submit, or that a candidate is
normally expected to accept:
- privacy policy / data protection / GDPR / Datenschutz consent
- terms & conditions / AGB / Nutzungsbedingungen
- confirming the entered information is accurate / truthful
- consent to process and store the application data for THIS hiring process
- storing the data in a talent pool ONLY when the checkbox is marked required
- eligibility self-declarations that hold for any ordinary adult applying
  for a real job (e.g. "I am at least 18 years old", "I am legally
  entitled to work in [country]", "I have no undisclosed conflicts of
  interest") — assume true unless the profile/CV explicitly states
  otherwise; a genuine job applicant submitting this form is virtually
  always eligible, and leaving a required declaration like this unticked
  blocks submission for no real reason

DO NOT TICK (check: false) — optional and promotional:
- newsletters, marketing e-mails, "career news", event invitations
- job alerts / notifications about new postings
  (e.g. "Benachrichtigungen über neue Stellenausschreibungen erhalten")
- sharing data with third parties / partner companies for marketing
- joining a talent pool / candidate database when NOT required
- anything that benefits the applicant only beyond this one application

Rules:
- "required: true" means the form marks the field mandatory — a strong
  signal to tick, unless the text is clearly marketing.
- If a checkbox is ambiguous AND not required, set check: false.
- Labels may be in any language; judge by meaning, not keywords.
- Return one decision per input item, using its "index".

category: "required-consent" (ticked, mandatory-type), "marketing" (left
off), "optional" (non-marketing but skippable, left off unless required),
"unclear" (left off). reason: one short phrase.`;async function Be(e){if(e.length===0)return[];const t=JSON.stringify(e.map((n,s)=>({index:s,label:n.label,required:n.required,currentlyChecked:n.checked})),null,2),o=await p({schemaName:"checkbox_decisions",schema:Fe,model:h,systemPrompt:Ye,userPrompt:t,parse:n=>JSON.parse(n)}),a=new Map;for(const n of o.decisions)a.set(n.index,n);return e.map((n,s)=>{const i=a.get(s);return i?{name:n.name,label:n.label,check:i.check,category:i.category,reason:i.reason}:{name:n.name,label:n.label,check:n.required,category:n.required?"required-consent":"unclear",reason:n.required?"Marked required by the form":"No decision returned"}})}const Je={type:"object",additionalProperties:!1,required:["postingLanguages","requirements"],properties:{postingLanguages:{type:"array",items:{type:"string"}},requirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...Y,null]}}}}}},He=`You read a job posting and report its language(s) and any explicit
language-proficiency requirement it states.

- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- requirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or
  "Native" for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent",
  "professional working proficiency" -> "C1"; "conversational" -> "B1". If a language is
  mentioned but no level can be reasonably inferred, set level to null. Do not invent a
  requirement that isn't stated in the text. If nothing is stated, return an empty array.`;async function Ke(e){return p({schemaName:"job_language",schema:Je,model:h,systemPrompt:He,userPrompt:JSON.stringify(e,null,2),parse:t=>JSON.parse(t)})}async function N(e){const t=await c(e);await Promise.all(t.map(o=>chrome.tabs.sendMessage(e,{type:"CANCEL_ELEMENT_PICKER",tabId:e},{frameId:o}).catch(()=>{})))}async function d(e,t,o){return(await Promise.all(t.map(n=>chrome.tabs.sendMessage(e,o,{frameId:n}).catch(()=>{})))).filter(n=>!!n)}async function Ve(e){switch(e.type){case"GET_PROFILE":return{type:"PROFILE_DATA",profile:await g()};case"GET_JOB":{const t=await c(e.tabId),a=(await d(e.tabId,t,e)).filter(r=>r.type==="JOB_DATA");if(a.length===0)return;const n=a.find(r=>r.sufficient);if(n)return n;const s=a.reduce((r,l)=>l.job.description.length>r.job.description.length?l:r),i=a.map(r=>r.visibleText??"").filter(Boolean).join(`

`).slice(0,2e4);try{return{type:"JOB_DATA",job:await _(i||s.visibleText||"",s.job.url),sufficient:!0}}catch{return s}}case"EXTRACT_JOB_FROM_TEXT":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});return{type:"JOB_DATA",job:await _(e.text,(t==null?void 0:t.url)??""),sufficient:!0}}case"AUTOFILL":{const t=await c(e.tabId),a=(await d(e.tabId,t,e)).filter(n=>n.type==="AUTOFILL_RESULT");return{type:"AUTOFILL_RESULT",filled:a.reduce((n,s)=>n+s.filled,0),total:a.reduce((n,s)=>n+s.total,0),generatedPassword:a.map(n=>n.generatedPassword).find(Boolean)??null}}case"GENERATE_COVER_LETTER":{const t=await Se(e.job);return await T("lastCoverLetter",t.content),{type:"COVER_LETTER_RESULT",content:t.content,slopFindings:t.slopFindings,cleaned:t.cleaned}}case"UPLOAD_FILE":{const t=await c(e.tabId),a=(await d(e.tabId,t,e)).filter(n=>n.type==="UPLOAD_FILE_RESULT");return{type:"UPLOAD_FILE_RESULT",nativeInputs:a.reduce((n,s)=>n+s.nativeInputs,0),dropZones:a.reduce((n,s)=>n+s.dropZones,0)}}case"REVISE_COVER_LETTER":{const t=await Le(e.content,e.instructions,e.job);return await T("lastCoverLetter",t),{type:"REVISE_COVER_LETTER_RESULT",content:t}}case"TRANSLATE_COVER_LETTER":return{type:"TRANSLATE_COVER_LETTER_RESULT",content:await Pe(e.content,e.targetLanguage)};case"DETECT_CUSTOM_QUESTIONS":{const t=await c(e.tabId),o=await d(e.tabId,t,e),a=new Set,n=[];for(const s of o)if(s.type==="CUSTOM_QUESTIONS_DATA")for(const i of s.questions)a.has(i.question)||(a.add(i.question),n.push({...i,id:`question-${n.length}`}));return{type:"CUSTOM_QUESTIONS_DATA",questions:n}}case"ANSWER_CUSTOM_QUESTION":{const t=await Ue(e.question,e.job,e.options,e.numeric,e.dateKind);return{type:"CUSTOM_QUESTION_ANSWER",question:e.question,answer:t}}case"FILL_CUSTOM_QUESTION_ANSWERS":{const t=await c(e.tabId),o=await d(e.tabId,t,e);let a=0;for(const n of o)n.type==="CUSTOM_QUESTION_FILL_RESULT"&&(a+=n.filled);return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:a}}case"START_ELEMENT_PICKER":{const t=await c(e.tabId),o=t.map(n=>chrome.tabs.sendMessage(e.tabId,e,{frameId:n}).catch(()=>{})),a=await new Promise(n=>{let s=o.length;s===0&&n(void 0);for(const i of o)i.then(r=>{s-=1,r&&!r.cancelled&&r.picked.length>0||r!=null&&r.cancelled?n(r):s===0&&n(r??void 0)})});return await Promise.all(t.map(n=>chrome.tabs.sendMessage(e.tabId,{type:"CANCEL_ELEMENT_PICKER",tabId:e.tabId},{frameId:n}).catch(()=>{}))),a??{type:"ELEMENT_PICKER_RESULT",cancelled:!0,picked:[],blockText:"",semanticCount:0}}case"CANCEL_ELEMENT_PICKER":{await N(e.tabId);return}case"DECOMPOSE_BLOCK":return{type:"BLOCK_QUESTIONS",questions:await $e(e.blockText,e.fields)};case"FILL_QUESTION_ANSWERS_BY_LOCATOR":{const t=await c(e.tabId),o=await d(e.tabId,t,e);let a=0;for(const n of o)n.type==="CUSTOM_QUESTION_FILL_RESULT"&&(a+=n.filled);return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:a}}case"DETECT_CHECKBOXES":{const t=await c(e.tabId),o=await d(e.tabId,t,e),a=new Set,n=[];for(const s of o)if(s.type==="CHECKBOXES_DATA")for(const i of s.checkboxes){const r=i.name||i.label;!r||a.has(r)||(a.add(r),n.push({...i,id:`checkbox-${n.length}`}))}return{type:"CHECKBOXES_DATA",checkboxes:n}}case"DECIDE_CHECKBOXES":return{type:"CHECKBOX_DECISIONS",decisions:await Be(e.checkboxes)};case"APPLY_CHECKBOX_DECISIONS":{const t=await c(e.tabId),o=await d(e.tabId,t,e);let a=0;for(const n of o)n.type==="CHECKBOX_APPLY_RESULT"&&(a+=n.changed);return{type:"CHECKBOX_APPLY_RESULT",changed:a}}case"DETECT_JOB_LANGUAGE":return{type:"JOB_LANGUAGE_DATA",info:await Ke(e.job)};default:return}}const Xe="src/sidepanel/index.html";chrome.runtime.onInstalled.addListener(()=>{G(),chrome.sidePanel.setOptions({enabled:!1})});chrome.contextMenus.onClicked.addListener((e,t)=>{W(e,t)});chrome.action.onClicked.addListener(e=>{if(e.id===void 0)return;const t=e.id;chrome.sidePanel.setOptions({tabId:t,path:Xe,enabled:!0}),chrome.sidePanel.open({tabId:t}).catch(o=>console.error("sidePanel.open failed",o)),c(t)});chrome.tabs.onRemoved.addListener(e=>{B(e)});chrome.runtime.onMessage.addListener((e,t,o)=>(Ve(e).then(o).catch(a=>{o({type:"ERROR",error:a instanceof Error?a.message:String(a),code:a instanceof Error?a.name:void 0})}),!0));chrome.runtime.onConnect.addListener(e=>{const t=/^picker-(\d+)$/.exec(e.name);if(!t)return;const o=Number(t[1]);e.onDisconnect.addListener(()=>{N(o)})});
