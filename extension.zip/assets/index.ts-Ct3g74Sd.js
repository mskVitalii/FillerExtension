import{P as St,g as Oe,a as P,b as kt,c as Tt,s as _t,d as R,r as Re,e as Pe,A as It,f as Lt,h as xe,i as Ne,j as At,k as Ct,l as Ot,m as Rt,n as Me,o as v,J as $e,p as Pt,q as C,t as xt,u as B,v as Nt,w as Ue,x as se,M as Mt,y as ie,z as $t,B as je,C as U,D as Ut,E as jt,F as Dt,G as Ft,H as qt,I as X,K as Jt,L as j,N as De,O as Gt,Q as Fe,R as Bt,S as Yt,T as qe,U as Je,V as Ge,W as re,X as Be,Y as Vt,Z as Ye,_ as Ht,$ as de,a0 as Ve,a1 as Kt,a2 as He,a3 as Wt,a4 as zt,a5 as Qt,a6 as Ke,a7 as Xt,a8 as oe,a9 as F,aa as N,ab as Zt,ac as q,ad as Z,ae as We,af as ze,ag as Qe,ah as Xe,ai as Ze,aj as en,ak as tn,al as he,am as V,an as et,ao as tt,ap as nt,aq as nn,ar as an,as as at,at as sn,au as rn,av as on,aw as cn,ax as ln,ay as un,az as pn,aA as J,aB as dn,aC as hn,aD as fn,aE as W,aF as gn,aG as mn,aH as yn,aI as wn,aJ as bn,aK as st,aL as vn,aM as En}from"./registration-B1qr1wUj.js";import{canonicalPhone as Sn}from"./phone-B8k1SbKu.js";const it={...St,cv:"CV",coverLetter:"Cover Letter",generatePassword:"Generated password"},kn=Object.keys(it);async function S(e){try{const n=(await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:["content-script.js"]})).map(a=>a.frameId).filter(a=>typeof a=="number");if(n.length>0)return n}catch{}try{return await chrome.scripting.executeScript({target:{tabId:e},files:["content-script.js"]}),[0]}catch{return[0]}}function Tn(){const e=[];for(const t of Array.from(document.querySelectorAll("iframe, frame"))){const n=t.getBoundingClientRect(),a=n.width*n.height;t.src&&n.width>=200&&n.height>=150&&e.push({src:t.src,area:a})}return{origin:location.origin,children:e}}async function _n(e){let t;try{t=await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},func:Tn})}catch{return[]}const n=new Set,a=new Map;for(const{result:i}of t)if(i){n.add(i.origin);for(const r of i.children){let o;try{const c=new URL(r.src);if(c.protocol!=="https:"&&c.protocol!=="http:")continue;o=c.origin}catch{continue}a.set(o,Math.max(a.get(o)??0,r.area))}}const s=[];for(const i of[...a.keys()].sort((r,o)=>a.get(o)-a.get(r))){if(n.has(i))continue;if(await chrome.permissions.contains({origins:[`${i}/*`]}).catch(()=>!1)||s.push(i),s.length===3)break}return s}async function In(e,t){if(e==="cv"){const s=await Oe();return(s==null?void 0:s.text)??""}if(e==="coverLetter")return await P("lastCoverLetter")??"";if(e==="generatePassword"){const s=await kt(t);if(s!=null&&s.generatedPassword)return s.generatedPassword;const i=Tt();return s&&await _t(t,{...s,generatedPassword:i}),i}const n=await R(),a=n[e]??"";return e==="phone"&&a?Sn(a,n.country):a}const D="job-app-assistant-insert",Ln={generatePassword:"Generate password"},An=kn.map(e=>({id:e,title:Ln[e]??it[e]}));function Cn(){chrome.contextMenus.removeAll(()=>{chrome.contextMenus.create({id:D,title:"Insert",contexts:["editable"]});for(const e of An)chrome.contextMenus.create({id:`${D}:${e.id}`,parentId:D,title:e.title,contexts:["editable"]})})}function On(e){return e.startsWith(`${D}:`)?e.slice(D.length+1):null}async function Rn(e,t){if(!(t!=null&&t.id)||typeof e.menuItemId!="string")return;const n=On(e.menuItemId);if(!n)return;const a=t.id,s=await Re(await Pe(),()=>In(n,a));await S(t.id);const i={type:"INSERT_VALUE",field:n,value:s};chrome.tabs.sendMessage(t.id,i,{frameId:e.frameId}).catch(()=>{})}const Pn=new Set(["profileCache","cvLibraryCache","legendLibraryCache","customFieldsCache","languageLevelsCache","faqAnswersCache","generationRulesCache","outreachRulesCache"]),$=new Map;function xn(){return Promise.all([R(),Oe(),Ne(),At(),Ct(),Ot(),Rt(),Me()]).then(([e,t,n,a,s,i,r,o])=>({profile:e,cvText:(t==null?void 0:t.text)??"",personalLegend:(n==null?void 0:n.content)??"",generationRules:(a==null?void 0:a.content)??"",outreachRules:(s==null?void 0:s.content)??"",languageLevels:i,customFields:r,faq:o}))}async function E(){const e=await xe();let t=$.get(e);if(!t){t=xn(),$.set(e,t);const n=t;n.catch(()=>{$.get(e)===n&&$.delete(e)})}return t}var Ce;typeof chrome<"u"&&((Ce=chrome.storage)!=null&&Ce.onChanged)&&chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&Object.keys(e).some(n=>n===It||Pn.has(Lt(n)))&&$.clear()});const A=`Write like a specific person, not an AI assistant. These rules have no exceptions:

- NEVER use an em dash ("—"), a spaced en dash ("–") or "--" as punctuation. Real people don't write that way. Use a comma, a period, parentheses, or two sentences.
- Banned words: delve, foster, leverage, utilize, facilitate, empower, streamline, robust, cutting-edge, paradigm shift, game changer, tapestry, realm, beacon, multifaceted, meticulous, intricate, paramount, transformative, elevate, embark, supercharge, harness, ever-evolving. Say the plain thing.
- Cut empty phrases: "it's worth noting", "at the end of the day", "when it comes to", "at its core", "in today's world", "the reality is", "in order to", "going forward".
- No "not X, it's Y" / "the question isn't X, it's Y" / "not just X but Y" contrasts. State Y directly.
- No throat-clearing openers ("Here's the thing", "Let me be clear", "I'll be honest") and no faux-insight setups ("what most people get wrong", "here's what nobody tells you").
- No importance puffery ("stands as a testament", "marks a pivotal moment", "plays a vital role", "underscores its significance"). State the fact and stop.
- No colon reveals: a noun phrase, a colon, then a dramatic lowercase clause.
- No trailing "-ing" clauses that editorialize ("highlighting the commitment to...", "underscoring its importance", "showcasing", "reflecting"). End the sentence.
- No metadiscourse that tells the reader what to notice ("this matters", "this distinction matters", "in other words", "as you can see").
- No "In conclusion" / "Ultimately" / "Overall" recap ending and no cute one-line kicker. Stop on the last concrete point.
- No emoji, no mid-sentence bold, no rhetorical questions.
- Vary sentence shape; don't stack short punchy fragments.
- Be concrete: name the technology, project, number, or outcome instead of calling it "significant", "impactful" or "exciting". Use active voice.`;function k(e){return e.replace(/[ \t]*[—―][ \t]*/g,", ").replace(/[ \t]+--[ \t]+/g,", ").replace(/(\D)[ \t]+–[ \t]+(?=\D)/g,"$1, ").replace(/[ \t]+([,.;:!?])/g,"$1").replace(/,(\s*[.;:!?])/g,"$1").replace(/,[ \t]*,/g,",").replace(/^[ \t]*,[ \t]*/gm,"").replace(/([([{])[ \t]*,[ \t]*/g,"$1").replace(/[ \t]*,[ \t]*([)\]}])/g,"$1").replace(/,[ \t]*$/gm,"").replace(/[ \t]+$/gm,"")}const Nn=`You write the applicant's own answers to standard interview-FAQ
questions (spec_5 section B) — general-purpose answers meant to be reused, as-is or
lightly adapted, whenever a real application form asks a close variant of one of them.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend, and
  custom fields. Never invent experience, technologies, companies, education,
  achievements, or a concrete salary figure that wasn't actually given.
- If information needed for a good answer is missing (no CV, no Personal Legend
  content covering it), write a short, honest, generically true answer rather
  than fabricating specifics — the applicant can always sharpen it later.
- Keep each answer 2-5 sentences: concrete and confident, never generic
  corporate filler, no restating the question.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text per answer, no markdown, no numbering.

${A}`;function Mn(e){return{type:"object",additionalProperties:!1,required:["answers"],properties:{answers:{type:"array",minItems:e,maxItems:e,items:{type:"string"}}}}}async function $n(e){if(e.length===0)return[];const{profile:t,cvText:n,personalLegend:a,generationRules:s,customFields:i}=await E(),r=JSON.stringify({profile:t,cvText:n,personalLegend:a,generationRules:s,customFields:i,questions:e},null,2),o=await v({schemaName:"faq_answers",schema:Mn(e.length),systemPrompt:Nn,userPrompt:r,parse:c=>JSON.parse(c)});return e.map((c,u)=>({question:c,answer:k(o.answers[u]??"")}))}async function Un(e,t){const n=new Map(t.map(i=>[i.question,i.answer])),a=e.filter(i=>{var r;return!((r=n.get(i))!=null&&r.trim())}),s=await $n(a);for(const i of s)n.set(i.question,i.answer);return e.map(i=>({question:i,answer:n.get(i)??""}))}function jn(e){return e!=null&&e.length?`Seniority levels to target: ${$e.filter(n=>e.includes(n.id)).map(n=>n.label.toLowerCase()).join(", ")}. Only include postings for these levels.`:""}function Dn(e,t){const n=$e.filter(s=>t==null?void 0:t.includes(s.id));if(n.length===0)return e;const a=[];for(const s of e)for(const i of n)a.push(s.toLowerCase().includes(i.keyword)?s:`${i.keyword} ${s}`.trim());return[...new Set(a)]}function Fn(e){const t=C(e);return t.length===0?"":t.length===1?`Role/keywords focus: "${t[0]}".`:`Role/keywords: any of ${t.map(n=>`"${n}"`).join(", ")}.`}function qn(e){return[Fn(e),e.where?`Location: "${e.where}".`:"",jn(e.grades),e.remoteOnly?"Prefer remote-friendly roles.":"",Pt(e.negative)].filter(Boolean).join(" ")}function Jn(e){return e.length===0?"":`

Already found and shown to the applicant — do NOT return any of these again,
find genuinely different postings instead:
${e.map(n=>`- ${n.title} at ${n.company} (${n.url})`).join(`
`)}`}function O(e){return typeof e=="string"?e.trim():""}function Gn(e){const t=e.trim().replace(/^(?:[-*•]|\d+[.)])\s+/u,"").replace(/,$/,"");if(!t.startsWith("{")||!t.endsWith("}"))return null;let n;try{n=JSON.parse(t)}catch{return null}const a=O(n.url),s=O(n.title);return!/^https?:\/\//i.test(a)||!s?null:{title:s,company:O(n.company),location:O(n.location),url:a,salary:O(n.salary),snippet:O(n.snippet),postedAt:O(n.postedAt)}}function Bn(e){let t="";function n(a){const s=Gn(a);s&&e(s)}return{push(a){t+=a;let s;for(;(s=t.indexOf(`
`))!==-1;)n(t.slice(0,s)),t=t.slice(s+1)},end(){n(t),t=""}}}const Yn=6,fe=[{id:"ats",focus:`Look on applicant tracking systems: ${Ue.join(", ")}.`},{id:"careers",focus:"Look on the hiring companies' own career pages (company websites, not job boards)."},{id:"boards",focus:"Look on job boards and aggregators (LinkedIn, Indeed, StepStone, Glassdoor, Welcome to the Jungle, Wellfound, Arbeitnow and similar); when the board links to the employer's own posting, give that URL."}];function Vn(e,t,n=[],a){const s=qn(e),i=se();return`Search the web for current, actually open job postings that fit this
candidate:

${t||"(no candidate background available)"}

${s||"No further constraints — use the candidate's own background to pick a fitting role/location."}

Today is ${i}. Only include postings published in the last ${Mt} days
that are still accepting applications — skip anything marked closed, expired or filled,
or shown with an older date. Skip postings that are a poor fit for the candidate (wrong
seniority, unrelated field).
Prefer the employer's own posting on its applicant tracking system (${Ue.join(", ")})
or career page over copies on aggregators, which often outlive the real posting.
Only real individual postings with their direct listing URL — never a search results page,
a generic careers homepage or an aggregator's category page.${a?`
${a}`:""}${Jn(n)}

OUTPUT FORMAT — follow exactly. Up to ${Yn} of the best matches, best first, as JSON
Lines: one JSON object per line, nothing else (no prose, no markdown, no code fences, no
citations). Each object has exactly these string keys:
{"title":"","company":"","location":"","url":"","salary":"","postedAt":"","snippet":""}
- "url": the posting's direct URL as found.
- "salary": as stated, or "" — never guess.
- "postedAt": YYYY-MM-DD when the posting states a date (resolve "3 days ago" against
  ${i}), else "".
- "snippet": one sentence, at most 25 words, on why it fits this candidate.
If you find no fitting posting, output nothing.`}const z={timeoutMs:9e4,idleMs:4e4,parseTimeoutMs:3e4};function ge(e){const t=n=>n.toLowerCase().replace(/[^a-z0-9]+/g," ").trim();return e.company?`${t(e.company)}|${t(e.title)}`:e.url}async function Hn(e,t,n=[],a,s,i){const r=performance.now();let o=null;const c=[],u=new Set,l=d=>u.has(d.url)||u.has(ge(d))?!1:(u.add(d.url),u.add(ge(d)),c.push(d),!0),g=await Promise.allSettled(fe.map(async d=>{const w=Vn(e,t,n,d.focus),b=Bn(T=>{const[K]=ie([{...T,source:"openai"}]);!K||!l(K)||(o??(o=performance.now()),s==null||s([K]))}),I=performance.now();try{const T=await xt(w,b.push,{reasoningEffort:"low",timeoutMs:z.timeoutMs,idleMs:z.idleMs,signal:i});return b.end(),T}finally{a==null||a.push({label:`Web search (${d.id})`,ms:performance.now()-I})}}));a==null||a.push({label:"Web search",ms:performance.now()-r}),o!==null&&(a==null||a.push({label:"First result",ms:o-r}));const h=g.flatMap((d,w)=>d.status==="rejected"?[{id:fe[w].id,err:d.reason}]:[]),p=d=>d instanceof Error?d.message:"the search failed";if(h.length===g.length&&c.length===0)throw h[0].err;const m=h.map(d=>`Web search (${d.id}) stopped: ${p(d.err)}`);if(c.length>0)return{results:c,warnings:m};const y=g.map(d=>d.status==="fulfilled"?d.value:"").filter(d=>d.trim()).join(`

---

`);return y?{results:await B(a,"Parse results",()=>Nt(y,"openai",t,{negative:e.negative,where:e.where,remoteOnly:e.remoteOnly,reasoningEffort:"low",timeoutMs:z.parseTimeoutMs,signal:i})),warnings:m}:{results:c,warnings:m}}function Kn(e,t){return!e&&!t?"":je({low:Math.round(e??t??0),high:Math.round(t??e??0)})}function Wn(e){return new Promise(t=>setTimeout(t,e))}const zn=350,Qn=12,me=15e3;function Xn(e,t,n,a,s){const i=new URL(`https://api.adzuna.com/v1/api/jobs/${a}/search/${s}`);i.searchParams.set("app_id",n.appId),i.searchParams.set("app_key",n.appKey),i.searchParams.set("results_per_page","15"),i.searchParams.set("content-type","application/json"),e&&i.searchParams.set("what",e),t.where&&i.searchParams.set("where",t.where);const r=$t(t.negative);return r&&i.searchParams.set("what_exclude",r),i.toString()}async function Zn(e,t,n,a,s,i){const r=AbortSignal.timeout(me);let o;try{o=await fetch(Xn(e,t,n,a,s),{signal:i?AbortSignal.any([i,r]):r})}catch(l){throw r.aborted?new Error(`timed out after ${me/1e3} s`):l}if(!o.ok){const l=await o.text().catch(()=>"");throw new Error(`Adzuna search failed (${o.status}): ${l.slice(0,300)}`)}const u=(await o.json()).results.map(l=>{var g,h;return{title:l.title,company:((g=l.company)==null?void 0:g.display_name)??"",location:((h=l.location)==null?void 0:h.display_name)??"",url:l.redirect_url,salary:Kn(l.salary_min,l.salary_max),snippet:(l.description??"").slice(0,300),postedAt:l.created??"",source:"adzuna",tag:e}});return ie(u)}async function ea(e,t,n,a=1,s,i){var f;const r=C(e),o=e.tags&&e.tags.length>0?e.tags:r.length>0?r:[e.what],c=Math.max(((f=e.grades)==null?void 0:f.length)??0,1),u=Math.max(1,Math.floor(Qn/c)),l=Dn(o.slice(0,u),e.grades),g=new Set,h=[],p=[];o.length>u&&p.push(`Only the first ${u} search terms were used with ${c} grades selected.`);let m=0,y=null;for(let d=0;d<l.length&&!(i!=null&&i.aborted);d++){const w=l[d];try{const I=(await Zn(w,e,t,n,a,i)).filter(T=>!g.has(T.url));for(const T of I)g.add(T.url);h.push(...I),I.length>0&&(s==null||s(I))}catch(b){m++,y??(y=b),p.push(`"${w}" — ${b instanceof Error?b.message:"search failed"}`)}d<l.length-1&&await Wn(zn)}if(m===l.length&&y)throw y;return{results:h,warnings:p}}const ta=new Set(["AT","AU","BE","BR","CA","CH","DE","ES","FR","GB","IN","IT","MX","NL","NZ","PL","RU","SG","US","ZA"]);function na(e){var n;const t=(n=U(e))==null?void 0:n.toUpperCase();return t&&ta.has(t)?t.toLowerCase():"us"}const aa="https://api.theirstack.com/v1/jobs/search",sa=10,ye=25,ia=14,ra=3,oa=8,we=2e4,ee="theirstackState",ca={student:["junior"],junior:["junior"],middle:["mid_level"],senior:["senior"],lead:["staff","senior"]};function la(e,t=""){var s;const n=jt(e);return((n?U(n):U(((s=e.split(",").pop())==null?void 0:s.trim())??""))||U(t)||"").toUpperCase()}const ua=[[/^(münchen|munich)$/i,"münchen|munich"],[/^(köln|cologne)$/i,"köln|cologne"],[/^(nürnberg|nuremberg)$/i,"nürnberg|nuremberg"],[/^(hannover|hanover)$/i,"hannover|hanover"],[/^(wien|vienna)$/i,"wien|vienna"],[/^(zürich|zurich)$/i,"zürich|zurich"]];function pa(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function da(e){const t=qt(e);if(!t||U(t))return"";const n=ua.find(([a])=>a.test(t));return n?n[1]:pa(t.toLowerCase())}function ha(e,t){const n=C(e).slice(0,oa),a=[...new Set((e.grades??[]).flatMap(r=>ca[r]??[]))],s=e.remoteOnly?"":da(e.where),i=Dt(e.negative??"").filter(r=>/^[\p{L}\p{N} +#.-]+$/u.test(r));return{...n.length?{job_title_or:n}:{},posted_at_max_age_days:ia,is_closed:!1,property_exists_or:["final_url"],easy_apply_or_null:!1,...t.countryCode?{job_country_code_or:[t.countryCode]}:{},...s?{job_location_pattern_or:[s]}:{},...e.remoteOnly?{workplace_types_or:["remote"]}:{},...a.length?{job_seniority_or:a}:{},...Ft(e.negative)?{company_type:"direct_employer"}:{},...i.length?{job_title_not:i}:{},...t.excludeIds.length?{job_id_not:t.excludeIds}:{},order_by:[{field:"date_posted",desc:!0}],include_total_results:!1,limit:t.limit,page:0}}function Q(e){if(!e)return"";try{const t=new URL(e.trim());return t.protocol==="https:"||t.protocol==="http:"?t.toString():""}catch{return""}}function fa(e){var s;if((s=e.salary_string)!=null&&s.trim())return e.salary_string.trim();const t=e.min_annual_salary??e.max_annual_salary,n=e.max_annual_salary??e.min_annual_salary;if(!t&&!n)return"";const a=je({low:Math.round(t??0),high:Math.round(n??0)});return e.salary_currency?`${a} ${e.salary_currency}`:a}function ga(e){var i;const t=Q(e.final_url),n=Q(e.url)||Q(e.source_url),a=t||n,s=(e.description??"").replace(/[#*_`>]+/g," ").replace(/\s+/g," ").trim();return{title:(e.job_title??"").trim(),company:(((i=e.company_object)==null?void 0:i.name)??e.company??"").trim(),location:(e.short_location??e.location??e.country??"").trim()||(e.remote?"Remote":""),url:a,salary:fa(e),snippet:s.slice(0,300),postedAt:e.date_posted??"",source:"theirstack",sourceIds:{theirstack:String(e.id)},...t&&n&&n!==t?{boardUrl:n}:{},...t?{}:{boardOnly:!0}}}function be(e=new Date){return e.toISOString().slice(0,10)}async function ma(){try{const e=(await chrome.storage.local.get(ee))[ee];return{seen:Array.isArray(e==null?void 0:e.seen)?e.seen.filter(t=>typeof t=="number"):[],day:(e==null?void 0:e.day)??"",credits:(e==null?void 0:e.credits)??0}}catch{return{seen:[],day:"",credits:0}}}async function ya(e){await chrome.storage.local.set({[ee]:{...e,seen:e.seen.slice(-2e3)}}).catch(()=>{})}function wa(e=[]){return e.map(t=>{var n;return Number((n=t.sourceIds)==null?void 0:n.theirstack)}).filter(t=>Number.isInteger(t)&&t>0)}async function rt(e,t,n={}){const a=n.now??new Date,s=await ma();s.day!==be(a)&&Object.assign(s,{day:be(a),credits:0});const i=ye-s.credits;if(i<=0)return{results:[],credits:0,warnings:[`TheirStack skipped: today's budget of ${ye} credits is used up (it resets at 00:00 UTC).`]};const r=la(e.where,n.profileCountry);if(!r&&!e.remoteOnly)return{results:[],credits:0,warnings:["TheirStack skipped: set a country or city in the location, so it doesn't pay for jobs elsewhere."]};const o=[...new Set([...s.seen,...wa(n.exclude)])].slice(-2e3),c=ha(e,{countryCode:r,limit:Math.min(sa,i),excludeIds:o}),u=AbortSignal.timeout(we);let l;try{l=await fetch(aa,{method:"POST",headers:{Authorization:`Bearer ${t}`,"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(c),signal:n.signal?AbortSignal.any([n.signal,u]):u})}catch(p){throw u.aborted?new Error(`TheirStack timed out after ${we/1e3} s`):p}if(!l.ok){const p=await l.text().catch(()=>""),m=l.status===401?" (check the API key)":l.status===402?" (out of API credits)":l.status===429?" (rate limit — the free plan allows 10 requests a minute)":"";throw new Error(`TheirStack ${l.status}${m}${p?`: ${p.slice(0,200)}`:""}`)}const g=(await l.json()).data??[];return s.credits+=g.length,s.seen=[...new Set([...s.seen,...g.map(p=>p.id).filter(p=>Number.isInteger(p))])],await ya(s),{results:ie(g.map(ga).filter(p=>p.url&&p.title),a).filter(p=>!Ut(p,n.exclude??[])),warnings:[],credits:g.length}}const ba={type:"object",additionalProperties:!1,required:["what","where"],properties:{what:{type:"string"},where:{type:"string"}}},va=`You suggest a starting job-search query for the applicant described below.
"what" is a short role/keywords phrase (e.g. "senior backend engineer", "product designer") —
their most recent or clearly strongest role from the CV/Personal Legend. Pick ONE single title:
never join multiple roles or technologies with "/", "," or parentheses (e.g. never "Full-Stack
Developer / Backend Engineer (Go, Python, React)") — that reads as a combined AND-match to a
literal keyword search and returns nothing. "where" is a location (city, region, or country) —
their stated city/country if given, else "".
Output only the two fields, no explanation.`;async function Ea(){const{profile:e,cvText:t,personalLegend:n}=await E(),a=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:n},null,2),s=await v({schemaName:"job_search_query_suggestion",schema:ba,systemPrompt:va,userPrompt:a,parse:i=>JSON.parse(i),reasoningEffort:"low"});return{what:s.what,where:s.where||[e.city,e.country].filter(Boolean).join(", ")}}const Sa={type:"object",additionalProperties:!1,required:["tags"],properties:{tags:{type:"array",items:{type:"string"}}}},ka=`You generate keyword search tags for Adzuna's job-search API, grounded in
the candidate's real background below. Per Adzuna's own docs
(https://developer.adzuna.com/docs/search), "what" is a single literal keyword/phrase match, not
a semantic search and not a boolean query — so ONE combined tag naming several technologies or
role variants (e.g. "Full-Stack Developer / Backend Engineer (Go, Python, React)") matches
nothing. You compensate by generating a small cross-product of short, atomic tags instead, each
run as its own separate search and merged afterwards.

Method — build the tags as a cross-product, exactly like this worked example for a candidate
whose strongest stack is Go and who also does full-stack/backend work:
  golang developer, go developer, go engineer, golang engineer,
  backend engineer, backend developer, fullstack engineer, fullstack developer,
  software engineer, software developer
That is: {primary technology + its common short aliases} × {developer, engineer}, PLUS
{their role-shape words, e.g. backend / fullstack / frontend / mobile / data — whichever
genuinely apply, without a technology} × {developer, engineer}, PLUS a generic "software
developer" / "software engineer" fallback pair.

Rules:
- Base every tag on their actual, strongest-fitting technology/field from the CV/Personal
  Legend — never invent a technology, role-shape, or seniority they don't have.
- Identify the ONE primary technology (e.g. "Go") plus its common short aliases people actually
  search with (e.g. "Golang") — do not alias unrelated technologies together.
- Each tag pairs exactly one technology-or-role-shape word with exactly one of "developer" /
  "engineer" (add "programmer" only if that's a genuinely common term for that stack). Never put
  two technologies, or a technology and a role-shape, in the same tag.
- If the CV shows a clear secondary technology/stack, budget permitting, add its own couple of
  tags the same way — still never combined with the primary one in a single tag.
- For EACH language listed in "languages" below (skip English), also include ONE of the
  strongest-technology tags translated into that language using the natural job-title term a
  native speaker would search with (not a literal word-for-word translation).
- Each tag is 1-3 words, lowercase, and never contains "/", ",", "(", ")", or a seniority
  qualifier ("senior", "junior", etc.).
- Deduplicate. Return 6-12 tags total, most relevant first.
- Output only the tags, no explanation.`;async function Ta(){const{profile:e,cvText:t,personalLegend:n,languageLevels:a}=await E(),s=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:n,languages:a.map(r=>r.language)},null,2);return(await v({schemaName:"job_search_tags",schema:Sa,systemPrompt:ka,userPrompt:s,parse:r=>JSON.parse(r),reasoningEffort:"low"})).tags.map(r=>r.trim()).filter(Boolean)}const _a=4;function Ia(e){return JSON.stringify([e.profile.city,e.profile.country,e.cvText,e.personalLegend,e.languageLevels.map(t=>t.language)])}async function La(e){const t=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(e));return[...new Uint8Array(t)].map(n=>n.toString(16).padStart(2,"0")).join("")}async function ce(e){var o;const t=await La(Ia(await E())),n=await P("jobSearchSuggestionCache")??[],a=n.find(c=>c.key===t);if(a&&(!e||a.tags))return{what:a.what,where:a.where,tags:a.tags,cached:!0};const[s,i]=await Promise.all([a?{what:a.what,where:a.where}:Ea(),e?Ta():Promise.resolve(void 0)]),r={key:t,...s,tags:i!=null&&i.length?i:a==null?void 0:a.tags};return(r.what||(o=r.tags)!=null&&o.length)&&await X("jobSearchSuggestionCache",[r,...n.filter(c=>c.key!==t)].slice(0,_a)),{what:r.what,where:r.where,tags:r.tags,cached:!1}}async function G(e,t){var i;const n=performance.now(),a=await ce(!0);e.push({label:a.cached?`${t} (cached)`:t,ms:performance.now()-n});const s=qe((i=a.tags)!=null&&i.length?a.tags:[a.what]);if(s.length===0)throw new Error("Couldn't derive search terms from your CV — type a few search terms.");return{what:a.what,where:a.where,terms:s}}const Y={jobsuche:{label:"Arbeitsagentur",maxPage:Vt,origin:Be,run:(e,t,n)=>Je({...e,terms:t.terms},t.page,{exclude:n.excludeResults,onResults:n.onResults,signal:n.signal})},theirstack:{label:"TheirStack",maxPage:ra,run:(e,t,n)=>rt({...e,terms:t.terms},t.creds.theirstackApiKey,{profileCountry:t.profileCountry,exclude:n.excludeResults,signal:n.signal})},loopcv:{label:"LoopCV",maxPage:1,origin:re,run:(e,t,n)=>Ge({...e,terms:t.terms},t.creds.loopcvApiKey,{page:t.page,profileCountry:t.profileCountry,exclude:n.excludeResults,signal:n.signal})}},Aa={[Be]:"rest.arbeitsagentur.de",[re]:"b2b-api.loopcv.com"};async function Ca(e,t={}){const[n,a,s]=await Promise.all([Jt().catch(()=>null),R().catch(()=>null),j().catch(()=>null)]),i=(a==null?void 0:a.country)??"",r=[];return e.provider!=="jobsuche"&&(t.jobsuche??(n==null?void 0:n.jobsucheEnabled)??!0)&&De(e.where,i)&&r.push(Y.jobsuche),e.provider!=="theirstack"&&(s!=null&&s.theirstackApiKey)&&(t.theirstack??(n==null?void 0:n.theirstackEnabled)??!0)&&r.push(Y.theirstack),e.provider!=="loopcv"&&(s!=null&&s.loopcvApiKey)&&(t.loopcv??(n==null?void 0:n.loopcvEnabled)??!0)&&r.push(Y.loopcv),r.length===0||!s?ot(e,t):Oa(e,t,r,{profileCountry:i,creds:s})}async function Oa(e,t,n,a){var g;const s=t.page??1;let i=null;const r=()=>i??(i=(async()=>{var p;const h=(p=e.tags)!=null&&p.length?e.tags:C(e);return qe(h.length>0?h:(await ce(!0)).tags??[])})()),o=async h=>{const p=performance.now();if(s>h.maxPage)return{side:h,results:[],warnings:[],ms:0};if(h.origin&&!await Fe(h.origin))return{side:h,results:[],warnings:[`${h.label} skipped: allow Filler to reach ${Aa[h.origin]} (Settings → Job search).`],ms:0};try{const m=await h.run(e,{page:s,terms:await r(),...a},t);return{side:h,...m,ms:performance.now()-p}}catch(m){return{side:h,results:[],warnings:[`${h.label} — ${m instanceof Error?m.message:"search failed"}`],ms:performance.now()-p}}},[c,...u]=await Promise.all([ot(e,t),...n.map(o)]),l=[...c.warnings??[]];for(const h of u)h.ms>0&&c.stages.push({label:`${h.side.label} search`,ms:h.ms}),l.push(...h.warnings),h.side!==Y.jobsuche&&h.results.length>0&&((g=t.onResults)==null||g.call(t,h.results));return{...c,results:Yt(c.results,...u.map(h=>h.results)),...l.length?{warnings:l}:{}}}async function ot(e,t){var l,g,h;const n=performance.now(),a=[],s=()=>({totalMs:performance.now()-n,stages:a});if(e.provider==="jobsuche"){const p=await R().catch(()=>null);let m=e;if(C(m).length===0){const d=await G(a,"Suggest terms");m={...m,terms:d.terms,where:m.where.trim()||d.where}}if(!De(m.where,(p==null?void 0:p.country)??""))throw new Error("The Arbeitsagentur only lists jobs in Germany — set the location to Germany or a German city.");if(!await Gt())throw new Error("Allow Filler to reach rest.arbeitsagentur.de first (Settings → Job search).");const{results:y,warnings:f}=await B(a,"Arbeitsagentur search",()=>Je(m,t.page??1,{exclude:t.excludeResults,onResults:t.onResults,signal:t.signal}));return{results:y,resolvedQuery:m,...f.length?{warnings:f}:{},...s()}}if(e.provider==="theirstack"||e.provider==="loopcv"){const[p,m]=await Promise.all([j(),R().catch(()=>null)]),y=e.provider==="theirstack"?p.theirstackApiKey:p.loopcvApiKey,f=e.provider==="theirstack"?"TheirStack":"LoopCV";if(!y)throw new Error(`Add your ${f} API key in Settings first.`);if(e.provider==="loopcv"&&!await Fe(re))throw new Error("Allow Filler to reach b2b-api.loopcv.com first (Settings → Job search).");let d=e;if(C(d).length===0){const T=await G(a,"Suggest terms");d={...d,terms:T.terms,where:d.where.trim()||T.where}}const w={profileCountry:(m==null?void 0:m.country)??"",exclude:t.excludeResults,signal:t.signal},{results:b,warnings:I}=await B(a,`${f} search`,()=>e.provider==="theirstack"?rt(d,y,w):Ge(d,y,{...w,page:t.page??1}));return b.length>0&&((l=t.onResults)==null||l.call(t,b)),{results:b,resolvedQuery:d,...I.length?{warnings:I}:{},...s()}}if(e.provider==="adzuna"){const[p,m]=await Promise.all([j(),R()]);if(!p.adzunaAppId||!p.adzunaAppKey)throw new Error("Add your Adzuna app_id and app_key in Settings first.");let y=e;if(!((g=y.tags)!=null&&g.length)){const w=C(y);if(w.length>0)y={...y,tags:w};else{const b=await G(a,"Suggest tags");y={...y,what:b.what,where:y.where.trim()||b.where,tags:b.terms}}}const{results:f,warnings:d}=await B(a,"Adzuna search",()=>ea(y,{appId:p.adzunaAppId,appKey:p.adzunaAppKey},na(m.country),t.page??1,t.onResults,t.signal));return{results:f,resolvedQuery:y,warnings:d,...s()}}const[i,r]=await Promise.all([Ne(),j()]),o=(i==null?void 0:i.content)??"";if(e.provider==="tavily"){if(!r.tavilyApiKey)throw new Error("Add your Tavily API key in Settings first.");let p=e;if(C(p).length===0){const f=await G(a,"Suggest terms");p={...p,terms:f.terms,where:p.where.trim()||f.where}}const{results:m,warnings:y}=await Bt(p,r.tavilyApiKey,o,t.excludeResults,a,t.signal,t.page??1);return m.length>0&&((h=t.onResults)==null||h.call(t,m)),{results:m,resolvedQuery:p,...y.length?{warnings:y}:{},...s()}}const{results:c,warnings:u}=await Hn(e,o,t.excludeResults,a,t.onResults,t.signal);return{results:c,resolvedQuery:e,...u.length?{warnings:u}:{},...s()}}const Ra={type:"object",additionalProperties:!1,required:["keyRequirements","relevantExperienceHints","suggestedTone","suggestedFocus"],properties:{keyRequirements:{type:"array",items:{type:"string"}},relevantExperienceHints:{type:"array",items:{type:"string"}},suggestedTone:{type:"string"},suggestedFocus:{type:"string"}}};async function Pa(e){return v({schemaName:"job_analysis",schema:Ra,model:await Ye(),systemPrompt:"You analyze job postings for a job-application assistant. Identify the most important requirements and what an applicant should emphasize. Do not invent details that are not present in the posting.",userPrompt:JSON.stringify(e,null,2),parse:t=>JSON.parse(t)})}const xa=`You write tailored cover letters for job applications.

The user message holds the applicant's data as JSON, and may end with an
"Applicant's rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and
   Personal Legend. Never invent experience, technologies, companies,
   education, or achievements, even if the applicant's rules ask for them.
   If information needed to be compelling is missing, write around it
   honestly rather than fabricating it.
2. The applicant's rules. Follow every instruction there on tone, length,
   structure, language, and what to include or avoid, including where it
   departs from the defaults below. Every rule there applies to the whole
   letter, not just the opening.
3. Language. If "postingLanguage" is given, write the entire letter in that
   language, using the salutation, register, and closing conventions native
   speakers of it would expect on a job application (e.g. formal
   "Sie"/"Herr"/"Frau" address and a "Sehr geehrte(r) ..." opening in German,
   not a literal English-to-German translation).
4. The house style below. Its "no exceptions" means no exceptions of your
   own; an explicit applicant rule still overrides it.
5. Tone and emphasis tailored to the job analysis provided.

Output plain prose paragraphs, no markdown headers.

${A}`;async function Na(e,t){const a=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,analysis:e.analysis,postingLanguage:e.postingLanguage||void 0},null,2)+ct(e.generationRules),s=await Ht(xa,a,t??(()=>{}));return k(s)}function ct(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const le={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},lt={type:"object",additionalProperties:!1,required:["subject","body"],properties:{subject:{type:["string","null"]},body:{type:"string"}}},Ma=`You are a sharp human editor cleaning up a cover letter draft.

Fix ONLY the flagged AI-writing patterns listed below. Make the minimum
effective edit — do not rewrite sentences that were not flagged, do not
change facts, experience, technologies, or claims, and do not add new
content. Replace banned words/clichés with plain, concrete language.
Rewrite "not X, it's Y" contrasts as a direct statement of Y. Cut
throat-clearing openers, weasel attribution, and importance-puffery instead
of softening them. If the ending is a generic summary/recap, end on the
letter's last concrete point instead. Replace every em dash ("—") with a
comma, a period, or parentheses.

The user message may end with the applicant's own rules for the letter. If a
flagged pattern is something those rules explicitly ask for, leave it as is:
the applicant's rules outrank the house style.

Do not introduce any new AI-slop while editing. For reference, the full
house style is:

${A}

Output plain prose paragraphs, no markdown headers.`;async function $a(e,t,n=""){const a=JSON.stringify({draft:e,flaggedPatterns:t.map(i=>`${i.pattern}: "${i.match}"`)},null,2)+ct(n),s=await v({schemaName:"cover_letter_polish",schema:le,systemPrompt:Ma,userPrompt:a,parse:i=>JSON.parse(i)});return k(s.content)}const Ua=["delve","foster","leverage","utilize","facilitate","empower","streamline","robust","cutting-edge","paradigm shift","game changer","this is huge","this changes everything","tapestry","realm","beacon","multifaceted","meticulous","intricate","paramount","transformative","elevate","embark","supercharge","harness","ever-evolving"],ja=["it's worth noting","it is worth noting","it's important to note","it is important to note","at the end of the day","when it comes to","at its core","in today's world","in the age of","in the world of","the reality is","the truth is","in terms of","with regard to","in order to","going forward"],Da=["here's the thing","here's what i mean","let me be clear","i'll be honest","the uncomfortable truth is"],Fa=["this is the part most people skip","what most people get wrong","here's what nobody tells you","the part everyone misses"],qa=["stands as a testament","marks a pivotal moment","plays a vital role","solidifies its position","underscores its significance"],Ja=["experts agree","industry reports suggest","many argue","widely regarded as","studies show"],Ga=[/^in conclusion\b/i,/^ultimately\b/i,/^overall\b/i];function Ba(e){const t=e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`\\b${t.replace(/ /g,"\\s+")}\\b`,"i")}function x(e,t,n){const a=[];for(const s of t){const i=Ba(s).exec(e);i&&a.push({pattern:n,match:i[0]})}return a}function Ya(e){const t=/\b(?:isn'?t|is not)\b[^.!?]{3,60}[,.]?\s*(?:it'?s|it is)\b[^.!?]{3,80}[.!?]/i,n=/\bnot just\b[^.!?]{3,60}(?:\bbut\b|[,.]?\s*(?:it'?s|it is)\b)[^.!?]{0,80}[.!?]/i,a=[],s=t.exec(e);s&&a.push({pattern:"binary-contrast",match:s[0].trim()});const i=n.exec(e);return i&&a.push({pattern:"binary-contrast",match:i[0].trim()}),a}function Va(e){const t=e.split(/\n{2,}/).map(a=>a.trim()).filter(Boolean),n=t[t.length-1];if(!n)return[];for(const a of Ga)if(a.test(n))return[{pattern:"summary-recap-ending",match:n.slice(0,60)}];return[]}function Ha(e){const t=(e.match(/—/g)??[]).length;return t===0?[]:[{pattern:"em-dash",match:t===1?"1 em dash":`${t} em dashes`}]}function Ka(e){return[...x(e,Ua,"banned-word"),...x(e,ja,"empty-phrase"),...x(e,Da,"throat-clearing-opener"),...x(e,Fa,"faux-insight-setup"),...x(e,qa,"importance-puffery"),...x(e,Ja,"weasel-attribution"),...Ya(e),...Va(e),...Ha(e)]}async function Wa(e,t,n){const a=await E(),s=await Pa(e),i=await Na({profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,generationRules:a.generationRules,job:e,analysis:s,postingLanguage:t},n),r=Ka(i);return r.length===0?{content:i,slopFindings:r,cleaned:!1}:{content:await $a(i,r,a.generationRules),slopFindings:r,cleaned:!0}}const za=`You write a short outreach message an applicant sends to a named
recruiter/hiring contact BEFORE or alongside applying, to start a conversation about a specific
job posting — not a cover letter, and not addressed to "the hiring team".

The user message holds the applicant's data as JSON ("contact" is the email address or LinkedIn
URL found on the posting, "channel" is "email" or "linkedin"), and may end with an "Applicant's
rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and Personal Legend. Never
   invent experience, technologies, companies, education, or achievements.
2. The applicant's rules. Follow every instruction there on tone, length, structure, language,
   and what to include or avoid, including where it departs from the defaults below.
3. Language. If "postingLanguage" is given, write the entire message in that language, using
   the salutation and register native speakers of it would expect.
4. Channel. If "channel" is "email", write a short email: "subject" is REQUIRED, never null or
   empty: a specific, non-generic subject line under 80 characters that names the role and the
   company (and, if it fits, the applicant's strongest match), in the message's language. "body"
   opens with a greeting and closes with a signature using the applicant's name; it does not
   repeat the subject. If "channel" is "linkedin", write a LinkedIn connection/message note
   instead: "subject" is null, "body" has no email greeting/signature and stays under LinkedIn's
   informal register.
5. The house style below. Its "no exceptions" means no exceptions of your own; an explicit
   applicant rule still overrides it.

Defaults (apply unless the applicant's rules say otherwise): under 120 words, state who the
applicant is and the one or two things that make them a fit for THIS role, and end with a clear,
low-pressure ask (a quick chat, or just flagging interest before applying). Never sound like a
mass-sent template.

${A}`;async function Qa(e){const n=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,contact:e.contact,channel:de(e.contact)?"email":"linkedin",postingLanguage:e.postingLanguage||void 0},null,2)+Xa(e.outreachRules),a=await v({schemaName:"outreach_message",schema:lt,model:await Ve(),systemPrompt:za,userPrompt:n,parse:s=>JSON.parse(s)});return{subject:de(e.contact)?ut(a.subject,e.job):null,body:k(a.body)}}function ut(e,t){const n=k((e??"").replace(/^\s*subject\s*:\s*/i,"").replace(/\s+/g," ").trim());if(n)return n;const a=t.position.trim(),s=t.company.trim();return a&&s?`${a} at ${s}`:a||s||"Job application"}function Xa(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const pt={type:"array",items:{type:"object",additionalProperties:!1,required:["text","kind","matchesProfile"],properties:{text:{type:"string"},kind:{type:"string",enum:["hard","soft"]},matchesProfile:{type:"boolean"}}}};function ue(e){return`KEYWORDS
- Pick the SKILLS the posting asks for, and nothing else. Each one is either:
  - "hard": a technical skill, tool, technology, programming language, framework, platform,
    method or domain expertise (e.g. "TypeScript", "Kubernetes", "C++", ".NET", "CI/CD",
    "SQL", "machine learning", "financial modelling", "Figma", "Scrum");
  - "soft": a real interpersonal/working skill (e.g. "communication", "mentoring",
    "stakeholder management", "problem-solving", "ownership").
- NEVER return anything that is not a skill. In particular, never return:
  - the company name, its products' brand names used as a name, or any other organization;
  - cities, countries, regions, addresses, time zones;
  - work modes and contract terms ("remote", "hybrid", "on-site", "full-time", "contract");
  - benefits and pay ("salary", "equity", "health insurance", "30 days vacation", "bonus");
  - job titles and seniority ("Senior Backend Engineer", "Team Lead", "junior");
  - years of experience, degrees, certificates as such ("5+ years", "Bachelor's degree");
  - spoken languages ("English", "German") — those are reported separately above;
  - generic words ("team", "experience", "work", "product", "environment", "opportunity",
    "fast-paced environment", "passion").
- Every keyword's "text" MUST be copied VERBATIM from ${e} — the exact same characters
  and casing, not a paraphrase, synonym, or translation — because the extension re-finds this
  exact text on the page to highlight it. A keyword that doesn't appear verbatim is useless.
- Prefer short phrases: single words or 2-3 word phrases, never sentences.
- Return up to 15, most important first. Fewer is fine: return an empty array rather than
  padding the list with anything from the NEVER list above.
- No duplicates, and no two keywords where one is a substring of the other (keep the more
  specific/longer one).
- Set "matchesProfile" to true when the applicant's profile/cvText/personalLegend shows they
  already have, use, or meet that skill — false when the posting asks for it but nothing in
  the applicant's material supports it. Judge substance, not exact wording (e.g.
  "Kubernetes" counts as a match if the CV mentions "container orchestration with K8s" or
  "EKS"). When genuinely unsure, set it to false — this flags a possible gap for the
  applicant to address rather than silently hiding it.`}const Za=new Set(["team","teams","experience","work","job","role","position","company","candidate","opportunity","environment","product","products","customer","customers","client","clients","project","projects","skills","knowledge","ability","responsibilities","requirements","tasks","career","growth","culture","mission","vision","values","impact","passion","motivation","startup","scale-up","industry","business","fast-paced environment","dynamic environment","nice to have","must have","plus","years","year","years of experience","professional experience","work experience","degree","bachelor","bachelor's degree","master","master's degree","university degree","diploma","phd","intern","internship","junior","middle","mid-level","senior","lead","principal","staff","head","manager","remote","fully remote","remote work","hybrid","on-site","onsite","office","in office","home office","homeoffice","relocation","visa sponsorship","full-time","full time","part-time","part time","contract","freelance","permanent","temporary","salary","competitive salary","bonus","equity","stock options","esop","benefits","vacation","paid time off","pto","holidays","health insurance","insurance","pension","gym","gym membership","free lunch","snacks","flexible hours","flexible working hours","learning budget","parental leave","erfahrung","berufserfahrung","aufgaben","anforderungen","unternehmen","vollzeit","teilzeit","festanstellung","gehalt","urlaub","vertrag","büro","mobiles arbeiten","команда","опыт","опыт работы","работа","компания","проект","проекты","задачи","требования","обязанности","удаленно","удаленка","удаленная работа","гибрид","офис","полный день","полная занятость","частичная занятость","зарплата","оклад","бонусы","дмс","отпуск","релокация"]),es=new Set(Kt.map(e=>L(e))),ts=new RegExp("\\s*,?\\s*(?<![\\p{L}\\p{N}])(?:inc|ltd|llc|gmbh|ag|se|kg|ug|bv|nv|sa|sas|srl|plc|corp|corporation|co|company|oy|ab|as|ооо|ао)\\.?$","iu");function L(e){return e.normalize("NFC").toLowerCase().replace(/ё/g,"е").replace(/[’`]/g,"'").replace(/^[\s"'«».,:;!?()[\]-]+|[\s"'«».,:;!?()[\]-]+$/g,"").replace(/\s+/g," ")}function ns(e){const t=L(e);if(!t)return[];const n=L(t.replace(ts,""));return n&&n!==t?[t,n]:[t]}function as(e){const t=L(e);if(!t)return[];const n=e.split(/[,/|·•()]/).map(L).filter(Boolean);return[t,...n]}function ss(e){return L(e.replace(/\((?:[mwfdx]\s*\/\s*)+[mwfdx]\)/gi,""))}const is=/^\d+(?:\s*[-–+]\s*\d*)?\+?\s*(?:years?|yrs?|jahre?n?|лет|года?|ans|años)(?![\p{L}\p{N}])/iu;function te(e,t){const n=e.trim();if([...n].length<2)return!new RegExp("^\\p{Lu}$","u").test(n);if(!new RegExp("\\p{L}","u").test(n)||/[$€£¥₽%]/u.test(n))return!0;const a=L(n);return!a||Za.has(a)||es.has(a)||is.test(a)||ns(t.company).includes(a)||as(t.location).includes(a)?!0:a===ss(t.position)}function pe(e,t){const n=new Set;return e.filter(a=>{const s=L(a.text);return n.has(s)||te(a.text,t)?!1:(n.add(s),!0)})}function rs(e,t){var s;const n=(s=e.match(/\s*[,;|·•]\s*/u))==null?void 0:s[0];if(!n)return te(e,t)?"":e;const a=new Set;return e.split(/\s*[,;|·•]\s*/u).filter(i=>{const r=L(i);return!i.trim()||a.has(r)||te(i,t)?!1:(a.add(r),!0)}).join(n)}const dt={postingLanguages:{type:"array",items:{type:"string"}},languageRequirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...Ke,null]}}}},keywords:pt},os={type:"object",additionalProperties:!1,required:["company","position","location","description","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},description:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...dt}},ht=`LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- languageRequirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or "Native"
  for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent", "professional
  working proficiency" -> "C1"; "conversational" -> "B1". If a language is mentioned but no level
  can be reasonably inferred, set level to null. Do not invent a requirement that isn't stated in
  the text. If nothing is stated, return an empty array.`,cs=`You read the visible text of a job-posting page and do two things with it
in one pass: extract the structured posting fields, and analyze the result for language and
keywords — against the applicant profile/CV/Personal Legend given below.

EXTRACTION
- Only use information present in "pageText"; leave a field empty/null if unknown.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- For "contact", prefer a named recruiter/hiring manager's email address or LinkedIn
  profile/company URL if one is mentioned, copied VERBATIM (exact characters); otherwise null.

${ht}

${ue('"pageText"')}`;async function ls(e,t){const n=await E(),a=JSON.stringify({profile:n.profile,cvText:n.cvText,personalLegend:n.personalLegend,pageText:e.slice(0,12e3)},null,2),s=await v({schemaName:"job_extraction_and_brief",schema:os,model:await He(),reasoningEffort:"low",systemPrompt:cs,userPrompt:a,parse:o=>JSON.parse(o)}),i={company:s.company,position:Wt(s.position),location:s.location,description:s.description,requirements:s.requirements,responsibilities:s.responsibilities,salary:s.salary,techStack:s.techStack,contact:s.contact,url:t},r={language:{postingLanguages:s.postingLanguages,requirements:s.languageRequirements},keywords:pe(s.keywords,i),contact:null};return{job:i,brief:r}}const us={type:"object",additionalProperties:!1,required:["company","position","location","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...dt}},ps=`You read the visible text of a job-posting page. It was already parsed
without AI: "knownFields" holds what that found. Fill in what it missed, and analyze the posting
for language and keywords — against the applicant profile/CV/Personal Legend given below.

FIELDS
- Fill only the fields named in "fieldsToFill". For every other posting field return "" / [] /
  null — those are kept from the page as they are. Never re-type the posting's description.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- company: the hiring company, not the job board or recruiting platform hosting the page.
- location: as written in the posting; "" if none.
- requirements, responsibilities: at most 8 items each, each a short phrase (12 words or fewer),
  not copied paragraphs.
- techStack: technology names only.
- contact: a named recruiter/hiring manager's email address or LinkedIn profile/company URL,
  copied VERBATIM (exact characters); otherwise null.
- Only use information present in "pageText"; leave a field empty/null if unknown.

${ht}

${ue('"pageText"')}`;async function ds(e,t){const n=await E(),a=zt(e),s=t||e.description,i=JSON.stringify({profile:n.profile,cvText:n.cvText,personalLegend:n.personalLegend,knownFields:{position:e.position,company:e.company,location:e.location,salary:e.salary,contact:e.contact},fieldsToFill:a,pageText:s.slice(0,12e3)},null,2),r=await v({schemaName:"job_completion_and_brief",schema:us,model:await He(),reasoningEffort:"low",systemPrompt:ps,userPrompt:i,parse:u=>JSON.parse(u)}),o=Qt(e,r,a,s),c={language:{postingLanguages:r.postingLanguages,requirements:r.languageRequirements},keywords:pe(r.keywords,o),contact:null};return{job:o,brief:c}}const hs=`You are editing an existing cover letter draft on the applicant's
instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the
  letter the instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements
  that aren't already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the
  instruction explicitly asks to change it.
- Output plain prose paragraphs, no markdown headers.
- Don't introduce AI-slop while editing, and clean it from any sentence you
  touch.

${A}`;async function fs(e,t,n){const a=JSON.stringify({draft:e,instructions:t,job:n},null,2),s=await v({schemaName:"cover_letter_revision",schema:le,model:await Xt(),systemPrompt:hs,userPrompt:a,parse:i=>JSON.parse(i)});return k(s.content)}const gs=`You are editing an existing outreach message (an email or LinkedIn note
to a recruiter/hiring contact) on the applicant's instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the message the
  instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements that aren't
  already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the instruction explicitly
  asks to change it.
- If the draft's "subject" is null, keep it null (it's a LinkedIn note). Otherwise keep a
  specific subject line, changing it only if the instruction (or the edit) requires it.
- Don't introduce AI-slop while editing, and clean it from any sentence you touch.

${A}`;async function ms(e,t,n){const a=JSON.stringify({draft:e,instructions:t,job:n},null,2),s=await v({schemaName:"outreach_message_revision",schema:lt,model:await Ve(),systemPrompt:gs,userPrompt:a,parse:i=>JSON.parse(i)});return{subject:e.subject===null?null:ut(s.subject||e.subject,n),body:k(s.body)}}const ys=`You translate a cover letter for the applicant's own understanding —
not for submission. Translate faithfully, preserve paragraph breaks, and keep
names, companies, and technical terms as-is where translating them would be
unnatural. Do not use em dashes ("—"); use commas or periods. Output plain
prose paragraphs, no markdown headers, no notes about the translation itself.`;async function ws(e,t){const n=JSON.stringify({content:e,targetLanguage:t},null,2),a=await v({schemaName:"cover_letter_translation",schema:le,systemPrompt:ys,userPrompt:n,parse:s=>JSON.parse(s)});return k(a.content)}const ve=new RegExp([String.raw`(?:additional|further|other|more|extra|supplementary)\s+(?:information|info|details|comments?|remarks?|notes?|thoughts)`,String.raw`anything\s+else`,String.raw`is\s+there\s+anything(?:\s+else)?`,String.raw`any(?:thing)?\s+(?:other|further|additional|final)\s+(?:comments?|remarks?|notes?|information|thoughts)`,String.raw`(?:any|final)\s+(?:comments?|remarks?|notes?|thoughts)`,String.raw`(?:a\s+)?(?:message|note)\s+(?:to|for)\s+(?:the\s+|our\s+)?(?:hiring\s+(?:team|manager)|recruit(?:er|ing\s+team|ment\s+team)|team|us|company|employer)`,String.raw`(?:weitere|zus[aä]tzliche|sonstige|erg[aä]nzende|andere)\s+(?:informationen|infos?|angaben|anmerkungen|hinweise|bemerkungen|mitteilungen|kommentare)`,String.raw`sonstiges`,String.raw`(?:m[oö]chten|willst|m[oö]chtest)\s+(?:sie|du)\s+uns\s+(?:sonst\s+)?noch\s+(?:etwas|was)`,String.raw`gibt\s+es\s+(?:sonst\s+)?noch\s+(?:etwas|was)`,String.raw`(?:nachricht|mitteilung)\s+an\s+(?:uns|das\s+team|den\s+recruiter|die\s+personalabteilung)`,String.raw`informations?\s+compl[ée]mentaires?`,String.raw`informaci[oó]n\s+adicional`,String.raw`дополнительн(?:ая|ые)\s+(?:информация|сведения|комментари[йи])`].join("|"),"iu"),bs=/^(?:your\s+|ihre?\s+|deine?\s+|persönliche\s+)?(?:messages?|comments?|remarks?|notes?|nachricht|anmerkungen?|bemerkungen?|kommentare?|hinweise?|mitteilung|commentaires?|comentarios?|комментари[йи]|сообщение)$/iu,vs=/^(?:your\s+|ihr\s+)?(?:cover\s+letter|motivation(?:al)?\s+letter|anschreiben|motivationsschreiben|lettre\s+de\s+motivation|carta\s+de\s+presentaci[oó]n|сопроводительное\s+письмо)$/iu,Es=new RegExp(String.raw`\b(?:optional|freiwillig|facultatif|opcional|необязательно|please|bitte|here|hier|you|you'?d|would|like|to|share|add|tell|let|us|know|mention|with|about|yourself|we|should|that|the|a|an|and|or|for|me|your|our|any|on|in|of|this|application|role|position|job|team|hiring|sie|du|uns|noch|etwas|was|mitteilen|teilen|sagen|zu|ihrer|ihre|deiner|bewerbung|stelle|möchten|möchtest|gibt|es|sonst|und|oder|für|die|der|das|den|dem|an|mit|über|is|there|else|do|have|want|wish|feel|free|e\.?\s?g\.?|z\.?\s?b\.?)\b`,"giu");function Ss(e){return e.replace(/[*✱:?!.…]+/g," ").replace(/\((?:optional|freiwillig|facultatif|opcional|необязательно)\)/giu," ").replace(/\s+/g," ").trim()}function ks(e,t){return e.replace(t," ").replace(/[()[\],;/\-–—"'„“”]+/g," ").replace(Es," ").split(/\s+/).filter(a=>new RegExp("\\p{L}{2}","u").test(a))}function Ts(e){const t=Ss(e);return t?vs.test(t)?"coverLetter":bs.test(t)?"weak":new RegExp(ve.source,"giu").test(t)?ks(t,new RegExp(ve.source,"giu")).length>=3?null:"strong":null:null}const _s=[/\b(?:please|kindly)\b[^.!?\n]{0,100}\b(?:mention|include|state|indicate|tell\s+us|let\s+us\s+know|add|note|specify|quote|answer)\b[^.!?\n]{0,100}\b(?:application|cover\s+letter|message|submission)\b[^.!?\n]*/iu,/\bin\s+your\s+(?:application|cover\s+letter|message)\b[^.!?\n]{0,100}\b(?:mention|include|state|tell\s+us|let\s+us\s+know|answer|describe)\b[^.!?\n]*/iu,/\b(?:code\s?word|keyword|reference\s+(?:number|code)|kennwort|kennziffer|referenznummer|stichwort)\b[^.!?\n]*/iu,/\b(?:geben|nennen|teilen|erw[aä]hnen|beantworten)\s+sie\b[^.!?\n]{0,120}\b(?:bewerbung|anschreiben|nachricht)\b[^.!?\n]*/iu,/\bin\s+ihrer\s+bewerbung\b[^.!?\n]{0,120}\b(?:an|nennen|angeben|mitteilen|erw[aä]hnen|beantworten)\b[^.!?\n]*/iu];function Ee(e){const t=[e.description??"",...e.requirements??[],...e.responsibilities??[]].join(`
`);for(const n of _s){const a=n.exec(t);if(a)return a[0].trim().slice(0,300)}return null}function Is(e,t){if(t.required===!0)return{action:"write",reason:"required",postingAsk:Ee(e)??void 0};const n=Ee(e);return n?{action:"write",reason:"posting",postingAsk:n}:t.required===!1?{action:"skip"}:{action:"write",reason:"asked"}}const Ls={type:"object",additionalProperties:!1,required:["skip","answer"],properties:{skip:{type:"boolean"},answer:{type:"string"}}},As=`You decide what, if anything, goes into the open catch-all field at the end of a
job application form ("Additional information", "Anything else you'd like to share?", "Weitere
Informationen", "Sonstiges", "Message to the hiring team"). The recruiter already has everything
in "formValues", "otherAnswers", the attached CV ("cvText"), the cover letter ("coverLetter") and
the profile. Repeating any of it wastes their time and makes the application look padded.

Rules:
- "skip": true, "answer": "" is the normal result. Choose it whenever there is nothing NEW and
  relevant to add. An empty field is fine.
- Never repeat or paraphrase: contact data (name, email, phone, address, city), links (LinkedIn,
  GitHub, portfolio, website), salary expectations, start date / notice period / availability,
  work permit / visa / relocation, language levels, a summary of the CV or the experience, or the
  motivation already given in the cover letter or other answers.
- "postingAsk" (when present) is what the job posting explicitly asks applicants to include.
  Answer exactly that, from the applicant's data, if it isn't already in the form. If the data
  doesn't have it, skip.
- "required": true means the form won't submit with the field empty. Then don't skip: write ONE
  short sentence with something new from the Personal Legend or custom fields, or, if there is
  truly nothing new, one plain neutral sentence (e.g. that you look forward to hearing from them).
- Otherwise ("required" false or unknown), write only when there is a genuinely new, relevant fact
  (e.g. a constraint the recruiter must know that appears nowhere else).
- At most 2 sentences, plain text, no greeting, no sign-off, no lists, no markdown.
- Never invent facts. Use ONLY the applicant data given.
- If "postingLanguage" is given, write in that language with its native application register.

${A}`,Cs=/\b(?:https?:\/\/|www\.)\S+|\b[\w.-]+\.(?:com|de|io|dev|net|org|me)\/\S*/i,Os=/\b[\w.+-]+@[\w-]+\.[\w.-]+\b/,Rs=/(?:\+|\b00)\d[\d\s/().-]{6,}\d|\b0\d{2,4}[\s/-]?\d{3,}[\s-]?\d{2,}\b/;function Ps(e){return e.replace(/\s+/g," ").trim().split(new RegExp("(?<=[.!?])\\s+(?=\\S)","u")).filter(n=>n&&!Cs.test(n)&&!Os.test(n)&&!Rs.test(n)).slice(0,2).join(" ").trim()}const ft="catchAllAdds";function xs(e){return{type:"predicate",name:ft,instructions:`The application form has an open catch-all field ("field"), not marked required: "Additional information", "Anything else?".
The recruiter already has the applicant's CV, cover letter, profile and every value in "formValues"
and "otherAnswers". Should the applicant write anything in it?
- Yes only if ${e?`the applicant's data covers what the posting explicitly asks applicants to include ("postingAsk") and the form doesn't already hold it, or if `:""}the applicant's data holds a genuinely NEW fact relevant to this application that appears nowhere else (e.g. a constraint the recruiter must know).
- No for anything already in the CV, cover letter, profile or form: contact data, links, salary, start date /
  notice period / availability, work permit / visa / relocation, language levels, a summary of the
  experience, the motivation.
- No when in doubt: an empty field is the normal, good outcome.`}}async function Ns(e,t,n,a){try{const s=[...e.input,{role:"user",content:[{type:"input_json",data:{formValues:(n.formValues??[]).filter(r=>r.value.trim()),otherAnswers:(n.otherAnswers??[]).filter(r=>r.answer.trim()),coverLetterAttached:n.coverLetterAttached||void 0,postingAsk:a??null,field:t}}]}],i=await N({input:s,promptCacheKey:e.promptCacheKey,questions:[xs(a)]});return Zt(i,ft)}catch(s){if(s instanceof q)throw s;return console.warn("[Filler] Decisions API failed, writing the catch-all via Responses:",s),null}}async function gt(e,t,n,a){const s=Is(t,n);if(s.action==="skip")return{answer:"",sufficientInfo:!0,skipped:!0};const[i,r]=await Promise.all([E(),P("lastCoverLetter")]);if(n.required!==!0){const l=oe(i,r??"",t,a),g=await Ns(l,e,n,s.postingAsk);if(g!==null&&g<F.catchAllWrite)return{answer:"",sufficientInfo:!0,skipped:!0}}const o=JSON.stringify({job:t,profile:i.profile,cvText:i.cvText,coverLetter:r??"",coverLetterAttached:n.coverLetterAttached||void 0,personalLegend:i.personalLegend,customFields:i.customFields,languageLevels:i.languageLevels,generationRules:i.generationRules,postingLanguage:a||void 0,formValues:(n.formValues??[]).filter(l=>l.value.trim()),otherAnswers:(n.otherAnswers??[]).filter(l=>l.answer.trim()),postingAsk:s.postingAsk,required:n.required??"unknown",question:e},null,2),c=await v({schemaName:"catch_all_answer",schema:Ls,systemPrompt:As,userPrompt:o,label:"Catch-all answer",parse:l=>JSON.parse(l)}),u=c.skip?"":Ps(k(c.answer));return u?{answer:u,sufficientInfo:!0,skipped:!1}:{answer:"",sufficientInfo:n.required!==!0,skipped:!0}}const Ms={type:"object",additionalProperties:!1,required:["answer","sufficientInfo"],properties:{answer:{type:"string"},sufficientInfo:{type:"boolean"}}},Se=`You answer a custom question from a job application form on the
applicant's behalf.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend,
  cover letter, custom fields, language levels, and job posting. Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, the
  "languageLevels" list is the authoritative answer (CEFR levels the
  applicant self-reported in Settings) — use it directly rather than
  guessing from the CV or defaulting to a low/neutral level.
- If the profile/CV/Personal Legend/etc genuinely lack what's needed to
  answer this question — not just a minor detail, but the actual substance
  being asked for — set "sufficientInfo" to false and "answer" to an empty
  string. Do NOT write a sentence explaining that you don't have the
  information (e.g. "I don't have this information available") — that text
  would otherwise get typed straight into the applicant's form field, which
  is worse than leaving it blank for the applicant to fill in themselves.
  Only do this when the information is truly absent; a question you can
  answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient —
  set sufficientInfo to true and give that honest answer.
- If "postingLanguage" is given, write the answer in that language, using
  the salutation/register conventions native speakers of it would expect on
  a job application (e.g. formal "Sie"/"Herr"/"Frau" address in German, not
  a literal English-to-German translation) — unless the question itself, or
  "generationRules", explicitly asks for a different language.
- If this question is a newsletter, marketing-email, or job-alert
  subscription opt-in phrased as a choice (e.g. "Would you like to
  subscribe to our newsletter? Yes/No"), always choose the option that
  declines it — the applicant never needs this to submit the application.
- "faq" is a set of pre-written answers to standard interview-FAQ questions
  (spec_5 section B). If the question being asked now is the same as, or a
  close variant of, one already in "faq", reuse its substance and phrasing —
  adapt only what the target field's length/format actually requires — so
  the applicant's answer stays consistent across different forms rather
  than being re-derived from scratch each time.
- Match the question's expected length: a short field gets a short answer, an
  open-ended "tell us about..." field gets a fuller one.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text, no markdown, no restating the question.

${A}`,$s=/\b(?:please\s+(?:provide|specify|clarify)|could\s+you\s+(?:please\s+)?(?:provide|clarify|specify)|i\s+(?:don'?t|do\s+not)\s+see)\b.{0,40}?\b(?:question|prompt)\b|\bno\s+(?:specific\s+)?question\s+(?:was|is)?\s*(?:provided|given|specified|attached)\b/i;function mt(e){const t=e.trim();return t?t.length<220&&$s.test(t):!0}const Us=`
- This is a MULTIPLE-CHOICE question: "options" lists the allowed answers.
  Reply with EXACTLY ONE option, copied verbatim, and nothing else.
- Base the choice on the applicant's profile/CV/Personal Legend. If the
  needed fact is genuinely absent (e.g. pronouns not stated anywhere),
  prefer a neutral option, an explicit "prefer not to say", or the option
  that commits the applicant least.`,js=`
- This is a SELECT-ALL-THAT-APPLY question: "options" lists every allowed
  answer. Reply with every option that genuinely applies, each copied
  verbatim, joined by " | " (a single pipe surrounded by one space on each
  side) — nothing else. If none apply, reply with an empty string.
- Base each choice strictly on the applicant's profile/CV/Personal Legend —
  never include an option just because it's plausible or common; only ones
  the applicant's own material actually supports.`,Ds=`
- This field only accepts a plain number: reply with digits only (a single
  "." for a decimal if needed) — no currency symbol, no thousands
  separator, no unit, no words, no range. If a range genuinely fits best
  (e.g. a salary expectation given as "65-75k"), reply with one
  representative figure (its midpoint), not the range.`;function Fs(e){return`
- This field only accepts a date in the exact format "${Ze[e]}"
  — reply with ONLY that value, nothing else (no words, no explanation).
  "todayISO" in the data below is today's date: compute the answer from it
  — e.g. "available with one month's notice" → todayISO plus one month;
  "immediately" / "as soon as possible" / no stated constraint → todayISO
  itself. Never answer with a description of the notice period or
  availability instead of the date itself.`}async function qs(e,t,n,a,s,i,r,o){if(!(n&&n.length>0)&&!a&&!s&&(o||o===void 0&&Ts(e)==="strong"))return gt(e,t,o??{},r);const[u,l]=await Promise.all([E(),P("lastCoverLetter")]),{input:g,promptCacheKey:h}=oe(u,l??"",t,r),p={question:e,options:n,multi:i,numeric:a,dateKind:s},m=Z(p);try{const y=await N({input:g,promptCacheKey:h,questions:m?We(p,0):[ze(p,0)]});if(m){const f=Qe(p,0,y);if(f)return f}else if(Xe(0,y)===!1)return{answer:"",sufficientInfo:!1}}catch(y){if(y instanceof q)throw y;console.warn("[Filler] Decisions API failed, answering via Responses:",y)}return Js(e,t,n,a,s,i,r)}async function Js(e,t,n,a,s,i,r){const[o,c]=await Promise.all([E(),P("lastCoverLetter")]),u=JSON.stringify({job:t,profile:o.profile,cvText:o.cvText,personalLegend:o.personalLegend,generationRules:o.generationRules,coverLetter:c??"",languageLevels:o.languageLevels,customFields:o.customFields,faq:o.faq.filter(p=>p.answer.trim()),todayISO:se(),postingLanguage:r||void 0,question:e,options:n&&n.length>0?n:void 0},null,2),l=[n&&n.length>0?i?js:Us:"",a?Ds:"",s?Fs(s):""].filter(Boolean),g=await v({schemaName:"custom_question_answer",schema:Ms,systemPrompt:l.length>0?[Se,...l].join(`
`):Se,userPrompt:u,parse:p=>JSON.parse(p)});return!g.sufficientInfo||mt(g.answer)?{answer:"",sufficientInfo:g.sufficientInfo}:{answer:n&&n.length>0||a||!!s?g.answer:k(g.answer),sufficientInfo:!0}}const Gs={type:"object",additionalProperties:!1,required:["questions"],properties:{questions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","question"],properties:{index:{type:"integer"},question:{type:"string"}}}}}},Bs=`You are given a block of a job-application form: its visible text, and a
list of the input fields inside it. For each field that asks the applicant
something, return the question it is asking, phrased as a plain question.

Rules:
- Use ONLY the visible text provided. Never invent a question.
- Match each question to its field by "index".
- Omit a field that is not a real question (layout helper, hidden field,
  search box, honeypot, a plain "First name"-style profile field).
- A field with "options" is a multiple-choice question — still return only
  its question text, not the options.
- Output the question text only — no numbering, no "Question:" prefix.
- Questions may be in any language; keep the form's own language.`;async function Ys(e,t){if(t.length===0)return{};const n=JSON.stringify({blockText:e.slice(0,6e3),fields:t},null,2),a=await v({schemaName:"block_questions",schema:Gs,systemPrompt:Bs,userPrompt:n,parse:i=>JSON.parse(i)}),s={};for(const i of a.questions)i.question.trim()&&(s[i.index]=i.question.trim());return s}const Vs={type:"object",additionalProperties:!1,required:["checkboxDecisions","questionAnswers"],properties:{checkboxDecisions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","check","category","reason"],properties:{index:{type:"integer"},check:{type:"boolean"},category:{type:"string",enum:["required-consent","marketing","optional","unclear"]},reason:{type:"string"}}}},questionAnswers:{type:"array",items:{type:"object",additionalProperties:!1,required:["id","answer","sufficientInfo"],properties:{id:{type:"string"},answer:{type:"string"},sufficientInfo:{type:"boolean"}}}}}},Hs=`You fill in two independent things found on a job-application form at once:
consent checkboxes to decide, and custom questions to answer on the applicant's behalf. The
applicant has already chosen to submit this application.

CHECKBOXES (one decision per item in "checkboxes", matched back by "index")

TICK (check: true) — things required to submit, or that a candidate is normally expected to
accept:
- privacy policy / data protection / GDPR / Datenschutz consent
- terms & conditions / AGB / Nutzungsbedingungen
- confirming the entered information is accurate / truthful
- consent to process and store the application data for THIS hiring process
- storing the data in a talent pool ONLY when the checkbox is marked required
- eligibility self-declarations that hold for any ordinary adult applying for a real job (e.g.
  "I am at least 18 years old", "I am legally entitled to work in [country]", "I have no
  undisclosed conflicts of interest") — assume true unless the profile/CV explicitly states
  otherwise; a genuine job applicant submitting this form is virtually always eligible, and
  leaving a required declaration like this unticked blocks submission for no real reason

DO NOT TICK (check: false) — optional and promotional:
- newsletters, marketing e-mails, "career news", event invitations
- job alerts / notifications about new postings (e.g. "Benachrichtigungen über neue
  Stellenausschreibungen erhalten")
- sharing data with third parties / partner companies for marketing
- joining a talent pool / candidate database when NOT required
- anything that benefits the applicant only beyond this one application

Rules:
- "required: true" means the form marks the field mandatory — a strong signal to tick, unless
  the text is clearly marketing.
- A newsletter/marketing-email/job-alert opt-in is NEVER ticked, even when the form marks it
  "required" — that flag is routinely misused by forms to guilt-trip applicants into
  subscribing, even though applicants never actually need it to submit. When genuinely in doubt
  whether a required checkbox is a real submission requirement or a disguised newsletter
  opt-in, prefer NOT ticking it.
- If a checkbox is ambiguous AND not required, set check: false.
- Labels may be in any language; judge by meaning, not keywords.
- category: "required-consent" (ticked, mandatory-type), "marketing" (left off), "optional"
  (non-marketing but skippable, left off unless required), "unclear" (left off). reason: one
  short phrase.
- Return one decision per input item in "checkboxes", using its "index". If "checkboxes" is
  empty, return an empty array.

QUESTIONS (one answer per item in "questions", matched back by "id")

Ground rules:
- Use ONLY facts present in the shared "profile"/"cvText"/"personalLegend"/"generationRules"/
  "coverLetter"/"languageLevels"/"customFields"/"faq" given below, plus "job". Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, "languageLevels" is the
  authoritative answer (CEFR levels the applicant self-reported in Settings) — use it directly
  rather than guessing from the CV or defaulting to a low/neutral level.
- If the shared material genuinely lacks what's needed to answer a given question — not just a
  minor detail, but the actual substance being asked for — set that item's "sufficientInfo" to
  false and "answer" to an empty string. Do NOT write a sentence explaining that you don't have
  the information — that text would otherwise get typed straight into the applicant's form
  field, which is worse than leaving it blank. Only do this when the information is truly
  absent; a question you can answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient.
- If "postingLanguage" is given, write answers in that language, using the salutation/register
  conventions native speakers of it would expect on a job application (e.g. formal
  "Sie"/"Herr"/"Frau" address in German) — unless the question itself, or "generationRules",
  explicitly asks for a different language.
- A newsletter/marketing-email/job-alert subscription opt-in phrased as a question (e.g. "Would
  you like to subscribe to our newsletter? Yes/No") always gets the option that declines it.
- "faq" is a set of pre-written answers to standard interview-FAQ questions. If a question being
  asked now is the same as, or a close variant of, one already in "faq", reuse its substance and
  phrasing — adapt only what the target field's length/format actually requires.
- Match each question's expected length: a short field gets a short answer, an open-ended
  "tell us about..." field gets a fuller one.
- Output plain text per answer, no markdown, no restating the question.
- Each item in "questions" may also carry:
  - "options" (and not "multi"): a single-choice question — reply with EXACTLY ONE option,
    copied verbatim, nothing else. If the needed fact is genuinely absent (e.g. pronouns not
    stated anywhere), prefer a neutral option or an explicit "prefer not to say".
  - "options" with "multi": true: a select-all-that-apply question — reply with every option
    that genuinely applies, each copied verbatim, joined by " | " (one pipe, one space each
    side). If none apply, reply with an empty string. Never include an option just because it's
    plausible — only ones the applicant's own material actually supports.
  - "numeric": true: the field only accepts a plain number — reply with digits only (a single
    "." for a decimal if needed), no currency symbol, no thousands separator, no unit, no words,
    no range. If a range genuinely fits best (e.g. "65-75k"), reply with one representative
    figure (its midpoint).
  - "dateFormat": the field only accepts a date in exactly that format — reply with ONLY that
    value, nothing else. "todayISO" below is today's date: compute the answer from it — e.g.
    "available with one month's notice" -> todayISO plus one month; "immediately"/"as soon as
    possible"/no stated constraint -> todayISO itself.
- Return one answer per input item in "questions", using its "id". If "questions" is empty,
  return an empty array.

${A}`;function Ks(e,t){const n=new Map;for(const a of t)n.set(a.index,a);return e.map((a,s)=>{const i=n.get(s);if(i){const r=i.check&&he(a.label)?!1:i.check;return{name:a.name,label:a.label,check:r,category:i.category,reason:i.reason}}return he(a.label)?{name:a.name,label:a.label,check:!1,category:"marketing",reason:"No decision returned — looks like a newsletter/marketing opt-in"}:{name:a.name,label:a.label,check:a.required,category:a.required?"required-consent":"unclear",reason:a.required?"Marked required by the form":"No decision returned"}})}function Ws(e,t){const n=new Map;for(const a of t)n.set(a.id,a);return e.map(a=>{const s=n.get(a.id);if(!s)return{id:a.id,answer:"",sufficientInfo:!0};if(!s.sufficientInfo||mt(s.answer))return{id:a.id,answer:"",sufficientInfo:s.sufficientInfo};const i=a.options&&a.options.length>0||a.numeric||!!a.dateKind;return{id:a.id,answer:i?s.answer:k(s.answer),sufficientInfo:!0}})}async function ke(e,t,n,a){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[s,i]=await Promise.all([E(),P("lastCoverLetter")]),r=JSON.stringify({job:n,profile:s.profile,cvText:s.cvText,personalLegend:s.personalLegend,generationRules:s.generationRules,coverLetter:i??"",languageLevels:s.languageLevels,customFields:s.customFields,faq:s.faq.filter(c=>c.answer.trim()),todayISO:se(),postingLanguage:a||void 0,checkboxes:e.map((c,u)=>({index:u,label:c.label,required:c.required,currentlyChecked:c.checked})),questions:t.map(c=>({id:c.id,question:c.question,options:c.options&&c.options.length>0?c.options:void 0,multi:c.multi,numeric:c.numeric,dateFormat:c.dateKind?Ze[c.dateKind]:void 0}))},null,2),o=await v({schemaName:"page_content_decisions",schema:Vs,systemPrompt:Hs,userPrompt:r,parse:c=>JSON.parse(c)});return{checkboxDecisions:Ks(e,o.checkboxDecisions),questionAnswers:Ws(t,o.questionAnswers)}}async function zs(e,t,n,a){const s=t.filter(l=>l.catchAll),i=s.length>0?t.filter(l=>!l.catchAll):t,r=await Qs(e,i,n,a);if(s.length===0)return r;const o=i.flatMap(l=>{var h;const g=((h=r.questionAnswers.find(p=>p.id===l.id))==null?void 0:h.answer)??"";return g?[{question:l.question,answer:g}]:[]}),c=await Promise.all(s.map(async l=>{const{answer:g,sufficientInfo:h}=await gt(l.question,n,{required:l.required??!1,formValues:l.formValues,otherAnswers:o,coverLetterAttached:l.coverLetterAttached},a);return{id:l.id,answer:g,sufficientInfo:h}})),u=new Map([...r.questionAnswers,...c].map(l=>[l.id,l]));return{checkboxDecisions:r.checkboxDecisions,questionAnswers:t.map(l=>u.get(l.id)??{id:l.id,answer:"",sufficientInfo:!0})}}async function Qs(e,t,n,a){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[s,i]=await Promise.all([E(),P("lastCoverLetter")]),{input:r,promptCacheKey:o}=oe(s,i??"",n,a),c=t.map((f,d)=>({q:f,i:d})),u=c.filter(({q:f})=>Z(f)),l=c.filter(({q:f})=>!Z(f));let g;try{g=await N({input:r,promptCacheKey:o,questions:[...en(e),...u.flatMap(({q:f,i:d})=>We(f,d)),...l.map(({q:f,i:d})=>ze(f,d))]})}catch(f){if(f instanceof q)throw f;return console.warn("[Filler] Decisions API failed, falling back to Responses:",f),ke(e,t,n,a)}const h=e.map((f,d)=>tn(f,d,g)),p=e.filter((f,d)=>!h[d]),m=new Map,y=[];for(const{q:f,i:d}of u){const w=Qe(f,d,g);w?m.set(f.id,{id:f.id,...w}):y.push(f)}for(const{q:f,i:d}of l)Xe(d,g)===!1?m.set(f.id,{id:f.id,answer:"",sufficientInfo:!1}):y.push(f);if(p.length>0||y.length>0){const f=await ke(p,y,n,a);for(const w of f.questionAnswers)m.set(w.id,w);const d=new Map(f.checkboxDecisions.map(w=>[w.name+"\0"+w.label,w]));e.forEach((w,b)=>{h[b]||(h[b]=d.get(w.name+"\0"+w.label)??null)})}return{checkboxDecisions:h.filter(f=>f!==null),questionAnswers:t.map(f=>m.get(f.id)??{id:f.id,answer:"",sufficientInfo:!0})}}const ne="(none of these)",yt="(not a profile field)",wt={salutation:"Salutation / title / gender as a form of address (Mr, Ms, Frau, Herr).",pronouns:"Preferred pronouns (she/her, he/him).",firstName:"The applicant's first / given name only.",lastName:"The applicant's last / family name only.",fullName:"The applicant's full name in one box.",email:"The applicant's e-mail address.",phone:"The applicant's phone / mobile number.",address:"Street and house number.",city:"City / town the applicant lives in.",postalCode:"Postal / ZIP code.",country:"Country the applicant lives in (not nationality, not where they want to work).",linkedin:"LinkedIn profile URL.",github:"GitHub profile URL.",website:"Personal website or portfolio URL.",expectedSalary:"The applicant's salary expectation as an amount (not a currency or period picker)."},Xs=[...Object.entries(wt).map(([e,t])=>({value:e,description:t})),{value:yt,description:"Anything else: an application question, a date, a company, a job title, a free comment, or a field about somebody else (a referrer, a reference, an emergency contact)."}],Zs=`You help autofill a job-application form from the applicant's saved profile.
Two kinds of questions follow, each about one field of the form and independent of the others:
- Option questions: the field must be set to a value the applicant already gave, but its options word it differently
  (another language, an official name, a region added, an amount written as a range). Pick the option that means
  the same thing — the same country, the same city, the range containing the amount. When no option does, pick
  "${ne}"; never pick a merely similar one.
- Field questions: from what the page says about a field (label, name, placeholder…), which profile value does it ask
  for? Only the applicant's own data counts; when unsure, "${yt}".
Labels may be in any language: judge by meaning.`;function ei(e){var n,a;return[`label "${e.label}"`,`type ${e.kind}`,e.name&&`name "${e.name}"`,e.id&&`id "${e.id}"`,e.placeholder&&`placeholder "${e.placeholder}"`,e.ariaLabel&&`aria-label "${e.ariaLabel}"`,e.autocomplete&&`autocomplete "${e.autocomplete}"`,((n=e.other)==null?void 0:n.length)&&`nearby text ${e.other.map(s=>`"${s}"`).join(", ")}`,((a=e.options)==null?void 0:a.length)&&`options ${e.options.map(s=>`"${s}"`).join(", ")}`].filter(Boolean).join("; ")}function ti(e){return{type:"choice",name:e.id,instructions:`Form field labelled "${e.label}" (the applicant's ${e.field}). The applicant's value: "${e.value}". Which option is that value?`,choices:[...new Set(e.options)].filter(t=>t!==ne).map(t=>({value:t})).concat({value:ne})}}function ni(e){return[...e.optionPicks.filter(t=>t.options.length>0).map(ti),...e.fieldKinds.map(t=>({type:"choice",name:t.id,instructions:`A form field with ${ei(t.signals)}. Which of the applicant's profile values does it ask for?`,choices:Xs}))]}function ai(e,t){return{optionPicks:e.optionPicks.filter(n=>t.has(n.id)).map(n=>{const a=V(t,n.id),s=a&&a.confidence>=F.optionMatch&&n.options.includes(a.choice);return{id:n.id,choice:s?a.choice:null}}),fieldKinds:e.fieldKinds.filter(n=>t.has(n.id)).map(n=>{const a=V(t,n.id),s=a&&a.confidence>=F.profileField&&a.choice in wt;return{id:n.id,field:s?a.choice:null}})}}async function si(e){const t=ni(e);if(t.length===0)return{optionPicks:[],fieldKinds:[]};const n=await N({input:Zs,questions:t,promptCacheKey:"filler-field-decisions"});return ai(e,n)}const ii={type:"object",additionalProperties:!1,required:["postingLanguages","requirements","keywords","contact"],properties:{postingLanguages:{type:"array",items:{type:"string"}},requirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...Ke,null]}}}},keywords:pt,contact:{type:["string","null"]}}},ri=`You read a job posting and report three independent things about it: its
language, the skills it asks for (keywords), and (only if asked below) a recruiter/hiring
contact. Judge language and keywords against the applicant profile/CV/Personal Legend given
below.

LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- requirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or
  "Native" for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent",
  "professional working proficiency" -> "C1"; "conversational" -> "B1". If a language is
  mentioned but no level can be reasonably inferred, set level to null. Do not invent a
  requirement that isn't stated in the text. If nothing is stated, return an empty array.

${ue("the posting text (job title, description, requirements, responsibilities)")}

CONTACT
- "job.contact" below is the recruiter/hiring contact already found elsewhere, or null if none
  was found yet.
- If it is already set (not null), ignore this entirely and return "contact": null — there is
  nothing to add.
- If it is null, look for one in the job's own text (description/requirements/responsibilities):
  a named recruiter/hiring manager's email address, or a LinkedIn profile/company URL. If you
  find one, copy it VERBATIM (exact characters) so it can be re-found on the page for
  highlighting — the same rule as for keywords. If none is mentioned, return "contact": null.`;async function oi(e){const t=await E(),n=JSON.stringify({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,job:e},null,2),a=await v({schemaName:"job_brief",schema:ii,model:await Ye(),systemPrompt:ri,userPrompt:n,parse:s=>JSON.parse(s)});return{language:{postingLanguages:a.postingLanguages,requirements:a.requirements},keywords:pe(a.keywords,e),contact:a.contact}}const ci={type:"object",additionalProperties:!1,required:["cvId","reason"],properties:{cvId:{type:"string"},reason:{type:"string"}}},li=`You pick which of an applicant's CVs to send to one job posting.
Each CV has an id, a name, the language it's written in, the applicant's own rules for which
postings it's for, and the start of its text.
- Prefer a CV written in the posting's language; if none, an English one.
- Then follow the applicant's rules: the CV whose rules fit this posting best.
- Then the one marked default for that language.
Return the chosen CV's exact "id" and a reason of at most 10 words. Plain text, no em dashes.`;async function ui(e,t,n){if(t.length<2)return null;const a=t.map((s,i)=>`cv${i+1}`);try{const s=await N({input:[{role:"user",content:[{type:"input_text",text:"A job posting the applicant is applying to:"},{type:"input_json",data:{position:e.position,company:e.company,location:e.location,language:n??null,techStack:e.techStack,description:e.description.slice(0,4e3)}}]}],questions:[{type:"choice",name:"cv",instructions:"Which of the applicant's CVs should be sent to this posting? Prefer a CV written in the posting's language (else an English one), then the one whose rules fit the posting best, then the one marked default for that language.",choices:t.map((o,c)=>({value:a[c],description:pi(o)}))}]}),i=V(s,"cv"),r=i?a.indexOf(i.choice):-1;return!i||r<0||i.confidence<F.cvChoice?null:{cvId:t[r].id,reason:"",source:"ai",confidence:i.confidence}}catch(s){if(s instanceof q)throw s;return console.warn("[Filler] Decisions API failed, choosing the CV via Responses:",s),di(e,t,n)}}function pi(e){var t;return[`Name: ${et(e)}.`,`Language: ${e.language?tt(e.language):"not set"}${e.isDefaultForLanguage?" (default CV for that language)":""}.`,(t=e.rules)!=null&&t.trim()?`Applicant's rules for it: ${e.rules.trim()}`:"",`Starts: ${e.text.slice(0,600).replace(/\s+/g," ")}`].filter(Boolean).join(" ")}async function di(e,t,n){if(t.length<2)return null;const a={posting:{position:e.position,company:e.company,location:e.location,language:n??null,techStack:e.techStack,description:e.description.slice(0,4e3)},cvs:t.map(i=>({id:i.id,name:et(i),language:i.language?tt(i.language):null,defaultForLanguage:!!i.isDefaultForLanguage,rules:i.rules??"",textStart:i.text.slice(0,1200)}))},s=await v({schemaName:"cv_choice",schema:ci,model:await nt(),reasoningEffort:"low",systemPrompt:li,userPrompt:JSON.stringify(a,null,2),parse:i=>JSON.parse(i)});return t.some(i=>i.id===s.cvId)?{cvId:s.cvId,reason:s.reason.replace(/—/g,",").trim()||"AI pick",source:"ai"}:null}const hi={type:"object",additionalProperties:!1,required:["values"],properties:{values:{type:"array",items:{type:"object",additionalProperties:!1,required:["name","value","reason"],properties:{name:{type:"string"},value:{type:"string"},reason:{type:"string"}}}}}},fi=`You adapt an applicant's CV template to one specific job posting by
choosing a value for each {{placeholder}} in it.

Each variable comes with:
- "description": the applicant's own instruction for what the placeholder means and
  how to choose it. Follow it.
- "mode": "choice" means "value" MUST be exactly one of "options", copied verbatim
  (same spelling, same case, same line breaks). "free" means "options" are only
  examples of the expected shape and length; write the value that fits this posting
  in that same shape (e.g. a city name, a comma-separated list).
- "foundInPosting": options that literally occur in the posting text, most frequent
  first. A strong hint, not an order: the role's actual focus matters more than a
  passing mention.

Rules:
- Pick what makes this CV the closest honest match for this posting: its title, its
  location, its main technology, the vocabulary it uses.
- A job title / position value is the bare role name: no bracketed asides like (m/w/d),
  (f/m/d) or (Remote), no seniority level (Senior, Middle, Junior, Sr., Staff, Principal),
  no team, location or contract qualifiers. "Senior Backend Engineer (m/f/d)" -> "Backend Engineer".
- Honesty: never make the CV claim a skill, technology or experience the applicant's
  CV text / Personal Legend doesn't support, unless the variable's description
  explicitly asks for it. For list-like values, prefer terms that are both in the
  posting and supported by the applicant's background.
- Write the value in the same language as the surrounding template text.
- Return one entry per variable given, using its exact "name".
- "reason": one short sentence (max ~15 words) on why this value fits the posting.
- Plain text only, no markdown, no em dashes.`;function gi(e,t){const n=s=>s.trim().replace(/\s+/g," ").toLowerCase(),a=n(e);return t.options.find(s=>n(s)===a)??null}async function mi(e,t){const n=new Set(nn(t.content)),a=t.variables.filter(u=>n.has(u.name));if(a.length===0)return[];const s=await E(),i=a.filter(u=>u.mode==="choice"&&u.options.length>=2),r=a.filter(u=>!(u.mode==="choice"&&u.options.length>0)),[o,c]=await Promise.all([i.length>0?wi(e,t,i,s):new Map,r.length>0?vt(e,t,r,s):new Map]);return a.map(u=>o.get(u.name)??c.get(u.name)??{name:u.name,value:an(u,e),reason:""})}const yi=`You adapt an applicant's CV template to one specific job posting: for each {{placeholder}}
pick the variant that makes this CV the closest honest match for the posting (its title, its location,
its main technology, the vocabulary it uses). Follow the applicant's own instruction for the placeholder.
Variants that literally occur in the posting are a strong hint, not an order: the role's actual focus
matters more than a passing mention. Never pick a variant that claims a skill, technology or experience
the applicant's CV text / Personal Legend doesn't support, unless the instruction explicitly asks for it.`;async function wi(e,t,n,a){const s=r=>`o${r+1}`,i=n.map((r,o)=>{const c=at(r.options,e).map(u=>`${s(r.options.indexOf(u))} ("${u}")`);return{type:"choice",name:`v${o}`,instructions:[`CV placeholder {{${r.name}}}. Which variant should fill it for this posting?`,r.description.trim()?`The applicant's instruction for it: ${r.description.trim()}`:"",c.length>0?`Variants found verbatim in the posting, most frequent first: ${c.join(", ")}.`:""].filter(Boolean).join(`
`),choices:r.options.map((u,l)=>({value:s(l),description:u}))}});try{const r=await N({input:[{role:"developer",content:yi},{role:"user",content:[{type:"input_json",data:{applicant:{cvText:a.cvText.slice(0,12e3),personalLegend:a.personalLegend.slice(0,8e3),city:a.profile.city,country:a.profile.country}}},{type:"input_json",data:{job:bt(e)}}]}],promptCacheKey:`filler-cv-values-${sn(a.cvText+a.personalLegend)}`,questions:i}),o=new Map;return n.forEach((c,u)=>{const l=V(r,`v${u}`),g=l?c.options.findIndex((h,p)=>s(p)===l.choice):-1;!l||g<0||l.confidence<F.cvVariableChoice||o.set(c.name,{name:c.name,value:c.options[g],reason:`AI pick, ${Math.round(l.confidence*100)}% sure`})}),o}catch(r){if(r instanceof q)throw r;return console.warn("[Filler] Decisions API failed, picking CV variants via Responses:",r),vt(e,t,n,a)}}function bt(e){return{position:e.position,company:e.company,location:e.location,techStack:e.techStack,requirements:e.requirements,responsibilities:e.responsibilities,description:e.description.slice(0,8e3)}}async function vt(e,t,n,a){const s={variables:n.map(o=>({name:o.name,mode:o.mode,description:o.description,options:o.options,foundInPosting:at(o.options,e)})),template:t.content.slice(0,12e3),job:bt(e),applicant:{cvText:a.cvText.slice(0,12e3),personalLegend:a.personalLegend.slice(0,8e3),city:a.profile.city,country:a.profile.country}},i=await v({schemaName:"cv_template_values",schema:hi,model:await nt(),systemPrompt:fi,userPrompt:JSON.stringify(s,null,2),parse:o=>JSON.parse(o)}),r=new Map;for(const o of n){const c=i.values.find(l=>l.name===o.name);if(!c)continue;if(o.mode==="choice"&&o.options.length>0){const l=gi(c.value,o);l&&r.set(o.name,{name:o.name,value:l,reason:k(c.reason)});continue}const u=k(c.value);r.set(o.name,{name:o.name,value:rn(o.name)?rs(u,e):u,reason:k(c.reason)})}return r}async function Et(e){const t=await S(e);await Promise.all(t.map(n=>chrome.tabs.sendMessage(e,{type:"CANCEL_ELEMENT_PICKER",tabId:e},{frameId:n}).catch(()=>{})))}async function _(e,t,n){return(await Promise.all(t.map(s=>chrome.tabs.sendMessage(e,n,{frameId:s}).catch(()=>{})))).filter(s=>!!s)}async function Te(e,t,n,a){if(n!==void 0&&t.includes(n)){const s=await chrome.tabs.sendMessage(e,a,{frameId:n}).catch(()=>{});if(s)return[s]}return _(e,t,a)}function bi(e){const t=new Map;for(const n of e){const a=n.locator.frameId;t.set(a,[...t.get(a)??[],n])}return t}async function vi(e){if(!Ei.has(e.type))return _e(e);const t=e.projectId??await Pe();return Re(t,()=>_e(e))}const Ei=new Set(["GET_PROFILE","DECIDE_FIELDS","COMPLETE_JOB","EXTRACT_JOB_FROM_TEXT","GENERATE_COVER_LETTER","REVISE_COVER_LETTER","TRANSLATE_COVER_LETTER","GENERATE_OUTREACH_MESSAGE","REVISE_OUTREACH_MESSAGE","ANSWER_CUSTOM_QUESTION","DECOMPOSE_BLOCK","DECIDE_PAGE_CONTENT","DETECT_JOB_BRIEF","GENERATE_FAQ_ANSWERS","SEARCH_JOBS","SUGGEST_SEARCH_QUERY","SUGGEST_CV_VALUES","CHOOSE_CV"]);async function _e(e){switch(e.type){case"FILL_STATS_REPORT":{await fn(e.run);return}case"DECIDE_FIELDS":return{type:"FIELD_DECISIONS",result:await si(e.request)};case"GET_PROFILE":return{type:"PROFILE_DATA",profile:await R()};case"GET_JOB":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});if(!e.force&&(t!=null&&t.url)){const c=await dn(t.url);if(c!=null&&c.position&&c.company)return{type:"JOB_DATA",job:c,sufficient:!0}}const n=await S(e.tabId),s=(await _(e.tabId,n,e)).filter(c=>c.type==="JOB_DATA");if(s.length===0)return;const i=s.find(c=>c.sufficient);if(i)return t!=null&&t.url&&hn(t.url,i.job),i;const r=s.reduce((c,u)=>u.job.description.length>c.job.description.length?u:c),o=s.map(c=>c.visibleText??"").filter(Boolean).join(`

`).slice(0,2e4);return{type:"JOB_DATA",job:r.job,sufficient:!1,visibleText:o||r.visibleText||"",pageUrl:t==null?void 0:t.url}}case"COMPLETE_JOB":{const{job:t,brief:n}=await ds(e.job,e.text);return{type:"JOB_DATA",job:t,sufficient:!0,brief:n}}case"EXTRACT_JOB_FROM_TEXT":{const t=await chrome.tabs.get(e.tabId).catch(()=>{}),{job:n,brief:a}=await ls(e.text,(t==null?void 0:t.url)??"");return{type:"JOB_DATA",job:n,sufficient:!0,brief:a}}case"AUTOFILL":{const t=await S(e.tabId),a=(await _(e.tabId,t,e)).filter(s=>s.type==="AUTOFILL_RESULT");return{type:"AUTOFILL_RESULT",filled:a.reduce((s,i)=>s+i.filled,0),total:a.reduce((s,i)=>s+i.total,0),generatedPassword:a.map(s=>s.generatedPassword).find(Boolean)??null}}case"GENERATE_COVER_LETTER":{const{tabId:t}=e,n=await xe(),a=e.job.url;let s="",i=0;await J(t,{jobUrl:a,projectId:n,status:"generating",content:""});let r;try{r=await Wa(e.job,e.postingLanguage,o=>{chrome.runtime.sendMessage({type:"COVER_LETTER_STREAM_CHUNK",tabId:t,delta:o}).catch(()=>{}),s+=o,Date.now()-i>400&&(i=Date.now(),J(t,{jobUrl:a,projectId:n,status:"generating",content:s}).catch(()=>{}))})}catch(o){const c=o instanceof Error?o.message:String(o);throw await J(t,{jobUrl:a,projectId:n,status:"error",content:"",error:c}).catch(()=>{}),o}return await J(t,{jobUrl:a,projectId:n,status:"done",content:r.content,cleanedPatterns:r.cleaned?Array.from(new Set(r.slopFindings.map(o=>o.pattern))):[]}),await X("lastCoverLetter",r.content),{type:"COVER_LETTER_RESULT",content:r.content,slopFindings:r.slopFindings,cleaned:r.cleaned}}case"UPLOAD_FILE":{const t=await S(e.tabId),a=(e.targetLocator?await Te(e.tabId,t,e.targetLocator.frameId,e):await _(e.tabId,t,e)).filter(s=>s.type==="UPLOAD_FILE_RESULT");return{type:"UPLOAD_FILE_RESULT",nativeInputs:a.reduce((s,i)=>s+i.nativeInputs,0),dropZones:a.reduce((s,i)=>s+i.dropZones,0)}}case"REVISE_COVER_LETTER":{const t=await fs(e.content,e.instructions,e.job);return await X("lastCoverLetter",t),{type:"REVISE_COVER_LETTER_RESULT",content:t}}case"TRANSLATE_COVER_LETTER":return{type:"TRANSLATE_COVER_LETTER_RESULT",content:await ws(e.content,e.targetLanguage)};case"GENERATE_OUTREACH_MESSAGE":{const t=await E(),n=await Qa({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,outreachRules:t.outreachRules,job:e.job,contact:e.contact,postingLanguage:e.postingLanguage});return{type:"OUTREACH_MESSAGE_RESULT",subject:n.subject,body:n.body}}case"REVISE_OUTREACH_MESSAGE":{const t=await ms({subject:e.subject,body:e.body},e.instructions,e.job);return{type:"OUTREACH_MESSAGE_RESULT",subject:t.subject,body:t.body}}case"GET_FRAME_ACCESS":return{type:"FRAME_ACCESS",blockedOrigins:await _n(e.tabId)};case"DETECT_CUSTOM_QUESTIONS":{const t=await S(e.tabId),n=await _(e.tabId,t,e),a=new Set,s=[];for(const i of n)if(i.type==="CUSTOM_QUESTIONS_DATA")for(const r of i.questions)a.has(r.question)||(a.add(r.question),s.push({...r,id:`question-${s.length}`}));return{type:"CUSTOM_QUESTIONS_DATA",questions:s}}case"ANSWER_CUSTOM_QUESTION":{const t=await qs(e.question,e.job,e.options,e.numeric,e.dateKind,e.multi,e.postingLanguage,e.catchAll);return{type:"CUSTOM_QUESTION_ANSWER",question:e.question,answer:t.answer,sufficientInfo:t.sufficientInfo}}case"FILL_CUSTOM_QUESTION_ANSWERS":{const t=await S(e.tabId),n=await _(e.tabId,t,e);let a=0;const s=[];for(const i of n)i.type==="CUSTOM_QUESTION_FILL_RESULT"&&(a+=i.filled,s.push(...i.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:a,unfilled:s}}case"START_ELEMENT_PICKER":{const t=await S(e.tabId),n=t.map(s=>chrome.tabs.sendMessage(e.tabId,e,{frameId:s}).then(i=>i?{result:i,frameId:s}:void 0).catch(()=>{})),a=await new Promise(s=>{let i=n.length;i===0&&s(void 0);for(const r of n)r.then(o=>{i-=1,o?s(o):i===0&&s(void 0)})});return await Promise.all(t.map(s=>chrome.tabs.sendMessage(e.tabId,{type:"CANCEL_ELEMENT_PICKER",tabId:e.tabId},{frameId:s}).catch(()=>{}))),a?{...a.result,picked:a.result.picked.map(s=>({...s,locator:{...s.locator,frameId:a.frameId}}))}:{type:"ELEMENT_PICKER_RESULT",cancelled:!0,picked:[],blockText:"",semanticCount:0}}case"CANCEL_ELEMENT_PICKER":{await Et(e.tabId);return}case"DECOMPOSE_BLOCK":return{type:"BLOCK_QUESTIONS",questions:await Ys(e.blockText,e.fields)};case"FILL_QUESTION_ANSWERS_BY_LOCATOR":{const t=await S(e.tabId),n=(await Promise.all([...bi(e.items)].map(([i,r])=>Te(e.tabId,t,i,{...e,items:r})))).flat();let a=0;const s=[];for(const i of n)i.type==="CUSTOM_QUESTION_FILL_RESULT"&&(a+=i.filled,s.push(...i.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:a,unfilled:s}}case"DETECT_CHECKBOXES":{const t=await S(e.tabId),n=await _(e.tabId,t,e),a=new Set,s=[];for(const i of n)if(i.type==="CHECKBOXES_DATA")for(const r of i.checkboxes){const o=r.name||r.label;!o||a.has(o)||(a.add(o),s.push({...r,id:`checkbox-${s.length}`}))}return{type:"CHECKBOXES_DATA",checkboxes:s}}case"DECIDE_PAGE_CONTENT":{const{checkboxDecisions:t,questionAnswers:n}=await zs(e.checkboxes,e.questions,e.job,e.postingLanguage);return{type:"PAGE_CONTENT_DECISIONS",checkboxDecisions:t,questionAnswers:n}}case"APPLY_CHECKBOX_DECISIONS":{const t=await S(e.tabId),n=await _(e.tabId,t,e);let a=0;for(const s of n)s.type==="CHECKBOX_APPLY_RESULT"&&(a+=s.changed);return{type:"CHECKBOX_APPLY_RESULT",changed:a}}case"DETECT_JOB_BRIEF":{const t=await oi(e.job);return{type:"JOB_BRIEF_DATA",language:t.language,keywords:t.keywords,contact:t.contact}}case"HIGHLIGHT_KEYWORDS":{const t=await S(e.tabId);return{type:"KEYWORD_HIGHLIGHT_RESULT",matched:(await _(e.tabId,t,e)).reduce((s,i)=>i.type==="KEYWORD_HIGHLIGHT_RESULT"?s+i.matched:s,0)}}case"CLEAR_KEYWORD_HIGHLIGHTS":{const t=await S(e.tabId);await _(e.tabId,t,e);return}case"GENERATE_FAQ_ANSWERS":{const t=await Me(),n=await Un(e.questions,t);try{await pn(n)}catch{}return{type:"FAQ_ANSWERS_RESULT",entries:n}}case"SEARCH_JOBS":{const{searchId:t}=e,n=t?s=>{chrome.runtime.sendMessage({type:"JOB_SEARCH_PROGRESS",searchId:t,results:s}).catch(()=>{})}:void 0,a=setInterval(()=>void chrome.runtime.getPlatformInfo().catch(()=>{}),2e4);try{return{type:"JOB_SEARCH_RESULTS",...await Ca(e.query,{page:e.page,excludeResults:e.excludeResults,onResults:n})}}finally{clearInterval(a)}}case"SUGGEST_SEARCH_QUERY":{const{what:t,where:n,tags:a}=await ce(e.provider==="adzuna");return{type:"SEARCH_QUERY_SUGGESTION",what:t,where:n,...e.provider==="adzuna"?{tags:a}:{}}}case"LINKEDIN_ADD_JOBS":return{type:"LINKEDIN_JOBS_ADDED",...await ln(un(e.jobs))};case"GET_LINKEDIN_COLLECTED":return{type:"LINKEDIN_COLLECTED",ids:(await cn()).map(n=>n.id)};case"FIND_EMPLOYER_POSTING":{const{tavilyApiKey:t}=await j();return{type:"EMPLOYER_POSTING_CANDIDATES",candidates:await on(e,t)}}case"SUGGEST_CV_VALUES":return{type:"CV_VALUES",values:await mi(e.job,e.template)};case"CHOOSE_CV":return{type:"CV_CHOICE",choice:await ui(e.job,e.cvs,e.postingLanguage)};default:return}}const ae="filler-update-check",Ie=6*60;function Si(){chrome.runtime.onInstalled.addListener(()=>{Le(),W({force:!0}).catch(M)}),chrome.runtime.onStartup.addListener(()=>{Le(),gn().catch(M),W().catch(M)}),chrome.alarms.onAlarm.addListener(e=>{e.name===ae&&W({force:!0}).then(()=>Ae()).catch(M)}),chrome.runtime.onUpdateAvailable.addListener(e=>{mn(e.version).then(()=>Ae()).catch(M)})}async function Le(){await chrome.alarms.get(ae)||await chrome.alarms.create(ae,{delayInMinutes:Ie,periodInMinutes:Ie})}async function Ae(){if(!yn())return;const{offer:e}=await wn();if((e==null?void 0:e.kind)!=="store"||e.version===bn())return;(await chrome.runtime.getContexts({contextTypes:[chrome.runtime.ContextType.SIDE_PANEL,chrome.runtime.ContextType.TAB,chrome.runtime.ContextType.POPUP,chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]})).length===0&&chrome.runtime.reload()}function M(e){console.warn("Filler update check failed",e)}const ki="src/sidepanel/index.html";chrome.runtime.onInstalled.addListener(()=>{Cn(),chrome.sidePanel.setOptions({enabled:!1}),st().catch(e=>console.error("LinkedIn collector sync failed",e))});function H(){st().catch(e=>console.error("LinkedIn collector sync failed",e))}chrome.runtime.onStartup.addListener(H);chrome.permissions.onAdded.addListener(H);chrome.permissions.onRemoved.addListener(H);chrome.storage.onChanged.addListener((e,t)=>{vn(e,t)&&H()});Si();chrome.contextMenus.onClicked.addListener((e,t)=>{Rn(e,t)});chrome.action.onClicked.addListener(e=>{if(e.id===void 0)return;const t=e.id;chrome.sidePanel.setOptions({tabId:t,path:`${ki}?tabId=${t}`,enabled:!0}),chrome.sidePanel.open({tabId:t}).catch(n=>console.error("sidePanel.open failed",n)),Ti(t)});async function Ti(e){await S(e);const t={type:"TAB_ACCESS_GRANTED",tabId:e};await chrome.runtime.sendMessage(t).catch(()=>{})}chrome.tabs.onRemoved.addListener(e=>{En(e)});chrome.runtime.onMessage.addListener((e,t,n)=>(vi(e).then(n).catch(a=>{n({type:"ERROR",error:a instanceof Error?a.message:String(a),code:a instanceof Error?a.name:void 0})}),!0));chrome.runtime.onConnect.addListener(e=>{const t=/^picker-(\d+)$/.exec(e.name);if(!t)return;const n=Number(t[1]);e.onDisconnect.addListener(()=>{Et(n)})});
