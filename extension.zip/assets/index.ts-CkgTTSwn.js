import{P as Fe,g as ce,a as R,b as De,c as Ye,s as Je,d as M,e as le,f as Be,h as He,i as Ge,j as Ve,k as ue,r as b,J as pe,n as de,t as j,l as q,M as he,m as Ke,A as H,o as We,p as Qe,q as ze,u as D,v as z,w as ge,x as Xe,y as X,z as fe,C as Ze,B as me,D as et,E as tt,F as nt,G as ye,H as at,I as we,K as Y,L as G,N as be,O as ve,Q as Ee,R as Se,S as V,T as Te,U as st,V as it,W as Z,X as ot,Y as rt,Z as ke,_ as Le,$ as Ie,a0 as ct,a1 as lt,a2 as ee,a3 as ut,a4 as pt,a5 as P,a6 as dt,a7 as ht,a8 as gt,a9 as ft}from"./template-Cy0twWAG.js";import{c as mt,a as yt}from"./phone-D3SACKoL.js";const _e={...Fe,cv:"CV",coverLetter:"Cover Letter",generatePassword:"Generated password"},wt=Object.keys(_e);async function E(e){try{const a=(await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:["content-script.js"]})).map(n=>n.frameId).filter(n=>typeof n=="number");if(a.length>0)return a}catch{}try{return await chrome.scripting.executeScript({target:{tabId:e},files:["content-script.js"]}),[0]}catch{return[0]}}function bt(){const e=[];for(const t of Array.from(document.querySelectorAll("iframe, frame"))){const a=t.getBoundingClientRect(),n=a.width*a.height;t.src&&a.width>=200&&a.height>=150&&e.push({src:t.src,area:n})}return{origin:location.origin,children:e}}async function vt(e){let t;try{t=await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},func:bt})}catch{return[]}const a=new Set,n=new Map;for(const{result:i}of t)if(i){a.add(i.origin);for(const o of i.children){let r;try{const c=new URL(o.src);if(c.protocol!=="https:"&&c.protocol!=="http:")continue;r=c.origin}catch{continue}n.set(r,Math.max(n.get(r)??0,o.area))}}const s=[];for(const i of[...n.keys()].sort((o,r)=>n.get(r)-n.get(o))){if(a.has(i))continue;if(await chrome.permissions.contains({origins:[`${i}/*`]}).catch(()=>!1)||s.push(i),s.length===3)break}return s}async function Et(e,t){if(e==="cv"){const s=await ce();return(s==null?void 0:s.text)??""}if(e==="coverLetter")return await R("lastCoverLetter")??"";if(e==="generatePassword"){const s=await De(t);if(s!=null&&s.generatedPassword)return s.generatedPassword;const i=Ye();return s&&await Je(t,{...s,generatedPassword:i}),i}const a=await M(),n=a[e]??"";return e==="phone"&&n?mt(n,a.country):n}const C="job-app-assistant-insert",St={generatePassword:"Generate password"},Tt=wt.map(e=>({id:e,title:St[e]??_e[e]}));function kt(){chrome.contextMenus.removeAll(()=>{chrome.contextMenus.create({id:C,title:"Insert",contexts:["editable"]});for(const e of Tt)chrome.contextMenus.create({id:`${C}:${e.id}`,parentId:C,title:e.title,contexts:["editable"]})})}function Lt(e){return e.startsWith(`${C}:`)?e.slice(C.length+1):null}async function It(e,t){if(!(t!=null&&t.id)||typeof e.menuItemId!="string")return;const a=Lt(e.menuItemId);if(!a)return;const n=await Et(a,t.id);await E(t.id);const s={type:"INSERT_VALUE",field:a,value:n};chrome.tabs.sendMessage(t.id,s,{frameId:e.frameId}).catch(()=>{})}const _t=new Set(["profileCache","cvLibraryCache","legendLibraryCache","customFieldsCache","languageLevelsCache","faqAnswersCache","generationRulesCache","outreachRulesCache"]);let O=null;function At(){return Promise.all([M(),ce(),le(),Be(),He(),Ge(),Ve(),ue()]).then(([e,t,a,n,s,i,o,r])=>({profile:e,cvText:(t==null?void 0:t.text)??"",personalLegend:(a==null?void 0:a.content)??"",generationRules:(n==null?void 0:n.content)??"",outreachRules:(s==null?void 0:s.content)??"",languageLevels:i,customFields:o,faq:r}))}function S(){return O||(O=At(),O.catch(()=>{O=null})),O}var re;typeof chrome<"u"&&((re=chrome.storage)!=null&&re.onChanged)&&chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&Object.keys(e).some(a=>_t.has(a))&&(O=null)});const I=`Write like a specific person, not an AI assistant. These rules have no exceptions:

- NEVER use an em dash ("—"), a spaced en dash ("–") or "--" as punctuation. Real people don't write that way. Use a comma, a period, parentheses, or two sentences.
- Banned words: delve, foster, leverage, utilize, facilitate, empower, streamline, robust, cutting-edge, paradigm shift, game changer, tapestry, realm, beacon, multifaceted, meticulous, intricate, paramount, transformative, elevate, embark, supercharge, harness, ever-evolving. Say the plain thing.
- Cut empty phrases: "it's worth noting", "at the end of the day", "when it comes to", "at its core", "in today's world", "the reality is", "in order to", "going forward".
- No "not X, it's Y" / "the question isn't X, it's Y" / "not just X but Y" contrasts. State Y directly.
- No throat-clearing openers ("Here's the thing", "Let me be clear", "I'll be honest") and no faux-insight setups ("what most people get wrong", "here's what nobody tells you").
- No importance puffery ("stands as a testament", "marks a pivotal moment", "plays a vital role", "underscores its significance"). State the fact and stop.
- No colon reveals: a noun phrase, a colon, then a dramatic lowercase clause.
- No trailing "-ing" clauses that editorialize ("highlighting the commitment to...", "underscoring its importance", "showcasing", "reflecting"). End the sentence.
- No metadiscourse that tells the reader what to notice ("this matters", "this distinction matters", "in other words", "as you can see").
- No "In conclusion" / "Ultimately" / "Overall" recap ending and no cute one-line kicker. Stop on the last concrete point.
- No emoji, no mid-sentence bold, no rhetorical questions.
- Vary sentence shape; don't stack short punchy fragments.
- Be concrete: name the technology, project, number, or outcome instead of calling it "significant", "impactful" or "exciting". Use active voice.`;function T(e){return e.replace(/[ \t]*[—―][ \t]*/g,", ").replace(/[ \t]+--[ \t]+/g,", ").replace(/(\D)[ \t]+–[ \t]+(?=\D)/g,"$1, ").replace(/[ \t]+([,.;:!?])/g,"$1").replace(/,(\s*[.;:!?])/g,"$1").replace(/,[ \t]*,/g,",").replace(/^[ \t]*,[ \t]*/gm,"").replace(/([([{])[ \t]*,[ \t]*/g,"$1").replace(/[ \t]*,[ \t]*([)\]}])/g,"$1").replace(/,[ \t]*$/gm,"").replace(/[ \t]+$/gm,"")}const Ot=`You write the applicant's own answers to standard interview-FAQ
questions (spec_5 section B) — general-purpose answers meant to be reused, as-is or
lightly adapted, whenever a real application form asks a close variant of one of them.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend, and
  custom fields. Never invent experience, technologies, companies, education,
  achievements, or a concrete salary figure that wasn't actually given.
- If information needed for a good answer is missing (no CV, no Personal Legend
  content covering it), write a short, honest, generically true answer rather
  than fabricating specifics — the applicant can always sharpen it later.
- Keep each answer 2-5 sentences: concrete and confident, never generic
  corporate filler, no restating the question.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text per answer, no markdown, no numbering.

${I}`;function Rt(e){return{type:"object",additionalProperties:!1,required:["answers"],properties:{answers:{type:"array",minItems:e,maxItems:e,items:{type:"string"}}}}}async function xt(e){if(e.length===0)return[];const{profile:t,cvText:a,personalLegend:n,generationRules:s,customFields:i}=await S(),o=JSON.stringify({profile:t,cvText:a,personalLegend:n,generationRules:s,customFields:i,questions:e},null,2),r=await b({schemaName:"faq_answers",schema:Rt(e.length),systemPrompt:Ot,userPrompt:o,parse:c=>JSON.parse(c)});return e.map((c,d)=>({question:c,answer:T(r.answers[d]??"")}))}async function Ct(e,t){const a=new Map(t.map(i=>[i.question,i.answer])),n=e.filter(i=>{var o;return!((o=a.get(i))!=null&&o.trim())}),s=await xt(n);for(const i of s)a.set(i.question,i.answer);return e.map(i=>({question:i,answer:a.get(i)??""}))}async function N(e,t,a){const n=performance.now();try{return await a()}finally{e==null||e.push({label:t,ms:performance.now()-n})}}function Pt(e){return e!=null&&e.length?`Seniority levels to target: ${pe.filter(a=>e.includes(a.id)).map(a=>a.label.toLowerCase()).join(", ")}. Only include postings for these levels.`:""}function Nt(e,t){const a=pe.filter(s=>t==null?void 0:t.includes(s.id));if(a.length===0)return e;const n=[];for(const s of e)for(const i of a)n.push(s.toLowerCase().includes(i.keyword)?s:`${i.keyword} ${s}`.trim());return[...new Set(n)]}function Ae(e){return[e.what?`Role/keywords focus: "${e.what}".`:"",e.where?`Location: "${e.where}".`:"",Pt(e.grades),e.remoteOnly?"Prefer remote-friendly roles.":"",de(e.negative)].filter(Boolean).join(" ")}const Mt={type:"object",additionalProperties:!1,required:["jobs"],properties:{jobs:{type:"array",items:{type:"object",additionalProperties:!1,required:["title","company","location","url","salary","snippet","postedAt"],properties:{title:{type:"string"},company:{type:"string"},location:{type:"string"},url:{type:"string"},salary:{type:"string"},snippet:{type:"string"},postedAt:{type:"string"}}}}}};function jt(e,t){const a=de(t);return`You turn raw web-search results about job openings into a clean,
structured list. The input text was produced by a live internet search and may include
citations, markdown links, or unrelated surrounding prose — extract only genuine
individual job postings from it.

Rules:
- Only include entries that are clearly actual job postings with a real listing URL —
  never a company's generic careers-page homepage, a search-results page, or an
  aggregator's category page.
- "url" must be copied exactly from the source text (never invented).
- "salary" is "" when no figure was given — never guess one.
- "postedAt" is the date the posting was published, as YYYY-MM-DD, only when the text
  states it. Resolve relative dates ("posted 3 days ago", "2w") against today, ${e}.
  Use "" when no date is given — never guess one.
- Drop postings the text marks as closed, expired, filled or "no longer accepting
  applications", and postings published more than ${he} days before ${e}.
- "snippet" is a 1-2 sentence summary of the role; when a "candidate" background is given
  below, make it say *why this posting fits them* specifically (seniority match, matching
  skills, location/remote fit) rather than just restating the posting.
- If a "candidate" background is given, drop postings that are a poor fit for them (wrong
  seniority, unrelated field) even if they're genuine job postings — only surface ones
  actually worth their time.
- Deduplicate: the same posting linked twice becomes one entry.${a?`
- ${a}`:""}
- If nothing in the text is actually a job posting, return an empty "jobs" array.`}async function Oe(e,t,a,n={}){const s=a?`candidate:
${a}

---

${e.slice(0,4e4)}`:e.slice(0,4e4),i=await b({schemaName:"job_listings",schema:Mt,systemPrompt:jt(j(),n.negative),userPrompt:s,reasoningEffort:n.reasoningEffort,timeoutMs:n.timeoutMs,signal:n.signal,label:"Parsing search results",parse:o=>JSON.parse(o)});return q(i.jobs.filter(o=>o.url.trim()).map(o=>({...o,source:t})))}function Re(e){return e.length===0?"":`

Already found and shown to the applicant — do NOT return any of these again,
find genuinely different postings instead:
${e.map(a=>`- ${a.title} at ${a.company} (${a.url})`).join(`
`)}`}function _(e){return typeof e=="string"?e.trim():""}function qt(e){const t=e.trim().replace(/^(?:[-*•]|\d+[.)])\s+/u,"").replace(/,$/,"");if(!t.startsWith("{")||!t.endsWith("}"))return null;let a;try{a=JSON.parse(t)}catch{return null}const n=_(a.url),s=_(a.title);return!/^https?:\/\//i.test(n)||!s?null:{title:s,company:_(a.company),location:_(a.location),url:n,salary:_(a.salary),snippet:_(a.snippet),postedAt:_(a.postedAt)}}function Ut(e){let t="";function a(n){const s=qt(n);s&&e(s)}return{push(n){t+=n;let s;for(;(s=t.indexOf(`
`))!==-1;)a(t.slice(0,s)),t=t.slice(s+1)},end(){a(t),t=""}}}const $t=6,te=[{id:"ats",focus:`Look on applicant tracking systems: ${H.join(", ")}.`},{id:"careers",focus:"Look on the hiring companies' own career pages (company websites, not job boards)."},{id:"boards",focus:"Look on job boards and aggregators (LinkedIn, Indeed, StepStone, Glassdoor, Welcome to the Jungle, Wellfound, Arbeitnow and similar); when the board links to the employer's own posting, give that URL."}];function Ft(e,t,a=[],n){const s=Ae(e),i=j();return`Search the web for current, actually open job postings that fit this
candidate:

${t||"(no candidate background available)"}

${s||"No further constraints — use the candidate's own background to pick a fitting role/location."}

Today is ${i}. Only include postings published in the last ${he} days
that are still accepting applications — skip anything marked closed, expired or filled,
or shown with an older date. Skip postings that are a poor fit for the candidate (wrong
seniority, unrelated field).
Prefer the employer's own posting on its applicant tracking system (${H.join(", ")})
or career page over copies on aggregators, which often outlive the real posting.
Only real individual postings with their direct listing URL — never a search results page,
a generic careers homepage or an aggregator's category page.${n?`
${n}`:""}${Re(a)}

OUTPUT FORMAT — follow exactly. Up to ${$t} of the best matches, best first, as JSON
Lines: one JSON object per line, nothing else (no prose, no markdown, no code fences, no
citations). Each object has exactly these string keys:
{"title":"","company":"","location":"","url":"","salary":"","postedAt":"","snippet":""}
- "url": the posting's direct URL as found.
- "salary": as stated, or "" — never guess.
- "postedAt": YYYY-MM-DD when the posting states a date (resolve "3 days ago" against
  ${i}), else "".
- "snippet": one sentence, at most 25 words, on why it fits this candidate.
If you find no fitting posting, output nothing.`}const F={timeoutMs:9e4,idleMs:4e4,parseTimeoutMs:3e4};function ne(e){const t=a=>a.toLowerCase().replace(/[^a-z0-9]+/g," ").trim();return e.company?`${t(e.company)}|${t(e.title)}`:e.url}async function Dt(e,t,a=[],n,s,i){const o=performance.now();let r=null;const c=[],d=new Set,l=u=>d.has(u.url)||d.has(ne(u))?!1:(d.add(u.url),d.add(ne(u)),c.push(u),!0),h=await Promise.allSettled(te.map(async u=>{const f=Ft(e,t,a,u.focus),v=Ut(U=>{const[$]=q([{...U,source:"openai"}]);!$||!l($)||(r??(r=performance.now()),s==null||s([$]))}),x=performance.now();try{const U=await Ke(f,v.push,{reasoningEffort:"low",timeoutMs:F.timeoutMs,idleMs:F.idleMs,signal:i});return v.end(),U}finally{n==null||n.push({label:`Web search (${u.id})`,ms:performance.now()-x})}}));n==null||n.push({label:"Web search",ms:performance.now()-o}),r!==null&&(n==null||n.push({label:"First result",ms:r-o}));const m=h.flatMap((u,f)=>u.status==="rejected"?[{id:te[f].id,err:u.reason}]:[]),g=u=>u instanceof Error?u.message:"the search failed";if(m.length===h.length&&c.length===0)throw m[0].err;const w=m.map(u=>`Web search (${u.id}) stopped: ${g(u.err)}`);if(c.length>0)return{results:c,warnings:w};const y=h.map(u=>u.status==="fulfilled"?u.value:"").filter(u=>u.trim()).join(`

---

`);return y?{results:await N(n,"Parse results",()=>Oe(y,"openai",t,{negative:e.negative,reasoningEffort:"low",timeoutMs:F.parseTimeoutMs,signal:i})),warnings:w}:{results:c,warnings:w}}const Yt="https://api.tavily.com/search",Jt=2e3;function Bt(e,t,a,n=[]){const s=`Find job postings from the last few weeks, still open, that fit this candidate.
${Ae(e)}

Candidate background: ${a||"(none available)"}${Re(n)}`.trim().slice(0,Jt),i=We(e.negative);return{api_key:t,query:s,search_depth:"advanced",max_results:15,include_answer:!1,time_range:"month",include_published_date:!0,include_domains:H,include_domains_mode:"prefer",...i.length>0?{exclude_domains:i}:{}}}const J={searchTimeoutMs:25e3,parseTimeoutMs:4e4};async function Ht(e,t){for(let a=1;;a++){const n=AbortSignal.timeout(J.searchTimeoutMs);let s;try{s=await fetch(Yt,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e),signal:t?AbortSignal.any([t,n]):n})}catch(o){if(n.aborted)throw new Error(`Tavily search timed out after ${J.searchTimeoutMs/1e3} s.`);if(t!=null&&t.aborted||a>=2)throw o;continue}if(s.ok)return await s.json();const i=await s.text().catch(()=>"");if(a>=2||!(s.status===429||s.status>=500))throw new Error(`Tavily search failed (${s.status}): ${i.slice(0,300)}`);await new Promise(o=>setTimeout(o,1500))}}function Gt(e){return q(e.map(t=>{var a;return{title:t.title,company:"",location:"",url:t.url,salary:"",snippet:t.content.slice(0,240),postedAt:((a=t.published_date)==null?void 0:a.slice(0,10))??"",source:"tavily"}}))}async function Vt(e,t,a,n=[],s,i){var d;const o=Bt(e,t,a,n),r=await N(s,"Tavily search",()=>Ht(o,i));if(!((d=r.results)!=null&&d.length))return{results:[],warnings:[]};const c=r.results.map(l=>`Title: ${l.title}
URL: ${l.url}
${l.published_date?`Published: ${l.published_date}
`:""}${l.content}`).join(`

---

`);try{return{results:await N(s,"Parse results",()=>Oe(c,"tavily",a,{negative:e.negative,reasoningEffort:"low",timeoutMs:J.parseTimeoutMs,signal:i})),warnings:[]}}catch(l){if(i!=null&&i.aborted)throw l;const h=l instanceof Error?l.message:"parse failed";return{results:Gt(r.results),warnings:[`Couldn't sort Tavily's results (${h}) — showing them unfiltered.`]}}}function Kt(e,t){return!e&&!t?"":ze({low:Math.round(e??t??0),high:Math.round(t??e??0)})}function Wt(e){return new Promise(t=>setTimeout(t,e))}const Qt=350,zt=12,ae=15e3;function Xt(e,t,a,n,s){const i=new URL(`https://api.adzuna.com/v1/api/jobs/${n}/search/${s}`);i.searchParams.set("app_id",a.appId),i.searchParams.set("app_key",a.appKey),i.searchParams.set("results_per_page","15"),i.searchParams.set("content-type","application/json"),e&&i.searchParams.set("what",e),t.where&&i.searchParams.set("where",t.where);const o=Qe(t.negative);return o&&i.searchParams.set("what_exclude",o),i.toString()}async function Zt(e,t,a,n,s,i){const o=AbortSignal.timeout(ae);let r;try{r=await fetch(Xt(e,t,a,n,s),{signal:i?AbortSignal.any([i,o]):o})}catch(l){throw o.aborted?new Error(`timed out after ${ae/1e3} s`):l}if(!r.ok){const l=await r.text().catch(()=>"");throw new Error(`Adzuna search failed (${r.status}): ${l.slice(0,300)}`)}const d=(await r.json()).results.map(l=>{var h,m;return{title:l.title,company:((h=l.company)==null?void 0:h.display_name)??"",location:((m=l.location)==null?void 0:m.display_name)??"",url:l.redirect_url,salary:Kt(l.salary_min,l.salary_max),snippet:(l.description??"").slice(0,300),postedAt:l.created??"",source:"adzuna",tag:e}});return q(d)}async function en(e,t,a,n=1,s,i){var y;const o=e.tags&&e.tags.length>0?e.tags:[e.what],r=Math.max(((y=e.grades)==null?void 0:y.length)??0,1),c=Math.max(1,Math.floor(zt/r)),d=Nt(o.slice(0,c),e.grades),l=new Set,h=[],m=[];o.length>c&&m.push(`Only the first ${c} search terms were used with ${r} grades selected.`);let g=0,w=null;for(let p=0;p<d.length&&!(i!=null&&i.aborted);p++){const u=d[p];try{const v=(await Zt(u,e,t,a,n,i)).filter(x=>!l.has(x.url));for(const x of v)l.add(x.url);h.push(...v),v.length>0&&(s==null||s(v))}catch(f){g++,w??(w=f),m.push(`"${u}" — ${f instanceof Error?f.message:"search failed"}`)}p<d.length-1&&await Wt(Qt)}if(g===d.length&&w)throw w;return{results:h,warnings:m}}const tn=new Set(["AT","AU","BE","BR","CA","CH","DE","ES","FR","GB","IN","IT","MX","NL","NZ","PL","RU","SG","US","ZA"]);function nn(e){var a;const t=(a=yt(e))==null?void 0:a.toUpperCase();return t&&tn.has(t)?t.toLowerCase():"us"}const an={type:"object",additionalProperties:!1,required:["what","where"],properties:{what:{type:"string"},where:{type:"string"}}},sn=`You suggest a starting job-search query for the applicant described below.
"what" is a short role/keywords phrase (e.g. "senior backend engineer", "product designer") —
their most recent or clearly strongest role from the CV/Personal Legend. Pick ONE single title:
never join multiple roles or technologies with "/", "," or parentheses (e.g. never "Full-Stack
Developer / Backend Engineer (Go, Python, React)") — that reads as a combined AND-match to a
literal keyword search and returns nothing. "where" is a location (city, region, or country) —
their stated city/country if given, else "".
Output only the two fields, no explanation.`;async function on(){const{profile:e,cvText:t,personalLegend:a}=await S(),n=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:a},null,2),s=await b({schemaName:"job_search_query_suggestion",schema:an,systemPrompt:sn,userPrompt:n,parse:i=>JSON.parse(i),reasoningEffort:"low"});return{what:s.what,where:s.where||[e.city,e.country].filter(Boolean).join(", ")}}const rn={type:"object",additionalProperties:!1,required:["tags"],properties:{tags:{type:"array",items:{type:"string"}}}},cn=`You generate keyword search tags for Adzuna's job-search API, grounded in
the candidate's real background below. Per Adzuna's own docs
(https://developer.adzuna.com/docs/search), "what" is a single literal keyword/phrase match, not
a semantic search and not a boolean query — so ONE combined tag naming several technologies or
role variants (e.g. "Full-Stack Developer / Backend Engineer (Go, Python, React)") matches
nothing. You compensate by generating a small cross-product of short, atomic tags instead, each
run as its own separate search and merged afterwards.

Method — build the tags as a cross-product, exactly like this worked example for a candidate
whose strongest stack is Go and who also does full-stack/backend work:
  golang developer, go developer, go engineer, golang engineer,
  backend engineer, backend developer, fullstack engineer, fullstack developer,
  software engineer, software developer
That is: {primary technology + its common short aliases} × {developer, engineer}, PLUS
{their role-shape words, e.g. backend / fullstack / frontend / mobile / data — whichever
genuinely apply, without a technology} × {developer, engineer}, PLUS a generic "software
developer" / "software engineer" fallback pair.

Rules:
- Base every tag on their actual, strongest-fitting technology/field from the CV/Personal
  Legend — never invent a technology, role-shape, or seniority they don't have.
- Identify the ONE primary technology (e.g. "Go") plus its common short aliases people actually
  search with (e.g. "Golang") — do not alias unrelated technologies together.
- Each tag pairs exactly one technology-or-role-shape word with exactly one of "developer" /
  "engineer" (add "programmer" only if that's a genuinely common term for that stack). Never put
  two technologies, or a technology and a role-shape, in the same tag.
- If the CV shows a clear secondary technology/stack, budget permitting, add its own couple of
  tags the same way — still never combined with the primary one in a single tag.
- For EACH language listed in "languages" below (skip English), also include ONE of the
  strongest-technology tags translated into that language using the natural job-title term a
  native speaker would search with (not a literal word-for-word translation).
- Each tag is 1-3 words, lowercase, and never contains "/", ",", "(", ")", or a seniority
  qualifier ("senior", "junior", etc.).
- Deduplicate. Return 6-12 tags total, most relevant first.
- Output only the tags, no explanation.`;async function ln(){const{profile:e,cvText:t,personalLegend:a,languageLevels:n}=await S(),s=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:a,languages:n.map(o=>o.language)},null,2);return(await b({schemaName:"job_search_tags",schema:rn,systemPrompt:cn,userPrompt:s,parse:o=>JSON.parse(o),reasoningEffort:"low"})).tags.map(o=>o.trim()).filter(Boolean)}const un=4;function pn(e){return JSON.stringify([e.profile.city,e.profile.country,e.cvText,e.personalLegend,e.languageLevels.map(t=>t.language)])}async function dn(e){const t=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(e));return[...new Uint8Array(t)].map(a=>a.toString(16).padStart(2,"0")).join("")}async function xe(e){var r;const t=await dn(pn(await S())),a=await R("jobSearchSuggestionCache")??[],n=a.find(c=>c.key===t);if(n&&(!e||n.tags))return{what:n.what,where:n.where,tags:n.tags,cached:!0};const[s,i]=await Promise.all([n?{what:n.what,where:n.where}:on(),e?ln():Promise.resolve(void 0)]),o={key:t,...s,tags:i!=null&&i.length?i:n==null?void 0:n.tags};return(o.what||(r=o.tags)!=null&&r.length)&&await D("jobSearchSuggestionCache",[o,...a.filter(c=>c.key!==t)].slice(0,un)),{what:o.what,where:o.where,tags:o.tags,cached:!1}}async function hn(e,t={}){var l,h,m;const a=performance.now(),n=[],s=()=>({totalMs:performance.now()-a,stages:n});if(e.provider==="adzuna"){const[g,w]=await Promise.all([z(),M()]);if(!g.adzunaAppId||!g.adzunaAppKey)throw new Error("Add your Adzuna app_id and app_key in Settings first.");let y=e;if(!((l=y.tags)!=null&&l.length))if(y.what.trim())y={...y,tags:[y.what.trim()]};else{const f=performance.now(),v=await xe(!0);n.push({label:v.cached?"Suggest tags (cached)":"Suggest tags",ms:performance.now()-f}),y={...y,what:v.what,where:y.where.trim()||v.where,tags:(h=v.tags)!=null&&h.length?v.tags:[v.what]}}const{results:p,warnings:u}=await N(n,"Adzuna search",()=>en(y,{appId:g.adzunaAppId,appKey:g.adzunaAppKey},nn(w.country),t.page??1,t.onResults,t.signal));return{results:p,resolvedQuery:y,warnings:u,...s()}}const[i,o]=await Promise.all([le(),z()]),r=(i==null?void 0:i.content)??"";if(e.provider==="tavily"){if(!o.tavilyApiKey)throw new Error("Add your Tavily API key in Settings first.");const{results:g,warnings:w}=await Vt(e,o.tavilyApiKey,r,t.excludeResults,n,t.signal);return g.length>0&&((m=t.onResults)==null||m.call(t,g)),{results:g,resolvedQuery:e,...w.length?{warnings:w}:{},...s()}}const{results:c,warnings:d}=await Dt(e,r,t.excludeResults,n,t.onResults,t.signal);return{results:c,resolvedQuery:e,...d.length?{warnings:d}:{},...s()}}const gn={type:"object",additionalProperties:!1,required:["keyRequirements","relevantExperienceHints","suggestedTone","suggestedFocus"],properties:{keyRequirements:{type:"array",items:{type:"string"}},relevantExperienceHints:{type:"array",items:{type:"string"}},suggestedTone:{type:"string"},suggestedFocus:{type:"string"}}};async function fn(e){return b({schemaName:"job_analysis",schema:gn,model:await ge(),systemPrompt:"You analyze job postings for a job-application assistant. Identify the most important requirements and what an applicant should emphasize. Do not invent details that are not present in the posting.",userPrompt:JSON.stringify(e,null,2),parse:t=>JSON.parse(t)})}const mn=`You write tailored cover letters for job applications.

The user message holds the applicant's data as JSON, and may end with an
"Applicant's rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and
   Personal Legend. Never invent experience, technologies, companies,
   education, or achievements, even if the applicant's rules ask for them.
   If information needed to be compelling is missing, write around it
   honestly rather than fabricating it.
2. The applicant's rules. Follow every instruction there on tone, length,
   structure, language, and what to include or avoid, including where it
   departs from the defaults below. Every rule there applies to the whole
   letter, not just the opening.
3. Language. If "postingLanguage" is given, write the entire letter in that
   language, using the salutation, register, and closing conventions native
   speakers of it would expect on a job application (e.g. formal
   "Sie"/"Herr"/"Frau" address and a "Sehr geehrte(r) ..." opening in German,
   not a literal English-to-German translation).
4. The house style below. Its "no exceptions" means no exceptions of your
   own; an explicit applicant rule still overrides it.
5. Tone and emphasis tailored to the job analysis provided.

Output plain prose paragraphs, no markdown headers.

${I}`;async function yn(e,t){const n=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,analysis:e.analysis,postingLanguage:e.postingLanguage||void 0},null,2)+Ce(e.generationRules),s=await Xe(mn,n,t??(()=>{}));return T(s)}function Ce(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const K={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},Pe={type:"object",additionalProperties:!1,required:["subject","body"],properties:{subject:{type:["string","null"]},body:{type:"string"}}},wn=`You are a sharp human editor cleaning up a cover letter draft.

Fix ONLY the flagged AI-writing patterns listed below. Make the minimum
effective edit — do not rewrite sentences that were not flagged, do not
change facts, experience, technologies, or claims, and do not add new
content. Replace banned words/clichés with plain, concrete language.
Rewrite "not X, it's Y" contrasts as a direct statement of Y. Cut
throat-clearing openers, weasel attribution, and importance-puffery instead
of softening them. If the ending is a generic summary/recap, end on the
letter's last concrete point instead. Replace every em dash ("—") with a
comma, a period, or parentheses.

The user message may end with the applicant's own rules for the letter. If a
flagged pattern is something those rules explicitly ask for, leave it as is:
the applicant's rules outrank the house style.

Do not introduce any new AI-slop while editing. For reference, the full
house style is:

${I}

Output plain prose paragraphs, no markdown headers.`;async function bn(e,t,a=""){const n=JSON.stringify({draft:e,flaggedPatterns:t.map(i=>`${i.pattern}: "${i.match}"`)},null,2)+Ce(a),s=await b({schemaName:"cover_letter_polish",schema:K,systemPrompt:wn,userPrompt:n,parse:i=>JSON.parse(i)});return T(s.content)}const vn=["delve","foster","leverage","utilize","facilitate","empower","streamline","robust","cutting-edge","paradigm shift","game changer","this is huge","this changes everything","tapestry","realm","beacon","multifaceted","meticulous","intricate","paramount","transformative","elevate","embark","supercharge","harness","ever-evolving"],En=["it's worth noting","it is worth noting","it's important to note","it is important to note","at the end of the day","when it comes to","at its core","in today's world","in the age of","in the world of","the reality is","the truth is","in terms of","with regard to","in order to","going forward"],Sn=["here's the thing","here's what i mean","let me be clear","i'll be honest","the uncomfortable truth is"],Tn=["this is the part most people skip","what most people get wrong","here's what nobody tells you","the part everyone misses"],kn=["stands as a testament","marks a pivotal moment","plays a vital role","solidifies its position","underscores its significance"],Ln=["experts agree","industry reports suggest","many argue","widely regarded as","studies show"],In=[/^in conclusion\b/i,/^ultimately\b/i,/^overall\b/i];function _n(e){const t=e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`\\b${t.replace(/ /g,"\\s+")}\\b`,"i")}function A(e,t,a){const n=[];for(const s of t){const i=_n(s).exec(e);i&&n.push({pattern:a,match:i[0]})}return n}function An(e){const t=/\b(?:isn'?t|is not)\b[^.!?]{3,60}[,.]?\s*(?:it'?s|it is)\b[^.!?]{3,80}[.!?]/i,a=/\bnot just\b[^.!?]{3,60}(?:\bbut\b|[,.]?\s*(?:it'?s|it is)\b)[^.!?]{0,80}[.!?]/i,n=[],s=t.exec(e);s&&n.push({pattern:"binary-contrast",match:s[0].trim()});const i=a.exec(e);return i&&n.push({pattern:"binary-contrast",match:i[0].trim()}),n}function On(e){const t=e.split(/\n{2,}/).map(n=>n.trim()).filter(Boolean),a=t[t.length-1];if(!a)return[];for(const n of In)if(n.test(a))return[{pattern:"summary-recap-ending",match:a.slice(0,60)}];return[]}function Rn(e){const t=(e.match(/—/g)??[]).length;return t===0?[]:[{pattern:"em-dash",match:t===1?"1 em dash":`${t} em dashes`}]}function xn(e){return[...A(e,vn,"banned-word"),...A(e,En,"empty-phrase"),...A(e,Sn,"throat-clearing-opener"),...A(e,Tn,"faux-insight-setup"),...A(e,kn,"importance-puffery"),...A(e,Ln,"weasel-attribution"),...An(e),...On(e),...Rn(e)]}async function Cn(e,t,a){const n=await S(),s=await fn(e),i=await yn({profile:n.profile,cvText:n.cvText,personalLegend:n.personalLegend,generationRules:n.generationRules,job:e,analysis:s,postingLanguage:t},a),o=xn(i);return o.length===0?{content:i,slopFindings:o,cleaned:!1}:{content:await bn(i,o,n.generationRules),slopFindings:o,cleaned:!0}}const Pn=`You write a short outreach message an applicant sends to a named
recruiter/hiring contact BEFORE or alongside applying, to start a conversation about a specific
job posting — not a cover letter, and not addressed to "the hiring team".

The user message holds the applicant's data as JSON ("contact" is the email address or LinkedIn
URL found on the posting, "channel" is "email" or "linkedin"), and may end with an "Applicant's
rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and Personal Legend. Never
   invent experience, technologies, companies, education, or achievements.
2. The applicant's rules. Follow every instruction there on tone, length, structure, language,
   and what to include or avoid, including where it departs from the defaults below.
3. Language. If "postingLanguage" is given, write the entire message in that language, using
   the salutation and register native speakers of it would expect.
4. Channel. If "channel" is "email", write a short email: "subject" is REQUIRED, never null or
   empty: a specific, non-generic subject line under 80 characters that names the role and the
   company (and, if it fits, the applicant's strongest match), in the message's language. "body"
   opens with a greeting and closes with a signature using the applicant's name; it does not
   repeat the subject. If "channel" is "linkedin", write a LinkedIn connection/message note
   instead: "subject" is null, "body" has no email greeting/signature and stays under LinkedIn's
   informal register.
5. The house style below. Its "no exceptions" means no exceptions of your own; an explicit
   applicant rule still overrides it.

Defaults (apply unless the applicant's rules say otherwise): under 120 words, state who the
applicant is and the one or two things that make them a fit for THIS role, and end with a clear,
low-pressure ask (a quick chat, or just flagging interest before applying). Never sound like a
mass-sent template.

${I}`;async function Nn(e){const a=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,contact:e.contact,channel:X(e.contact)?"email":"linkedin",postingLanguage:e.postingLanguage||void 0},null,2)+Mn(e.outreachRules),n=await b({schemaName:"outreach_message",schema:Pe,model:await fe(),systemPrompt:Pn,userPrompt:a,parse:s=>JSON.parse(s)});return{subject:X(e.contact)?Ne(n.subject,e.job):null,body:T(n.body)}}function Ne(e,t){const a=T((e??"").replace(/^\s*subject\s*:\s*/i,"").replace(/\s+/g," ").trim());if(a)return a;const n=t.position.trim(),s=t.company.trim();return n&&s?`${n} at ${s}`:n||s||"Job application"}function Mn(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const Me={type:"array",items:{type:"object",additionalProperties:!1,required:["text","kind","matchesProfile"],properties:{text:{type:"string"},kind:{type:"string",enum:["hard","soft"]},matchesProfile:{type:"boolean"}}}};function W(e){return`KEYWORDS
- Pick the SKILLS the posting asks for, and nothing else. Each one is either:
  - "hard": a technical skill, tool, technology, programming language, framework, platform,
    method or domain expertise (e.g. "TypeScript", "Kubernetes", "C++", ".NET", "CI/CD",
    "SQL", "machine learning", "financial modelling", "Figma", "Scrum");
  - "soft": a real interpersonal/working skill (e.g. "communication", "mentoring",
    "stakeholder management", "problem-solving", "ownership").
- NEVER return anything that is not a skill. In particular, never return:
  - the company name, its products' brand names used as a name, or any other organization;
  - cities, countries, regions, addresses, time zones;
  - work modes and contract terms ("remote", "hybrid", "on-site", "full-time", "contract");
  - benefits and pay ("salary", "equity", "health insurance", "30 days vacation", "bonus");
  - job titles and seniority ("Senior Backend Engineer", "Team Lead", "junior");
  - years of experience, degrees, certificates as such ("5+ years", "Bachelor's degree");
  - spoken languages ("English", "German") — those are reported separately above;
  - generic words ("team", "experience", "work", "product", "environment", "opportunity",
    "fast-paced environment", "passion").
- Every keyword's "text" MUST be copied VERBATIM from ${e} — the exact same characters
  and casing, not a paraphrase, synonym, or translation — because the extension re-finds this
  exact text on the page to highlight it. A keyword that doesn't appear verbatim is useless.
- Prefer short phrases: single words or 2-3 word phrases, never sentences.
- Return up to 15, most important first. Fewer is fine: return an empty array rather than
  padding the list with anything from the NEVER list above.
- No duplicates, and no two keywords where one is a substring of the other (keep the more
  specific/longer one).
- Set "matchesProfile" to true when the applicant's profile/cvText/personalLegend shows they
  already have, use, or meet that skill — false when the posting asks for it but nothing in
  the applicant's material supports it. Judge substance, not exact wording (e.g.
  "Kubernetes" counts as a match if the CV mentions "container orchestration with K8s" or
  "EKS"). When genuinely unsure, set it to false — this flags a possible gap for the
  applicant to address rather than silently hiding it.`}const jn=new Set(["team","teams","experience","work","job","role","position","company","candidate","opportunity","environment","product","products","customer","customers","client","clients","project","projects","skills","knowledge","ability","responsibilities","requirements","tasks","career","growth","culture","mission","vision","values","impact","passion","motivation","startup","scale-up","industry","business","fast-paced environment","dynamic environment","nice to have","must have","plus","years","year","years of experience","professional experience","work experience","degree","bachelor","bachelor's degree","master","master's degree","university degree","diploma","phd","intern","internship","junior","middle","mid-level","senior","lead","principal","staff","head","manager","remote","fully remote","remote work","hybrid","on-site","onsite","office","in office","home office","homeoffice","relocation","visa sponsorship","full-time","full time","part-time","part time","contract","freelance","permanent","temporary","salary","competitive salary","bonus","equity","stock options","esop","benefits","vacation","paid time off","pto","holidays","health insurance","insurance","pension","gym","gym membership","free lunch","snacks","flexible hours","flexible working hours","learning budget","parental leave","erfahrung","berufserfahrung","aufgaben","anforderungen","unternehmen","vollzeit","teilzeit","festanstellung","gehalt","urlaub","vertrag","büro","mobiles arbeiten","команда","опыт","опыт работы","работа","компания","проект","проекты","задачи","требования","обязанности","удаленно","удаленка","удаленная работа","гибрид","офис","полный день","полная занятость","частичная занятость","зарплата","оклад","бонусы","дмс","отпуск","релокация"]),qn=new Set(Ze.map(e=>L(e))),Un=new RegExp("\\s*,?\\s*(?<![\\p{L}\\p{N}])(?:inc|ltd|llc|gmbh|ag|se|kg|ug|bv|nv|sa|sas|srl|plc|corp|corporation|co|company|oy|ab|as|ооо|ао)\\.?$","iu");function L(e){return e.normalize("NFC").toLowerCase().replace(/ё/g,"е").replace(/[’`]/g,"'").replace(/^[\s"'«».,:;!?()[\]-]+|[\s"'«».,:;!?()[\]-]+$/g,"").replace(/\s+/g," ")}function $n(e){const t=L(e);if(!t)return[];const a=L(t.replace(Un,""));return a&&a!==t?[t,a]:[t]}function Fn(e){const t=L(e);if(!t)return[];const a=e.split(/[,/|·•()]/).map(L).filter(Boolean);return[t,...a]}function Dn(e){return L(e.replace(/\((?:[mwfdx]\s*\/\s*)+[mwfdx]\)/gi,""))}const Yn=/^\d+(?:\s*[-–+]\s*\d*)?\+?\s*(?:years?|yrs?|jahre?n?|лет|года?|ans|años)(?![\p{L}\p{N}])/iu;function B(e,t){const a=e.trim();if([...a].length<2)return!new RegExp("^\\p{Lu}$","u").test(a);if(!new RegExp("\\p{L}","u").test(a)||/[$€£¥₽%]/u.test(a))return!0;const n=L(a);return!n||jn.has(n)||qn.has(n)||Yn.test(n)||$n(t.company).includes(n)||Fn(t.location).includes(n)?!0:n===Dn(t.position)}function Q(e,t){const a=new Set;return e.filter(n=>{const s=L(n.text);return a.has(s)||B(n.text,t)?!1:(a.add(s),!0)})}function Jn(e,t){var s;const a=(s=e.match(/\s*[,;|·•]\s*/u))==null?void 0:s[0];if(!a)return B(e,t)?"":e;const n=new Set;return e.split(/\s*[,;|·•]\s*/u).filter(i=>{const o=L(i);return!i.trim()||n.has(o)||B(i,t)?!1:(n.add(o),!0)}).join(a)}const je={postingLanguages:{type:"array",items:{type:"string"}},languageRequirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...ye,null]}}}},keywords:Me},Bn={type:"object",additionalProperties:!1,required:["company","position","location","description","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},description:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...je}},qe=`LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- languageRequirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or "Native"
  for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent", "professional
  working proficiency" -> "C1"; "conversational" -> "B1". If a language is mentioned but no level
  can be reasonably inferred, set level to null. Do not invent a requirement that isn't stated in
  the text. If nothing is stated, return an empty array.`,Hn=`You read the visible text of a job-posting page and do two things with it
in one pass: extract the structured posting fields, and analyze the result for language and
keywords — against the applicant profile/CV/Personal Legend given below.

EXTRACTION
- Only use information present in "pageText"; leave a field empty/null if unknown.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- For "contact", prefer a named recruiter/hiring manager's email address or LinkedIn
  profile/company URL if one is mentioned, copied VERBATIM (exact characters); otherwise null.

${qe}

${W('"pageText"')}`;async function Gn(e,t){const a=await S(),n=JSON.stringify({profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,pageText:e.slice(0,12e3)},null,2),s=await b({schemaName:"job_extraction_and_brief",schema:Bn,model:await me(),reasoningEffort:"low",systemPrompt:Hn,userPrompt:n,parse:r=>JSON.parse(r)}),i={company:s.company,position:et(s.position),location:s.location,description:s.description,requirements:s.requirements,responsibilities:s.responsibilities,salary:s.salary,techStack:s.techStack,contact:s.contact,url:t},o={language:{postingLanguages:s.postingLanguages,requirements:s.languageRequirements},keywords:Q(s.keywords,i),contact:null};return{job:i,brief:o}}const Vn={type:"object",additionalProperties:!1,required:["company","position","location","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...je}},Kn=`You read the visible text of a job-posting page. It was already parsed
without AI: "knownFields" holds what that found. Fill in what it missed, and analyze the posting
for language and keywords — against the applicant profile/CV/Personal Legend given below.

FIELDS
- Fill only the fields named in "fieldsToFill". For every other posting field return "" / [] /
  null — those are kept from the page as they are. Never re-type the posting's description.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- company: the hiring company, not the job board or recruiting platform hosting the page.
- location: as written in the posting; "" if none.
- requirements, responsibilities: at most 8 items each, each a short phrase (12 words or fewer),
  not copied paragraphs.
- techStack: technology names only.
- contact: a named recruiter/hiring manager's email address or LinkedIn profile/company URL,
  copied VERBATIM (exact characters); otherwise null.
- Only use information present in "pageText"; leave a field empty/null if unknown.

${qe}

${W('"pageText"')}`;async function Wn(e,t){const a=await S(),n=tt(e),s=t||e.description,i=JSON.stringify({profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,knownFields:{position:e.position,company:e.company,location:e.location,salary:e.salary,contact:e.contact},fieldsToFill:n,pageText:s.slice(0,12e3)},null,2),o=await b({schemaName:"job_completion_and_brief",schema:Vn,model:await me(),reasoningEffort:"low",systemPrompt:Kn,userPrompt:i,parse:d=>JSON.parse(d)}),r=nt(e,o,n,s),c={language:{postingLanguages:o.postingLanguages,requirements:o.languageRequirements},keywords:Q(o.keywords,r),contact:null};return{job:r,brief:c}}const Qn=`You are editing an existing cover letter draft on the applicant's
instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the
  letter the instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements
  that aren't already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the
  instruction explicitly asks to change it.
- Output plain prose paragraphs, no markdown headers.
- Don't introduce AI-slop while editing, and clean it from any sentence you
  touch.

${I}`;async function zn(e,t,a){const n=JSON.stringify({draft:e,instructions:t,job:a},null,2),s=await b({schemaName:"cover_letter_revision",schema:K,model:await at(),systemPrompt:Qn,userPrompt:n,parse:i=>JSON.parse(i)});return T(s.content)}const Xn=`You are editing an existing outreach message (an email or LinkedIn note
to a recruiter/hiring contact) on the applicant's instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the message the
  instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements that aren't
  already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the instruction explicitly
  asks to change it.
- If the draft's "subject" is null, keep it null (it's a LinkedIn note). Otherwise keep a
  specific subject line, changing it only if the instruction (or the edit) requires it.
- Don't introduce AI-slop while editing, and clean it from any sentence you touch.

${I}`;async function Zn(e,t,a){const n=JSON.stringify({draft:e,instructions:t,job:a},null,2),s=await b({schemaName:"outreach_message_revision",schema:Pe,model:await fe(),systemPrompt:Xn,userPrompt:n,parse:i=>JSON.parse(i)});return{subject:e.subject===null?null:Ne(s.subject||e.subject,a),body:T(s.body)}}const ea=`You translate a cover letter for the applicant's own understanding —
not for submission. Translate faithfully, preserve paragraph breaks, and keep
names, companies, and technical terms as-is where translating them would be
unnatural. Do not use em dashes ("—"); use commas or periods. Output plain
prose paragraphs, no markdown headers, no notes about the translation itself.`;async function ta(e,t){const a=JSON.stringify({content:e,targetLanguage:t},null,2),n=await b({schemaName:"cover_letter_translation",schema:K,systemPrompt:ea,userPrompt:a,parse:s=>JSON.parse(s)});return T(n.content)}const na={type:"object",additionalProperties:!1,required:["answer","sufficientInfo"],properties:{answer:{type:"string"},sufficientInfo:{type:"boolean"}}},se=`You answer a custom question from a job application form on the
applicant's behalf.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend,
  cover letter, custom fields, language levels, and job posting. Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, the
  "languageLevels" list is the authoritative answer (CEFR levels the
  applicant self-reported in Settings) — use it directly rather than
  guessing from the CV or defaulting to a low/neutral level.
- If the profile/CV/Personal Legend/etc genuinely lack what's needed to
  answer this question — not just a minor detail, but the actual substance
  being asked for — set "sufficientInfo" to false and "answer" to an empty
  string. Do NOT write a sentence explaining that you don't have the
  information (e.g. "I don't have this information available") — that text
  would otherwise get typed straight into the applicant's form field, which
  is worse than leaving it blank for the applicant to fill in themselves.
  Only do this when the information is truly absent; a question you can
  answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient —
  set sufficientInfo to true and give that honest answer.
- If "postingLanguage" is given, write the answer in that language, using
  the salutation/register conventions native speakers of it would expect on
  a job application (e.g. formal "Sie"/"Herr"/"Frau" address in German, not
  a literal English-to-German translation) — unless the question itself, or
  "generationRules", explicitly asks for a different language.
- If this question is a newsletter, marketing-email, or job-alert
  subscription opt-in phrased as a choice (e.g. "Would you like to
  subscribe to our newsletter? Yes/No"), always choose the option that
  declines it — the applicant never needs this to submit the application.
- "faq" is a set of pre-written answers to standard interview-FAQ questions
  (spec_5 section B). If the question being asked now is the same as, or a
  close variant of, one already in "faq", reuse its substance and phrasing —
  adapt only what the target field's length/format actually requires — so
  the applicant's answer stays consistent across different forms rather
  than being re-derived from scratch each time.
- Match the question's expected length: a short field gets a short answer, an
  open-ended "tell us about..." field gets a fuller one.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text, no markdown, no restating the question.

${I}`,aa=/\b(?:please\s+(?:provide|specify|clarify)|could\s+you\s+(?:please\s+)?(?:provide|clarify|specify)|i\s+(?:don'?t|do\s+not)\s+see)\b.{0,40}?\b(?:question|prompt)\b|\bno\s+(?:specific\s+)?question\s+(?:was|is)?\s*(?:provided|given|specified|attached)\b/i;function Ue(e){const t=e.trim();return t?t.length<220&&aa.test(t):!0}const sa=`
- This is a MULTIPLE-CHOICE question: "options" lists the allowed answers.
  Reply with EXACTLY ONE option, copied verbatim, and nothing else.
- Base the choice on the applicant's profile/CV/Personal Legend. If the
  needed fact is genuinely absent (e.g. pronouns not stated anywhere),
  prefer a neutral option, an explicit "prefer not to say", or the option
  that commits the applicant least.`,ia=`
- This is a SELECT-ALL-THAT-APPLY question: "options" lists every allowed
  answer. Reply with every option that genuinely applies, each copied
  verbatim, joined by " | " (a single pipe surrounded by one space on each
  side) — nothing else. If none apply, reply with an empty string.
- Base each choice strictly on the applicant's profile/CV/Personal Legend —
  never include an option just because it's plausible or common; only ones
  the applicant's own material actually supports.`,oa=`
- This field only accepts a plain number: reply with digits only (a single
  "." for a decimal if needed) — no currency symbol, no thousands
  separator, no unit, no words, no range. If a range genuinely fits best
  (e.g. a salary expectation given as "65-75k"), reply with one
  representative figure (its midpoint), not the range.`;function ra(e){return`
- This field only accepts a date in the exact format "${Te[e]}"
  — reply with ONLY that value, nothing else (no words, no explanation).
  "todayISO" in the data below is today's date: compute the answer from it
  — e.g. "available with one month's notice" → todayISO plus one month;
  "immediately" / "as soon as possible" / no stated constraint → todayISO
  itself. Never answer with a description of the notice period or
  availability instead of the date itself.`}async function ca(e,t,a,n,s,i,o){const[r,c]=await Promise.all([S(),R("lastCoverLetter")]),{input:d,promptCacheKey:l}=we(r,c??"",t,o),h={question:e,options:a,multi:i,numeric:n,dateKind:s},m=Y(h);try{const g=await G({input:d,promptCacheKey:l,questions:m?be(h,0):[ve(h,0)]});if(m){const w=Ee(h,0,g);if(w)return w}else if(Se(0,g)===!1)return{answer:"",sufficientInfo:!1}}catch(g){if(g instanceof V)throw g;console.warn("[Filler] Decisions API failed, answering via Responses:",g)}return la(e,t,a,n,s,i,o)}async function la(e,t,a,n,s,i,o){const[r,c]=await Promise.all([S(),R("lastCoverLetter")]),d=JSON.stringify({job:t,profile:r.profile,cvText:r.cvText,personalLegend:r.personalLegend,generationRules:r.generationRules,coverLetter:c??"",languageLevels:r.languageLevels,customFields:r.customFields,faq:r.faq.filter(g=>g.answer.trim()),todayISO:j(),postingLanguage:o||void 0,question:e,options:a&&a.length>0?a:void 0},null,2),l=[a&&a.length>0?i?ia:sa:"",n?oa:"",s?ra(s):""].filter(Boolean),h=await b({schemaName:"custom_question_answer",schema:na,systemPrompt:l.length>0?[se,...l].join(`
`):se,userPrompt:d,parse:g=>JSON.parse(g)});return!h.sufficientInfo||Ue(h.answer)?{answer:"",sufficientInfo:h.sufficientInfo}:{answer:a&&a.length>0||n||!!s?h.answer:T(h.answer),sufficientInfo:!0}}const ua={type:"object",additionalProperties:!1,required:["questions"],properties:{questions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","question"],properties:{index:{type:"integer"},question:{type:"string"}}}}}},pa=`You are given a block of a job-application form: its visible text, and a
list of the input fields inside it. For each field that asks the applicant
something, return the question it is asking, phrased as a plain question.

Rules:
- Use ONLY the visible text provided. Never invent a question.
- Match each question to its field by "index".
- Omit a field that is not a real question (layout helper, hidden field,
  search box, honeypot, a plain "First name"-style profile field).
- A field with "options" is a multiple-choice question — still return only
  its question text, not the options.
- Output the question text only — no numbering, no "Question:" prefix.
- Questions may be in any language; keep the form's own language.`;async function da(e,t){if(t.length===0)return{};const a=JSON.stringify({blockText:e.slice(0,6e3),fields:t},null,2),n=await b({schemaName:"block_questions",schema:ua,systemPrompt:pa,userPrompt:a,parse:i=>JSON.parse(i)}),s={};for(const i of n.questions)i.question.trim()&&(s[i.index]=i.question.trim());return s}const ha={type:"object",additionalProperties:!1,required:["checkboxDecisions","questionAnswers"],properties:{checkboxDecisions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","check","category","reason"],properties:{index:{type:"integer"},check:{type:"boolean"},category:{type:"string",enum:["required-consent","marketing","optional","unclear"]},reason:{type:"string"}}}},questionAnswers:{type:"array",items:{type:"object",additionalProperties:!1,required:["id","answer","sufficientInfo"],properties:{id:{type:"string"},answer:{type:"string"},sufficientInfo:{type:"boolean"}}}}}},ga=`You fill in two independent things found on a job-application form at once:
consent checkboxes to decide, and custom questions to answer on the applicant's behalf. The
applicant has already chosen to submit this application.

CHECKBOXES (one decision per item in "checkboxes", matched back by "index")

TICK (check: true) — things required to submit, or that a candidate is normally expected to
accept:
- privacy policy / data protection / GDPR / Datenschutz consent
- terms & conditions / AGB / Nutzungsbedingungen
- confirming the entered information is accurate / truthful
- consent to process and store the application data for THIS hiring process
- storing the data in a talent pool ONLY when the checkbox is marked required
- eligibility self-declarations that hold for any ordinary adult applying for a real job (e.g.
  "I am at least 18 years old", "I am legally entitled to work in [country]", "I have no
  undisclosed conflicts of interest") — assume true unless the profile/CV explicitly states
  otherwise; a genuine job applicant submitting this form is virtually always eligible, and
  leaving a required declaration like this unticked blocks submission for no real reason

DO NOT TICK (check: false) — optional and promotional:
- newsletters, marketing e-mails, "career news", event invitations
- job alerts / notifications about new postings (e.g. "Benachrichtigungen über neue
  Stellenausschreibungen erhalten")
- sharing data with third parties / partner companies for marketing
- joining a talent pool / candidate database when NOT required
- anything that benefits the applicant only beyond this one application

Rules:
- "required: true" means the form marks the field mandatory — a strong signal to tick, unless
  the text is clearly marketing.
- A newsletter/marketing-email/job-alert opt-in is NEVER ticked, even when the form marks it
  "required" — that flag is routinely misused by forms to guilt-trip applicants into
  subscribing, even though applicants never actually need it to submit. When genuinely in doubt
  whether a required checkbox is a real submission requirement or a disguised newsletter
  opt-in, prefer NOT ticking it.
- If a checkbox is ambiguous AND not required, set check: false.
- Labels may be in any language; judge by meaning, not keywords.
- category: "required-consent" (ticked, mandatory-type), "marketing" (left off), "optional"
  (non-marketing but skippable, left off unless required), "unclear" (left off). reason: one
  short phrase.
- Return one decision per input item in "checkboxes", using its "index". If "checkboxes" is
  empty, return an empty array.

QUESTIONS (one answer per item in "questions", matched back by "id")

Ground rules:
- Use ONLY facts present in the shared "profile"/"cvText"/"personalLegend"/"generationRules"/
  "coverLetter"/"languageLevels"/"customFields"/"faq" given below, plus "job". Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, "languageLevels" is the
  authoritative answer (CEFR levels the applicant self-reported in Settings) — use it directly
  rather than guessing from the CV or defaulting to a low/neutral level.
- If the shared material genuinely lacks what's needed to answer a given question — not just a
  minor detail, but the actual substance being asked for — set that item's "sufficientInfo" to
  false and "answer" to an empty string. Do NOT write a sentence explaining that you don't have
  the information — that text would otherwise get typed straight into the applicant's form
  field, which is worse than leaving it blank. Only do this when the information is truly
  absent; a question you can answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient.
- If "postingLanguage" is given, write answers in that language, using the salutation/register
  conventions native speakers of it would expect on a job application (e.g. formal
  "Sie"/"Herr"/"Frau" address in German) — unless the question itself, or "generationRules",
  explicitly asks for a different language.
- A newsletter/marketing-email/job-alert subscription opt-in phrased as a question (e.g. "Would
  you like to subscribe to our newsletter? Yes/No") always gets the option that declines it.
- "faq" is a set of pre-written answers to standard interview-FAQ questions. If a question being
  asked now is the same as, or a close variant of, one already in "faq", reuse its substance and
  phrasing — adapt only what the target field's length/format actually requires.
- Match each question's expected length: a short field gets a short answer, an open-ended
  "tell us about..." field gets a fuller one.
- Output plain text per answer, no markdown, no restating the question.
- Each item in "questions" may also carry:
  - "options" (and not "multi"): a single-choice question — reply with EXACTLY ONE option,
    copied verbatim, nothing else. If the needed fact is genuinely absent (e.g. pronouns not
    stated anywhere), prefer a neutral option or an explicit "prefer not to say".
  - "options" with "multi": true: a select-all-that-apply question — reply with every option
    that genuinely applies, each copied verbatim, joined by " | " (one pipe, one space each
    side). If none apply, reply with an empty string. Never include an option just because it's
    plausible — only ones the applicant's own material actually supports.
  - "numeric": true: the field only accepts a plain number — reply with digits only (a single
    "." for a decimal if needed), no currency symbol, no thousands separator, no unit, no words,
    no range. If a range genuinely fits best (e.g. "65-75k"), reply with one representative
    figure (its midpoint).
  - "dateFormat": the field only accepts a date in exactly that format — reply with ONLY that
    value, nothing else. "todayISO" below is today's date: compute the answer from it — e.g.
    "available with one month's notice" -> todayISO plus one month; "immediately"/"as soon as
    possible"/no stated constraint -> todayISO itself.
- Return one answer per input item in "questions", using its "id". If "questions" is empty,
  return an empty array.

${I}`;function fa(e,t){const a=new Map;for(const n of t)a.set(n.index,n);return e.map((n,s)=>{const i=a.get(s);if(i){const o=i.check&&Z(n.label)?!1:i.check;return{name:n.name,label:n.label,check:o,category:i.category,reason:i.reason}}return Z(n.label)?{name:n.name,label:n.label,check:!1,category:"marketing",reason:"No decision returned — looks like a newsletter/marketing opt-in"}:{name:n.name,label:n.label,check:n.required,category:n.required?"required-consent":"unclear",reason:n.required?"Marked required by the form":"No decision returned"}})}function ma(e,t){const a=new Map;for(const n of t)a.set(n.id,n);return e.map(n=>{const s=a.get(n.id);if(!s)return{id:n.id,answer:"",sufficientInfo:!0};if(!s.sufficientInfo||Ue(s.answer))return{id:n.id,answer:"",sufficientInfo:s.sufficientInfo};const i=n.options&&n.options.length>0||n.numeric||!!n.dateKind;return{id:n.id,answer:i?s.answer:T(s.answer),sufficientInfo:!0}})}async function ie(e,t,a,n){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[s,i]=await Promise.all([S(),R("lastCoverLetter")]),o=JSON.stringify({job:a,profile:s.profile,cvText:s.cvText,personalLegend:s.personalLegend,generationRules:s.generationRules,coverLetter:i??"",languageLevels:s.languageLevels,customFields:s.customFields,faq:s.faq.filter(c=>c.answer.trim()),todayISO:j(),postingLanguage:n||void 0,checkboxes:e.map((c,d)=>({index:d,label:c.label,required:c.required,currentlyChecked:c.checked})),questions:t.map(c=>({id:c.id,question:c.question,options:c.options&&c.options.length>0?c.options:void 0,multi:c.multi,numeric:c.numeric,dateFormat:c.dateKind?Te[c.dateKind]:void 0}))},null,2),r=await b({schemaName:"page_content_decisions",schema:ha,systemPrompt:ga,userPrompt:o,parse:c=>JSON.parse(c)});return{checkboxDecisions:fa(e,r.checkboxDecisions),questionAnswers:ma(t,r.questionAnswers)}}async function ya(e,t,a,n){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[s,i]=await Promise.all([S(),R("lastCoverLetter")]),{input:o,promptCacheKey:r}=we(s,i??"",a,n),c=t.map((p,u)=>({q:p,i:u})),d=c.filter(({q:p})=>Y(p)),l=c.filter(({q:p})=>!Y(p));let h;try{h=await G({input:o,promptCacheKey:r,questions:[...st(e),...d.flatMap(({q:p,i:u})=>be(p,u)),...l.map(({q:p,i:u})=>ve(p,u))]})}catch(p){if(p instanceof V)throw p;return console.warn("[Filler] Decisions API failed, falling back to Responses:",p),ie(e,t,a,n)}const m=e.map((p,u)=>it(p,u,h)),g=e.filter((p,u)=>!m[u]),w=new Map,y=[];for(const{q:p,i:u}of d){const f=Ee(p,u,h);f?w.set(p.id,{id:p.id,...f}):y.push(p)}for(const{q:p,i:u}of l)Se(u,h)===!1?w.set(p.id,{id:p.id,answer:"",sufficientInfo:!1}):y.push(p);if(g.length>0||y.length>0){const p=await ie(g,y,a,n);for(const f of p.questionAnswers)w.set(f.id,f);const u=new Map(p.checkboxDecisions.map(f=>[f.name+"\0"+f.label,f]));e.forEach((f,v)=>{m[v]||(m[v]=u.get(f.name+"\0"+f.label)??null)})}return{checkboxDecisions:m.filter(p=>p!==null),questionAnswers:t.map(p=>w.get(p.id)??{id:p.id,answer:"",sufficientInfo:!0})}}const wa={type:"object",additionalProperties:!1,required:["postingLanguages","requirements","keywords","contact"],properties:{postingLanguages:{type:"array",items:{type:"string"}},requirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...ye,null]}}}},keywords:Me,contact:{type:["string","null"]}}},ba=`You read a job posting and report three independent things about it: its
language, the skills it asks for (keywords), and (only if asked below) a recruiter/hiring
contact. Judge language and keywords against the applicant profile/CV/Personal Legend given
below.

LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- requirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or
  "Native" for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent",
  "professional working proficiency" -> "C1"; "conversational" -> "B1". If a language is
  mentioned but no level can be reasonably inferred, set level to null. Do not invent a
  requirement that isn't stated in the text. If nothing is stated, return an empty array.

${W("the posting text (job title, description, requirements, responsibilities)")}

CONTACT
- "job.contact" below is the recruiter/hiring contact already found elsewhere, or null if none
  was found yet.
- If it is already set (not null), ignore this entirely and return "contact": null — there is
  nothing to add.
- If it is null, look for one in the job's own text (description/requirements/responsibilities):
  a named recruiter/hiring manager's email address, or a LinkedIn profile/company URL. If you
  find one, copy it VERBATIM (exact characters) so it can be re-found on the page for
  highlighting — the same rule as for keywords. If none is mentioned, return "contact": null.`;async function va(e){const t=await S(),a=JSON.stringify({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,job:e},null,2),n=await b({schemaName:"job_brief",schema:wa,model:await ge(),systemPrompt:ba,userPrompt:a,parse:s=>JSON.parse(s)});return{language:{postingLanguages:n.postingLanguages,requirements:n.requirements},keywords:Q(n.keywords,e),contact:n.contact}}const Ea={type:"object",additionalProperties:!1,required:["cvId","reason"],properties:{cvId:{type:"string"},reason:{type:"string"}}},Sa=`You pick which of an applicant's CVs to send to one job posting.
Each CV has an id, a name, the language it's written in, the applicant's own rules for which
postings it's for, and the start of its text.
- Prefer a CV written in the posting's language; if none, an English one.
- Then follow the applicant's rules: the CV whose rules fit this posting best.
- Then the one marked default for that language.
Return the chosen CV's exact "id" and a reason of at most 10 words. Plain text, no em dashes.`;async function Ta(e,t,a){if(t.length<2)return null;const n=t.map((s,i)=>`cv${i+1}`);try{const s=await G({input:[{role:"user",content:[{type:"input_text",text:"A job posting the applicant is applying to:"},{type:"input_json",data:{position:e.position,company:e.company,location:e.location,language:a??null,techStack:e.techStack,description:e.description.slice(0,4e3)}}]}],questions:[{type:"choice",name:"cv",instructions:"Which of the applicant's CVs should be sent to this posting? Prefer a CV written in the posting's language (else an English one), then the one whose rules fit the posting best, then the one marked default for that language.",choices:t.map((r,c)=>({value:n[c],description:ka(r)}))}]}),i=ot(s,"cv"),o=i?n.indexOf(i.choice):-1;return!i||o<0||i.confidence<rt.cvChoice?null:{cvId:t[o].id,reason:"",source:"ai",confidence:i.confidence}}catch(s){if(s instanceof V)throw s;return console.warn("[Filler] Decisions API failed, choosing the CV via Responses:",s),La(e,t,a)}}function ka(e){var t;return[`Name: ${ke(e)}.`,`Language: ${e.language?Le(e.language):"not set"}${e.isDefaultForLanguage?" (default CV for that language)":""}.`,(t=e.rules)!=null&&t.trim()?`Applicant's rules for it: ${e.rules.trim()}`:"",`Starts: ${e.text.slice(0,600).replace(/\s+/g," ")}`].filter(Boolean).join(" ")}async function La(e,t,a){if(t.length<2)return null;const n={posting:{position:e.position,company:e.company,location:e.location,language:a??null,techStack:e.techStack,description:e.description.slice(0,4e3)},cvs:t.map(i=>({id:i.id,name:ke(i),language:i.language?Le(i.language):null,defaultForLanguage:!!i.isDefaultForLanguage,rules:i.rules??"",textStart:i.text.slice(0,1200)}))},s=await b({schemaName:"cv_choice",schema:Ea,model:await Ie(),reasoningEffort:"low",systemPrompt:Sa,userPrompt:JSON.stringify(n,null,2),parse:i=>JSON.parse(i)});return t.some(i=>i.id===s.cvId)?{cvId:s.cvId,reason:s.reason.replace(/—/g,",").trim()||"AI pick",source:"ai"}:null}const Ia={type:"object",additionalProperties:!1,required:["values"],properties:{values:{type:"array",items:{type:"object",additionalProperties:!1,required:["name","value","reason"],properties:{name:{type:"string"},value:{type:"string"},reason:{type:"string"}}}}}},_a=`You adapt an applicant's CV template to one specific job posting by
choosing a value for each {{placeholder}} in it.

Each variable comes with:
- "description": the applicant's own instruction for what the placeholder means and
  how to choose it. Follow it.
- "mode": "choice" means "value" MUST be exactly one of "options", copied verbatim
  (same spelling, same case, same line breaks). "free" means "options" are only
  examples of the expected shape and length; write the value that fits this posting
  in that same shape (e.g. a city name, a comma-separated list).
- "foundInPosting": options that literally occur in the posting text, most frequent
  first. A strong hint, not an order: the role's actual focus matters more than a
  passing mention.

Rules:
- Pick what makes this CV the closest honest match for this posting: its title, its
  location, its main technology, the vocabulary it uses.
- A job title / position value is the bare role name: no bracketed asides like (m/w/d),
  (f/m/d) or (Remote), no seniority level (Senior, Middle, Junior, Sr., Staff, Principal),
  no team, location or contract qualifiers. "Senior Backend Engineer (m/f/d)" -> "Backend Engineer".
- Honesty: never make the CV claim a skill, technology or experience the applicant's
  CV text / Personal Legend doesn't support, unless the variable's description
  explicitly asks for it. For list-like values, prefer terms that are both in the
  posting and supported by the applicant's background.
- Write the value in the same language as the surrounding template text.
- Return one entry per variable given, using its exact "name".
- "reason": one short sentence (max ~15 words) on why this value fits the posting.
- Plain text only, no markdown, no em dashes.`;function Aa(e,t){const a=s=>s.trim().replace(/\s+/g," ").toLowerCase(),n=a(e);return t.options.find(s=>a(s)===n)??null}async function Oa(e,t){const a=new Set(ct(t.content)),n=t.variables.filter(r=>a.has(r.name));if(n.length===0)return[];const s=await S(),i={variables:n.map(r=>({name:r.name,mode:r.mode,description:r.description,options:r.options,foundInPosting:lt(r.options,e)})),template:t.content.slice(0,12e3),job:{position:e.position,company:e.company,location:e.location,techStack:e.techStack,requirements:e.requirements,responsibilities:e.responsibilities,description:e.description.slice(0,8e3)},applicant:{cvText:s.cvText.slice(0,12e3),personalLegend:s.personalLegend.slice(0,8e3),city:s.profile.city,country:s.profile.country}},o=await b({schemaName:"cv_template_values",schema:Ia,model:await Ie(),systemPrompt:_a,userPrompt:JSON.stringify(i,null,2),parse:r=>JSON.parse(r)});return n.map(r=>{const c=o.values.find(l=>l.name===r.name);if(!c)return{name:r.name,value:ee(r,e),reason:""};if(r.mode==="choice"&&r.options.length>0){const l=Aa(c.value,r);return l?{name:r.name,value:l,reason:T(c.reason)}:{name:r.name,value:ee(r,e),reason:""}}const d=T(c.value);return{name:r.name,value:ut(r.name)?Jn(d,e):d,reason:T(c.reason)}})}async function $e(e){const t=await E(e);await Promise.all(t.map(a=>chrome.tabs.sendMessage(e,{type:"CANCEL_ELEMENT_PICKER",tabId:e},{frameId:a}).catch(()=>{})))}async function k(e,t,a){return(await Promise.all(t.map(s=>chrome.tabs.sendMessage(e,a,{frameId:s}).catch(()=>{})))).filter(s=>!!s)}async function oe(e,t,a,n){if(a!==void 0&&t.includes(a)){const s=await chrome.tabs.sendMessage(e,n,{frameId:a}).catch(()=>{});if(s)return[s]}return k(e,t,n)}function Ra(e){const t=new Map;for(const a of e){const n=a.locator.frameId;t.set(n,[...t.get(n)??[],a])}return t}async function xa(e){switch(e.type){case"FILL_STATS_REPORT":{await gt(e.run);return}case"GET_PROFILE":return{type:"PROFILE_DATA",profile:await M()};case"GET_JOB":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});if(!e.force&&(t!=null&&t.url)){const c=await dt(t.url);if(c!=null&&c.position&&c.company)return{type:"JOB_DATA",job:c,sufficient:!0}}const a=await E(e.tabId),s=(await k(e.tabId,a,e)).filter(c=>c.type==="JOB_DATA");if(s.length===0)return;const i=s.find(c=>c.sufficient);if(i)return t!=null&&t.url&&ht(t.url,i.job),i;const o=s.reduce((c,d)=>d.job.description.length>c.job.description.length?d:c),r=s.map(c=>c.visibleText??"").filter(Boolean).join(`

`).slice(0,2e4);return{type:"JOB_DATA",job:o.job,sufficient:!1,visibleText:r||o.visibleText||"",pageUrl:t==null?void 0:t.url}}case"COMPLETE_JOB":{const{job:t,brief:a}=await Wn(e.job,e.text);return{type:"JOB_DATA",job:t,sufficient:!0,brief:a}}case"EXTRACT_JOB_FROM_TEXT":{const t=await chrome.tabs.get(e.tabId).catch(()=>{}),{job:a,brief:n}=await Gn(e.text,(t==null?void 0:t.url)??"");return{type:"JOB_DATA",job:a,sufficient:!0,brief:n}}case"AUTOFILL":{const t=await E(e.tabId),n=(await k(e.tabId,t,e)).filter(s=>s.type==="AUTOFILL_RESULT");return{type:"AUTOFILL_RESULT",filled:n.reduce((s,i)=>s+i.filled,0),total:n.reduce((s,i)=>s+i.total,0),generatedPassword:n.map(s=>s.generatedPassword).find(Boolean)??null}}case"GENERATE_COVER_LETTER":{const{tabId:t}=e,a=e.job.url;let n="",s=0;await P(t,{jobUrl:a,status:"generating",content:""});let i;try{i=await Cn(e.job,e.postingLanguage,o=>{chrome.runtime.sendMessage({type:"COVER_LETTER_STREAM_CHUNK",tabId:t,delta:o}).catch(()=>{}),n+=o,Date.now()-s>400&&(s=Date.now(),P(t,{jobUrl:a,status:"generating",content:n}).catch(()=>{}))})}catch(o){const r=o instanceof Error?o.message:String(o);throw await P(t,{jobUrl:a,status:"error",content:"",error:r}).catch(()=>{}),o}return await P(t,{jobUrl:a,status:"done",content:i.content,cleanedPatterns:i.cleaned?Array.from(new Set(i.slopFindings.map(o=>o.pattern))):[]}),await D("lastCoverLetter",i.content),{type:"COVER_LETTER_RESULT",content:i.content,slopFindings:i.slopFindings,cleaned:i.cleaned}}case"UPLOAD_FILE":{const t=await E(e.tabId),n=(e.targetLocator?await oe(e.tabId,t,e.targetLocator.frameId,e):await k(e.tabId,t,e)).filter(s=>s.type==="UPLOAD_FILE_RESULT");return{type:"UPLOAD_FILE_RESULT",nativeInputs:n.reduce((s,i)=>s+i.nativeInputs,0),dropZones:n.reduce((s,i)=>s+i.dropZones,0)}}case"REVISE_COVER_LETTER":{const t=await zn(e.content,e.instructions,e.job);return await D("lastCoverLetter",t),{type:"REVISE_COVER_LETTER_RESULT",content:t}}case"TRANSLATE_COVER_LETTER":return{type:"TRANSLATE_COVER_LETTER_RESULT",content:await ta(e.content,e.targetLanguage)};case"GENERATE_OUTREACH_MESSAGE":{const t=await S(),a=await Nn({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,outreachRules:t.outreachRules,job:e.job,contact:e.contact,postingLanguage:e.postingLanguage});return{type:"OUTREACH_MESSAGE_RESULT",subject:a.subject,body:a.body}}case"REVISE_OUTREACH_MESSAGE":{const t=await Zn({subject:e.subject,body:e.body},e.instructions,e.job);return{type:"OUTREACH_MESSAGE_RESULT",subject:t.subject,body:t.body}}case"GET_FRAME_ACCESS":return{type:"FRAME_ACCESS",blockedOrigins:await vt(e.tabId)};case"DETECT_CUSTOM_QUESTIONS":{const t=await E(e.tabId),a=await k(e.tabId,t,e),n=new Set,s=[];for(const i of a)if(i.type==="CUSTOM_QUESTIONS_DATA")for(const o of i.questions)n.has(o.question)||(n.add(o.question),s.push({...o,id:`question-${s.length}`}));return{type:"CUSTOM_QUESTIONS_DATA",questions:s}}case"ANSWER_CUSTOM_QUESTION":{const t=await ca(e.question,e.job,e.options,e.numeric,e.dateKind,e.multi,e.postingLanguage);return{type:"CUSTOM_QUESTION_ANSWER",question:e.question,answer:t.answer,sufficientInfo:t.sufficientInfo}}case"FILL_CUSTOM_QUESTION_ANSWERS":{const t=await E(e.tabId),a=await k(e.tabId,t,e);let n=0;const s=[];for(const i of a)i.type==="CUSTOM_QUESTION_FILL_RESULT"&&(n+=i.filled,s.push(...i.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:n,unfilled:s}}case"START_ELEMENT_PICKER":{const t=await E(e.tabId),a=t.map(s=>chrome.tabs.sendMessage(e.tabId,e,{frameId:s}).then(i=>i?{result:i,frameId:s}:void 0).catch(()=>{})),n=await new Promise(s=>{let i=a.length;i===0&&s(void 0);for(const o of a)o.then(r=>{i-=1,r?s(r):i===0&&s(void 0)})});return await Promise.all(t.map(s=>chrome.tabs.sendMessage(e.tabId,{type:"CANCEL_ELEMENT_PICKER",tabId:e.tabId},{frameId:s}).catch(()=>{}))),n?{...n.result,picked:n.result.picked.map(s=>({...s,locator:{...s.locator,frameId:n.frameId}}))}:{type:"ELEMENT_PICKER_RESULT",cancelled:!0,picked:[],blockText:"",semanticCount:0}}case"CANCEL_ELEMENT_PICKER":{await $e(e.tabId);return}case"DECOMPOSE_BLOCK":return{type:"BLOCK_QUESTIONS",questions:await da(e.blockText,e.fields)};case"FILL_QUESTION_ANSWERS_BY_LOCATOR":{const t=await E(e.tabId),a=(await Promise.all([...Ra(e.items)].map(([i,o])=>oe(e.tabId,t,i,{...e,items:o})))).flat();let n=0;const s=[];for(const i of a)i.type==="CUSTOM_QUESTION_FILL_RESULT"&&(n+=i.filled,s.push(...i.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:n,unfilled:s}}case"DETECT_CHECKBOXES":{const t=await E(e.tabId),a=await k(e.tabId,t,e),n=new Set,s=[];for(const i of a)if(i.type==="CHECKBOXES_DATA")for(const o of i.checkboxes){const r=o.name||o.label;!r||n.has(r)||(n.add(r),s.push({...o,id:`checkbox-${s.length}`}))}return{type:"CHECKBOXES_DATA",checkboxes:s}}case"DECIDE_PAGE_CONTENT":{const{checkboxDecisions:t,questionAnswers:a}=await ya(e.checkboxes,e.questions,e.job,e.postingLanguage);return{type:"PAGE_CONTENT_DECISIONS",checkboxDecisions:t,questionAnswers:a}}case"APPLY_CHECKBOX_DECISIONS":{const t=await E(e.tabId),a=await k(e.tabId,t,e);let n=0;for(const s of a)s.type==="CHECKBOX_APPLY_RESULT"&&(n+=s.changed);return{type:"CHECKBOX_APPLY_RESULT",changed:n}}case"DETECT_JOB_BRIEF":{const t=await va(e.job);return{type:"JOB_BRIEF_DATA",language:t.language,keywords:t.keywords,contact:t.contact}}case"HIGHLIGHT_KEYWORDS":{const t=await E(e.tabId);return{type:"KEYWORD_HIGHLIGHT_RESULT",matched:(await k(e.tabId,t,e)).reduce((s,i)=>i.type==="KEYWORD_HIGHLIGHT_RESULT"?s+i.matched:s,0)}}case"CLEAR_KEYWORD_HIGHLIGHTS":{const t=await E(e.tabId);await k(e.tabId,t,e);return}case"GENERATE_FAQ_ANSWERS":{const t=await ue(),a=await Ct(e.questions,t);try{await pt(a)}catch{}return{type:"FAQ_ANSWERS_RESULT",entries:a}}case"SEARCH_JOBS":{const{searchId:t}=e,a=t?s=>{chrome.runtime.sendMessage({type:"JOB_SEARCH_PROGRESS",searchId:t,results:s}).catch(()=>{})}:void 0,n=setInterval(()=>void chrome.runtime.getPlatformInfo().catch(()=>{}),2e4);try{return{type:"JOB_SEARCH_RESULTS",...await hn(e.query,{page:e.page,excludeResults:e.excludeResults,onResults:a})}}finally{clearInterval(n)}}case"SUGGEST_SEARCH_QUERY":{const{what:t,where:a,tags:n}=await xe(e.provider==="adzuna");return{type:"SEARCH_QUERY_SUGGESTION",what:t,where:a,...e.provider==="adzuna"?{tags:n}:{}}}case"SUGGEST_CV_VALUES":return{type:"CV_VALUES",values:await Oa(e.job,e.template)};case"CHOOSE_CV":return{type:"CV_CHOICE",choice:await Ta(e.job,e.cvs,e.postingLanguage)};default:return}}const Ca="src/sidepanel/index.html";chrome.runtime.onInstalled.addListener(()=>{kt(),chrome.sidePanel.setOptions({enabled:!1})});chrome.contextMenus.onClicked.addListener((e,t)=>{It(e,t)});chrome.action.onClicked.addListener(e=>{if(e.id===void 0)return;const t=e.id;chrome.sidePanel.setOptions({tabId:t,path:`${Ca}?tabId=${t}`,enabled:!0}),chrome.sidePanel.open({tabId:t}).catch(a=>console.error("sidePanel.open failed",a)),Pa(t)});async function Pa(e){await E(e);const t={type:"TAB_ACCESS_GRANTED",tabId:e};await chrome.runtime.sendMessage(t).catch(()=>{})}chrome.tabs.onRemoved.addListener(e=>{ft(e)});chrome.runtime.onMessage.addListener((e,t,a)=>(xa(e).then(a).catch(n=>{a({type:"ERROR",error:n instanceof Error?n.message:String(n),code:n instanceof Error?n.name:void 0})}),!0));chrome.runtime.onConnect.addListener(e=>{const t=/^picker-(\d+)$/.exec(e.name);if(!t)return;const a=Number(t[1]);e.onDisconnect.addListener(()=>{$e(a)})});
