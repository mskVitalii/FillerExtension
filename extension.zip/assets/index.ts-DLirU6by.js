import{P as et,g as be,a as R,b as tt,c as nt,s as at,d as D,e as ve,f as it,h as st,i as ot,j as rt,k as Ee,r as b,J as Z,n as Se,t as Y,l as V,M as ke,m as ct,A as ee,o as lt,p as ut,q as pt,u as G,v as se,w as Te,x as dt,y as oe,z as Le,C as ht,B as Ie,D as ft,E as gt,F as mt,G as Ae,H as yt,I as te,K as M,L as x,N as wt,O as j,Q as K,R as _e,S as Re,T as Oe,U as Ce,V as Pe,W as bt,X as vt,Y as re,Z as U,_ as xe,$ as Ne,a0 as Me,a1 as Et,a2 as St,a3 as $e,a4 as kt,a5 as Tt,a6 as Lt,a7 as q,a8 as It,a9 as At,aa as _t,ab as Rt}from"./template-CqiGRpL-.js";import{c as Ot,a as Ct}from"./phone-D3SACKoL.js";const je={...et,cv:"CV",coverLetter:"Cover Letter",generatePassword:"Generated password"},Pt=Object.keys(je);async function E(e){try{const a=(await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:["content-script.js"]})).map(n=>n.frameId).filter(n=>typeof n=="number");if(a.length>0)return a}catch{}try{return await chrome.scripting.executeScript({target:{tabId:e},files:["content-script.js"]}),[0]}catch{return[0]}}function xt(){const e=[];for(const t of Array.from(document.querySelectorAll("iframe, frame"))){const a=t.getBoundingClientRect(),n=a.width*a.height;t.src&&a.width>=200&&a.height>=150&&e.push({src:t.src,area:n})}return{origin:location.origin,children:e}}async function Nt(e){let t;try{t=await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},func:xt})}catch{return[]}const a=new Set,n=new Map;for(const{result:s}of t)if(s){a.add(s.origin);for(const o of s.children){let r;try{const c=new URL(o.src);if(c.protocol!=="https:"&&c.protocol!=="http:")continue;r=c.origin}catch{continue}n.set(r,Math.max(n.get(r)??0,o.area))}}const i=[];for(const s of[...n.keys()].sort((o,r)=>n.get(r)-n.get(o))){if(a.has(s))continue;if(await chrome.permissions.contains({origins:[`${s}/*`]}).catch(()=>!1)||i.push(s),i.length===3)break}return i}async function Mt(e,t){if(e==="cv"){const i=await be();return(i==null?void 0:i.text)??""}if(e==="coverLetter")return await R("lastCoverLetter")??"";if(e==="generatePassword"){const i=await tt(t);if(i!=null&&i.generatedPassword)return i.generatedPassword;const s=nt();return i&&await at(t,{...i,generatedPassword:s}),s}const a=await D(),n=a[e]??"";return e==="phone"&&n?Ot(n,a.country):n}const N="job-app-assistant-insert",$t={generatePassword:"Generate password"},jt=Pt.map(e=>({id:e,title:$t[e]??je[e]}));function qt(){chrome.contextMenus.removeAll(()=>{chrome.contextMenus.create({id:N,title:"Insert",contexts:["editable"]});for(const e of jt)chrome.contextMenus.create({id:`${N}:${e.id}`,parentId:N,title:e.title,contexts:["editable"]})})}function Ut(e){return e.startsWith(`${N}:`)?e.slice(N.length+1):null}async function Ft(e,t){if(!(t!=null&&t.id)||typeof e.menuItemId!="string")return;const a=Ut(e.menuItemId);if(!a)return;const n=await Mt(a,t.id);await E(t.id);const i={type:"INSERT_VALUE",field:a,value:n};chrome.tabs.sendMessage(t.id,i,{frameId:e.frameId}).catch(()=>{})}const Dt=new Set(["profileCache","cvLibraryCache","legendLibraryCache","customFieldsCache","languageLevelsCache","faqAnswersCache","generationRulesCache","outreachRulesCache"]);let P=null;function Yt(){return Promise.all([D(),be(),ve(),it(),st(),ot(),rt(),Ee()]).then(([e,t,a,n,i,s,o,r])=>({profile:e,cvText:(t==null?void 0:t.text)??"",personalLegend:(a==null?void 0:a.content)??"",generationRules:(n==null?void 0:n.content)??"",outreachRules:(i==null?void 0:i.content)??"",languageLevels:s,customFields:o,faq:r}))}function v(){return P||(P=Yt(),P.catch(()=>{P=null})),P}var we;typeof chrome<"u"&&((we=chrome.storage)!=null&&we.onChanged)&&chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&Object.keys(e).some(a=>Dt.has(a))&&(P=null)});const I=`Write like a specific person, not an AI assistant. These rules have no exceptions:

- NEVER use an em dash ("—"), a spaced en dash ("–") or "--" as punctuation. Real people don't write that way. Use a comma, a period, parentheses, or two sentences.
- Banned words: delve, foster, leverage, utilize, facilitate, empower, streamline, robust, cutting-edge, paradigm shift, game changer, tapestry, realm, beacon, multifaceted, meticulous, intricate, paramount, transformative, elevate, embark, supercharge, harness, ever-evolving. Say the plain thing.
- Cut empty phrases: "it's worth noting", "at the end of the day", "when it comes to", "at its core", "in today's world", "the reality is", "in order to", "going forward".
- No "not X, it's Y" / "the question isn't X, it's Y" / "not just X but Y" contrasts. State Y directly.
- No throat-clearing openers ("Here's the thing", "Let me be clear", "I'll be honest") and no faux-insight setups ("what most people get wrong", "here's what nobody tells you").
- No importance puffery ("stands as a testament", "marks a pivotal moment", "plays a vital role", "underscores its significance"). State the fact and stop.
- No colon reveals: a noun phrase, a colon, then a dramatic lowercase clause.
- No trailing "-ing" clauses that editorialize ("highlighting the commitment to...", "underscoring its importance", "showcasing", "reflecting"). End the sentence.
- No metadiscourse that tells the reader what to notice ("this matters", "this distinction matters", "in other words", "as you can see").
- No "In conclusion" / "Ultimately" / "Overall" recap ending and no cute one-line kicker. Stop on the last concrete point.
- No emoji, no mid-sentence bold, no rhetorical questions.
- Vary sentence shape; don't stack short punchy fragments.
- Be concrete: name the technology, project, number, or outcome instead of calling it "significant", "impactful" or "exciting". Use active voice.`;function S(e){return e.replace(/[ \t]*[—―][ \t]*/g,", ").replace(/[ \t]+--[ \t]+/g,", ").replace(/(\D)[ \t]+–[ \t]+(?=\D)/g,"$1, ").replace(/[ \t]+([,.;:!?])/g,"$1").replace(/,(\s*[.;:!?])/g,"$1").replace(/,[ \t]*,/g,",").replace(/^[ \t]*,[ \t]*/gm,"").replace(/([([{])[ \t]*,[ \t]*/g,"$1").replace(/[ \t]*,[ \t]*([)\]}])/g,"$1").replace(/,[ \t]*$/gm,"").replace(/[ \t]+$/gm,"")}const Vt=`You write the applicant's own answers to standard interview-FAQ
questions (spec_5 section B) — general-purpose answers meant to be reused, as-is or
lightly adapted, whenever a real application form asks a close variant of one of them.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend, and
  custom fields. Never invent experience, technologies, companies, education,
  achievements, or a concrete salary figure that wasn't actually given.
- If information needed for a good answer is missing (no CV, no Personal Legend
  content covering it), write a short, honest, generically true answer rather
  than fabricating specifics — the applicant can always sharpen it later.
- Keep each answer 2-5 sentences: concrete and confident, never generic
  corporate filler, no restating the question.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text per answer, no markdown, no numbering.

${I}`;function Ht(e){return{type:"object",additionalProperties:!1,required:["answers"],properties:{answers:{type:"array",minItems:e,maxItems:e,items:{type:"string"}}}}}async function Bt(e){if(e.length===0)return[];const{profile:t,cvText:a,personalLegend:n,generationRules:i,customFields:s}=await v(),o=JSON.stringify({profile:t,cvText:a,personalLegend:n,generationRules:i,customFields:s,questions:e},null,2),r=await b({schemaName:"faq_answers",schema:Ht(e.length),systemPrompt:Vt,userPrompt:o,parse:c=>JSON.parse(c)});return e.map((c,u)=>({question:c,answer:S(r.answers[u]??"")}))}async function Jt(e,t){const a=new Map(t.map(s=>[s.question,s.answer])),n=e.filter(s=>{var o;return!((o=a.get(s))!=null&&o.trim())}),i=await Bt(n);for(const s of i)a.set(s.question,s.answer);return e.map(s=>({question:s,answer:a.get(s)??""}))}async function F(e,t,a){const n=performance.now();try{return await a()}finally{e==null||e.push({label:t,ms:performance.now()-n})}}function Gt(e){return e!=null&&e.length?`Seniority levels to target: ${Z.filter(a=>e.includes(a.id)).map(a=>a.label.toLowerCase()).join(", ")}. Only include postings for these levels.`:""}function Kt(e,t){const a=Z.filter(i=>t==null?void 0:t.includes(i.id));if(a.length===0)return e;const n=[];for(const i of e)for(const s of a)n.push(i.toLowerCase().includes(s.keyword)?i:`${s.keyword} ${i}`.trim());return[...new Set(n)]}const Wt=80;function W(e){const t=new Set,a=[];for(const n of e){const i=n.replace(/\s+/g," ").trim().slice(0,Wt).trim(),s=i.toLowerCase();!i||t.has(s)||(t.add(s),a.push(i))}return a}function $(e){const t=W(e.terms??[]);return t.length>0?t:W([e.what??""])}function zt(e){const t=$(e);return t.length===0?"":t.length===1?`Role/keywords focus: "${t[0]}".`:`Role/keywords: any of ${t.map(a=>`"${a}"`).join(", ")}.`}function Qt(e){return[zt(e),e.where?`Location: "${e.where}".`:"",Gt(e.grades),e.remoteOnly?"Prefer remote-friendly roles.":"",Se(e.negative)].filter(Boolean).join(" ")}const Xt={type:"object",additionalProperties:!1,required:["jobs"],properties:{jobs:{type:"array",items:{type:"object",additionalProperties:!1,required:["title","company","location","url","salary","snippet","postedAt"],properties:{title:{type:"string"},company:{type:"string"},location:{type:"string"},url:{type:"string"},salary:{type:"string"},snippet:{type:"string"},postedAt:{type:"string"}}}}}};function Zt(e,t){const a=Se(t);return`You turn raw web-search results about job openings into a clean,
structured list. The input text was produced by a live internet search and may include
citations, markdown links, or unrelated surrounding prose — extract only genuine
individual job postings from it.

Rules:
- Only include entries that are clearly actual job postings with a real listing URL —
  never a company's generic careers-page homepage, a search-results page, or an
  aggregator's category page.
- "url" must be copied exactly from the source text (never invented).
- "salary" is "" when no figure was given — never guess one.
- "postedAt" is the date the posting was published, as YYYY-MM-DD, only when the text
  states it. Resolve relative dates ("posted 3 days ago", "2w") against today, ${e}.
  Use "" when no date is given — never guess one.
- Drop postings the text marks as closed, expired, filled or "no longer accepting
  applications", and postings published more than ${ke} days before ${e}.
- "snippet" is a 1-2 sentence summary of the role; when a "candidate" background is given
  below, make it say *why this posting fits them* specifically (seniority match, matching
  skills, location/remote fit) rather than just restating the posting.
- If a "candidate" background is given, drop postings that are a poor fit for them (wrong
  seniority, unrelated field) even if they're genuine job postings — only surface ones
  actually worth their time.
- Deduplicate: the same posting linked twice becomes one entry.${a?`
- ${a}`:""}
- If nothing in the text is actually a job posting, return an empty "jobs" array.`}async function qe(e,t,a,n={}){const i=a?`candidate:
${a}

---

${e.slice(0,4e4)}`:e.slice(0,4e4),s=await b({schemaName:"job_listings",schema:Xt,systemPrompt:Zt(Y(),n.negative),userPrompt:i,reasoningEffort:n.reasoningEffort,timeoutMs:n.timeoutMs,signal:n.signal,label:"Parsing search results",parse:o=>JSON.parse(o)});return V(s.jobs.filter(o=>o.url.trim()).map(o=>({...o,source:t})))}function en(e){return e.length===0?"":`

Already found and shown to the applicant — do NOT return any of these again,
find genuinely different postings instead:
${e.map(a=>`- ${a.title} at ${a.company} (${a.url})`).join(`
`)}`}function _(e){return typeof e=="string"?e.trim():""}function tn(e){const t=e.trim().replace(/^(?:[-*•]|\d+[.)])\s+/u,"").replace(/,$/,"");if(!t.startsWith("{")||!t.endsWith("}"))return null;let a;try{a=JSON.parse(t)}catch{return null}const n=_(a.url),i=_(a.title);return!/^https?:\/\//i.test(n)||!i?null:{title:i,company:_(a.company),location:_(a.location),url:n,salary:_(a.salary),snippet:_(a.snippet),postedAt:_(a.postedAt)}}function nn(e){let t="";function a(n){const i=tn(n);i&&e(i)}return{push(n){t+=n;let i;for(;(i=t.indexOf(`
`))!==-1;)a(t.slice(0,i)),t=t.slice(i+1)},end(){a(t),t=""}}}const an=6,ce=[{id:"ats",focus:`Look on applicant tracking systems: ${ee.join(", ")}.`},{id:"careers",focus:"Look on the hiring companies' own career pages (company websites, not job boards)."},{id:"boards",focus:"Look on job boards and aggregators (LinkedIn, Indeed, StepStone, Glassdoor, Welcome to the Jungle, Wellfound, Arbeitnow and similar); when the board links to the employer's own posting, give that URL."}];function sn(e,t,a=[],n){const i=Qt(e),s=Y();return`Search the web for current, actually open job postings that fit this
candidate:

${t||"(no candidate background available)"}

${i||"No further constraints — use the candidate's own background to pick a fitting role/location."}

Today is ${s}. Only include postings published in the last ${ke} days
that are still accepting applications — skip anything marked closed, expired or filled,
or shown with an older date. Skip postings that are a poor fit for the candidate (wrong
seniority, unrelated field).
Prefer the employer's own posting on its applicant tracking system (${ee.join(", ")})
or career page over copies on aggregators, which often outlive the real posting.
Only real individual postings with their direct listing URL — never a search results page,
a generic careers homepage or an aggregator's category page.${n?`
${n}`:""}${en(a)}

OUTPUT FORMAT — follow exactly. Up to ${an} of the best matches, best first, as JSON
Lines: one JSON object per line, nothing else (no prose, no markdown, no code fences, no
citations). Each object has exactly these string keys:
{"title":"","company":"","location":"","url":"","salary":"","postedAt":"","snippet":""}
- "url": the posting's direct URL as found.
- "salary": as stated, or "" — never guess.
- "postedAt": YYYY-MM-DD when the posting states a date (resolve "3 days ago" against
  ${s}), else "".
- "snippet": one sentence, at most 25 words, on why it fits this candidate.
If you find no fitting posting, output nothing.`}const B={timeoutMs:9e4,idleMs:4e4,parseTimeoutMs:3e4};function le(e){const t=a=>a.toLowerCase().replace(/[^a-z0-9]+/g," ").trim();return e.company?`${t(e.company)}|${t(e.title)}`:e.url}async function on(e,t,a=[],n,i,s){const o=performance.now();let r=null;const c=[],u=new Set,l=d=>u.has(d.url)||u.has(le(d))?!1:(u.add(d.url),u.add(le(d)),c.push(d),!0),f=await Promise.allSettled(ce.map(async d=>{const w=sn(e,t,a,d.focus),k=nn(A=>{const[H]=V([{...A,source:"openai"}]);!H||!l(H)||(r??(r=performance.now()),i==null||i([H]))}),O=performance.now();try{const A=await ct(w,k.push,{reasoningEffort:"low",timeoutMs:B.timeoutMs,idleMs:B.idleMs,signal:s});return k.end(),A}finally{n==null||n.push({label:`Web search (${d.id})`,ms:performance.now()-O})}}));n==null||n.push({label:"Web search",ms:performance.now()-o}),r!==null&&(n==null||n.push({label:"First result",ms:r-o}));const g=f.flatMap((d,w)=>d.status==="rejected"?[{id:ce[w].id,err:d.reason}]:[]),p=d=>d instanceof Error?d.message:"the search failed";if(g.length===f.length&&c.length===0)throw g[0].err;const m=g.map(d=>`Web search (${d.id}) stopped: ${p(d.err)}`);if(c.length>0)return{results:c,warnings:m};const y=f.map(d=>d.status==="fulfilled"?d.value:"").filter(d=>d.trim()).join(`

---

`);return y?{results:await F(n,"Parse results",()=>qe(y,"openai",t,{negative:e.negative,reasoningEffort:"low",timeoutMs:B.parseTimeoutMs,signal:s})),warnings:m}:{results:c,warnings:m}}const rn="https://api.tavily.com/search",ue=350,cn=6,ln=3,un=10,pn=40,dn=1500,hn=100;function fn(e,t){const a=e.replace(/["\s]+/g," ").trim(),n=Z.filter(o=>{var r;return(r=t.grades)==null?void 0:r.includes(o.id)}).map(o=>o.label.toLowerCase()).filter(o=>!a.toLowerCase().includes(o)),i=["jobs",t.where.trim().slice(0,hn),t.remoteOnly?"remote":"",...n].filter(Boolean).join(" "),s=Math.max(1,ue-i.length-3);return`"${a.slice(0,s).trim()}" ${i}`.slice(0,ue).trim()}function gn(e,t,a){const n=lt(e.negative);return{api_key:a,query:fn(t,e),search_depth:"advanced",max_results:un,include_answer:!1,time_range:"month",include_published_date:!0,include_domains:ee,include_domains_mode:"prefer",...n.length>0?{exclude_domains:n}:{}}}const z={searchTimeoutMs:25e3,parseTimeoutMs:4e4};async function mn(e,t){for(let a=1;;a++){const n=AbortSignal.timeout(z.searchTimeoutMs);let i;try{i=await fetch(rn,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e),signal:t?AbortSignal.any([t,n]):n})}catch(o){if(n.aborted)throw new Error(`Tavily search timed out after ${z.searchTimeoutMs/1e3} s.`);if(t!=null&&t.aborted||a>=2)throw o;continue}if(i.ok)return await i.json();const s=await i.text().catch(()=>"");if(a>=2||!(i.status===429||i.status>=500))throw new Error(`Tavily search failed (${i.status}): ${s.slice(0,300)}`);await new Promise(o=>setTimeout(o,1500))}}function yn(e){const t=e?Date.parse(e):NaN;return Number.isNaN(t)?"":new Date(t).toISOString().slice(0,10)}function wn(e){return V(e.map(t=>({title:t.title,company:"",location:"",url:t.url,salary:"",snippet:(t.content??"").slice(0,240),postedAt:yn(t.published_date),source:"tavily"})))}async function bn(e,t,a){const n=new Array(e.length);let i=0;const s=async()=>{for(;i<e.length;){const o=i++;n[o]=await a(e[o])}};return await Promise.all(Array.from({length:Math.min(t,e.length)},s)),n}function J(e){return e.trim().replace(/#.*$/,"").replace(/\/+$/,"").toLowerCase()}function vn(e,t=[],a=pn){const n=new Set(t.map(o=>J(o.url))),i=[],s=Math.max(0,...e.map(o=>o.length));for(let o=0;o<s&&i.length<a;o++)for(const r of e){const c=r[o];if(!(!(c!=null&&c.url)||n.has(J(c.url)))&&(n.add(J(c.url)),i.push(c),i.length>=a))break}return i}async function En(e,t,a,n=[],i,s){const o=$(e);if(o.length===0)throw new Error("Tavily needs at least one search term.");const r=o.slice(0,cn),c=[];o.length>r.length&&c.push(`Only the first ${r.length} of ${o.length} search terms were searched with Tavily.`);const u=await F(i,"Tavily search",()=>bn(r,ln,async p=>{try{const m=await mn(gn(e,p,t),s);return{term:p,hits:m.results??[]}}catch(m){if(s!=null&&s.aborted)throw m;return{term:p,hits:[],error:m}}})),l=u.filter(p=>p.error!==void 0);if(l.length===u.length)throw l[0].error;for(const p of l)c.push(`"${p.term}" — ${p.error instanceof Error?p.error.message:"search failed"}`);const f=vn(u.map(p=>p.hits),n);if(f.length===0)return{results:[],warnings:c};const g=f.map(p=>`Title: ${p.title}
URL: ${p.url}
${p.published_date?`Published: ${p.published_date}
`:""}${(p.content??"").slice(0,dn)}`).join(`

---

`);try{return{results:await F(i,"Parse results",()=>qe(g,"tavily",a,{negative:e.negative,reasoningEffort:"low",timeoutMs:z.parseTimeoutMs,signal:s})),warnings:c}}catch(p){if(s!=null&&s.aborted)throw p;const m=p instanceof Error?p.message:"parse failed";return{results:wn(f),warnings:[...c,`Couldn't sort Tavily's results (${m}) — showing them unfiltered.`]}}}function Sn(e,t){return!e&&!t?"":pt({low:Math.round(e??t??0),high:Math.round(t??e??0)})}function kn(e){return new Promise(t=>setTimeout(t,e))}const Tn=350,Ln=12,pe=15e3;function In(e,t,a,n,i){const s=new URL(`https://api.adzuna.com/v1/api/jobs/${n}/search/${i}`);s.searchParams.set("app_id",a.appId),s.searchParams.set("app_key",a.appKey),s.searchParams.set("results_per_page","15"),s.searchParams.set("content-type","application/json"),e&&s.searchParams.set("what",e),t.where&&s.searchParams.set("where",t.where);const o=ut(t.negative);return o&&s.searchParams.set("what_exclude",o),s.toString()}async function An(e,t,a,n,i,s){const o=AbortSignal.timeout(pe);let r;try{r=await fetch(In(e,t,a,n,i),{signal:s?AbortSignal.any([s,o]):o})}catch(l){throw o.aborted?new Error(`timed out after ${pe/1e3} s`):l}if(!r.ok){const l=await r.text().catch(()=>"");throw new Error(`Adzuna search failed (${r.status}): ${l.slice(0,300)}`)}const u=(await r.json()).results.map(l=>{var f,g;return{title:l.title,company:((f=l.company)==null?void 0:f.display_name)??"",location:((g=l.location)==null?void 0:g.display_name)??"",url:l.redirect_url,salary:Sn(l.salary_min,l.salary_max),snippet:(l.description??"").slice(0,300),postedAt:l.created??"",source:"adzuna",tag:e}});return V(u)}async function _n(e,t,a,n=1,i,s){var h;const o=$(e),r=e.tags&&e.tags.length>0?e.tags:o.length>0?o:[e.what],c=Math.max(((h=e.grades)==null?void 0:h.length)??0,1),u=Math.max(1,Math.floor(Ln/c)),l=Kt(r.slice(0,u),e.grades),f=new Set,g=[],p=[];r.length>u&&p.push(`Only the first ${u} search terms were used with ${c} grades selected.`);let m=0,y=null;for(let d=0;d<l.length&&!(s!=null&&s.aborted);d++){const w=l[d];try{const O=(await An(w,e,t,a,n,s)).filter(A=>!f.has(A.url));for(const A of O)f.add(A.url);g.push(...O),O.length>0&&(i==null||i(O))}catch(k){m++,y??(y=k),p.push(`"${w}" — ${k instanceof Error?k.message:"search failed"}`)}d<l.length-1&&await kn(Tn)}if(m===l.length&&y)throw y;return{results:g,warnings:p}}const Rn=new Set(["AT","AU","BE","BR","CA","CH","DE","ES","FR","GB","IN","IT","MX","NL","NZ","PL","RU","SG","US","ZA"]);function On(e){var a;const t=(a=Ct(e))==null?void 0:a.toUpperCase();return t&&Rn.has(t)?t.toLowerCase():"us"}const Cn={type:"object",additionalProperties:!1,required:["what","where"],properties:{what:{type:"string"},where:{type:"string"}}},Pn=`You suggest a starting job-search query for the applicant described below.
"what" is a short role/keywords phrase (e.g. "senior backend engineer", "product designer") —
their most recent or clearly strongest role from the CV/Personal Legend. Pick ONE single title:
never join multiple roles or technologies with "/", "," or parentheses (e.g. never "Full-Stack
Developer / Backend Engineer (Go, Python, React)") — that reads as a combined AND-match to a
literal keyword search and returns nothing. "where" is a location (city, region, or country) —
their stated city/country if given, else "".
Output only the two fields, no explanation.`;async function xn(){const{profile:e,cvText:t,personalLegend:a}=await v(),n=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:a},null,2),i=await b({schemaName:"job_search_query_suggestion",schema:Cn,systemPrompt:Pn,userPrompt:n,parse:s=>JSON.parse(s),reasoningEffort:"low"});return{what:i.what,where:i.where||[e.city,e.country].filter(Boolean).join(", ")}}const Nn={type:"object",additionalProperties:!1,required:["tags"],properties:{tags:{type:"array",items:{type:"string"}}}},Mn=`You generate keyword search tags for Adzuna's job-search API, grounded in
the candidate's real background below. Per Adzuna's own docs
(https://developer.adzuna.com/docs/search), "what" is a single literal keyword/phrase match, not
a semantic search and not a boolean query — so ONE combined tag naming several technologies or
role variants (e.g. "Full-Stack Developer / Backend Engineer (Go, Python, React)") matches
nothing. You compensate by generating a small cross-product of short, atomic tags instead, each
run as its own separate search and merged afterwards.

Method — build the tags as a cross-product, exactly like this worked example for a candidate
whose strongest stack is Go and who also does full-stack/backend work:
  golang developer, go developer, go engineer, golang engineer,
  backend engineer, backend developer, fullstack engineer, fullstack developer,
  software engineer, software developer
That is: {primary technology + its common short aliases} × {developer, engineer}, PLUS
{their role-shape words, e.g. backend / fullstack / frontend / mobile / data — whichever
genuinely apply, without a technology} × {developer, engineer}, PLUS a generic "software
developer" / "software engineer" fallback pair.

Rules:
- Base every tag on their actual, strongest-fitting technology/field from the CV/Personal
  Legend — never invent a technology, role-shape, or seniority they don't have.
- Identify the ONE primary technology (e.g. "Go") plus its common short aliases people actually
  search with (e.g. "Golang") — do not alias unrelated technologies together.
- Each tag pairs exactly one technology-or-role-shape word with exactly one of "developer" /
  "engineer" (add "programmer" only if that's a genuinely common term for that stack). Never put
  two technologies, or a technology and a role-shape, in the same tag.
- If the CV shows a clear secondary technology/stack, budget permitting, add its own couple of
  tags the same way — still never combined with the primary one in a single tag.
- For EACH language listed in "languages" below (skip English), also include ONE of the
  strongest-technology tags translated into that language using the natural job-title term a
  native speaker would search with (not a literal word-for-word translation).
- Each tag is 1-3 words, lowercase, and never contains "/", ",", "(", ")", or a seniority
  qualifier ("senior", "junior", etc.).
- Deduplicate. Return 6-12 tags total, most relevant first.
- Output only the tags, no explanation.`;async function $n(){const{profile:e,cvText:t,personalLegend:a,languageLevels:n}=await v(),i=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:a,languages:n.map(o=>o.language)},null,2);return(await b({schemaName:"job_search_tags",schema:Nn,systemPrompt:Mn,userPrompt:i,parse:o=>JSON.parse(o),reasoningEffort:"low"})).tags.map(o=>o.trim()).filter(Boolean)}const jn=4;function qn(e){return JSON.stringify([e.profile.city,e.profile.country,e.cvText,e.personalLegend,e.languageLevels.map(t=>t.language)])}async function Un(e){const t=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(e));return[...new Uint8Array(t)].map(a=>a.toString(16).padStart(2,"0")).join("")}async function Ue(e){var r;const t=await Un(qn(await v())),a=await R("jobSearchSuggestionCache")??[],n=a.find(c=>c.key===t);if(n&&(!e||n.tags))return{what:n.what,where:n.where,tags:n.tags,cached:!0};const[i,s]=await Promise.all([n?{what:n.what,where:n.where}:xn(),e?$n():Promise.resolve(void 0)]),o={key:t,...i,tags:s!=null&&s.length?s:n==null?void 0:n.tags};return(o.what||(r=o.tags)!=null&&r.length)&&await G("jobSearchSuggestionCache",[o,...a.filter(c=>c.key!==t)].slice(0,jn)),{what:o.what,where:o.where,tags:o.tags,cached:!1}}async function de(e,t){var s;const a=performance.now(),n=await Ue(!0);e.push({label:n.cached?`${t} (cached)`:t,ms:performance.now()-a});const i=W((s=n.tags)!=null&&s.length?n.tags:[n.what]);if(i.length===0)throw new Error("Couldn't derive search terms from your CV — type a few search terms.");return{what:n.what,where:n.where,terms:i}}async function Fn(e,t={}){var l,f;const a=performance.now(),n=[],i=()=>({totalMs:performance.now()-a,stages:n});if(e.provider==="adzuna"){const[g,p]=await Promise.all([se(),D()]);if(!g.adzunaAppId||!g.adzunaAppKey)throw new Error("Add your Adzuna app_id and app_key in Settings first.");let m=e;if(!((l=m.tags)!=null&&l.length)){const d=$(m);if(d.length>0)m={...m,tags:d};else{const w=await de(n,"Suggest tags");m={...m,what:w.what,where:m.where.trim()||w.where,tags:w.terms}}}const{results:y,warnings:h}=await F(n,"Adzuna search",()=>_n(m,{appId:g.adzunaAppId,appKey:g.adzunaAppKey},On(p.country),t.page??1,t.onResults,t.signal));return{results:y,resolvedQuery:m,warnings:h,...i()}}const[s,o]=await Promise.all([ve(),se()]),r=(s==null?void 0:s.content)??"";if(e.provider==="tavily"){if(!o.tavilyApiKey)throw new Error("Add your Tavily API key in Settings first.");let g=e;if($(g).length===0){const y=await de(n,"Suggest terms");g={...g,terms:y.terms,where:g.where.trim()||y.where}}const{results:p,warnings:m}=await En(g,o.tavilyApiKey,r,t.excludeResults,n,t.signal);return p.length>0&&((f=t.onResults)==null||f.call(t,p)),{results:p,resolvedQuery:g,...m.length?{warnings:m}:{},...i()}}const{results:c,warnings:u}=await on(e,r,t.excludeResults,n,t.onResults,t.signal);return{results:c,resolvedQuery:e,...u.length?{warnings:u}:{},...i()}}const Dn={type:"object",additionalProperties:!1,required:["keyRequirements","relevantExperienceHints","suggestedTone","suggestedFocus"],properties:{keyRequirements:{type:"array",items:{type:"string"}},relevantExperienceHints:{type:"array",items:{type:"string"}},suggestedTone:{type:"string"},suggestedFocus:{type:"string"}}};async function Yn(e){return b({schemaName:"job_analysis",schema:Dn,model:await Te(),systemPrompt:"You analyze job postings for a job-application assistant. Identify the most important requirements and what an applicant should emphasize. Do not invent details that are not present in the posting.",userPrompt:JSON.stringify(e,null,2),parse:t=>JSON.parse(t)})}const Vn=`You write tailored cover letters for job applications.

The user message holds the applicant's data as JSON, and may end with an
"Applicant's rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and
   Personal Legend. Never invent experience, technologies, companies,
   education, or achievements, even if the applicant's rules ask for them.
   If information needed to be compelling is missing, write around it
   honestly rather than fabricating it.
2. The applicant's rules. Follow every instruction there on tone, length,
   structure, language, and what to include or avoid, including where it
   departs from the defaults below. Every rule there applies to the whole
   letter, not just the opening.
3. Language. If "postingLanguage" is given, write the entire letter in that
   language, using the salutation, register, and closing conventions native
   speakers of it would expect on a job application (e.g. formal
   "Sie"/"Herr"/"Frau" address and a "Sehr geehrte(r) ..." opening in German,
   not a literal English-to-German translation).
4. The house style below. Its "no exceptions" means no exceptions of your
   own; an explicit applicant rule still overrides it.
5. Tone and emphasis tailored to the job analysis provided.

Output plain prose paragraphs, no markdown headers.

${I}`;async function Hn(e,t){const n=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,analysis:e.analysis,postingLanguage:e.postingLanguage||void 0},null,2)+Fe(e.generationRules),i=await dt(Vn,n,t??(()=>{}));return S(i)}function Fe(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const ne={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},De={type:"object",additionalProperties:!1,required:["subject","body"],properties:{subject:{type:["string","null"]},body:{type:"string"}}},Bn=`You are a sharp human editor cleaning up a cover letter draft.

Fix ONLY the flagged AI-writing patterns listed below. Make the minimum
effective edit — do not rewrite sentences that were not flagged, do not
change facts, experience, technologies, or claims, and do not add new
content. Replace banned words/clichés with plain, concrete language.
Rewrite "not X, it's Y" contrasts as a direct statement of Y. Cut
throat-clearing openers, weasel attribution, and importance-puffery instead
of softening them. If the ending is a generic summary/recap, end on the
letter's last concrete point instead. Replace every em dash ("—") with a
comma, a period, or parentheses.

The user message may end with the applicant's own rules for the letter. If a
flagged pattern is something those rules explicitly ask for, leave it as is:
the applicant's rules outrank the house style.

Do not introduce any new AI-slop while editing. For reference, the full
house style is:

${I}

Output plain prose paragraphs, no markdown headers.`;async function Jn(e,t,a=""){const n=JSON.stringify({draft:e,flaggedPatterns:t.map(s=>`${s.pattern}: "${s.match}"`)},null,2)+Fe(a),i=await b({schemaName:"cover_letter_polish",schema:ne,systemPrompt:Bn,userPrompt:n,parse:s=>JSON.parse(s)});return S(i.content)}const Gn=["delve","foster","leverage","utilize","facilitate","empower","streamline","robust","cutting-edge","paradigm shift","game changer","this is huge","this changes everything","tapestry","realm","beacon","multifaceted","meticulous","intricate","paramount","transformative","elevate","embark","supercharge","harness","ever-evolving"],Kn=["it's worth noting","it is worth noting","it's important to note","it is important to note","at the end of the day","when it comes to","at its core","in today's world","in the age of","in the world of","the reality is","the truth is","in terms of","with regard to","in order to","going forward"],Wn=["here's the thing","here's what i mean","let me be clear","i'll be honest","the uncomfortable truth is"],zn=["this is the part most people skip","what most people get wrong","here's what nobody tells you","the part everyone misses"],Qn=["stands as a testament","marks a pivotal moment","plays a vital role","solidifies its position","underscores its significance"],Xn=["experts agree","industry reports suggest","many argue","widely regarded as","studies show"],Zn=[/^in conclusion\b/i,/^ultimately\b/i,/^overall\b/i];function ea(e){const t=e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`\\b${t.replace(/ /g,"\\s+")}\\b`,"i")}function C(e,t,a){const n=[];for(const i of t){const s=ea(i).exec(e);s&&n.push({pattern:a,match:s[0]})}return n}function ta(e){const t=/\b(?:isn'?t|is not)\b[^.!?]{3,60}[,.]?\s*(?:it'?s|it is)\b[^.!?]{3,80}[.!?]/i,a=/\bnot just\b[^.!?]{3,60}(?:\bbut\b|[,.]?\s*(?:it'?s|it is)\b)[^.!?]{0,80}[.!?]/i,n=[],i=t.exec(e);i&&n.push({pattern:"binary-contrast",match:i[0].trim()});const s=a.exec(e);return s&&n.push({pattern:"binary-contrast",match:s[0].trim()}),n}function na(e){const t=e.split(/\n{2,}/).map(n=>n.trim()).filter(Boolean),a=t[t.length-1];if(!a)return[];for(const n of Zn)if(n.test(a))return[{pattern:"summary-recap-ending",match:a.slice(0,60)}];return[]}function aa(e){const t=(e.match(/—/g)??[]).length;return t===0?[]:[{pattern:"em-dash",match:t===1?"1 em dash":`${t} em dashes`}]}function ia(e){return[...C(e,Gn,"banned-word"),...C(e,Kn,"empty-phrase"),...C(e,Wn,"throat-clearing-opener"),...C(e,zn,"faux-insight-setup"),...C(e,Qn,"importance-puffery"),...C(e,Xn,"weasel-attribution"),...ta(e),...na(e),...aa(e)]}async function sa(e,t,a){const n=await v(),i=await Yn(e),s=await Hn({profile:n.profile,cvText:n.cvText,personalLegend:n.personalLegend,generationRules:n.generationRules,job:e,analysis:i,postingLanguage:t},a),o=ia(s);return o.length===0?{content:s,slopFindings:o,cleaned:!1}:{content:await Jn(s,o,n.generationRules),slopFindings:o,cleaned:!0}}const oa=`You write a short outreach message an applicant sends to a named
recruiter/hiring contact BEFORE or alongside applying, to start a conversation about a specific
job posting — not a cover letter, and not addressed to "the hiring team".

The user message holds the applicant's data as JSON ("contact" is the email address or LinkedIn
URL found on the posting, "channel" is "email" or "linkedin"), and may end with an "Applicant's
rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and Personal Legend. Never
   invent experience, technologies, companies, education, or achievements.
2. The applicant's rules. Follow every instruction there on tone, length, structure, language,
   and what to include or avoid, including where it departs from the defaults below.
3. Language. If "postingLanguage" is given, write the entire message in that language, using
   the salutation and register native speakers of it would expect.
4. Channel. If "channel" is "email", write a short email: "subject" is REQUIRED, never null or
   empty: a specific, non-generic subject line under 80 characters that names the role and the
   company (and, if it fits, the applicant's strongest match), in the message's language. "body"
   opens with a greeting and closes with a signature using the applicant's name; it does not
   repeat the subject. If "channel" is "linkedin", write a LinkedIn connection/message note
   instead: "subject" is null, "body" has no email greeting/signature and stays under LinkedIn's
   informal register.
5. The house style below. Its "no exceptions" means no exceptions of your own; an explicit
   applicant rule still overrides it.

Defaults (apply unless the applicant's rules say otherwise): under 120 words, state who the
applicant is and the one or two things that make them a fit for THIS role, and end with a clear,
low-pressure ask (a quick chat, or just flagging interest before applying). Never sound like a
mass-sent template.

${I}`;async function ra(e){const a=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,contact:e.contact,channel:oe(e.contact)?"email":"linkedin",postingLanguage:e.postingLanguage||void 0},null,2)+ca(e.outreachRules),n=await b({schemaName:"outreach_message",schema:De,model:await Le(),systemPrompt:oa,userPrompt:a,parse:i=>JSON.parse(i)});return{subject:oe(e.contact)?Ye(n.subject,e.job):null,body:S(n.body)}}function Ye(e,t){const a=S((e??"").replace(/^\s*subject\s*:\s*/i,"").replace(/\s+/g," ").trim());if(a)return a;const n=t.position.trim(),i=t.company.trim();return n&&i?`${n} at ${i}`:n||i||"Job application"}function ca(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const Ve={type:"array",items:{type:"object",additionalProperties:!1,required:["text","kind","matchesProfile"],properties:{text:{type:"string"},kind:{type:"string",enum:["hard","soft"]},matchesProfile:{type:"boolean"}}}};function ae(e){return`KEYWORDS
- Pick the SKILLS the posting asks for, and nothing else. Each one is either:
  - "hard": a technical skill, tool, technology, programming language, framework, platform,
    method or domain expertise (e.g. "TypeScript", "Kubernetes", "C++", ".NET", "CI/CD",
    "SQL", "machine learning", "financial modelling", "Figma", "Scrum");
  - "soft": a real interpersonal/working skill (e.g. "communication", "mentoring",
    "stakeholder management", "problem-solving", "ownership").
- NEVER return anything that is not a skill. In particular, never return:
  - the company name, its products' brand names used as a name, or any other organization;
  - cities, countries, regions, addresses, time zones;
  - work modes and contract terms ("remote", "hybrid", "on-site", "full-time", "contract");
  - benefits and pay ("salary", "equity", "health insurance", "30 days vacation", "bonus");
  - job titles and seniority ("Senior Backend Engineer", "Team Lead", "junior");
  - years of experience, degrees, certificates as such ("5+ years", "Bachelor's degree");
  - spoken languages ("English", "German") — those are reported separately above;
  - generic words ("team", "experience", "work", "product", "environment", "opportunity",
    "fast-paced environment", "passion").
- Every keyword's "text" MUST be copied VERBATIM from ${e} — the exact same characters
  and casing, not a paraphrase, synonym, or translation — because the extension re-finds this
  exact text on the page to highlight it. A keyword that doesn't appear verbatim is useless.
- Prefer short phrases: single words or 2-3 word phrases, never sentences.
- Return up to 15, most important first. Fewer is fine: return an empty array rather than
  padding the list with anything from the NEVER list above.
- No duplicates, and no two keywords where one is a substring of the other (keep the more
  specific/longer one).
- Set "matchesProfile" to true when the applicant's profile/cvText/personalLegend shows they
  already have, use, or meet that skill — false when the posting asks for it but nothing in
  the applicant's material supports it. Judge substance, not exact wording (e.g.
  "Kubernetes" counts as a match if the CV mentions "container orchestration with K8s" or
  "EKS"). When genuinely unsure, set it to false — this flags a possible gap for the
  applicant to address rather than silently hiding it.`}const la=new Set(["team","teams","experience","work","job","role","position","company","candidate","opportunity","environment","product","products","customer","customers","client","clients","project","projects","skills","knowledge","ability","responsibilities","requirements","tasks","career","growth","culture","mission","vision","values","impact","passion","motivation","startup","scale-up","industry","business","fast-paced environment","dynamic environment","nice to have","must have","plus","years","year","years of experience","professional experience","work experience","degree","bachelor","bachelor's degree","master","master's degree","university degree","diploma","phd","intern","internship","junior","middle","mid-level","senior","lead","principal","staff","head","manager","remote","fully remote","remote work","hybrid","on-site","onsite","office","in office","home office","homeoffice","relocation","visa sponsorship","full-time","full time","part-time","part time","contract","freelance","permanent","temporary","salary","competitive salary","bonus","equity","stock options","esop","benefits","vacation","paid time off","pto","holidays","health insurance","insurance","pension","gym","gym membership","free lunch","snacks","flexible hours","flexible working hours","learning budget","parental leave","erfahrung","berufserfahrung","aufgaben","anforderungen","unternehmen","vollzeit","teilzeit","festanstellung","gehalt","urlaub","vertrag","büro","mobiles arbeiten","команда","опыт","опыт работы","работа","компания","проект","проекты","задачи","требования","обязанности","удаленно","удаленка","удаленная работа","гибрид","офис","полный день","полная занятость","частичная занятость","зарплата","оклад","бонусы","дмс","отпуск","релокация"]),ua=new Set(ht.map(e=>L(e))),pa=new RegExp("\\s*,?\\s*(?<![\\p{L}\\p{N}])(?:inc|ltd|llc|gmbh|ag|se|kg|ug|bv|nv|sa|sas|srl|plc|corp|corporation|co|company|oy|ab|as|ооо|ао)\\.?$","iu");function L(e){return e.normalize("NFC").toLowerCase().replace(/ё/g,"е").replace(/[’`]/g,"'").replace(/^[\s"'«».,:;!?()[\]-]+|[\s"'«».,:;!?()[\]-]+$/g,"").replace(/\s+/g," ")}function da(e){const t=L(e);if(!t)return[];const a=L(t.replace(pa,""));return a&&a!==t?[t,a]:[t]}function ha(e){const t=L(e);if(!t)return[];const a=e.split(/[,/|·•()]/).map(L).filter(Boolean);return[t,...a]}function fa(e){return L(e.replace(/\((?:[mwfdx]\s*\/\s*)+[mwfdx]\)/gi,""))}const ga=/^\d+(?:\s*[-–+]\s*\d*)?\+?\s*(?:years?|yrs?|jahre?n?|лет|года?|ans|años)(?![\p{L}\p{N}])/iu;function Q(e,t){const a=e.trim();if([...a].length<2)return!new RegExp("^\\p{Lu}$","u").test(a);if(!new RegExp("\\p{L}","u").test(a)||/[$€£¥₽%]/u.test(a))return!0;const n=L(a);return!n||la.has(n)||ua.has(n)||ga.test(n)||da(t.company).includes(n)||ha(t.location).includes(n)?!0:n===fa(t.position)}function ie(e,t){const a=new Set;return e.filter(n=>{const i=L(n.text);return a.has(i)||Q(n.text,t)?!1:(a.add(i),!0)})}function ma(e,t){var i;const a=(i=e.match(/\s*[,;|·•]\s*/u))==null?void 0:i[0];if(!a)return Q(e,t)?"":e;const n=new Set;return e.split(/\s*[,;|·•]\s*/u).filter(s=>{const o=L(s);return!s.trim()||n.has(o)||Q(s,t)?!1:(n.add(o),!0)}).join(a)}const He={postingLanguages:{type:"array",items:{type:"string"}},languageRequirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...Ae,null]}}}},keywords:Ve},ya={type:"object",additionalProperties:!1,required:["company","position","location","description","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},description:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...He}},Be=`LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- languageRequirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or "Native"
  for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent", "professional
  working proficiency" -> "C1"; "conversational" -> "B1". If a language is mentioned but no level
  can be reasonably inferred, set level to null. Do not invent a requirement that isn't stated in
  the text. If nothing is stated, return an empty array.`,wa=`You read the visible text of a job-posting page and do two things with it
in one pass: extract the structured posting fields, and analyze the result for language and
keywords — against the applicant profile/CV/Personal Legend given below.

EXTRACTION
- Only use information present in "pageText"; leave a field empty/null if unknown.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- For "contact", prefer a named recruiter/hiring manager's email address or LinkedIn
  profile/company URL if one is mentioned, copied VERBATIM (exact characters); otherwise null.

${Be}

${ae('"pageText"')}`;async function ba(e,t){const a=await v(),n=JSON.stringify({profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,pageText:e.slice(0,12e3)},null,2),i=await b({schemaName:"job_extraction_and_brief",schema:ya,model:await Ie(),reasoningEffort:"low",systemPrompt:wa,userPrompt:n,parse:r=>JSON.parse(r)}),s={company:i.company,position:ft(i.position),location:i.location,description:i.description,requirements:i.requirements,responsibilities:i.responsibilities,salary:i.salary,techStack:i.techStack,contact:i.contact,url:t},o={language:{postingLanguages:i.postingLanguages,requirements:i.languageRequirements},keywords:ie(i.keywords,s),contact:null};return{job:s,brief:o}}const va={type:"object",additionalProperties:!1,required:["company","position","location","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...He}},Ea=`You read the visible text of a job-posting page. It was already parsed
without AI: "knownFields" holds what that found. Fill in what it missed, and analyze the posting
for language and keywords — against the applicant profile/CV/Personal Legend given below.

FIELDS
- Fill only the fields named in "fieldsToFill". For every other posting field return "" / [] /
  null — those are kept from the page as they are. Never re-type the posting's description.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- company: the hiring company, not the job board or recruiting platform hosting the page.
- location: as written in the posting; "" if none.
- requirements, responsibilities: at most 8 items each, each a short phrase (12 words or fewer),
  not copied paragraphs.
- techStack: technology names only.
- contact: a named recruiter/hiring manager's email address or LinkedIn profile/company URL,
  copied VERBATIM (exact characters); otherwise null.
- Only use information present in "pageText"; leave a field empty/null if unknown.

${Be}

${ae('"pageText"')}`;async function Sa(e,t){const a=await v(),n=gt(e),i=t||e.description,s=JSON.stringify({profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,knownFields:{position:e.position,company:e.company,location:e.location,salary:e.salary,contact:e.contact},fieldsToFill:n,pageText:i.slice(0,12e3)},null,2),o=await b({schemaName:"job_completion_and_brief",schema:va,model:await Ie(),reasoningEffort:"low",systemPrompt:Ea,userPrompt:s,parse:u=>JSON.parse(u)}),r=mt(e,o,n,i),c={language:{postingLanguages:o.postingLanguages,requirements:o.languageRequirements},keywords:ie(o.keywords,r),contact:null};return{job:r,brief:c}}const ka=`You are editing an existing cover letter draft on the applicant's
instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the
  letter the instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements
  that aren't already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the
  instruction explicitly asks to change it.
- Output plain prose paragraphs, no markdown headers.
- Don't introduce AI-slop while editing, and clean it from any sentence you
  touch.

${I}`;async function Ta(e,t,a){const n=JSON.stringify({draft:e,instructions:t,job:a},null,2),i=await b({schemaName:"cover_letter_revision",schema:ne,model:await yt(),systemPrompt:ka,userPrompt:n,parse:s=>JSON.parse(s)});return S(i.content)}const La=`You are editing an existing outreach message (an email or LinkedIn note
to a recruiter/hiring contact) on the applicant's instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the message the
  instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements that aren't
  already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the instruction explicitly
  asks to change it.
- If the draft's "subject" is null, keep it null (it's a LinkedIn note). Otherwise keep a
  specific subject line, changing it only if the instruction (or the edit) requires it.
- Don't introduce AI-slop while editing, and clean it from any sentence you touch.

${I}`;async function Ia(e,t,a){const n=JSON.stringify({draft:e,instructions:t,job:a},null,2),i=await b({schemaName:"outreach_message_revision",schema:De,model:await Le(),systemPrompt:La,userPrompt:n,parse:s=>JSON.parse(s)});return{subject:e.subject===null?null:Ye(i.subject||e.subject,a),body:S(i.body)}}const Aa=`You translate a cover letter for the applicant's own understanding —
not for submission. Translate faithfully, preserve paragraph breaks, and keep
names, companies, and technical terms as-is where translating them would be
unnatural. Do not use em dashes ("—"); use commas or periods. Output plain
prose paragraphs, no markdown headers, no notes about the translation itself.`;async function _a(e,t){const a=JSON.stringify({content:e,targetLanguage:t},null,2),n=await b({schemaName:"cover_letter_translation",schema:ne,systemPrompt:Aa,userPrompt:a,parse:i=>JSON.parse(i)});return S(n.content)}const he=new RegExp([String.raw`(?:additional|further|other|more|extra|supplementary)\s+(?:information|info|details|comments?|remarks?|notes?|thoughts)`,String.raw`anything\s+else`,String.raw`is\s+there\s+anything(?:\s+else)?`,String.raw`any(?:thing)?\s+(?:other|further|additional|final)\s+(?:comments?|remarks?|notes?|information|thoughts)`,String.raw`(?:any|final)\s+(?:comments?|remarks?|notes?|thoughts)`,String.raw`(?:a\s+)?(?:message|note)\s+(?:to|for)\s+(?:the\s+|our\s+)?(?:hiring\s+(?:team|manager)|recruit(?:er|ing\s+team|ment\s+team)|team|us|company|employer)`,String.raw`(?:weitere|zus[aä]tzliche|sonstige|erg[aä]nzende|andere)\s+(?:informationen|infos?|angaben|anmerkungen|hinweise|bemerkungen|mitteilungen|kommentare)`,String.raw`sonstiges`,String.raw`(?:m[oö]chten|willst|m[oö]chtest)\s+(?:sie|du)\s+uns\s+(?:sonst\s+)?noch\s+(?:etwas|was)`,String.raw`gibt\s+es\s+(?:sonst\s+)?noch\s+(?:etwas|was)`,String.raw`(?:nachricht|mitteilung)\s+an\s+(?:uns|das\s+team|den\s+recruiter|die\s+personalabteilung)`,String.raw`informations?\s+compl[ée]mentaires?`,String.raw`informaci[oó]n\s+adicional`,String.raw`дополнительн(?:ая|ые)\s+(?:информация|сведения|комментари[йи])`].join("|"),"iu"),Ra=/^(?:your\s+|ihre?\s+|deine?\s+|persönliche\s+)?(?:messages?|comments?|remarks?|notes?|nachricht|anmerkungen?|bemerkungen?|kommentare?|hinweise?|mitteilung|commentaires?|comentarios?|комментари[йи]|сообщение)$/iu,Oa=/^(?:your\s+|ihr\s+)?(?:cover\s+letter|motivation(?:al)?\s+letter|anschreiben|motivationsschreiben|lettre\s+de\s+motivation|carta\s+de\s+presentaci[oó]n|сопроводительное\s+письмо)$/iu,Ca=new RegExp(String.raw`\b(?:optional|freiwillig|facultatif|opcional|необязательно|please|bitte|here|hier|you|you'?d|would|like|to|share|add|tell|let|us|know|mention|with|about|yourself|we|should|that|the|a|an|and|or|for|me|your|our|any|on|in|of|this|application|role|position|job|team|hiring|sie|du|uns|noch|etwas|was|mitteilen|teilen|sagen|zu|ihrer|ihre|deiner|bewerbung|stelle|möchten|möchtest|gibt|es|sonst|und|oder|für|die|der|das|den|dem|an|mit|über|is|there|else|do|have|want|wish|feel|free|e\.?\s?g\.?|z\.?\s?b\.?)\b`,"giu");function Pa(e){return e.replace(/[*✱:?!.…]+/g," ").replace(/\((?:optional|freiwillig|facultatif|opcional|необязательно)\)/giu," ").replace(/\s+/g," ").trim()}function xa(e,t){return e.replace(t," ").replace(/[()[\],;/\-–—"'„“”]+/g," ").replace(Ca," ").split(/\s+/).filter(n=>new RegExp("\\p{L}{2}","u").test(n))}function Na(e){const t=Pa(e);return t?Oa.test(t)?"coverLetter":Ra.test(t)?"weak":new RegExp(he.source,"giu").test(t)?xa(t,new RegExp(he.source,"giu")).length>=3?null:"strong":null:null}const Ma=[/\b(?:please|kindly)\b[^.!?\n]{0,100}\b(?:mention|include|state|indicate|tell\s+us|let\s+us\s+know|add|note|specify|quote|answer)\b[^.!?\n]{0,100}\b(?:application|cover\s+letter|message|submission)\b[^.!?\n]*/iu,/\bin\s+your\s+(?:application|cover\s+letter|message)\b[^.!?\n]{0,100}\b(?:mention|include|state|tell\s+us|let\s+us\s+know|answer|describe)\b[^.!?\n]*/iu,/\b(?:code\s?word|keyword|reference\s+(?:number|code)|kennwort|kennziffer|referenznummer|stichwort)\b[^.!?\n]*/iu,/\b(?:geben|nennen|teilen|erw[aä]hnen|beantworten)\s+sie\b[^.!?\n]{0,120}\b(?:bewerbung|anschreiben|nachricht)\b[^.!?\n]*/iu,/\bin\s+ihrer\s+bewerbung\b[^.!?\n]{0,120}\b(?:an|nennen|angeben|mitteilen|erw[aä]hnen|beantworten)\b[^.!?\n]*/iu];function fe(e){const t=[e.description??"",...e.requirements??[],...e.responsibilities??[]].join(`
`);for(const a of Ma){const n=a.exec(t);if(n)return n[0].trim().slice(0,300)}return null}function $a(e,t){if(t.required===!0)return{action:"write",reason:"required",postingAsk:fe(e)??void 0};const a=fe(e);return a?{action:"write",reason:"posting",postingAsk:a}:t.required===!1?{action:"skip"}:{action:"write",reason:"asked"}}const ja={type:"object",additionalProperties:!1,required:["skip","answer"],properties:{skip:{type:"boolean"},answer:{type:"string"}}},qa=`You decide what, if anything, goes into the open catch-all field at the end of a
job application form ("Additional information", "Anything else you'd like to share?", "Weitere
Informationen", "Sonstiges", "Message to the hiring team"). The recruiter already has everything
in "formValues", "otherAnswers", the attached CV ("cvText"), the cover letter ("coverLetter") and
the profile. Repeating any of it wastes their time and makes the application look padded.

Rules:
- "skip": true, "answer": "" is the normal result. Choose it whenever there is nothing NEW and
  relevant to add. An empty field is fine.
- Never repeat or paraphrase: contact data (name, email, phone, address, city), links (LinkedIn,
  GitHub, portfolio, website), salary expectations, start date / notice period / availability,
  work permit / visa / relocation, language levels, a summary of the CV or the experience, or the
  motivation already given in the cover letter or other answers.
- "postingAsk" (when present) is what the job posting explicitly asks applicants to include.
  Answer exactly that, from the applicant's data, if it isn't already in the form. If the data
  doesn't have it, skip.
- "required": true means the form won't submit with the field empty. Then don't skip: write ONE
  short sentence with something new from the Personal Legend or custom fields, or, if there is
  truly nothing new, one plain neutral sentence (e.g. that you look forward to hearing from them).
- Otherwise ("required" false or unknown), write only when there is a genuinely new, relevant fact
  (e.g. a constraint the recruiter must know that appears nowhere else).
- At most 2 sentences, plain text, no greeting, no sign-off, no lists, no markdown.
- Never invent facts. Use ONLY the applicant data given.
- If "postingLanguage" is given, write in that language with its native application register.

${I}`,Ua=/\b(?:https?:\/\/|www\.)\S+|\b[\w.-]+\.(?:com|de|io|dev|net|org|me)\/\S*/i,Fa=/\b[\w.+-]+@[\w-]+\.[\w.-]+\b/,Da=/(?:\+|\b00)\d[\d\s/().-]{6,}\d|\b0\d{2,4}[\s/-]?\d{3,}[\s-]?\d{2,}\b/;function Ya(e){return e.replace(/\s+/g," ").trim().split(new RegExp("(?<=[.!?])\\s+(?=\\S)","u")).filter(a=>a&&!Ua.test(a)&&!Fa.test(a)&&!Da.test(a)).slice(0,2).join(" ").trim()}const Je="catchAllAdds";function Va(e){return{type:"predicate",name:Je,instructions:`The application form has an open catch-all field ("field"), not marked required: "Additional information", "Anything else?".
The recruiter already has the applicant's CV, cover letter, profile and every value in "formValues"
and "otherAnswers". Should the applicant write anything in it?
- Yes only if ${e?`the applicant's data covers what the posting explicitly asks applicants to include ("postingAsk") and the form doesn't already hold it, or if `:""}the applicant's data holds a genuinely NEW fact relevant to this application that appears nowhere else (e.g. a constraint the recruiter must know).
- No for anything already in the CV, cover letter, profile or form: contact data, links, salary, start date /
  notice period / availability, work permit / visa / relocation, language levels, a summary of the
  experience, the motivation.
- No when in doubt: an empty field is the normal, good outcome.`}}async function Ha(e,t,a,n){try{const i=[...e.input,{role:"user",content:[{type:"input_json",data:{formValues:(a.formValues??[]).filter(o=>o.value.trim()),otherAnswers:(a.otherAnswers??[]).filter(o=>o.answer.trim()),coverLetterAttached:a.coverLetterAttached||void 0,postingAsk:n??null,field:t}}]}],s=await x({input:i,promptCacheKey:e.promptCacheKey,questions:[Va(n)]});return wt(s,Je)}catch(i){if(i instanceof j)throw i;return console.warn("[Filler] Decisions API failed, writing the catch-all via Responses:",i),null}}async function Ge(e,t,a,n){const i=$a(t,a);if(i.action==="skip")return{answer:"",sufficientInfo:!0,skipped:!0};const[s,o]=await Promise.all([v(),R("lastCoverLetter")]);if(a.required!==!0){const l=te(s,o??"",t,n),f=await Ha(l,e,a,i.postingAsk);if(f!==null&&f<M.catchAllWrite)return{answer:"",sufficientInfo:!0,skipped:!0}}const r=JSON.stringify({job:t,profile:s.profile,cvText:s.cvText,coverLetter:o??"",coverLetterAttached:a.coverLetterAttached||void 0,personalLegend:s.personalLegend,customFields:s.customFields,languageLevels:s.languageLevels,generationRules:s.generationRules,postingLanguage:n||void 0,formValues:(a.formValues??[]).filter(l=>l.value.trim()),otherAnswers:(a.otherAnswers??[]).filter(l=>l.answer.trim()),postingAsk:i.postingAsk,required:a.required??"unknown",question:e},null,2),c=await b({schemaName:"catch_all_answer",schema:ja,systemPrompt:qa,userPrompt:r,label:"Catch-all answer",parse:l=>JSON.parse(l)}),u=c.skip?"":Ya(S(c.answer));return u?{answer:u,sufficientInfo:!0,skipped:!1}:{answer:"",sufficientInfo:a.required!==!0,skipped:!0}}const Ba={type:"object",additionalProperties:!1,required:["answer","sufficientInfo"],properties:{answer:{type:"string"},sufficientInfo:{type:"boolean"}}},ge=`You answer a custom question from a job application form on the
applicant's behalf.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend,
  cover letter, custom fields, language levels, and job posting. Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, the
  "languageLevels" list is the authoritative answer (CEFR levels the
  applicant self-reported in Settings) — use it directly rather than
  guessing from the CV or defaulting to a low/neutral level.
- If the profile/CV/Personal Legend/etc genuinely lack what's needed to
  answer this question — not just a minor detail, but the actual substance
  being asked for — set "sufficientInfo" to false and "answer" to an empty
  string. Do NOT write a sentence explaining that you don't have the
  information (e.g. "I don't have this information available") — that text
  would otherwise get typed straight into the applicant's form field, which
  is worse than leaving it blank for the applicant to fill in themselves.
  Only do this when the information is truly absent; a question you can
  answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient —
  set sufficientInfo to true and give that honest answer.
- If "postingLanguage" is given, write the answer in that language, using
  the salutation/register conventions native speakers of it would expect on
  a job application (e.g. formal "Sie"/"Herr"/"Frau" address in German, not
  a literal English-to-German translation) — unless the question itself, or
  "generationRules", explicitly asks for a different language.
- If this question is a newsletter, marketing-email, or job-alert
  subscription opt-in phrased as a choice (e.g. "Would you like to
  subscribe to our newsletter? Yes/No"), always choose the option that
  declines it — the applicant never needs this to submit the application.
- "faq" is a set of pre-written answers to standard interview-FAQ questions
  (spec_5 section B). If the question being asked now is the same as, or a
  close variant of, one already in "faq", reuse its substance and phrasing —
  adapt only what the target field's length/format actually requires — so
  the applicant's answer stays consistent across different forms rather
  than being re-derived from scratch each time.
- Match the question's expected length: a short field gets a short answer, an
  open-ended "tell us about..." field gets a fuller one.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text, no markdown, no restating the question.

${I}`,Ja=/\b(?:please\s+(?:provide|specify|clarify)|could\s+you\s+(?:please\s+)?(?:provide|clarify|specify)|i\s+(?:don'?t|do\s+not)\s+see)\b.{0,40}?\b(?:question|prompt)\b|\bno\s+(?:specific\s+)?question\s+(?:was|is)?\s*(?:provided|given|specified|attached)\b/i;function Ke(e){const t=e.trim();return t?t.length<220&&Ja.test(t):!0}const Ga=`
- This is a MULTIPLE-CHOICE question: "options" lists the allowed answers.
  Reply with EXACTLY ONE option, copied verbatim, and nothing else.
- Base the choice on the applicant's profile/CV/Personal Legend. If the
  needed fact is genuinely absent (e.g. pronouns not stated anywhere),
  prefer a neutral option, an explicit "prefer not to say", or the option
  that commits the applicant least.`,Ka=`
- This is a SELECT-ALL-THAT-APPLY question: "options" lists every allowed
  answer. Reply with every option that genuinely applies, each copied
  verbatim, joined by " | " (a single pipe surrounded by one space on each
  side) — nothing else. If none apply, reply with an empty string.
- Base each choice strictly on the applicant's profile/CV/Personal Legend —
  never include an option just because it's plausible or common; only ones
  the applicant's own material actually supports.`,Wa=`
- This field only accepts a plain number: reply with digits only (a single
  "." for a decimal if needed) — no currency symbol, no thousands
  separator, no unit, no words, no range. If a range genuinely fits best
  (e.g. a salary expectation given as "65-75k"), reply with one
  representative figure (its midpoint), not the range.`;function za(e){return`
- This field only accepts a date in the exact format "${Pe[e]}"
  — reply with ONLY that value, nothing else (no words, no explanation).
  "todayISO" in the data below is today's date: compute the answer from it
  — e.g. "available with one month's notice" → todayISO plus one month;
  "immediately" / "as soon as possible" / no stated constraint → todayISO
  itself. Never answer with a description of the notice period or
  availability instead of the date itself.`}async function Qa(e,t,a,n,i,s,o,r){if(!(a&&a.length>0)&&!n&&!i&&(r||r===void 0&&Na(e)==="strong"))return Ge(e,t,r??{},o);const[u,l]=await Promise.all([v(),R("lastCoverLetter")]),{input:f,promptCacheKey:g}=te(u,l??"",t,o),p={question:e,options:a,multi:s,numeric:n,dateKind:i},m=K(p);try{const y=await x({input:f,promptCacheKey:g,questions:m?_e(p,0):[Re(p,0)]});if(m){const h=Oe(p,0,y);if(h)return h}else if(Ce(0,y)===!1)return{answer:"",sufficientInfo:!1}}catch(y){if(y instanceof j)throw y;console.warn("[Filler] Decisions API failed, answering via Responses:",y)}return Xa(e,t,a,n,i,s,o)}async function Xa(e,t,a,n,i,s,o){const[r,c]=await Promise.all([v(),R("lastCoverLetter")]),u=JSON.stringify({job:t,profile:r.profile,cvText:r.cvText,personalLegend:r.personalLegend,generationRules:r.generationRules,coverLetter:c??"",languageLevels:r.languageLevels,customFields:r.customFields,faq:r.faq.filter(p=>p.answer.trim()),todayISO:Y(),postingLanguage:o||void 0,question:e,options:a&&a.length>0?a:void 0},null,2),l=[a&&a.length>0?s?Ka:Ga:"",n?Wa:"",i?za(i):""].filter(Boolean),f=await b({schemaName:"custom_question_answer",schema:Ba,systemPrompt:l.length>0?[ge,...l].join(`
`):ge,userPrompt:u,parse:p=>JSON.parse(p)});return!f.sufficientInfo||Ke(f.answer)?{answer:"",sufficientInfo:f.sufficientInfo}:{answer:a&&a.length>0||n||!!i?f.answer:S(f.answer),sufficientInfo:!0}}const Za={type:"object",additionalProperties:!1,required:["questions"],properties:{questions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","question"],properties:{index:{type:"integer"},question:{type:"string"}}}}}},ei=`You are given a block of a job-application form: its visible text, and a
list of the input fields inside it. For each field that asks the applicant
something, return the question it is asking, phrased as a plain question.

Rules:
- Use ONLY the visible text provided. Never invent a question.
- Match each question to its field by "index".
- Omit a field that is not a real question (layout helper, hidden field,
  search box, honeypot, a plain "First name"-style profile field).
- A field with "options" is a multiple-choice question — still return only
  its question text, not the options.
- Output the question text only — no numbering, no "Question:" prefix.
- Questions may be in any language; keep the form's own language.`;async function ti(e,t){if(t.length===0)return{};const a=JSON.stringify({blockText:e.slice(0,6e3),fields:t},null,2),n=await b({schemaName:"block_questions",schema:Za,systemPrompt:ei,userPrompt:a,parse:s=>JSON.parse(s)}),i={};for(const s of n.questions)s.question.trim()&&(i[s.index]=s.question.trim());return i}const ni={type:"object",additionalProperties:!1,required:["checkboxDecisions","questionAnswers"],properties:{checkboxDecisions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","check","category","reason"],properties:{index:{type:"integer"},check:{type:"boolean"},category:{type:"string",enum:["required-consent","marketing","optional","unclear"]},reason:{type:"string"}}}},questionAnswers:{type:"array",items:{type:"object",additionalProperties:!1,required:["id","answer","sufficientInfo"],properties:{id:{type:"string"},answer:{type:"string"},sufficientInfo:{type:"boolean"}}}}}},ai=`You fill in two independent things found on a job-application form at once:
consent checkboxes to decide, and custom questions to answer on the applicant's behalf. The
applicant has already chosen to submit this application.

CHECKBOXES (one decision per item in "checkboxes", matched back by "index")

TICK (check: true) — things required to submit, or that a candidate is normally expected to
accept:
- privacy policy / data protection / GDPR / Datenschutz consent
- terms & conditions / AGB / Nutzungsbedingungen
- confirming the entered information is accurate / truthful
- consent to process and store the application data for THIS hiring process
- storing the data in a talent pool ONLY when the checkbox is marked required
- eligibility self-declarations that hold for any ordinary adult applying for a real job (e.g.
  "I am at least 18 years old", "I am legally entitled to work in [country]", "I have no
  undisclosed conflicts of interest") — assume true unless the profile/CV explicitly states
  otherwise; a genuine job applicant submitting this form is virtually always eligible, and
  leaving a required declaration like this unticked blocks submission for no real reason

DO NOT TICK (check: false) — optional and promotional:
- newsletters, marketing e-mails, "career news", event invitations
- job alerts / notifications about new postings (e.g. "Benachrichtigungen über neue
  Stellenausschreibungen erhalten")
- sharing data with third parties / partner companies for marketing
- joining a talent pool / candidate database when NOT required
- anything that benefits the applicant only beyond this one application

Rules:
- "required: true" means the form marks the field mandatory — a strong signal to tick, unless
  the text is clearly marketing.
- A newsletter/marketing-email/job-alert opt-in is NEVER ticked, even when the form marks it
  "required" — that flag is routinely misused by forms to guilt-trip applicants into
  subscribing, even though applicants never actually need it to submit. When genuinely in doubt
  whether a required checkbox is a real submission requirement or a disguised newsletter
  opt-in, prefer NOT ticking it.
- If a checkbox is ambiguous AND not required, set check: false.
- Labels may be in any language; judge by meaning, not keywords.
- category: "required-consent" (ticked, mandatory-type), "marketing" (left off), "optional"
  (non-marketing but skippable, left off unless required), "unclear" (left off). reason: one
  short phrase.
- Return one decision per input item in "checkboxes", using its "index". If "checkboxes" is
  empty, return an empty array.

QUESTIONS (one answer per item in "questions", matched back by "id")

Ground rules:
- Use ONLY facts present in the shared "profile"/"cvText"/"personalLegend"/"generationRules"/
  "coverLetter"/"languageLevels"/"customFields"/"faq" given below, plus "job". Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, "languageLevels" is the
  authoritative answer (CEFR levels the applicant self-reported in Settings) — use it directly
  rather than guessing from the CV or defaulting to a low/neutral level.
- If the shared material genuinely lacks what's needed to answer a given question — not just a
  minor detail, but the actual substance being asked for — set that item's "sufficientInfo" to
  false and "answer" to an empty string. Do NOT write a sentence explaining that you don't have
  the information — that text would otherwise get typed straight into the applicant's form
  field, which is worse than leaving it blank. Only do this when the information is truly
  absent; a question you can answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient.
- If "postingLanguage" is given, write answers in that language, using the salutation/register
  conventions native speakers of it would expect on a job application (e.g. formal
  "Sie"/"Herr"/"Frau" address in German) — unless the question itself, or "generationRules",
  explicitly asks for a different language.
- A newsletter/marketing-email/job-alert subscription opt-in phrased as a question (e.g. "Would
  you like to subscribe to our newsletter? Yes/No") always gets the option that declines it.
- "faq" is a set of pre-written answers to standard interview-FAQ questions. If a question being
  asked now is the same as, or a close variant of, one already in "faq", reuse its substance and
  phrasing — adapt only what the target field's length/format actually requires.
- Match each question's expected length: a short field gets a short answer, an open-ended
  "tell us about..." field gets a fuller one.
- Output plain text per answer, no markdown, no restating the question.
- Each item in "questions" may also carry:
  - "options" (and not "multi"): a single-choice question — reply with EXACTLY ONE option,
    copied verbatim, nothing else. If the needed fact is genuinely absent (e.g. pronouns not
    stated anywhere), prefer a neutral option or an explicit "prefer not to say".
  - "options" with "multi": true: a select-all-that-apply question — reply with every option
    that genuinely applies, each copied verbatim, joined by " | " (one pipe, one space each
    side). If none apply, reply with an empty string. Never include an option just because it's
    plausible — only ones the applicant's own material actually supports.
  - "numeric": true: the field only accepts a plain number — reply with digits only (a single
    "." for a decimal if needed), no currency symbol, no thousands separator, no unit, no words,
    no range. If a range genuinely fits best (e.g. "65-75k"), reply with one representative
    figure (its midpoint).
  - "dateFormat": the field only accepts a date in exactly that format — reply with ONLY that
    value, nothing else. "todayISO" below is today's date: compute the answer from it — e.g.
    "available with one month's notice" -> todayISO plus one month; "immediately"/"as soon as
    possible"/no stated constraint -> todayISO itself.
- Return one answer per input item in "questions", using its "id". If "questions" is empty,
  return an empty array.

${I}`;function ii(e,t){const a=new Map;for(const n of t)a.set(n.index,n);return e.map((n,i)=>{const s=a.get(i);if(s){const o=s.check&&re(n.label)?!1:s.check;return{name:n.name,label:n.label,check:o,category:s.category,reason:s.reason}}return re(n.label)?{name:n.name,label:n.label,check:!1,category:"marketing",reason:"No decision returned — looks like a newsletter/marketing opt-in"}:{name:n.name,label:n.label,check:n.required,category:n.required?"required-consent":"unclear",reason:n.required?"Marked required by the form":"No decision returned"}})}function si(e,t){const a=new Map;for(const n of t)a.set(n.id,n);return e.map(n=>{const i=a.get(n.id);if(!i)return{id:n.id,answer:"",sufficientInfo:!0};if(!i.sufficientInfo||Ke(i.answer))return{id:n.id,answer:"",sufficientInfo:i.sufficientInfo};const s=n.options&&n.options.length>0||n.numeric||!!n.dateKind;return{id:n.id,answer:s?i.answer:S(i.answer),sufficientInfo:!0}})}async function me(e,t,a,n){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[i,s]=await Promise.all([v(),R("lastCoverLetter")]),o=JSON.stringify({job:a,profile:i.profile,cvText:i.cvText,personalLegend:i.personalLegend,generationRules:i.generationRules,coverLetter:s??"",languageLevels:i.languageLevels,customFields:i.customFields,faq:i.faq.filter(c=>c.answer.trim()),todayISO:Y(),postingLanguage:n||void 0,checkboxes:e.map((c,u)=>({index:u,label:c.label,required:c.required,currentlyChecked:c.checked})),questions:t.map(c=>({id:c.id,question:c.question,options:c.options&&c.options.length>0?c.options:void 0,multi:c.multi,numeric:c.numeric,dateFormat:c.dateKind?Pe[c.dateKind]:void 0}))},null,2),r=await b({schemaName:"page_content_decisions",schema:ni,systemPrompt:ai,userPrompt:o,parse:c=>JSON.parse(c)});return{checkboxDecisions:ii(e,r.checkboxDecisions),questionAnswers:si(t,r.questionAnswers)}}async function oi(e,t,a,n){const i=t.filter(l=>l.catchAll),s=i.length>0?t.filter(l=>!l.catchAll):t,o=await ri(e,s,a,n);if(i.length===0)return o;const r=s.flatMap(l=>{var g;const f=((g=o.questionAnswers.find(p=>p.id===l.id))==null?void 0:g.answer)??"";return f?[{question:l.question,answer:f}]:[]}),c=await Promise.all(i.map(async l=>{const{answer:f,sufficientInfo:g}=await Ge(l.question,a,{required:l.required??!1,formValues:l.formValues,otherAnswers:r,coverLetterAttached:l.coverLetterAttached},n);return{id:l.id,answer:f,sufficientInfo:g}})),u=new Map([...o.questionAnswers,...c].map(l=>[l.id,l]));return{checkboxDecisions:o.checkboxDecisions,questionAnswers:t.map(l=>u.get(l.id)??{id:l.id,answer:"",sufficientInfo:!0})}}async function ri(e,t,a,n){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[i,s]=await Promise.all([v(),R("lastCoverLetter")]),{input:o,promptCacheKey:r}=te(i,s??"",a,n),c=t.map((h,d)=>({q:h,i:d})),u=c.filter(({q:h})=>K(h)),l=c.filter(({q:h})=>!K(h));let f;try{f=await x({input:o,promptCacheKey:r,questions:[...bt(e),...u.flatMap(({q:h,i:d})=>_e(h,d)),...l.map(({q:h,i:d})=>Re(h,d))]})}catch(h){if(h instanceof j)throw h;return console.warn("[Filler] Decisions API failed, falling back to Responses:",h),me(e,t,a,n)}const g=e.map((h,d)=>vt(h,d,f)),p=e.filter((h,d)=>!g[d]),m=new Map,y=[];for(const{q:h,i:d}of u){const w=Oe(h,d,f);w?m.set(h.id,{id:h.id,...w}):y.push(h)}for(const{q:h,i:d}of l)Ce(d,f)===!1?m.set(h.id,{id:h.id,answer:"",sufficientInfo:!1}):y.push(h);if(p.length>0||y.length>0){const h=await me(p,y,a,n);for(const w of h.questionAnswers)m.set(w.id,w);const d=new Map(h.checkboxDecisions.map(w=>[w.name+"\0"+w.label,w]));e.forEach((w,k)=>{g[k]||(g[k]=d.get(w.name+"\0"+w.label)??null)})}return{checkboxDecisions:g.filter(h=>h!==null),questionAnswers:t.map(h=>m.get(h.id)??{id:h.id,answer:"",sufficientInfo:!0})}}const X="(none of these)",We="(not a profile field)",ze={salutation:"Salutation / title / gender as a form of address (Mr, Ms, Frau, Herr).",pronouns:"Preferred pronouns (she/her, he/him).",firstName:"The applicant's first / given name only.",lastName:"The applicant's last / family name only.",fullName:"The applicant's full name in one box.",email:"The applicant's e-mail address.",phone:"The applicant's phone / mobile number.",address:"Street and house number.",city:"City / town the applicant lives in.",postalCode:"Postal / ZIP code.",country:"Country the applicant lives in (not nationality, not where they want to work).",linkedin:"LinkedIn profile URL.",github:"GitHub profile URL.",website:"Personal website or portfolio URL.",expectedSalary:"The applicant's salary expectation as an amount (not a currency or period picker)."},ci=[...Object.entries(ze).map(([e,t])=>({value:e,description:t})),{value:We,description:"Anything else: an application question, a date, a company, a job title, a free comment, or a field about somebody else (a referrer, a reference, an emergency contact)."}],li=`You help autofill a job-application form from the applicant's saved profile.
Two kinds of questions follow, each about one field of the form and independent of the others:
- Option questions: the field must be set to a value the applicant already gave, but its options word it differently
  (another language, an official name, a region added, an amount written as a range). Pick the option that means
  the same thing — the same country, the same city, the range containing the amount. When no option does, pick
  "${X}"; never pick a merely similar one.
- Field questions: from what the page says about a field (label, name, placeholder…), which profile value does it ask
  for? Only the applicant's own data counts; when unsure, "${We}".
Labels may be in any language: judge by meaning.`;function ui(e){var a,n;return[`label "${e.label}"`,`type ${e.kind}`,e.name&&`name "${e.name}"`,e.id&&`id "${e.id}"`,e.placeholder&&`placeholder "${e.placeholder}"`,e.ariaLabel&&`aria-label "${e.ariaLabel}"`,e.autocomplete&&`autocomplete "${e.autocomplete}"`,((a=e.other)==null?void 0:a.length)&&`nearby text ${e.other.map(i=>`"${i}"`).join(", ")}`,((n=e.options)==null?void 0:n.length)&&`options ${e.options.map(i=>`"${i}"`).join(", ")}`].filter(Boolean).join("; ")}function pi(e){return{type:"choice",name:e.id,instructions:`Form field labelled "${e.label}" (the applicant's ${e.field}). The applicant's value: "${e.value}". Which option is that value?`,choices:[...new Set(e.options)].filter(t=>t!==X).map(t=>({value:t})).concat({value:X})}}function di(e){return[...e.optionPicks.filter(t=>t.options.length>0).map(pi),...e.fieldKinds.map(t=>({type:"choice",name:t.id,instructions:`A form field with ${ui(t.signals)}. Which of the applicant's profile values does it ask for?`,choices:ci}))]}function hi(e,t){return{optionPicks:e.optionPicks.filter(a=>t.has(a.id)).map(a=>{const n=U(t,a.id),i=n&&n.confidence>=M.optionMatch&&a.options.includes(n.choice);return{id:a.id,choice:i?n.choice:null}}),fieldKinds:e.fieldKinds.filter(a=>t.has(a.id)).map(a=>{const n=U(t,a.id),i=n&&n.confidence>=M.profileField&&n.choice in ze;return{id:a.id,field:i?n.choice:null}})}}async function fi(e){const t=di(e);if(t.length===0)return{optionPicks:[],fieldKinds:[]};const a=await x({input:li,questions:t,promptCacheKey:"filler-field-decisions"});return hi(e,a)}const gi={type:"object",additionalProperties:!1,required:["postingLanguages","requirements","keywords","contact"],properties:{postingLanguages:{type:"array",items:{type:"string"}},requirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...Ae,null]}}}},keywords:Ve,contact:{type:["string","null"]}}},mi=`You read a job posting and report three independent things about it: its
language, the skills it asks for (keywords), and (only if asked below) a recruiter/hiring
contact. Judge language and keywords against the applicant profile/CV/Personal Legend given
below.

LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- requirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or
  "Native" for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent",
  "professional working proficiency" -> "C1"; "conversational" -> "B1". If a language is
  mentioned but no level can be reasonably inferred, set level to null. Do not invent a
  requirement that isn't stated in the text. If nothing is stated, return an empty array.

${ae("the posting text (job title, description, requirements, responsibilities)")}

CONTACT
- "job.contact" below is the recruiter/hiring contact already found elsewhere, or null if none
  was found yet.
- If it is already set (not null), ignore this entirely and return "contact": null — there is
  nothing to add.
- If it is null, look for one in the job's own text (description/requirements/responsibilities):
  a named recruiter/hiring manager's email address, or a LinkedIn profile/company URL. If you
  find one, copy it VERBATIM (exact characters) so it can be re-found on the page for
  highlighting — the same rule as for keywords. If none is mentioned, return "contact": null.`;async function yi(e){const t=await v(),a=JSON.stringify({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,job:e},null,2),n=await b({schemaName:"job_brief",schema:gi,model:await Te(),systemPrompt:mi,userPrompt:a,parse:i=>JSON.parse(i)});return{language:{postingLanguages:n.postingLanguages,requirements:n.requirements},keywords:ie(n.keywords,e),contact:n.contact}}const wi={type:"object",additionalProperties:!1,required:["cvId","reason"],properties:{cvId:{type:"string"},reason:{type:"string"}}},bi=`You pick which of an applicant's CVs to send to one job posting.
Each CV has an id, a name, the language it's written in, the applicant's own rules for which
postings it's for, and the start of its text.
- Prefer a CV written in the posting's language; if none, an English one.
- Then follow the applicant's rules: the CV whose rules fit this posting best.
- Then the one marked default for that language.
Return the chosen CV's exact "id" and a reason of at most 10 words. Plain text, no em dashes.`;async function vi(e,t,a){if(t.length<2)return null;const n=t.map((i,s)=>`cv${s+1}`);try{const i=await x({input:[{role:"user",content:[{type:"input_text",text:"A job posting the applicant is applying to:"},{type:"input_json",data:{position:e.position,company:e.company,location:e.location,language:a??null,techStack:e.techStack,description:e.description.slice(0,4e3)}}]}],questions:[{type:"choice",name:"cv",instructions:"Which of the applicant's CVs should be sent to this posting? Prefer a CV written in the posting's language (else an English one), then the one whose rules fit the posting best, then the one marked default for that language.",choices:t.map((r,c)=>({value:n[c],description:Ei(r)}))}]}),s=U(i,"cv"),o=s?n.indexOf(s.choice):-1;return!s||o<0||s.confidence<M.cvChoice?null:{cvId:t[o].id,reason:"",source:"ai",confidence:s.confidence}}catch(i){if(i instanceof j)throw i;return console.warn("[Filler] Decisions API failed, choosing the CV via Responses:",i),Si(e,t,a)}}function Ei(e){var t;return[`Name: ${xe(e)}.`,`Language: ${e.language?Ne(e.language):"not set"}${e.isDefaultForLanguage?" (default CV for that language)":""}.`,(t=e.rules)!=null&&t.trim()?`Applicant's rules for it: ${e.rules.trim()}`:"",`Starts: ${e.text.slice(0,600).replace(/\s+/g," ")}`].filter(Boolean).join(" ")}async function Si(e,t,a){if(t.length<2)return null;const n={posting:{position:e.position,company:e.company,location:e.location,language:a??null,techStack:e.techStack,description:e.description.slice(0,4e3)},cvs:t.map(s=>({id:s.id,name:xe(s),language:s.language?Ne(s.language):null,defaultForLanguage:!!s.isDefaultForLanguage,rules:s.rules??"",textStart:s.text.slice(0,1200)}))},i=await b({schemaName:"cv_choice",schema:wi,model:await Me(),reasoningEffort:"low",systemPrompt:bi,userPrompt:JSON.stringify(n,null,2),parse:s=>JSON.parse(s)});return t.some(s=>s.id===i.cvId)?{cvId:i.cvId,reason:i.reason.replace(/—/g,",").trim()||"AI pick",source:"ai"}:null}const ki={type:"object",additionalProperties:!1,required:["values"],properties:{values:{type:"array",items:{type:"object",additionalProperties:!1,required:["name","value","reason"],properties:{name:{type:"string"},value:{type:"string"},reason:{type:"string"}}}}}},Ti=`You adapt an applicant's CV template to one specific job posting by
choosing a value for each {{placeholder}} in it.

Each variable comes with:
- "description": the applicant's own instruction for what the placeholder means and
  how to choose it. Follow it.
- "mode": "choice" means "value" MUST be exactly one of "options", copied verbatim
  (same spelling, same case, same line breaks). "free" means "options" are only
  examples of the expected shape and length; write the value that fits this posting
  in that same shape (e.g. a city name, a comma-separated list).
- "foundInPosting": options that literally occur in the posting text, most frequent
  first. A strong hint, not an order: the role's actual focus matters more than a
  passing mention.

Rules:
- Pick what makes this CV the closest honest match for this posting: its title, its
  location, its main technology, the vocabulary it uses.
- A job title / position value is the bare role name: no bracketed asides like (m/w/d),
  (f/m/d) or (Remote), no seniority level (Senior, Middle, Junior, Sr., Staff, Principal),
  no team, location or contract qualifiers. "Senior Backend Engineer (m/f/d)" -> "Backend Engineer".
- Honesty: never make the CV claim a skill, technology or experience the applicant's
  CV text / Personal Legend doesn't support, unless the variable's description
  explicitly asks for it. For list-like values, prefer terms that are both in the
  posting and supported by the applicant's background.
- Write the value in the same language as the surrounding template text.
- Return one entry per variable given, using its exact "name".
- "reason": one short sentence (max ~15 words) on why this value fits the posting.
- Plain text only, no markdown, no em dashes.`;function Li(e,t){const a=i=>i.trim().replace(/\s+/g," ").toLowerCase(),n=a(e);return t.options.find(i=>a(i)===n)??null}async function Ii(e,t){const a=new Set(Et(t.content)),n=t.variables.filter(u=>a.has(u.name));if(n.length===0)return[];const i=await v(),s=n.filter(u=>u.mode==="choice"&&u.options.length>=2),o=n.filter(u=>!(u.mode==="choice"&&u.options.length>0)),[r,c]=await Promise.all([s.length>0?_i(e,t,s,i):new Map,o.length>0?Xe(e,t,o,i):new Map]);return n.map(u=>r.get(u.name)??c.get(u.name)??{name:u.name,value:St(u,e),reason:""})}const Ai=`You adapt an applicant's CV template to one specific job posting: for each {{placeholder}}
pick the variant that makes this CV the closest honest match for the posting (its title, its location,
its main technology, the vocabulary it uses). Follow the applicant's own instruction for the placeholder.
Variants that literally occur in the posting are a strong hint, not an order: the role's actual focus
matters more than a passing mention. Never pick a variant that claims a skill, technology or experience
the applicant's CV text / Personal Legend doesn't support, unless the instruction explicitly asks for it.`;async function _i(e,t,a,n){const i=o=>`o${o+1}`,s=a.map((o,r)=>{const c=$e(o.options,e).map(u=>`${i(o.options.indexOf(u))} ("${u}")`);return{type:"choice",name:`v${r}`,instructions:[`CV placeholder {{${o.name}}}. Which variant should fill it for this posting?`,o.description.trim()?`The applicant's instruction for it: ${o.description.trim()}`:"",c.length>0?`Variants found verbatim in the posting, most frequent first: ${c.join(", ")}.`:""].filter(Boolean).join(`
`),choices:o.options.map((u,l)=>({value:i(l),description:u}))}});try{const o=await x({input:[{role:"developer",content:Ai},{role:"user",content:[{type:"input_json",data:{applicant:{cvText:n.cvText.slice(0,12e3),personalLegend:n.personalLegend.slice(0,8e3),city:n.profile.city,country:n.profile.country}}},{type:"input_json",data:{job:Qe(e)}}]}],promptCacheKey:`filler-cv-values-${kt(n.cvText+n.personalLegend)}`,questions:s}),r=new Map;return a.forEach((c,u)=>{const l=U(o,`v${u}`),f=l?c.options.findIndex((g,p)=>i(p)===l.choice):-1;!l||f<0||l.confidence<M.cvVariableChoice||r.set(c.name,{name:c.name,value:c.options[f],reason:`AI pick, ${Math.round(l.confidence*100)}% sure`})}),r}catch(o){if(o instanceof j)throw o;return console.warn("[Filler] Decisions API failed, picking CV variants via Responses:",o),Xe(e,t,a,n)}}function Qe(e){return{position:e.position,company:e.company,location:e.location,techStack:e.techStack,requirements:e.requirements,responsibilities:e.responsibilities,description:e.description.slice(0,8e3)}}async function Xe(e,t,a,n){const i={variables:a.map(r=>({name:r.name,mode:r.mode,description:r.description,options:r.options,foundInPosting:$e(r.options,e)})),template:t.content.slice(0,12e3),job:Qe(e),applicant:{cvText:n.cvText.slice(0,12e3),personalLegend:n.personalLegend.slice(0,8e3),city:n.profile.city,country:n.profile.country}},s=await b({schemaName:"cv_template_values",schema:ki,model:await Me(),systemPrompt:Ti,userPrompt:JSON.stringify(i,null,2),parse:r=>JSON.parse(r)}),o=new Map;for(const r of a){const c=s.values.find(l=>l.name===r.name);if(!c)continue;if(r.mode==="choice"&&r.options.length>0){const l=Li(c.value,r);l&&o.set(r.name,{name:r.name,value:l,reason:S(c.reason)});continue}const u=S(c.value);o.set(r.name,{name:r.name,value:Tt(r.name)?ma(u,e):u,reason:S(c.reason)})}return o}async function Ze(e){const t=await E(e);await Promise.all(t.map(a=>chrome.tabs.sendMessage(e,{type:"CANCEL_ELEMENT_PICKER",tabId:e},{frameId:a}).catch(()=>{})))}async function T(e,t,a){return(await Promise.all(t.map(i=>chrome.tabs.sendMessage(e,a,{frameId:i}).catch(()=>{})))).filter(i=>!!i)}async function ye(e,t,a,n){if(a!==void 0&&t.includes(a)){const i=await chrome.tabs.sendMessage(e,n,{frameId:a}).catch(()=>{});if(i)return[i]}return T(e,t,n)}function Ri(e){const t=new Map;for(const a of e){const n=a.locator.frameId;t.set(n,[...t.get(n)??[],a])}return t}async function Oi(e){switch(e.type){case"FILL_STATS_REPORT":{await _t(e.run);return}case"DECIDE_FIELDS":return{type:"FIELD_DECISIONS",result:await fi(e.request)};case"GET_PROFILE":return{type:"PROFILE_DATA",profile:await D()};case"GET_JOB":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});if(!e.force&&(t!=null&&t.url)){const c=await It(t.url);if(c!=null&&c.position&&c.company)return{type:"JOB_DATA",job:c,sufficient:!0}}const a=await E(e.tabId),i=(await T(e.tabId,a,e)).filter(c=>c.type==="JOB_DATA");if(i.length===0)return;const s=i.find(c=>c.sufficient);if(s)return t!=null&&t.url&&At(t.url,s.job),s;const o=i.reduce((c,u)=>u.job.description.length>c.job.description.length?u:c),r=i.map(c=>c.visibleText??"").filter(Boolean).join(`

`).slice(0,2e4);return{type:"JOB_DATA",job:o.job,sufficient:!1,visibleText:r||o.visibleText||"",pageUrl:t==null?void 0:t.url}}case"COMPLETE_JOB":{const{job:t,brief:a}=await Sa(e.job,e.text);return{type:"JOB_DATA",job:t,sufficient:!0,brief:a}}case"EXTRACT_JOB_FROM_TEXT":{const t=await chrome.tabs.get(e.tabId).catch(()=>{}),{job:a,brief:n}=await ba(e.text,(t==null?void 0:t.url)??"");return{type:"JOB_DATA",job:a,sufficient:!0,brief:n}}case"AUTOFILL":{const t=await E(e.tabId),n=(await T(e.tabId,t,e)).filter(i=>i.type==="AUTOFILL_RESULT");return{type:"AUTOFILL_RESULT",filled:n.reduce((i,s)=>i+s.filled,0),total:n.reduce((i,s)=>i+s.total,0),generatedPassword:n.map(i=>i.generatedPassword).find(Boolean)??null}}case"GENERATE_COVER_LETTER":{const{tabId:t}=e,a=e.job.url;let n="",i=0;await q(t,{jobUrl:a,status:"generating",content:""});let s;try{s=await sa(e.job,e.postingLanguage,o=>{chrome.runtime.sendMessage({type:"COVER_LETTER_STREAM_CHUNK",tabId:t,delta:o}).catch(()=>{}),n+=o,Date.now()-i>400&&(i=Date.now(),q(t,{jobUrl:a,status:"generating",content:n}).catch(()=>{}))})}catch(o){const r=o instanceof Error?o.message:String(o);throw await q(t,{jobUrl:a,status:"error",content:"",error:r}).catch(()=>{}),o}return await q(t,{jobUrl:a,status:"done",content:s.content,cleanedPatterns:s.cleaned?Array.from(new Set(s.slopFindings.map(o=>o.pattern))):[]}),await G("lastCoverLetter",s.content),{type:"COVER_LETTER_RESULT",content:s.content,slopFindings:s.slopFindings,cleaned:s.cleaned}}case"UPLOAD_FILE":{const t=await E(e.tabId),n=(e.targetLocator?await ye(e.tabId,t,e.targetLocator.frameId,e):await T(e.tabId,t,e)).filter(i=>i.type==="UPLOAD_FILE_RESULT");return{type:"UPLOAD_FILE_RESULT",nativeInputs:n.reduce((i,s)=>i+s.nativeInputs,0),dropZones:n.reduce((i,s)=>i+s.dropZones,0)}}case"REVISE_COVER_LETTER":{const t=await Ta(e.content,e.instructions,e.job);return await G("lastCoverLetter",t),{type:"REVISE_COVER_LETTER_RESULT",content:t}}case"TRANSLATE_COVER_LETTER":return{type:"TRANSLATE_COVER_LETTER_RESULT",content:await _a(e.content,e.targetLanguage)};case"GENERATE_OUTREACH_MESSAGE":{const t=await v(),a=await ra({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,outreachRules:t.outreachRules,job:e.job,contact:e.contact,postingLanguage:e.postingLanguage});return{type:"OUTREACH_MESSAGE_RESULT",subject:a.subject,body:a.body}}case"REVISE_OUTREACH_MESSAGE":{const t=await Ia({subject:e.subject,body:e.body},e.instructions,e.job);return{type:"OUTREACH_MESSAGE_RESULT",subject:t.subject,body:t.body}}case"GET_FRAME_ACCESS":return{type:"FRAME_ACCESS",blockedOrigins:await Nt(e.tabId)};case"DETECT_CUSTOM_QUESTIONS":{const t=await E(e.tabId),a=await T(e.tabId,t,e),n=new Set,i=[];for(const s of a)if(s.type==="CUSTOM_QUESTIONS_DATA")for(const o of s.questions)n.has(o.question)||(n.add(o.question),i.push({...o,id:`question-${i.length}`}));return{type:"CUSTOM_QUESTIONS_DATA",questions:i}}case"ANSWER_CUSTOM_QUESTION":{const t=await Qa(e.question,e.job,e.options,e.numeric,e.dateKind,e.multi,e.postingLanguage,e.catchAll);return{type:"CUSTOM_QUESTION_ANSWER",question:e.question,answer:t.answer,sufficientInfo:t.sufficientInfo}}case"FILL_CUSTOM_QUESTION_ANSWERS":{const t=await E(e.tabId),a=await T(e.tabId,t,e);let n=0;const i=[];for(const s of a)s.type==="CUSTOM_QUESTION_FILL_RESULT"&&(n+=s.filled,i.push(...s.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:n,unfilled:i}}case"START_ELEMENT_PICKER":{const t=await E(e.tabId),a=t.map(i=>chrome.tabs.sendMessage(e.tabId,e,{frameId:i}).then(s=>s?{result:s,frameId:i}:void 0).catch(()=>{})),n=await new Promise(i=>{let s=a.length;s===0&&i(void 0);for(const o of a)o.then(r=>{s-=1,r?i(r):s===0&&i(void 0)})});return await Promise.all(t.map(i=>chrome.tabs.sendMessage(e.tabId,{type:"CANCEL_ELEMENT_PICKER",tabId:e.tabId},{frameId:i}).catch(()=>{}))),n?{...n.result,picked:n.result.picked.map(i=>({...i,locator:{...i.locator,frameId:n.frameId}}))}:{type:"ELEMENT_PICKER_RESULT",cancelled:!0,picked:[],blockText:"",semanticCount:0}}case"CANCEL_ELEMENT_PICKER":{await Ze(e.tabId);return}case"DECOMPOSE_BLOCK":return{type:"BLOCK_QUESTIONS",questions:await ti(e.blockText,e.fields)};case"FILL_QUESTION_ANSWERS_BY_LOCATOR":{const t=await E(e.tabId),a=(await Promise.all([...Ri(e.items)].map(([s,o])=>ye(e.tabId,t,s,{...e,items:o})))).flat();let n=0;const i=[];for(const s of a)s.type==="CUSTOM_QUESTION_FILL_RESULT"&&(n+=s.filled,i.push(...s.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:n,unfilled:i}}case"DETECT_CHECKBOXES":{const t=await E(e.tabId),a=await T(e.tabId,t,e),n=new Set,i=[];for(const s of a)if(s.type==="CHECKBOXES_DATA")for(const o of s.checkboxes){const r=o.name||o.label;!r||n.has(r)||(n.add(r),i.push({...o,id:`checkbox-${i.length}`}))}return{type:"CHECKBOXES_DATA",checkboxes:i}}case"DECIDE_PAGE_CONTENT":{const{checkboxDecisions:t,questionAnswers:a}=await oi(e.checkboxes,e.questions,e.job,e.postingLanguage);return{type:"PAGE_CONTENT_DECISIONS",checkboxDecisions:t,questionAnswers:a}}case"APPLY_CHECKBOX_DECISIONS":{const t=await E(e.tabId),a=await T(e.tabId,t,e);let n=0;for(const i of a)i.type==="CHECKBOX_APPLY_RESULT"&&(n+=i.changed);return{type:"CHECKBOX_APPLY_RESULT",changed:n}}case"DETECT_JOB_BRIEF":{const t=await yi(e.job);return{type:"JOB_BRIEF_DATA",language:t.language,keywords:t.keywords,contact:t.contact}}case"HIGHLIGHT_KEYWORDS":{const t=await E(e.tabId);return{type:"KEYWORD_HIGHLIGHT_RESULT",matched:(await T(e.tabId,t,e)).reduce((i,s)=>s.type==="KEYWORD_HIGHLIGHT_RESULT"?i+s.matched:i,0)}}case"CLEAR_KEYWORD_HIGHLIGHTS":{const t=await E(e.tabId);await T(e.tabId,t,e);return}case"GENERATE_FAQ_ANSWERS":{const t=await Ee(),a=await Jt(e.questions,t);try{await Lt(a)}catch{}return{type:"FAQ_ANSWERS_RESULT",entries:a}}case"SEARCH_JOBS":{const{searchId:t}=e,a=t?i=>{chrome.runtime.sendMessage({type:"JOB_SEARCH_PROGRESS",searchId:t,results:i}).catch(()=>{})}:void 0,n=setInterval(()=>void chrome.runtime.getPlatformInfo().catch(()=>{}),2e4);try{return{type:"JOB_SEARCH_RESULTS",...await Fn(e.query,{page:e.page,excludeResults:e.excludeResults,onResults:a})}}finally{clearInterval(n)}}case"SUGGEST_SEARCH_QUERY":{const{what:t,where:a,tags:n}=await Ue(e.provider==="adzuna");return{type:"SEARCH_QUERY_SUGGESTION",what:t,where:a,...e.provider==="adzuna"?{tags:n}:{}}}case"SUGGEST_CV_VALUES":return{type:"CV_VALUES",values:await Ii(e.job,e.template)};case"CHOOSE_CV":return{type:"CV_CHOICE",choice:await vi(e.job,e.cvs,e.postingLanguage)};default:return}}const Ci="src/sidepanel/index.html";chrome.runtime.onInstalled.addListener(()=>{qt(),chrome.sidePanel.setOptions({enabled:!1})});chrome.contextMenus.onClicked.addListener((e,t)=>{Ft(e,t)});chrome.action.onClicked.addListener(e=>{if(e.id===void 0)return;const t=e.id;chrome.sidePanel.setOptions({tabId:t,path:`${Ci}?tabId=${t}`,enabled:!0}),chrome.sidePanel.open({tabId:t}).catch(a=>console.error("sidePanel.open failed",a)),Pi(t)});async function Pi(e){await E(e);const t={type:"TAB_ACCESS_GRANTED",tabId:e};await chrome.runtime.sendMessage(t).catch(()=>{})}chrome.tabs.onRemoved.addListener(e=>{Rt(e)});chrome.runtime.onMessage.addListener((e,t,a)=>(Oi(e).then(a).catch(n=>{a({type:"ERROR",error:n instanceof Error?n.message:String(n),code:n instanceof Error?n.name:void 0})}),!0));chrome.runtime.onConnect.addListener(e=>{const t=/^picker-(\d+)$/.exec(e.name);if(!t)return;const a=Number(t[1]);e.onDisconnect.addListener(()=>{Ze(a)})});
