import{P as rt,g as Ee,a as C,b as ot,c as ct,s as lt,d as N,e as Se,f as ut,h as pt,i as dt,j as ht,k as ke,r as b,J as Le,n as ft,l as x,m as gt,t as H,o as mt,A as Te,p as te,M as yt,q as Ie,u as wt,v as bt,w as vt,x as K,y as Et,z as Ae,B as _e,C as W,D as St,E as kt,F as Ce,G as Oe,H as Lt,I as Re,K as Tt,L as oe,N as Pe,O as It,Q as xe,R as At,S as _t,T as Ct,U as Ne,V as Ot,W as ne,X as U,Y as M,Z as Rt,_ as q,$ as z,a0 as Me,a1 as je,a2 as $e,a3 as Ue,a4 as qe,a5 as Pt,a6 as xt,a7 as ce,a8 as D,a9 as Fe,aa as De,ab as Ye,ac as Nt,ad as Mt,ae as Je,af as jt,ag as $t,ah as Ut,ai as qt,aj as Ft,ak as Dt,al as Yt,am as F,an as Jt,ao as Bt,ap as Vt,aq as B,ar as Gt,as as Ht,at as Kt,au as Wt,av as zt,aw as Be,ax as Qt,ay as Xt}from"./registration-DOF9jkHr.js";import{canonicalPhone as Zt}from"./phone-rL_73DjL.js";const Ve={...rt,cv:"CV",coverLetter:"Cover Letter",generatePassword:"Generated password"},en=Object.keys(Ve);async function E(e){try{const a=(await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:["content-script.js"]})).map(n=>n.frameId).filter(n=>typeof n=="number");if(a.length>0)return a}catch{}try{return await chrome.scripting.executeScript({target:{tabId:e},files:["content-script.js"]}),[0]}catch{return[0]}}function tn(){const e=[];for(const t of Array.from(document.querySelectorAll("iframe, frame"))){const a=t.getBoundingClientRect(),n=a.width*a.height;t.src&&a.width>=200&&a.height>=150&&e.push({src:t.src,area:n})}return{origin:location.origin,children:e}}async function nn(e){let t;try{t=await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},func:tn})}catch{return[]}const a=new Set,n=new Map;for(const{result:i}of t)if(i){a.add(i.origin);for(const r of i.children){let o;try{const c=new URL(r.src);if(c.protocol!=="https:"&&c.protocol!=="http:")continue;o=c.origin}catch{continue}n.set(o,Math.max(n.get(o)??0,r.area))}}const s=[];for(const i of[...n.keys()].sort((r,o)=>n.get(o)-n.get(r))){if(a.has(i))continue;if(await chrome.permissions.contains({origins:[`${i}/*`]}).catch(()=>!1)||s.push(i),s.length===3)break}return s}async function an(e,t){if(e==="cv"){const s=await Ee();return(s==null?void 0:s.text)??""}if(e==="coverLetter")return await C("lastCoverLetter")??"";if(e==="generatePassword"){const s=await ot(t);if(s!=null&&s.generatedPassword)return s.generatedPassword;const i=ct();return s&&await lt(t,{...s,generatedPassword:i}),i}const a=await N(),n=a[e]??"";return e==="phone"&&n?Zt(n,a.country):n}const $="job-app-assistant-insert",sn={generatePassword:"Generate password"},rn=en.map(e=>({id:e,title:sn[e]??Ve[e]}));function on(){chrome.contextMenus.removeAll(()=>{chrome.contextMenus.create({id:$,title:"Insert",contexts:["editable"]});for(const e of rn)chrome.contextMenus.create({id:`${$}:${e.id}`,parentId:$,title:e.title,contexts:["editable"]})})}function cn(e){return e.startsWith(`${$}:`)?e.slice($.length+1):null}async function ln(e,t){if(!(t!=null&&t.id)||typeof e.menuItemId!="string")return;const a=cn(e.menuItemId);if(!a)return;const n=await an(a,t.id);await E(t.id);const s={type:"INSERT_VALUE",field:a,value:n};chrome.tabs.sendMessage(t.id,s,{frameId:e.frameId}).catch(()=>{})}const un=new Set(["profileCache","cvLibraryCache","legendLibraryCache","customFieldsCache","languageLevelsCache","faqAnswersCache","generationRulesCache","outreachRulesCache"]);let P=null;function pn(){return Promise.all([N(),Ee(),Se(),ut(),pt(),dt(),ht(),ke()]).then(([e,t,a,n,s,i,r,o])=>({profile:e,cvText:(t==null?void 0:t.text)??"",personalLegend:(a==null?void 0:a.content)??"",generationRules:(n==null?void 0:n.content)??"",outreachRules:(s==null?void 0:s.content)??"",languageLevels:i,customFields:r,faq:o}))}function v(){return P||(P=pn(),P.catch(()=>{P=null})),P}var ve;typeof chrome<"u"&&((ve=chrome.storage)!=null&&ve.onChanged)&&chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&Object.keys(e).some(a=>un.has(a))&&(P=null)});const I=`Write like a specific person, not an AI assistant. These rules have no exceptions:

- NEVER use an em dash ("—"), a spaced en dash ("–") or "--" as punctuation. Real people don't write that way. Use a comma, a period, parentheses, or two sentences.
- Banned words: delve, foster, leverage, utilize, facilitate, empower, streamline, robust, cutting-edge, paradigm shift, game changer, tapestry, realm, beacon, multifaceted, meticulous, intricate, paramount, transformative, elevate, embark, supercharge, harness, ever-evolving. Say the plain thing.
- Cut empty phrases: "it's worth noting", "at the end of the day", "when it comes to", "at its core", "in today's world", "the reality is", "in order to", "going forward".
- No "not X, it's Y" / "the question isn't X, it's Y" / "not just X but Y" contrasts. State Y directly.
- No throat-clearing openers ("Here's the thing", "Let me be clear", "I'll be honest") and no faux-insight setups ("what most people get wrong", "here's what nobody tells you").
- No importance puffery ("stands as a testament", "marks a pivotal moment", "plays a vital role", "underscores its significance"). State the fact and stop.
- No colon reveals: a noun phrase, a colon, then a dramatic lowercase clause.
- No trailing "-ing" clauses that editorialize ("highlighting the commitment to...", "underscoring its importance", "showcasing", "reflecting"). End the sentence.
- No metadiscourse that tells the reader what to notice ("this matters", "this distinction matters", "in other words", "as you can see").
- No "In conclusion" / "Ultimately" / "Overall" recap ending and no cute one-line kicker. Stop on the last concrete point.
- No emoji, no mid-sentence bold, no rhetorical questions.
- Vary sentence shape; don't stack short punchy fragments.
- Be concrete: name the technology, project, number, or outcome instead of calling it "significant", "impactful" or "exciting". Use active voice.`;function S(e){return e.replace(/[ \t]*[—―][ \t]*/g,", ").replace(/[ \t]+--[ \t]+/g,", ").replace(/(\D)[ \t]+–[ \t]+(?=\D)/g,"$1, ").replace(/[ \t]+([,.;:!?])/g,"$1").replace(/,(\s*[.;:!?])/g,"$1").replace(/,[ \t]*,/g,",").replace(/^[ \t]*,[ \t]*/gm,"").replace(/([([{])[ \t]*,[ \t]*/g,"$1").replace(/[ \t]*,[ \t]*([)\]}])/g,"$1").replace(/,[ \t]*$/gm,"").replace(/[ \t]+$/gm,"")}const dn=`You write the applicant's own answers to standard interview-FAQ
questions (spec_5 section B) — general-purpose answers meant to be reused, as-is or
lightly adapted, whenever a real application form asks a close variant of one of them.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend, and
  custom fields. Never invent experience, technologies, companies, education,
  achievements, or a concrete salary figure that wasn't actually given.
- If information needed for a good answer is missing (no CV, no Personal Legend
  content covering it), write a short, honest, generically true answer rather
  than fabricating specifics — the applicant can always sharpen it later.
- Keep each answer 2-5 sentences: concrete and confident, never generic
  corporate filler, no restating the question.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text per answer, no markdown, no numbering.

${I}`;function hn(e){return{type:"object",additionalProperties:!1,required:["answers"],properties:{answers:{type:"array",minItems:e,maxItems:e,items:{type:"string"}}}}}async function fn(e){if(e.length===0)return[];const{profile:t,cvText:a,personalLegend:n,generationRules:s,customFields:i}=await v(),r=JSON.stringify({profile:t,cvText:a,personalLegend:n,generationRules:s,customFields:i,questions:e},null,2),o=await b({schemaName:"faq_answers",schema:hn(e.length),systemPrompt:dn,userPrompt:r,parse:c=>JSON.parse(c)});return e.map((c,u)=>({question:c,answer:S(o.answers[u]??"")}))}async function gn(e,t){const a=new Map(t.map(i=>[i.question,i.answer])),n=e.filter(i=>{var r;return!((r=a.get(i))!=null&&r.trim())}),s=await fn(n);for(const i of s)a.set(i.question,i.answer);return e.map(i=>({question:i,answer:a.get(i)??""}))}function mn(e){return e!=null&&e.length?`Seniority levels to target: ${Le.filter(a=>e.includes(a.id)).map(a=>a.label.toLowerCase()).join(", ")}. Only include postings for these levels.`:""}function yn(e,t){const a=Le.filter(s=>t==null?void 0:t.includes(s.id));if(a.length===0)return e;const n=[];for(const s of e)for(const i of a)n.push(s.toLowerCase().includes(i.keyword)?s:`${i.keyword} ${s}`.trim());return[...new Set(n)]}function wn(e){const t=x(e);return t.length===0?"":t.length===1?`Role/keywords focus: "${t[0]}".`:`Role/keywords: any of ${t.map(a=>`"${a}"`).join(", ")}.`}function bn(e){return[wn(e),e.where?`Location: "${e.where}".`:"",mn(e.grades),e.remoteOnly?"Prefer remote-friendly roles.":"",ft(e.negative)].filter(Boolean).join(" ")}function vn(e){return e.length===0?"":`

Already found and shown to the applicant — do NOT return any of these again,
find genuinely different postings instead:
${e.map(a=>`- ${a.title} at ${a.company} (${a.url})`).join(`
`)}`}function _(e){return typeof e=="string"?e.trim():""}function En(e){const t=e.trim().replace(/^(?:[-*•]|\d+[.)])\s+/u,"").replace(/,$/,"");if(!t.startsWith("{")||!t.endsWith("}"))return null;let a;try{a=JSON.parse(t)}catch{return null}const n=_(a.url),s=_(a.title);return!/^https?:\/\//i.test(n)||!s?null:{title:s,company:_(a.company),location:_(a.location),url:n,salary:_(a.salary),snippet:_(a.snippet),postedAt:_(a.postedAt)}}function Sn(e){let t="";function a(n){const s=En(n);s&&e(s)}return{push(n){t+=n;let s;for(;(s=t.indexOf(`
`))!==-1;)a(t.slice(0,s)),t=t.slice(s+1)},end(){a(t),t=""}}}const kn=6,le=[{id:"ats",focus:`Look on applicant tracking systems: ${Te.join(", ")}.`},{id:"careers",focus:"Look on the hiring companies' own career pages (company websites, not job boards)."},{id:"boards",focus:"Look on job boards and aggregators (LinkedIn, Indeed, StepStone, Glassdoor, Welcome to the Jungle, Wellfound, Arbeitnow and similar); when the board links to the employer's own posting, give that URL."}];function Ln(e,t,a=[],n){const s=bn(e),i=te();return`Search the web for current, actually open job postings that fit this
candidate:

${t||"(no candidate background available)"}

${s||"No further constraints — use the candidate's own background to pick a fitting role/location."}

Today is ${i}. Only include postings published in the last ${yt} days
that are still accepting applications — skip anything marked closed, expired or filled,
or shown with an older date. Skip postings that are a poor fit for the candidate (wrong
seniority, unrelated field).
Prefer the employer's own posting on its applicant tracking system (${Te.join(", ")})
or career page over copies on aggregators, which often outlive the real posting.
Only real individual postings with their direct listing URL — never a search results page,
a generic careers homepage or an aggregator's category page.${n?`
${n}`:""}${vn(a)}

OUTPUT FORMAT — follow exactly. Up to ${kn} of the best matches, best first, as JSON
Lines: one JSON object per line, nothing else (no prose, no markdown, no code fences, no
citations). Each object has exactly these string keys:
{"title":"","company":"","location":"","url":"","salary":"","postedAt":"","snippet":""}
- "url": the posting's direct URL as found.
- "salary": as stated, or "" — never guess.
- "postedAt": YYYY-MM-DD when the posting states a date (resolve "3 days ago" against
  ${i}), else "".
- "snippet": one sentence, at most 25 words, on why it fits this candidate.
If you find no fitting posting, output nothing.`}const V={timeoutMs:9e4,idleMs:4e4,parseTimeoutMs:3e4};function ue(e){const t=a=>a.toLowerCase().replace(/[^a-z0-9]+/g," ").trim();return e.company?`${t(e.company)}|${t(e.title)}`:e.url}async function Tn(e,t,a=[],n,s,i){const r=performance.now();let o=null;const c=[],u=new Set,l=p=>u.has(p.url)||u.has(ue(p))?!1:(u.add(p.url),u.add(ue(p)),c.push(p),!0),f=await Promise.allSettled(le.map(async p=>{const w=Ln(e,t,a,p.focus),k=Sn(A=>{const[J]=Ie([{...A,source:"openai"}]);!J||!l(J)||(o??(o=performance.now()),s==null||s([J]))}),O=performance.now();try{const A=await gt(w,k.push,{reasoningEffort:"low",timeoutMs:V.timeoutMs,idleMs:V.idleMs,signal:i});return k.end(),A}finally{n==null||n.push({label:`Web search (${p.id})`,ms:performance.now()-O})}}));n==null||n.push({label:"Web search",ms:performance.now()-r}),o!==null&&(n==null||n.push({label:"First result",ms:o-r}));const h=f.flatMap((p,w)=>p.status==="rejected"?[{id:le[w].id,err:p.reason}]:[]),g=p=>p instanceof Error?p.message:"the search failed";if(h.length===f.length&&c.length===0)throw h[0].err;const m=h.map(p=>`Web search (${p.id}) stopped: ${g(p.err)}`);if(c.length>0)return{results:c,warnings:m};const y=f.map(p=>p.status==="fulfilled"?p.value:"").filter(p=>p.trim()).join(`

---

`);return y?{results:await H(n,"Parse results",()=>mt(y,"openai",t,{negative:e.negative,where:e.where,remoteOnly:e.remoteOnly,reasoningEffort:"low",timeoutMs:V.parseTimeoutMs,signal:i})),warnings:m}:{results:c,warnings:m}}function In(e,t){return!e&&!t?"":bt({low:Math.round(e??t??0),high:Math.round(t??e??0)})}function An(e){return new Promise(t=>setTimeout(t,e))}const _n=350,Cn=12,pe=15e3;function On(e,t,a,n,s){const i=new URL(`https://api.adzuna.com/v1/api/jobs/${n}/search/${s}`);i.searchParams.set("app_id",a.appId),i.searchParams.set("app_key",a.appKey),i.searchParams.set("results_per_page","15"),i.searchParams.set("content-type","application/json"),e&&i.searchParams.set("what",e),t.where&&i.searchParams.set("where",t.where);const r=wt(t.negative);return r&&i.searchParams.set("what_exclude",r),i.toString()}async function Rn(e,t,a,n,s,i){const r=AbortSignal.timeout(pe);let o;try{o=await fetch(On(e,t,a,n,s),{signal:i?AbortSignal.any([i,r]):r})}catch(l){throw r.aborted?new Error(`timed out after ${pe/1e3} s`):l}if(!o.ok){const l=await o.text().catch(()=>"");throw new Error(`Adzuna search failed (${o.status}): ${l.slice(0,300)}`)}const u=(await o.json()).results.map(l=>{var f,h;return{title:l.title,company:((f=l.company)==null?void 0:f.display_name)??"",location:((h=l.location)==null?void 0:h.display_name)??"",url:l.redirect_url,salary:In(l.salary_min,l.salary_max),snippet:(l.description??"").slice(0,300),postedAt:l.created??"",source:"adzuna",tag:e}});return Ie(u)}async function Pn(e,t,a,n=1,s,i){var d;const r=x(e),o=e.tags&&e.tags.length>0?e.tags:r.length>0?r:[e.what],c=Math.max(((d=e.grades)==null?void 0:d.length)??0,1),u=Math.max(1,Math.floor(Cn/c)),l=yn(o.slice(0,u),e.grades),f=new Set,h=[],g=[];o.length>u&&g.push(`Only the first ${u} search terms were used with ${c} grades selected.`);let m=0,y=null;for(let p=0;p<l.length&&!(i!=null&&i.aborted);p++){const w=l[p];try{const O=(await Rn(w,e,t,a,n,i)).filter(A=>!f.has(A.url));for(const A of O)f.add(A.url);h.push(...O),O.length>0&&(s==null||s(O))}catch(k){m++,y??(y=k),g.push(`"${w}" — ${k instanceof Error?k.message:"search failed"}`)}p<l.length-1&&await An(_n)}if(m===l.length&&y)throw y;return{results:h,warnings:g}}const xn=new Set(["AT","AU","BE","BR","CA","CH","DE","ES","FR","GB","IN","IT","MX","NL","NZ","PL","RU","SG","US","ZA"]);function Nn(e){var a;const t=(a=vt(e))==null?void 0:a.toUpperCase();return t&&xn.has(t)?t.toLowerCase():"us"}const Mn={type:"object",additionalProperties:!1,required:["what","where"],properties:{what:{type:"string"},where:{type:"string"}}},jn=`You suggest a starting job-search query for the applicant described below.
"what" is a short role/keywords phrase (e.g. "senior backend engineer", "product designer") —
their most recent or clearly strongest role from the CV/Personal Legend. Pick ONE single title:
never join multiple roles or technologies with "/", "," or parentheses (e.g. never "Full-Stack
Developer / Backend Engineer (Go, Python, React)") — that reads as a combined AND-match to a
literal keyword search and returns nothing. "where" is a location (city, region, or country) —
their stated city/country if given, else "".
Output only the two fields, no explanation.`;async function $n(){const{profile:e,cvText:t,personalLegend:a}=await v(),n=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:a},null,2),s=await b({schemaName:"job_search_query_suggestion",schema:Mn,systemPrompt:jn,userPrompt:n,parse:i=>JSON.parse(i),reasoningEffort:"low"});return{what:s.what,where:s.where||[e.city,e.country].filter(Boolean).join(", ")}}const Un={type:"object",additionalProperties:!1,required:["tags"],properties:{tags:{type:"array",items:{type:"string"}}}},qn=`You generate keyword search tags for Adzuna's job-search API, grounded in
the candidate's real background below. Per Adzuna's own docs
(https://developer.adzuna.com/docs/search), "what" is a single literal keyword/phrase match, not
a semantic search and not a boolean query — so ONE combined tag naming several technologies or
role variants (e.g. "Full-Stack Developer / Backend Engineer (Go, Python, React)") matches
nothing. You compensate by generating a small cross-product of short, atomic tags instead, each
run as its own separate search and merged afterwards.

Method — build the tags as a cross-product, exactly like this worked example for a candidate
whose strongest stack is Go and who also does full-stack/backend work:
  golang developer, go developer, go engineer, golang engineer,
  backend engineer, backend developer, fullstack engineer, fullstack developer,
  software engineer, software developer
That is: {primary technology + its common short aliases} × {developer, engineer}, PLUS
{their role-shape words, e.g. backend / fullstack / frontend / mobile / data — whichever
genuinely apply, without a technology} × {developer, engineer}, PLUS a generic "software
developer" / "software engineer" fallback pair.

Rules:
- Base every tag on their actual, strongest-fitting technology/field from the CV/Personal
  Legend — never invent a technology, role-shape, or seniority they don't have.
- Identify the ONE primary technology (e.g. "Go") plus its common short aliases people actually
  search with (e.g. "Golang") — do not alias unrelated technologies together.
- Each tag pairs exactly one technology-or-role-shape word with exactly one of "developer" /
  "engineer" (add "programmer" only if that's a genuinely common term for that stack). Never put
  two technologies, or a technology and a role-shape, in the same tag.
- If the CV shows a clear secondary technology/stack, budget permitting, add its own couple of
  tags the same way — still never combined with the primary one in a single tag.
- For EACH language listed in "languages" below (skip English), also include ONE of the
  strongest-technology tags translated into that language using the natural job-title term a
  native speaker would search with (not a literal word-for-word translation).
- Each tag is 1-3 words, lowercase, and never contains "/", ",", "(", ")", or a seniority
  qualifier ("senior", "junior", etc.).
- Deduplicate. Return 6-12 tags total, most relevant first.
- Output only the tags, no explanation.`;async function Fn(){const{profile:e,cvText:t,personalLegend:a,languageLevels:n}=await v(),s=JSON.stringify({profileCity:e.city,profileCountry:e.country,cvText:t,personalLegend:a,languages:n.map(r=>r.language)},null,2);return(await b({schemaName:"job_search_tags",schema:Un,systemPrompt:qn,userPrompt:s,parse:r=>JSON.parse(r),reasoningEffort:"low"})).tags.map(r=>r.trim()).filter(Boolean)}const Dn=4;function Yn(e){return JSON.stringify([e.profile.city,e.profile.country,e.cvText,e.personalLegend,e.languageLevels.map(t=>t.language)])}async function Jn(e){const t=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(e));return[...new Uint8Array(t)].map(a=>a.toString(16).padStart(2,"0")).join("")}async function ae(e){var o;const t=await Jn(Yn(await v())),a=await C("jobSearchSuggestionCache")??[],n=a.find(c=>c.key===t);if(n&&(!e||n.tags))return{what:n.what,where:n.where,tags:n.tags,cached:!0};const[s,i]=await Promise.all([n?{what:n.what,where:n.where}:$n(),e?Fn():Promise.resolve(void 0)]),r={key:t,...s,tags:i!=null&&i.length?i:n==null?void 0:n.tags};return(r.what||(o=r.tags)!=null&&o.length)&&await K("jobSearchSuggestionCache",[r,...a.filter(c=>c.key!==t)].slice(0,Dn)),{what:r.what,where:r.where,tags:r.tags,cached:!1}}async function G(e,t){var i;const a=performance.now(),n=await ae(!0);e.push({label:n.cached?`${t} (cached)`:t,ms:performance.now()-a});const s=Oe((i=n.tags)!=null&&i.length?n.tags:[n.what]);if(s.length===0)throw new Error("Couldn't derive search terms from your CV — type a few search terms.");return{what:n.what,where:n.where,terms:s}}const Bn="Arbeitsagentur skipped: allow Filler to reach rest.arbeitsagentur.de (Settings → Job search).";async function Vn(e,t={}){var s;if(!(e.provider!=="jobsuche"&&(t.jobsuche??((s=await Et().catch(()=>null))==null?void 0:s.jobsucheEnabled)??!0)))return Q(e,t);const n=await N().catch(()=>null);return Ae(e.where,(n==null?void 0:n.country)??"")?Gn(e,t):Q(e,t)}async function Gn(e,t){const a=t.page??1,n=(async()=>{var c;const o=performance.now();if(a>kt)return{results:[],warnings:[],ms:0};if(!await _e())return{results:[],warnings:[Bn],ms:0};try{let u=(c=e.tags)!=null&&c.length?e.tags:x(e);return u.length===0&&(u=(await ae(!0)).tags??[]),{...await Ce({...e,terms:Oe(u)},a,{exclude:t.excludeResults,onResults:t.onResults,signal:t.signal}),ms:performance.now()-o}}catch(u){return{results:[],warnings:[`Arbeitsagentur — ${u instanceof Error?u.message:"search failed"}`],ms:performance.now()-o}}})(),[s,i]=await Promise.all([Q(e,t),n]);i.ms>0&&s.stages.push({label:"Arbeitsagentur search",ms:i.ms});const r=[...s.warnings??[],...i.warnings];return{...s,results:Lt(s.results,i.results),...r.length?{warnings:r}:{}}}async function Q(e,t){var l,f;const a=performance.now(),n=[],s=()=>({totalMs:performance.now()-a,stages:n});if(e.provider==="jobsuche"){const h=await N().catch(()=>null);let g=e;if(x(g).length===0){const d=await G(n,"Suggest terms");g={...g,terms:d.terms,where:g.where.trim()||d.where}}if(!Ae(g.where,(h==null?void 0:h.country)??""))throw new Error("The Arbeitsagentur only lists jobs in Germany — set the location to Germany or a German city.");if(!await _e())throw new Error("Allow Filler to reach rest.arbeitsagentur.de first (Settings → Job search).");const{results:m,warnings:y}=await H(n,"Arbeitsagentur search",()=>Ce(g,t.page??1,{exclude:t.excludeResults,onResults:t.onResults,signal:t.signal}));return{results:m,resolvedQuery:g,...y.length?{warnings:y}:{},...s()}}if(e.provider==="adzuna"){const[h,g]=await Promise.all([W(),N()]);if(!h.adzunaAppId||!h.adzunaAppKey)throw new Error("Add your Adzuna app_id and app_key in Settings first.");let m=e;if(!((l=m.tags)!=null&&l.length)){const p=x(m);if(p.length>0)m={...m,tags:p};else{const w=await G(n,"Suggest tags");m={...m,what:w.what,where:m.where.trim()||w.where,tags:w.terms}}}const{results:y,warnings:d}=await H(n,"Adzuna search",()=>Pn(m,{appId:h.adzunaAppId,appKey:h.adzunaAppKey},Nn(g.country),t.page??1,t.onResults,t.signal));return{results:y,resolvedQuery:m,warnings:d,...s()}}const[i,r]=await Promise.all([Se(),W()]),o=(i==null?void 0:i.content)??"";if(e.provider==="tavily"){if(!r.tavilyApiKey)throw new Error("Add your Tavily API key in Settings first.");let h=e;if(x(h).length===0){const y=await G(n,"Suggest terms");h={...h,terms:y.terms,where:h.where.trim()||y.where}}const{results:g,warnings:m}=await St(h,r.tavilyApiKey,o,t.excludeResults,n,t.signal,t.page??1);return g.length>0&&((f=t.onResults)==null||f.call(t,g)),{results:g,resolvedQuery:h,...m.length?{warnings:m}:{},...s()}}const{results:c,warnings:u}=await Tn(e,o,t.excludeResults,n,t.onResults,t.signal);return{results:c,resolvedQuery:e,...u.length?{warnings:u}:{},...s()}}const Hn={type:"object",additionalProperties:!1,required:["keyRequirements","relevantExperienceHints","suggestedTone","suggestedFocus"],properties:{keyRequirements:{type:"array",items:{type:"string"}},relevantExperienceHints:{type:"array",items:{type:"string"}},suggestedTone:{type:"string"},suggestedFocus:{type:"string"}}};async function Kn(e){return b({schemaName:"job_analysis",schema:Hn,model:await Re(),systemPrompt:"You analyze job postings for a job-application assistant. Identify the most important requirements and what an applicant should emphasize. Do not invent details that are not present in the posting.",userPrompt:JSON.stringify(e,null,2),parse:t=>JSON.parse(t)})}const Wn=`You write tailored cover letters for job applications.

The user message holds the applicant's data as JSON, and may end with an
"Applicant's rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and
   Personal Legend. Never invent experience, technologies, companies,
   education, or achievements, even if the applicant's rules ask for them.
   If information needed to be compelling is missing, write around it
   honestly rather than fabricating it.
2. The applicant's rules. Follow every instruction there on tone, length,
   structure, language, and what to include or avoid, including where it
   departs from the defaults below. Every rule there applies to the whole
   letter, not just the opening.
3. Language. If "postingLanguage" is given, write the entire letter in that
   language, using the salutation, register, and closing conventions native
   speakers of it would expect on a job application (e.g. formal
   "Sie"/"Herr"/"Frau" address and a "Sehr geehrte(r) ..." opening in German,
   not a literal English-to-German translation).
4. The house style below. Its "no exceptions" means no exceptions of your
   own; an explicit applicant rule still overrides it.
5. Tone and emphasis tailored to the job analysis provided.

Output plain prose paragraphs, no markdown headers.

${I}`;async function zn(e,t){const n=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,analysis:e.analysis,postingLanguage:e.postingLanguage||void 0},null,2)+Ge(e.generationRules),s=await Tt(Wn,n,t??(()=>{}));return S(s)}function Ge(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const se={type:"object",additionalProperties:!1,required:["content"],properties:{content:{type:"string"}}},He={type:"object",additionalProperties:!1,required:["subject","body"],properties:{subject:{type:["string","null"]},body:{type:"string"}}},Qn=`You are a sharp human editor cleaning up a cover letter draft.

Fix ONLY the flagged AI-writing patterns listed below. Make the minimum
effective edit — do not rewrite sentences that were not flagged, do not
change facts, experience, technologies, or claims, and do not add new
content. Replace banned words/clichés with plain, concrete language.
Rewrite "not X, it's Y" contrasts as a direct statement of Y. Cut
throat-clearing openers, weasel attribution, and importance-puffery instead
of softening them. If the ending is a generic summary/recap, end on the
letter's last concrete point instead. Replace every em dash ("—") with a
comma, a period, or parentheses.

The user message may end with the applicant's own rules for the letter. If a
flagged pattern is something those rules explicitly ask for, leave it as is:
the applicant's rules outrank the house style.

Do not introduce any new AI-slop while editing. For reference, the full
house style is:

${I}

Output plain prose paragraphs, no markdown headers.`;async function Xn(e,t,a=""){const n=JSON.stringify({draft:e,flaggedPatterns:t.map(i=>`${i.pattern}: "${i.match}"`)},null,2)+Ge(a),s=await b({schemaName:"cover_letter_polish",schema:se,systemPrompt:Qn,userPrompt:n,parse:i=>JSON.parse(i)});return S(s.content)}const Zn=["delve","foster","leverage","utilize","facilitate","empower","streamline","robust","cutting-edge","paradigm shift","game changer","this is huge","this changes everything","tapestry","realm","beacon","multifaceted","meticulous","intricate","paramount","transformative","elevate","embark","supercharge","harness","ever-evolving"],ea=["it's worth noting","it is worth noting","it's important to note","it is important to note","at the end of the day","when it comes to","at its core","in today's world","in the age of","in the world of","the reality is","the truth is","in terms of","with regard to","in order to","going forward"],ta=["here's the thing","here's what i mean","let me be clear","i'll be honest","the uncomfortable truth is"],na=["this is the part most people skip","what most people get wrong","here's what nobody tells you","the part everyone misses"],aa=["stands as a testament","marks a pivotal moment","plays a vital role","solidifies its position","underscores its significance"],sa=["experts agree","industry reports suggest","many argue","widely regarded as","studies show"],ia=[/^in conclusion\b/i,/^ultimately\b/i,/^overall\b/i];function ra(e){const t=e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`\\b${t.replace(/ /g,"\\s+")}\\b`,"i")}function R(e,t,a){const n=[];for(const s of t){const i=ra(s).exec(e);i&&n.push({pattern:a,match:i[0]})}return n}function oa(e){const t=/\b(?:isn'?t|is not)\b[^.!?]{3,60}[,.]?\s*(?:it'?s|it is)\b[^.!?]{3,80}[.!?]/i,a=/\bnot just\b[^.!?]{3,60}(?:\bbut\b|[,.]?\s*(?:it'?s|it is)\b)[^.!?]{0,80}[.!?]/i,n=[],s=t.exec(e);s&&n.push({pattern:"binary-contrast",match:s[0].trim()});const i=a.exec(e);return i&&n.push({pattern:"binary-contrast",match:i[0].trim()}),n}function ca(e){const t=e.split(/\n{2,}/).map(n=>n.trim()).filter(Boolean),a=t[t.length-1];if(!a)return[];for(const n of ia)if(n.test(a))return[{pattern:"summary-recap-ending",match:a.slice(0,60)}];return[]}function la(e){const t=(e.match(/—/g)??[]).length;return t===0?[]:[{pattern:"em-dash",match:t===1?"1 em dash":`${t} em dashes`}]}function ua(e){return[...R(e,Zn,"banned-word"),...R(e,ea,"empty-phrase"),...R(e,ta,"throat-clearing-opener"),...R(e,na,"faux-insight-setup"),...R(e,aa,"importance-puffery"),...R(e,sa,"weasel-attribution"),...oa(e),...ca(e),...la(e)]}async function pa(e,t,a){const n=await v(),s=await Kn(e),i=await zn({profile:n.profile,cvText:n.cvText,personalLegend:n.personalLegend,generationRules:n.generationRules,job:e,analysis:s,postingLanguage:t},a),r=ua(i);return r.length===0?{content:i,slopFindings:r,cleaned:!1}:{content:await Xn(i,r,n.generationRules),slopFindings:r,cleaned:!0}}const da=`You write a short outreach message an applicant sends to a named
recruiter/hiring contact BEFORE or alongside applying, to start a conversation about a specific
job posting — not a cover letter, and not addressed to "the hiring team".

The user message holds the applicant's data as JSON ("contact" is the email address or LinkedIn
URL found on the posting, "channel" is "email" or "linkedin"), and may end with an "Applicant's
rules" section written by the applicant themselves.

Priority, highest first. When two of these conflict, the higher one wins:
1. Facts. Use ONLY facts present in the provided profile, CV text, and Personal Legend. Never
   invent experience, technologies, companies, education, or achievements.
2. The applicant's rules. Follow every instruction there on tone, length, structure, language,
   and what to include or avoid, including where it departs from the defaults below.
3. Language. If "postingLanguage" is given, write the entire message in that language, using
   the salutation and register native speakers of it would expect.
4. Channel. If "channel" is "email", write a short email: "subject" is REQUIRED, never null or
   empty: a specific, non-generic subject line under 80 characters that names the role and the
   company (and, if it fits, the applicant's strongest match), in the message's language. "body"
   opens with a greeting and closes with a signature using the applicant's name; it does not
   repeat the subject. If "channel" is "linkedin", write a LinkedIn connection/message note
   instead: "subject" is null, "body" has no email greeting/signature and stays under LinkedIn's
   informal register.
5. The house style below. Its "no exceptions" means no exceptions of your own; an explicit
   applicant rule still overrides it.

Defaults (apply unless the applicant's rules say otherwise): under 120 words, state who the
applicant is and the one or two things that make them a fit for THIS role, and end with a clear,
low-pressure ask (a quick chat, or just flagging interest before applying). Never sound like a
mass-sent template.

${I}`;async function ha(e){const a=JSON.stringify({profile:e.profile,cvText:e.cvText,personalLegend:e.personalLegend,job:e.job,contact:e.contact,channel:oe(e.contact)?"email":"linkedin",postingLanguage:e.postingLanguage||void 0},null,2)+fa(e.outreachRules),n=await b({schemaName:"outreach_message",schema:He,model:await Pe(),systemPrompt:da,userPrompt:a,parse:s=>JSON.parse(s)});return{subject:oe(e.contact)?Ke(n.subject,e.job):null,body:S(n.body)}}function Ke(e,t){const a=S((e??"").replace(/^\s*subject\s*:\s*/i,"").replace(/\s+/g," ").trim());if(a)return a;const n=t.position.trim(),s=t.company.trim();return n&&s?`${n} at ${s}`:n||s||"Job application"}function fa(e){const t=e.trim();return t?`

## Applicant's rules (highest priority after facts)

${t}
`:""}const We={type:"array",items:{type:"object",additionalProperties:!1,required:["text","kind","matchesProfile"],properties:{text:{type:"string"},kind:{type:"string",enum:["hard","soft"]},matchesProfile:{type:"boolean"}}}};function ie(e){return`KEYWORDS
- Pick the SKILLS the posting asks for, and nothing else. Each one is either:
  - "hard": a technical skill, tool, technology, programming language, framework, platform,
    method or domain expertise (e.g. "TypeScript", "Kubernetes", "C++", ".NET", "CI/CD",
    "SQL", "machine learning", "financial modelling", "Figma", "Scrum");
  - "soft": a real interpersonal/working skill (e.g. "communication", "mentoring",
    "stakeholder management", "problem-solving", "ownership").
- NEVER return anything that is not a skill. In particular, never return:
  - the company name, its products' brand names used as a name, or any other organization;
  - cities, countries, regions, addresses, time zones;
  - work modes and contract terms ("remote", "hybrid", "on-site", "full-time", "contract");
  - benefits and pay ("salary", "equity", "health insurance", "30 days vacation", "bonus");
  - job titles and seniority ("Senior Backend Engineer", "Team Lead", "junior");
  - years of experience, degrees, certificates as such ("5+ years", "Bachelor's degree");
  - spoken languages ("English", "German") — those are reported separately above;
  - generic words ("team", "experience", "work", "product", "environment", "opportunity",
    "fast-paced environment", "passion").
- Every keyword's "text" MUST be copied VERBATIM from ${e} — the exact same characters
  and casing, not a paraphrase, synonym, or translation — because the extension re-finds this
  exact text on the page to highlight it. A keyword that doesn't appear verbatim is useless.
- Prefer short phrases: single words or 2-3 word phrases, never sentences.
- Return up to 15, most important first. Fewer is fine: return an empty array rather than
  padding the list with anything from the NEVER list above.
- No duplicates, and no two keywords where one is a substring of the other (keep the more
  specific/longer one).
- Set "matchesProfile" to true when the applicant's profile/cvText/personalLegend shows they
  already have, use, or meet that skill — false when the posting asks for it but nothing in
  the applicant's material supports it. Judge substance, not exact wording (e.g.
  "Kubernetes" counts as a match if the CV mentions "container orchestration with K8s" or
  "EKS"). When genuinely unsure, set it to false — this flags a possible gap for the
  applicant to address rather than silently hiding it.`}const ga=new Set(["team","teams","experience","work","job","role","position","company","candidate","opportunity","environment","product","products","customer","customers","client","clients","project","projects","skills","knowledge","ability","responsibilities","requirements","tasks","career","growth","culture","mission","vision","values","impact","passion","motivation","startup","scale-up","industry","business","fast-paced environment","dynamic environment","nice to have","must have","plus","years","year","years of experience","professional experience","work experience","degree","bachelor","bachelor's degree","master","master's degree","university degree","diploma","phd","intern","internship","junior","middle","mid-level","senior","lead","principal","staff","head","manager","remote","fully remote","remote work","hybrid","on-site","onsite","office","in office","home office","homeoffice","relocation","visa sponsorship","full-time","full time","part-time","part time","contract","freelance","permanent","temporary","salary","competitive salary","bonus","equity","stock options","esop","benefits","vacation","paid time off","pto","holidays","health insurance","insurance","pension","gym","gym membership","free lunch","snacks","flexible hours","flexible working hours","learning budget","parental leave","erfahrung","berufserfahrung","aufgaben","anforderungen","unternehmen","vollzeit","teilzeit","festanstellung","gehalt","urlaub","vertrag","büro","mobiles arbeiten","команда","опыт","опыт работы","работа","компания","проект","проекты","задачи","требования","обязанности","удаленно","удаленка","удаленная работа","гибрид","офис","полный день","полная занятость","частичная занятость","зарплата","оклад","бонусы","дмс","отпуск","релокация"]),ma=new Set(It.map(e=>T(e))),ya=new RegExp("\\s*,?\\s*(?<![\\p{L}\\p{N}])(?:inc|ltd|llc|gmbh|ag|se|kg|ug|bv|nv|sa|sas|srl|plc|corp|corporation|co|company|oy|ab|as|ооо|ао)\\.?$","iu");function T(e){return e.normalize("NFC").toLowerCase().replace(/ё/g,"е").replace(/[’`]/g,"'").replace(/^[\s"'«».,:;!?()[\]-]+|[\s"'«».,:;!?()[\]-]+$/g,"").replace(/\s+/g," ")}function wa(e){const t=T(e);if(!t)return[];const a=T(t.replace(ya,""));return a&&a!==t?[t,a]:[t]}function ba(e){const t=T(e);if(!t)return[];const a=e.split(/[,/|·•()]/).map(T).filter(Boolean);return[t,...a]}function va(e){return T(e.replace(/\((?:[mwfdx]\s*\/\s*)+[mwfdx]\)/gi,""))}const Ea=/^\d+(?:\s*[-–+]\s*\d*)?\+?\s*(?:years?|yrs?|jahre?n?|лет|года?|ans|años)(?![\p{L}\p{N}])/iu;function X(e,t){const a=e.trim();if([...a].length<2)return!new RegExp("^\\p{Lu}$","u").test(a);if(!new RegExp("\\p{L}","u").test(a)||/[$€£¥₽%]/u.test(a))return!0;const n=T(a);return!n||ga.has(n)||ma.has(n)||Ea.test(n)||wa(t.company).includes(n)||ba(t.location).includes(n)?!0:n===va(t.position)}function re(e,t){const a=new Set;return e.filter(n=>{const s=T(n.text);return a.has(s)||X(n.text,t)?!1:(a.add(s),!0)})}function Sa(e,t){var s;const a=(s=e.match(/\s*[,;|·•]\s*/u))==null?void 0:s[0];if(!a)return X(e,t)?"":e;const n=new Set;return e.split(/\s*[,;|·•]\s*/u).filter(i=>{const r=T(i);return!i.trim()||n.has(r)||X(i,t)?!1:(n.add(r),!0)}).join(a)}const ze={postingLanguages:{type:"array",items:{type:"string"}},languageRequirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...Ne,null]}}}},keywords:We},ka={type:"object",additionalProperties:!1,required:["company","position","location","description","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},description:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...ze}},Qe=`LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- languageRequirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or "Native"
  for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent", "professional
  working proficiency" -> "C1"; "conversational" -> "B1". If a language is mentioned but no level
  can be reasonably inferred, set level to null. Do not invent a requirement that isn't stated in
  the text. If nothing is stated, return an empty array.`,La=`You read the visible text of a job-posting page and do two things with it
in one pass: extract the structured posting fields, and analyze the result for language and
keywords — against the applicant profile/CV/Personal Legend given below.

EXTRACTION
- Only use information present in "pageText"; leave a field empty/null if unknown.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- For "contact", prefer a named recruiter/hiring manager's email address or LinkedIn
  profile/company URL if one is mentioned, copied VERBATIM (exact characters); otherwise null.

${Qe}

${ie('"pageText"')}`;async function Ta(e,t){const a=await v(),n=JSON.stringify({profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,pageText:e.slice(0,12e3)},null,2),s=await b({schemaName:"job_extraction_and_brief",schema:ka,model:await xe(),reasoningEffort:"low",systemPrompt:La,userPrompt:n,parse:o=>JSON.parse(o)}),i={company:s.company,position:At(s.position),location:s.location,description:s.description,requirements:s.requirements,responsibilities:s.responsibilities,salary:s.salary,techStack:s.techStack,contact:s.contact,url:t},r={language:{postingLanguages:s.postingLanguages,requirements:s.languageRequirements},keywords:re(s.keywords,i),contact:null};return{job:i,brief:r}}const Ia={type:"object",additionalProperties:!1,required:["company","position","location","requirements","responsibilities","salary","techStack","contact","postingLanguages","languageRequirements","keywords"],properties:{company:{type:"string"},position:{type:"string"},location:{type:"string"},requirements:{type:"array",items:{type:"string"}},responsibilities:{type:"array",items:{type:"string"}},salary:{type:["string","null"]},techStack:{type:"array",items:{type:"string"}},contact:{type:["string","null"]},...ze}},Aa=`You read the visible text of a job-posting page. It was already parsed
without AI: "knownFields" holds what that found. Fill in what it missed, and analyze the posting
for language and keywords — against the applicant profile/CV/Personal Legend given below.

FIELDS
- Fill only the fields named in "fieldsToFill". For every other posting field return "" / [] /
  null — those are kept from the page as they are. Never re-type the posting's description.
- position: the bare role name only — no company, job board or "| LinkedIn"-style suffix, no
  bracketed asides like (m/w/d), (f/m/d) or (Remote), no seniority level (Senior, Junior, Middle,
  Lead-level prefixes like Staff/Principal) and no team/location/contract qualifiers.
  "Senior Backend Engineer (m/f/d) – Remote" -> "Backend Engineer".
- company: the hiring company, not the job board or recruiting platform hosting the page.
- location: as written in the posting; "" if none.
- requirements, responsibilities: at most 8 items each, each a short phrase (12 words or fewer),
  not copied paragraphs.
- techStack: technology names only.
- contact: a named recruiter/hiring manager's email address or LinkedIn profile/company URL,
  copied VERBATIM (exact characters); otherwise null.
- Only use information present in "pageText"; leave a field empty/null if unknown.

${Qe}

${ie('"pageText"')}`;async function _a(e,t){const a=await v(),n=_t(e),s=t||e.description,i=JSON.stringify({profile:a.profile,cvText:a.cvText,personalLegend:a.personalLegend,knownFields:{position:e.position,company:e.company,location:e.location,salary:e.salary,contact:e.contact},fieldsToFill:n,pageText:s.slice(0,12e3)},null,2),r=await b({schemaName:"job_completion_and_brief",schema:Ia,model:await xe(),reasoningEffort:"low",systemPrompt:Aa,userPrompt:i,parse:u=>JSON.parse(u)}),o=Ct(e,r,n,s),c={language:{postingLanguages:r.postingLanguages,requirements:r.languageRequirements},keywords:re(r.keywords,o),contact:null};return{job:o,brief:c}}const Ca=`You are editing an existing cover letter draft on the applicant's
instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the
  letter the instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements
  that aren't already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the
  instruction explicitly asks to change it.
- Output plain prose paragraphs, no markdown headers.
- Don't introduce AI-slop while editing, and clean it from any sentence you
  touch.

${I}`;async function Oa(e,t,a){const n=JSON.stringify({draft:e,instructions:t,job:a},null,2),s=await b({schemaName:"cover_letter_revision",schema:se,model:await Ot(),systemPrompt:Ca,userPrompt:n,parse:i=>JSON.parse(i)});return S(s.content)}const Ra=`You are editing an existing outreach message (an email or LinkedIn note
to a recruiter/hiring contact) on the applicant's instructions.

Ground rules:
- Apply ONLY the change the applicant asked for. Do not rewrite parts of the message the
  instruction didn't touch.
- Never invent experience, technologies, companies, education, or achievements that aren't
  already in the draft or the job context provided.
- Keep the same language the draft is currently written in unless the instruction explicitly
  asks to change it.
- If the draft's "subject" is null, keep it null (it's a LinkedIn note). Otherwise keep a
  specific subject line, changing it only if the instruction (or the edit) requires it.
- Don't introduce AI-slop while editing, and clean it from any sentence you touch.

${I}`;async function Pa(e,t,a){const n=JSON.stringify({draft:e,instructions:t,job:a},null,2),s=await b({schemaName:"outreach_message_revision",schema:He,model:await Pe(),systemPrompt:Ra,userPrompt:n,parse:i=>JSON.parse(i)});return{subject:e.subject===null?null:Ke(s.subject||e.subject,a),body:S(s.body)}}const xa=`You translate a cover letter for the applicant's own understanding —
not for submission. Translate faithfully, preserve paragraph breaks, and keep
names, companies, and technical terms as-is where translating them would be
unnatural. Do not use em dashes ("—"); use commas or periods. Output plain
prose paragraphs, no markdown headers, no notes about the translation itself.`;async function Na(e,t){const a=JSON.stringify({content:e,targetLanguage:t},null,2),n=await b({schemaName:"cover_letter_translation",schema:se,systemPrompt:xa,userPrompt:a,parse:s=>JSON.parse(s)});return S(n.content)}const de=new RegExp([String.raw`(?:additional|further|other|more|extra|supplementary)\s+(?:information|info|details|comments?|remarks?|notes?|thoughts)`,String.raw`anything\s+else`,String.raw`is\s+there\s+anything(?:\s+else)?`,String.raw`any(?:thing)?\s+(?:other|further|additional|final)\s+(?:comments?|remarks?|notes?|information|thoughts)`,String.raw`(?:any|final)\s+(?:comments?|remarks?|notes?|thoughts)`,String.raw`(?:a\s+)?(?:message|note)\s+(?:to|for)\s+(?:the\s+|our\s+)?(?:hiring\s+(?:team|manager)|recruit(?:er|ing\s+team|ment\s+team)|team|us|company|employer)`,String.raw`(?:weitere|zus[aä]tzliche|sonstige|erg[aä]nzende|andere)\s+(?:informationen|infos?|angaben|anmerkungen|hinweise|bemerkungen|mitteilungen|kommentare)`,String.raw`sonstiges`,String.raw`(?:m[oö]chten|willst|m[oö]chtest)\s+(?:sie|du)\s+uns\s+(?:sonst\s+)?noch\s+(?:etwas|was)`,String.raw`gibt\s+es\s+(?:sonst\s+)?noch\s+(?:etwas|was)`,String.raw`(?:nachricht|mitteilung)\s+an\s+(?:uns|das\s+team|den\s+recruiter|die\s+personalabteilung)`,String.raw`informations?\s+compl[ée]mentaires?`,String.raw`informaci[oó]n\s+adicional`,String.raw`дополнительн(?:ая|ые)\s+(?:информация|сведения|комментари[йи])`].join("|"),"iu"),Ma=/^(?:your\s+|ihre?\s+|deine?\s+|persönliche\s+)?(?:messages?|comments?|remarks?|notes?|nachricht|anmerkungen?|bemerkungen?|kommentare?|hinweise?|mitteilung|commentaires?|comentarios?|комментари[йи]|сообщение)$/iu,ja=/^(?:your\s+|ihr\s+)?(?:cover\s+letter|motivation(?:al)?\s+letter|anschreiben|motivationsschreiben|lettre\s+de\s+motivation|carta\s+de\s+presentaci[oó]n|сопроводительное\s+письмо)$/iu,$a=new RegExp(String.raw`\b(?:optional|freiwillig|facultatif|opcional|необязательно|please|bitte|here|hier|you|you'?d|would|like|to|share|add|tell|let|us|know|mention|with|about|yourself|we|should|that|the|a|an|and|or|for|me|your|our|any|on|in|of|this|application|role|position|job|team|hiring|sie|du|uns|noch|etwas|was|mitteilen|teilen|sagen|zu|ihrer|ihre|deiner|bewerbung|stelle|möchten|möchtest|gibt|es|sonst|und|oder|für|die|der|das|den|dem|an|mit|über|is|there|else|do|have|want|wish|feel|free|e\.?\s?g\.?|z\.?\s?b\.?)\b`,"giu");function Ua(e){return e.replace(/[*✱:?!.…]+/g," ").replace(/\((?:optional|freiwillig|facultatif|opcional|необязательно)\)/giu," ").replace(/\s+/g," ").trim()}function qa(e,t){return e.replace(t," ").replace(/[()[\],;/\-–—"'„“”]+/g," ").replace($a," ").split(/\s+/).filter(n=>new RegExp("\\p{L}{2}","u").test(n))}function Fa(e){const t=Ua(e);return t?ja.test(t)?"coverLetter":Ma.test(t)?"weak":new RegExp(de.source,"giu").test(t)?qa(t,new RegExp(de.source,"giu")).length>=3?null:"strong":null:null}const Da=[/\b(?:please|kindly)\b[^.!?\n]{0,100}\b(?:mention|include|state|indicate|tell\s+us|let\s+us\s+know|add|note|specify|quote|answer)\b[^.!?\n]{0,100}\b(?:application|cover\s+letter|message|submission)\b[^.!?\n]*/iu,/\bin\s+your\s+(?:application|cover\s+letter|message)\b[^.!?\n]{0,100}\b(?:mention|include|state|tell\s+us|let\s+us\s+know|answer|describe)\b[^.!?\n]*/iu,/\b(?:code\s?word|keyword|reference\s+(?:number|code)|kennwort|kennziffer|referenznummer|stichwort)\b[^.!?\n]*/iu,/\b(?:geben|nennen|teilen|erw[aä]hnen|beantworten)\s+sie\b[^.!?\n]{0,120}\b(?:bewerbung|anschreiben|nachricht)\b[^.!?\n]*/iu,/\bin\s+ihrer\s+bewerbung\b[^.!?\n]{0,120}\b(?:an|nennen|angeben|mitteilen|erw[aä]hnen|beantworten)\b[^.!?\n]*/iu];function he(e){const t=[e.description??"",...e.requirements??[],...e.responsibilities??[]].join(`
`);for(const a of Da){const n=a.exec(t);if(n)return n[0].trim().slice(0,300)}return null}function Ya(e,t){if(t.required===!0)return{action:"write",reason:"required",postingAsk:he(e)??void 0};const a=he(e);return a?{action:"write",reason:"posting",postingAsk:a}:t.required===!1?{action:"skip"}:{action:"write",reason:"asked"}}const Ja={type:"object",additionalProperties:!1,required:["skip","answer"],properties:{skip:{type:"boolean"},answer:{type:"string"}}},Ba=`You decide what, if anything, goes into the open catch-all field at the end of a
job application form ("Additional information", "Anything else you'd like to share?", "Weitere
Informationen", "Sonstiges", "Message to the hiring team"). The recruiter already has everything
in "formValues", "otherAnswers", the attached CV ("cvText"), the cover letter ("coverLetter") and
the profile. Repeating any of it wastes their time and makes the application look padded.

Rules:
- "skip": true, "answer": "" is the normal result. Choose it whenever there is nothing NEW and
  relevant to add. An empty field is fine.
- Never repeat or paraphrase: contact data (name, email, phone, address, city), links (LinkedIn,
  GitHub, portfolio, website), salary expectations, start date / notice period / availability,
  work permit / visa / relocation, language levels, a summary of the CV or the experience, or the
  motivation already given in the cover letter or other answers.
- "postingAsk" (when present) is what the job posting explicitly asks applicants to include.
  Answer exactly that, from the applicant's data, if it isn't already in the form. If the data
  doesn't have it, skip.
- "required": true means the form won't submit with the field empty. Then don't skip: write ONE
  short sentence with something new from the Personal Legend or custom fields, or, if there is
  truly nothing new, one plain neutral sentence (e.g. that you look forward to hearing from them).
- Otherwise ("required" false or unknown), write only when there is a genuinely new, relevant fact
  (e.g. a constraint the recruiter must know that appears nowhere else).
- At most 2 sentences, plain text, no greeting, no sign-off, no lists, no markdown.
- Never invent facts. Use ONLY the applicant data given.
- If "postingLanguage" is given, write in that language with its native application register.

${I}`,Va=/\b(?:https?:\/\/|www\.)\S+|\b[\w.-]+\.(?:com|de|io|dev|net|org|me)\/\S*/i,Ga=/\b[\w.+-]+@[\w-]+\.[\w.-]+\b/,Ha=/(?:\+|\b00)\d[\d\s/().-]{6,}\d|\b0\d{2,4}[\s/-]?\d{3,}[\s-]?\d{2,}\b/;function Ka(e){return e.replace(/\s+/g," ").trim().split(new RegExp("(?<=[.!?])\\s+(?=\\S)","u")).filter(a=>a&&!Va.test(a)&&!Ga.test(a)&&!Ha.test(a)).slice(0,2).join(" ").trim()}const Xe="catchAllAdds";function Wa(e){return{type:"predicate",name:Xe,instructions:`The application form has an open catch-all field ("field"), not marked required: "Additional information", "Anything else?".
The recruiter already has the applicant's CV, cover letter, profile and every value in "formValues"
and "otherAnswers". Should the applicant write anything in it?
- Yes only if ${e?`the applicant's data covers what the posting explicitly asks applicants to include ("postingAsk") and the form doesn't already hold it, or if `:""}the applicant's data holds a genuinely NEW fact relevant to this application that appears nowhere else (e.g. a constraint the recruiter must know).
- No for anything already in the CV, cover letter, profile or form: contact data, links, salary, start date /
  notice period / availability, work permit / visa / relocation, language levels, a summary of the
  experience, the motivation.
- No when in doubt: an empty field is the normal, good outcome.`}}async function za(e,t,a,n){try{const s=[...e.input,{role:"user",content:[{type:"input_json",data:{formValues:(a.formValues??[]).filter(r=>r.value.trim()),otherAnswers:(a.otherAnswers??[]).filter(r=>r.answer.trim()),coverLetterAttached:a.coverLetterAttached||void 0,postingAsk:n??null,field:t}}]}],i=await M({input:s,promptCacheKey:e.promptCacheKey,questions:[Wa(n)]});return Rt(i,Xe)}catch(s){if(s instanceof q)throw s;return console.warn("[Filler] Decisions API failed, writing the catch-all via Responses:",s),null}}async function Ze(e,t,a,n){const s=Ya(t,a);if(s.action==="skip")return{answer:"",sufficientInfo:!0,skipped:!0};const[i,r]=await Promise.all([v(),C("lastCoverLetter")]);if(a.required!==!0){const l=ne(i,r??"",t,n),f=await za(l,e,a,s.postingAsk);if(f!==null&&f<U.catchAllWrite)return{answer:"",sufficientInfo:!0,skipped:!0}}const o=JSON.stringify({job:t,profile:i.profile,cvText:i.cvText,coverLetter:r??"",coverLetterAttached:a.coverLetterAttached||void 0,personalLegend:i.personalLegend,customFields:i.customFields,languageLevels:i.languageLevels,generationRules:i.generationRules,postingLanguage:n||void 0,formValues:(a.formValues??[]).filter(l=>l.value.trim()),otherAnswers:(a.otherAnswers??[]).filter(l=>l.answer.trim()),postingAsk:s.postingAsk,required:a.required??"unknown",question:e},null,2),c=await b({schemaName:"catch_all_answer",schema:Ja,systemPrompt:Ba,userPrompt:o,label:"Catch-all answer",parse:l=>JSON.parse(l)}),u=c.skip?"":Ka(S(c.answer));return u?{answer:u,sufficientInfo:!0,skipped:!1}:{answer:"",sufficientInfo:a.required!==!0,skipped:!0}}const Qa={type:"object",additionalProperties:!1,required:["answer","sufficientInfo"],properties:{answer:{type:"string"},sufficientInfo:{type:"boolean"}}},fe=`You answer a custom question from a job application form on the
applicant's behalf.

Ground rules:
- Use ONLY facts present in the provided profile, CV text, Personal Legend,
  cover letter, custom fields, language levels, and job posting. Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, the
  "languageLevels" list is the authoritative answer (CEFR levels the
  applicant self-reported in Settings) — use it directly rather than
  guessing from the CV or defaulting to a low/neutral level.
- If the profile/CV/Personal Legend/etc genuinely lack what's needed to
  answer this question — not just a minor detail, but the actual substance
  being asked for — set "sufficientInfo" to false and "answer" to an empty
  string. Do NOT write a sentence explaining that you don't have the
  information (e.g. "I don't have this information available") — that text
  would otherwise get typed straight into the applicant's form field, which
  is worse than leaving it blank for the applicant to fill in themselves.
  Only do this when the information is truly absent; a question you can
  answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient —
  set sufficientInfo to true and give that honest answer.
- If "postingLanguage" is given, write the answer in that language, using
  the salutation/register conventions native speakers of it would expect on
  a job application (e.g. formal "Sie"/"Herr"/"Frau" address in German, not
  a literal English-to-German translation) — unless the question itself, or
  "generationRules", explicitly asks for a different language.
- If this question is a newsletter, marketing-email, or job-alert
  subscription opt-in phrased as a choice (e.g. "Would you like to
  subscribe to our newsletter? Yes/No"), always choose the option that
  declines it — the applicant never needs this to submit the application.
- "faq" is a set of pre-written answers to standard interview-FAQ questions
  (spec_5 section B). If the question being asked now is the same as, or a
  close variant of, one already in "faq", reuse its substance and phrasing —
  adapt only what the target field's length/format actually requires — so
  the applicant's answer stays consistent across different forms rather
  than being re-derived from scratch each time.
- Match the question's expected length: a short field gets a short answer, an
  open-ended "tell us about..." field gets a fuller one.
- If "generationRules" contains applicant-specified instructions for how
  their text should be written (tone, things to include/avoid), follow them
  as long as they don't conflict with the Ground rules above.
- Output plain text, no markdown, no restating the question.

${I}`,Xa=/\b(?:please\s+(?:provide|specify|clarify)|could\s+you\s+(?:please\s+)?(?:provide|clarify|specify)|i\s+(?:don'?t|do\s+not)\s+see)\b.{0,40}?\b(?:question|prompt)\b|\bno\s+(?:specific\s+)?question\s+(?:was|is)?\s*(?:provided|given|specified|attached)\b/i;function et(e){const t=e.trim();return t?t.length<220&&Xa.test(t):!0}const Za=`
- This is a MULTIPLE-CHOICE question: "options" lists the allowed answers.
  Reply with EXACTLY ONE option, copied verbatim, and nothing else.
- Base the choice on the applicant's profile/CV/Personal Legend. If the
  needed fact is genuinely absent (e.g. pronouns not stated anywhere),
  prefer a neutral option, an explicit "prefer not to say", or the option
  that commits the applicant least.`,es=`
- This is a SELECT-ALL-THAT-APPLY question: "options" lists every allowed
  answer. Reply with every option that genuinely applies, each copied
  verbatim, joined by " | " (a single pipe surrounded by one space on each
  side) — nothing else. If none apply, reply with an empty string.
- Base each choice strictly on the applicant's profile/CV/Personal Legend —
  never include an option just because it's plausible or common; only ones
  the applicant's own material actually supports.`,ts=`
- This field only accepts a plain number: reply with digits only (a single
  "." for a decimal if needed) — no currency symbol, no thousands
  separator, no unit, no words, no range. If a range genuinely fits best
  (e.g. a salary expectation given as "65-75k"), reply with one
  representative figure (its midpoint), not the range.`;function ns(e){return`
- This field only accepts a date in the exact format "${qe[e]}"
  — reply with ONLY that value, nothing else (no words, no explanation).
  "todayISO" in the data below is today's date: compute the answer from it
  — e.g. "available with one month's notice" → todayISO plus one month;
  "immediately" / "as soon as possible" / no stated constraint → todayISO
  itself. Never answer with a description of the notice period or
  availability instead of the date itself.`}async function as(e,t,a,n,s,i,r,o){if(!(a&&a.length>0)&&!n&&!s&&(o||o===void 0&&Fa(e)==="strong"))return Ze(e,t,o??{},r);const[u,l]=await Promise.all([v(),C("lastCoverLetter")]),{input:f,promptCacheKey:h}=ne(u,l??"",t,r),g={question:e,options:a,multi:i,numeric:n,dateKind:s},m=z(g);try{const y=await M({input:f,promptCacheKey:h,questions:m?Me(g,0):[je(g,0)]});if(m){const d=$e(g,0,y);if(d)return d}else if(Ue(0,y)===!1)return{answer:"",sufficientInfo:!1}}catch(y){if(y instanceof q)throw y;console.warn("[Filler] Decisions API failed, answering via Responses:",y)}return ss(e,t,a,n,s,i,r)}async function ss(e,t,a,n,s,i,r){const[o,c]=await Promise.all([v(),C("lastCoverLetter")]),u=JSON.stringify({job:t,profile:o.profile,cvText:o.cvText,personalLegend:o.personalLegend,generationRules:o.generationRules,coverLetter:c??"",languageLevels:o.languageLevels,customFields:o.customFields,faq:o.faq.filter(g=>g.answer.trim()),todayISO:te(),postingLanguage:r||void 0,question:e,options:a&&a.length>0?a:void 0},null,2),l=[a&&a.length>0?i?es:Za:"",n?ts:"",s?ns(s):""].filter(Boolean),f=await b({schemaName:"custom_question_answer",schema:Qa,systemPrompt:l.length>0?[fe,...l].join(`
`):fe,userPrompt:u,parse:g=>JSON.parse(g)});return!f.sufficientInfo||et(f.answer)?{answer:"",sufficientInfo:f.sufficientInfo}:{answer:a&&a.length>0||n||!!s?f.answer:S(f.answer),sufficientInfo:!0}}const is={type:"object",additionalProperties:!1,required:["questions"],properties:{questions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","question"],properties:{index:{type:"integer"},question:{type:"string"}}}}}},rs=`You are given a block of a job-application form: its visible text, and a
list of the input fields inside it. For each field that asks the applicant
something, return the question it is asking, phrased as a plain question.

Rules:
- Use ONLY the visible text provided. Never invent a question.
- Match each question to its field by "index".
- Omit a field that is not a real question (layout helper, hidden field,
  search box, honeypot, a plain "First name"-style profile field).
- A field with "options" is a multiple-choice question — still return only
  its question text, not the options.
- Output the question text only — no numbering, no "Question:" prefix.
- Questions may be in any language; keep the form's own language.`;async function os(e,t){if(t.length===0)return{};const a=JSON.stringify({blockText:e.slice(0,6e3),fields:t},null,2),n=await b({schemaName:"block_questions",schema:is,systemPrompt:rs,userPrompt:a,parse:i=>JSON.parse(i)}),s={};for(const i of n.questions)i.question.trim()&&(s[i.index]=i.question.trim());return s}const cs={type:"object",additionalProperties:!1,required:["checkboxDecisions","questionAnswers"],properties:{checkboxDecisions:{type:"array",items:{type:"object",additionalProperties:!1,required:["index","check","category","reason"],properties:{index:{type:"integer"},check:{type:"boolean"},category:{type:"string",enum:["required-consent","marketing","optional","unclear"]},reason:{type:"string"}}}},questionAnswers:{type:"array",items:{type:"object",additionalProperties:!1,required:["id","answer","sufficientInfo"],properties:{id:{type:"string"},answer:{type:"string"},sufficientInfo:{type:"boolean"}}}}}},ls=`You fill in two independent things found on a job-application form at once:
consent checkboxes to decide, and custom questions to answer on the applicant's behalf. The
applicant has already chosen to submit this application.

CHECKBOXES (one decision per item in "checkboxes", matched back by "index")

TICK (check: true) — things required to submit, or that a candidate is normally expected to
accept:
- privacy policy / data protection / GDPR / Datenschutz consent
- terms & conditions / AGB / Nutzungsbedingungen
- confirming the entered information is accurate / truthful
- consent to process and store the application data for THIS hiring process
- storing the data in a talent pool ONLY when the checkbox is marked required
- eligibility self-declarations that hold for any ordinary adult applying for a real job (e.g.
  "I am at least 18 years old", "I am legally entitled to work in [country]", "I have no
  undisclosed conflicts of interest") — assume true unless the profile/CV explicitly states
  otherwise; a genuine job applicant submitting this form is virtually always eligible, and
  leaving a required declaration like this unticked blocks submission for no real reason

DO NOT TICK (check: false) — optional and promotional:
- newsletters, marketing e-mails, "career news", event invitations
- job alerts / notifications about new postings (e.g. "Benachrichtigungen über neue
  Stellenausschreibungen erhalten")
- sharing data with third parties / partner companies for marketing
- joining a talent pool / candidate database when NOT required
- anything that benefits the applicant only beyond this one application

Rules:
- "required: true" means the form marks the field mandatory — a strong signal to tick, unless
  the text is clearly marketing.
- A newsletter/marketing-email/job-alert opt-in is NEVER ticked, even when the form marks it
  "required" — that flag is routinely misused by forms to guilt-trip applicants into
  subscribing, even though applicants never actually need it to submit. When genuinely in doubt
  whether a required checkbox is a real submission requirement or a disguised newsletter
  opt-in, prefer NOT ticking it.
- If a checkbox is ambiguous AND not required, set check: false.
- Labels may be in any language; judge by meaning, not keywords.
- category: "required-consent" (ticked, mandatory-type), "marketing" (left off), "optional"
  (non-marketing but skippable, left off unless required), "unclear" (left off). reason: one
  short phrase.
- Return one decision per input item in "checkboxes", using its "index". If "checkboxes" is
  empty, return an empty array.

QUESTIONS (one answer per item in "questions", matched back by "id")

Ground rules:
- Use ONLY facts present in the shared "profile"/"cvText"/"personalLegend"/"generationRules"/
  "coverLetter"/"languageLevels"/"customFields"/"faq" given below, plus "job". Never invent
  experience, technologies, companies, education, or achievements.
- For any question about the applicant's proficiency in a language, "languageLevels" is the
  authoritative answer (CEFR levels the applicant self-reported in Settings) — use it directly
  rather than guessing from the CV or defaulting to a low/neutral level.
- If the shared material genuinely lacks what's needed to answer a given question — not just a
  minor detail, but the actual substance being asked for — set that item's "sufficientInfo" to
  false and "answer" to an empty string. Do NOT write a sentence explaining that you don't have
  the information — that text would otherwise get typed straight into the applicant's form
  field, which is worse than leaving it blank. Only do this when the information is truly
  absent; a question you can answer honestly with what IS available (e.g. "I don't have direct
  experience with X, but I've worked with Y") still counts as sufficient.
- If "postingLanguage" is given, write answers in that language, using the salutation/register
  conventions native speakers of it would expect on a job application (e.g. formal
  "Sie"/"Herr"/"Frau" address in German) — unless the question itself, or "generationRules",
  explicitly asks for a different language.
- A newsletter/marketing-email/job-alert subscription opt-in phrased as a question (e.g. "Would
  you like to subscribe to our newsletter? Yes/No") always gets the option that declines it.
- "faq" is a set of pre-written answers to standard interview-FAQ questions. If a question being
  asked now is the same as, or a close variant of, one already in "faq", reuse its substance and
  phrasing — adapt only what the target field's length/format actually requires.
- Match each question's expected length: a short field gets a short answer, an open-ended
  "tell us about..." field gets a fuller one.
- Output plain text per answer, no markdown, no restating the question.
- Each item in "questions" may also carry:
  - "options" (and not "multi"): a single-choice question — reply with EXACTLY ONE option,
    copied verbatim, nothing else. If the needed fact is genuinely absent (e.g. pronouns not
    stated anywhere), prefer a neutral option or an explicit "prefer not to say".
  - "options" with "multi": true: a select-all-that-apply question — reply with every option
    that genuinely applies, each copied verbatim, joined by " | " (one pipe, one space each
    side). If none apply, reply with an empty string. Never include an option just because it's
    plausible — only ones the applicant's own material actually supports.
  - "numeric": true: the field only accepts a plain number — reply with digits only (a single
    "." for a decimal if needed), no currency symbol, no thousands separator, no unit, no words,
    no range. If a range genuinely fits best (e.g. "65-75k"), reply with one representative
    figure (its midpoint).
  - "dateFormat": the field only accepts a date in exactly that format — reply with ONLY that
    value, nothing else. "todayISO" below is today's date: compute the answer from it — e.g.
    "available with one month's notice" -> todayISO plus one month; "immediately"/"as soon as
    possible"/no stated constraint -> todayISO itself.
- Return one answer per input item in "questions", using its "id". If "questions" is empty,
  return an empty array.

${I}`;function us(e,t){const a=new Map;for(const n of t)a.set(n.index,n);return e.map((n,s)=>{const i=a.get(s);if(i){const r=i.check&&ce(n.label)?!1:i.check;return{name:n.name,label:n.label,check:r,category:i.category,reason:i.reason}}return ce(n.label)?{name:n.name,label:n.label,check:!1,category:"marketing",reason:"No decision returned — looks like a newsletter/marketing opt-in"}:{name:n.name,label:n.label,check:n.required,category:n.required?"required-consent":"unclear",reason:n.required?"Marked required by the form":"No decision returned"}})}function ps(e,t){const a=new Map;for(const n of t)a.set(n.id,n);return e.map(n=>{const s=a.get(n.id);if(!s)return{id:n.id,answer:"",sufficientInfo:!0};if(!s.sufficientInfo||et(s.answer))return{id:n.id,answer:"",sufficientInfo:s.sufficientInfo};const i=n.options&&n.options.length>0||n.numeric||!!n.dateKind;return{id:n.id,answer:i?s.answer:S(s.answer),sufficientInfo:!0}})}async function ge(e,t,a,n){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[s,i]=await Promise.all([v(),C("lastCoverLetter")]),r=JSON.stringify({job:a,profile:s.profile,cvText:s.cvText,personalLegend:s.personalLegend,generationRules:s.generationRules,coverLetter:i??"",languageLevels:s.languageLevels,customFields:s.customFields,faq:s.faq.filter(c=>c.answer.trim()),todayISO:te(),postingLanguage:n||void 0,checkboxes:e.map((c,u)=>({index:u,label:c.label,required:c.required,currentlyChecked:c.checked})),questions:t.map(c=>({id:c.id,question:c.question,options:c.options&&c.options.length>0?c.options:void 0,multi:c.multi,numeric:c.numeric,dateFormat:c.dateKind?qe[c.dateKind]:void 0}))},null,2),o=await b({schemaName:"page_content_decisions",schema:cs,systemPrompt:ls,userPrompt:r,parse:c=>JSON.parse(c)});return{checkboxDecisions:us(e,o.checkboxDecisions),questionAnswers:ps(t,o.questionAnswers)}}async function ds(e,t,a,n){const s=t.filter(l=>l.catchAll),i=s.length>0?t.filter(l=>!l.catchAll):t,r=await hs(e,i,a,n);if(s.length===0)return r;const o=i.flatMap(l=>{var h;const f=((h=r.questionAnswers.find(g=>g.id===l.id))==null?void 0:h.answer)??"";return f?[{question:l.question,answer:f}]:[]}),c=await Promise.all(s.map(async l=>{const{answer:f,sufficientInfo:h}=await Ze(l.question,a,{required:l.required??!1,formValues:l.formValues,otherAnswers:o,coverLetterAttached:l.coverLetterAttached},n);return{id:l.id,answer:f,sufficientInfo:h}})),u=new Map([...r.questionAnswers,...c].map(l=>[l.id,l]));return{checkboxDecisions:r.checkboxDecisions,questionAnswers:t.map(l=>u.get(l.id)??{id:l.id,answer:"",sufficientInfo:!0})}}async function hs(e,t,a,n){if(e.length===0&&t.length===0)return{checkboxDecisions:[],questionAnswers:[]};const[s,i]=await Promise.all([v(),C("lastCoverLetter")]),{input:r,promptCacheKey:o}=ne(s,i??"",a,n),c=t.map((d,p)=>({q:d,i:p})),u=c.filter(({q:d})=>z(d)),l=c.filter(({q:d})=>!z(d));let f;try{f=await M({input:r,promptCacheKey:o,questions:[...Pt(e),...u.flatMap(({q:d,i:p})=>Me(d,p)),...l.map(({q:d,i:p})=>je(d,p))]})}catch(d){if(d instanceof q)throw d;return console.warn("[Filler] Decisions API failed, falling back to Responses:",d),ge(e,t,a,n)}const h=e.map((d,p)=>xt(d,p,f)),g=e.filter((d,p)=>!h[p]),m=new Map,y=[];for(const{q:d,i:p}of u){const w=$e(d,p,f);w?m.set(d.id,{id:d.id,...w}):y.push(d)}for(const{q:d,i:p}of l)Ue(p,f)===!1?m.set(d.id,{id:d.id,answer:"",sufficientInfo:!1}):y.push(d);if(g.length>0||y.length>0){const d=await ge(g,y,a,n);for(const w of d.questionAnswers)m.set(w.id,w);const p=new Map(d.checkboxDecisions.map(w=>[w.name+"\0"+w.label,w]));e.forEach((w,k)=>{h[k]||(h[k]=p.get(w.name+"\0"+w.label)??null)})}return{checkboxDecisions:h.filter(d=>d!==null),questionAnswers:t.map(d=>m.get(d.id)??{id:d.id,answer:"",sufficientInfo:!0})}}const Z="(none of these)",tt="(not a profile field)",nt={salutation:"Salutation / title / gender as a form of address (Mr, Ms, Frau, Herr).",pronouns:"Preferred pronouns (she/her, he/him).",firstName:"The applicant's first / given name only.",lastName:"The applicant's last / family name only.",fullName:"The applicant's full name in one box.",email:"The applicant's e-mail address.",phone:"The applicant's phone / mobile number.",address:"Street and house number.",city:"City / town the applicant lives in.",postalCode:"Postal / ZIP code.",country:"Country the applicant lives in (not nationality, not where they want to work).",linkedin:"LinkedIn profile URL.",github:"GitHub profile URL.",website:"Personal website or portfolio URL.",expectedSalary:"The applicant's salary expectation as an amount (not a currency or period picker)."},fs=[...Object.entries(nt).map(([e,t])=>({value:e,description:t})),{value:tt,description:"Anything else: an application question, a date, a company, a job title, a free comment, or a field about somebody else (a referrer, a reference, an emergency contact)."}],gs=`You help autofill a job-application form from the applicant's saved profile.
Two kinds of questions follow, each about one field of the form and independent of the others:
- Option questions: the field must be set to a value the applicant already gave, but its options word it differently
  (another language, an official name, a region added, an amount written as a range). Pick the option that means
  the same thing — the same country, the same city, the range containing the amount. When no option does, pick
  "${Z}"; never pick a merely similar one.
- Field questions: from what the page says about a field (label, name, placeholder…), which profile value does it ask
  for? Only the applicant's own data counts; when unsure, "${tt}".
Labels may be in any language: judge by meaning.`;function ms(e){var a,n;return[`label "${e.label}"`,`type ${e.kind}`,e.name&&`name "${e.name}"`,e.id&&`id "${e.id}"`,e.placeholder&&`placeholder "${e.placeholder}"`,e.ariaLabel&&`aria-label "${e.ariaLabel}"`,e.autocomplete&&`autocomplete "${e.autocomplete}"`,((a=e.other)==null?void 0:a.length)&&`nearby text ${e.other.map(s=>`"${s}"`).join(", ")}`,((n=e.options)==null?void 0:n.length)&&`options ${e.options.map(s=>`"${s}"`).join(", ")}`].filter(Boolean).join("; ")}function ys(e){return{type:"choice",name:e.id,instructions:`Form field labelled "${e.label}" (the applicant's ${e.field}). The applicant's value: "${e.value}". Which option is that value?`,choices:[...new Set(e.options)].filter(t=>t!==Z).map(t=>({value:t})).concat({value:Z})}}function ws(e){return[...e.optionPicks.filter(t=>t.options.length>0).map(ys),...e.fieldKinds.map(t=>({type:"choice",name:t.id,instructions:`A form field with ${ms(t.signals)}. Which of the applicant's profile values does it ask for?`,choices:fs}))]}function bs(e,t){return{optionPicks:e.optionPicks.filter(a=>t.has(a.id)).map(a=>{const n=D(t,a.id),s=n&&n.confidence>=U.optionMatch&&a.options.includes(n.choice);return{id:a.id,choice:s?n.choice:null}}),fieldKinds:e.fieldKinds.filter(a=>t.has(a.id)).map(a=>{const n=D(t,a.id),s=n&&n.confidence>=U.profileField&&n.choice in nt;return{id:a.id,field:s?n.choice:null}})}}async function vs(e){const t=ws(e);if(t.length===0)return{optionPicks:[],fieldKinds:[]};const a=await M({input:gs,questions:t,promptCacheKey:"filler-field-decisions"});return bs(e,a)}const Es={type:"object",additionalProperties:!1,required:["postingLanguages","requirements","keywords","contact"],properties:{postingLanguages:{type:"array",items:{type:"string"}},requirements:{type:"array",items:{type:"object",additionalProperties:!1,required:["language","level"],properties:{language:{type:"string"},level:{type:["string","null"],enum:[...Ne,null]}}}},keywords:We,contact:{type:["string","null"]}}},Ss=`You read a job posting and report three independent things about it: its
language, the skills it asks for (keywords), and (only if asked below) a recruiter/hiring
contact. Judge language and keywords against the applicant profile/CV/Personal Legend given
below.

LANGUAGE
- postingLanguages: the language(s) the posting text itself is written in (e.g. "English").
- requirements: any language the posting explicitly asks the applicant to know or be
  proficient in, with a level. Map loose phrasing to the nearest CEFR level (A1-C2, or
  "Native" for "native speaker"/"muttersprachlich") when you reasonably can — e.g. "fluent",
  "professional working proficiency" -> "C1"; "conversational" -> "B1". If a language is
  mentioned but no level can be reasonably inferred, set level to null. Do not invent a
  requirement that isn't stated in the text. If nothing is stated, return an empty array.

${ie("the posting text (job title, description, requirements, responsibilities)")}

CONTACT
- "job.contact" below is the recruiter/hiring contact already found elsewhere, or null if none
  was found yet.
- If it is already set (not null), ignore this entirely and return "contact": null — there is
  nothing to add.
- If it is null, look for one in the job's own text (description/requirements/responsibilities):
  a named recruiter/hiring manager's email address, or a LinkedIn profile/company URL. If you
  find one, copy it VERBATIM (exact characters) so it can be re-found on the page for
  highlighting — the same rule as for keywords. If none is mentioned, return "contact": null.`;async function ks(e){const t=await v(),a=JSON.stringify({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,job:e},null,2),n=await b({schemaName:"job_brief",schema:Es,model:await Re(),systemPrompt:Ss,userPrompt:a,parse:s=>JSON.parse(s)});return{language:{postingLanguages:n.postingLanguages,requirements:n.requirements},keywords:re(n.keywords,e),contact:n.contact}}const Ls={type:"object",additionalProperties:!1,required:["cvId","reason"],properties:{cvId:{type:"string"},reason:{type:"string"}}},Ts=`You pick which of an applicant's CVs to send to one job posting.
Each CV has an id, a name, the language it's written in, the applicant's own rules for which
postings it's for, and the start of its text.
- Prefer a CV written in the posting's language; if none, an English one.
- Then follow the applicant's rules: the CV whose rules fit this posting best.
- Then the one marked default for that language.
Return the chosen CV's exact "id" and a reason of at most 10 words. Plain text, no em dashes.`;async function Is(e,t,a){if(t.length<2)return null;const n=t.map((s,i)=>`cv${i+1}`);try{const s=await M({input:[{role:"user",content:[{type:"input_text",text:"A job posting the applicant is applying to:"},{type:"input_json",data:{position:e.position,company:e.company,location:e.location,language:a??null,techStack:e.techStack,description:e.description.slice(0,4e3)}}]}],questions:[{type:"choice",name:"cv",instructions:"Which of the applicant's CVs should be sent to this posting? Prefer a CV written in the posting's language (else an English one), then the one whose rules fit the posting best, then the one marked default for that language.",choices:t.map((o,c)=>({value:n[c],description:As(o)}))}]}),i=D(s,"cv"),r=i?n.indexOf(i.choice):-1;return!i||r<0||i.confidence<U.cvChoice?null:{cvId:t[r].id,reason:"",source:"ai",confidence:i.confidence}}catch(s){if(s instanceof q)throw s;return console.warn("[Filler] Decisions API failed, choosing the CV via Responses:",s),_s(e,t,a)}}function As(e){var t;return[`Name: ${Fe(e)}.`,`Language: ${e.language?De(e.language):"not set"}${e.isDefaultForLanguage?" (default CV for that language)":""}.`,(t=e.rules)!=null&&t.trim()?`Applicant's rules for it: ${e.rules.trim()}`:"",`Starts: ${e.text.slice(0,600).replace(/\s+/g," ")}`].filter(Boolean).join(" ")}async function _s(e,t,a){if(t.length<2)return null;const n={posting:{position:e.position,company:e.company,location:e.location,language:a??null,techStack:e.techStack,description:e.description.slice(0,4e3)},cvs:t.map(i=>({id:i.id,name:Fe(i),language:i.language?De(i.language):null,defaultForLanguage:!!i.isDefaultForLanguage,rules:i.rules??"",textStart:i.text.slice(0,1200)}))},s=await b({schemaName:"cv_choice",schema:Ls,model:await Ye(),reasoningEffort:"low",systemPrompt:Ts,userPrompt:JSON.stringify(n,null,2),parse:i=>JSON.parse(i)});return t.some(i=>i.id===s.cvId)?{cvId:s.cvId,reason:s.reason.replace(/—/g,",").trim()||"AI pick",source:"ai"}:null}const Cs={type:"object",additionalProperties:!1,required:["values"],properties:{values:{type:"array",items:{type:"object",additionalProperties:!1,required:["name","value","reason"],properties:{name:{type:"string"},value:{type:"string"},reason:{type:"string"}}}}}},Os=`You adapt an applicant's CV template to one specific job posting by
choosing a value for each {{placeholder}} in it.

Each variable comes with:
- "description": the applicant's own instruction for what the placeholder means and
  how to choose it. Follow it.
- "mode": "choice" means "value" MUST be exactly one of "options", copied verbatim
  (same spelling, same case, same line breaks). "free" means "options" are only
  examples of the expected shape and length; write the value that fits this posting
  in that same shape (e.g. a city name, a comma-separated list).
- "foundInPosting": options that literally occur in the posting text, most frequent
  first. A strong hint, not an order: the role's actual focus matters more than a
  passing mention.

Rules:
- Pick what makes this CV the closest honest match for this posting: its title, its
  location, its main technology, the vocabulary it uses.
- A job title / position value is the bare role name: no bracketed asides like (m/w/d),
  (f/m/d) or (Remote), no seniority level (Senior, Middle, Junior, Sr., Staff, Principal),
  no team, location or contract qualifiers. "Senior Backend Engineer (m/f/d)" -> "Backend Engineer".
- Honesty: never make the CV claim a skill, technology or experience the applicant's
  CV text / Personal Legend doesn't support, unless the variable's description
  explicitly asks for it. For list-like values, prefer terms that are both in the
  posting and supported by the applicant's background.
- Write the value in the same language as the surrounding template text.
- Return one entry per variable given, using its exact "name".
- "reason": one short sentence (max ~15 words) on why this value fits the posting.
- Plain text only, no markdown, no em dashes.`;function Rs(e,t){const a=s=>s.trim().replace(/\s+/g," ").toLowerCase(),n=a(e);return t.options.find(s=>a(s)===n)??null}async function Ps(e,t){const a=new Set(Nt(t.content)),n=t.variables.filter(u=>a.has(u.name));if(n.length===0)return[];const s=await v(),i=n.filter(u=>u.mode==="choice"&&u.options.length>=2),r=n.filter(u=>!(u.mode==="choice"&&u.options.length>0)),[o,c]=await Promise.all([i.length>0?Ns(e,t,i,s):new Map,r.length>0?st(e,t,r,s):new Map]);return n.map(u=>o.get(u.name)??c.get(u.name)??{name:u.name,value:Mt(u,e),reason:""})}const xs=`You adapt an applicant's CV template to one specific job posting: for each {{placeholder}}
pick the variant that makes this CV the closest honest match for the posting (its title, its location,
its main technology, the vocabulary it uses). Follow the applicant's own instruction for the placeholder.
Variants that literally occur in the posting are a strong hint, not an order: the role's actual focus
matters more than a passing mention. Never pick a variant that claims a skill, technology or experience
the applicant's CV text / Personal Legend doesn't support, unless the instruction explicitly asks for it.`;async function Ns(e,t,a,n){const s=r=>`o${r+1}`,i=a.map((r,o)=>{const c=Je(r.options,e).map(u=>`${s(r.options.indexOf(u))} ("${u}")`);return{type:"choice",name:`v${o}`,instructions:[`CV placeholder {{${r.name}}}. Which variant should fill it for this posting?`,r.description.trim()?`The applicant's instruction for it: ${r.description.trim()}`:"",c.length>0?`Variants found verbatim in the posting, most frequent first: ${c.join(", ")}.`:""].filter(Boolean).join(`
`),choices:r.options.map((u,l)=>({value:s(l),description:u}))}});try{const r=await M({input:[{role:"developer",content:xs},{role:"user",content:[{type:"input_json",data:{applicant:{cvText:n.cvText.slice(0,12e3),personalLegend:n.personalLegend.slice(0,8e3),city:n.profile.city,country:n.profile.country}}},{type:"input_json",data:{job:at(e)}}]}],promptCacheKey:`filler-cv-values-${jt(n.cvText+n.personalLegend)}`,questions:i}),o=new Map;return a.forEach((c,u)=>{const l=D(r,`v${u}`),f=l?c.options.findIndex((h,g)=>s(g)===l.choice):-1;!l||f<0||l.confidence<U.cvVariableChoice||o.set(c.name,{name:c.name,value:c.options[f],reason:`AI pick, ${Math.round(l.confidence*100)}% sure`})}),o}catch(r){if(r instanceof q)throw r;return console.warn("[Filler] Decisions API failed, picking CV variants via Responses:",r),st(e,t,a,n)}}function at(e){return{position:e.position,company:e.company,location:e.location,techStack:e.techStack,requirements:e.requirements,responsibilities:e.responsibilities,description:e.description.slice(0,8e3)}}async function st(e,t,a,n){const s={variables:a.map(o=>({name:o.name,mode:o.mode,description:o.description,options:o.options,foundInPosting:Je(o.options,e)})),template:t.content.slice(0,12e3),job:at(e),applicant:{cvText:n.cvText.slice(0,12e3),personalLegend:n.personalLegend.slice(0,8e3),city:n.profile.city,country:n.profile.country}},i=await b({schemaName:"cv_template_values",schema:Cs,model:await Ye(),systemPrompt:Os,userPrompt:JSON.stringify(s,null,2),parse:o=>JSON.parse(o)}),r=new Map;for(const o of a){const c=i.values.find(l=>l.name===o.name);if(!c)continue;if(o.mode==="choice"&&o.options.length>0){const l=Rs(c.value,o);l&&r.set(o.name,{name:o.name,value:l,reason:S(c.reason)});continue}const u=S(c.value);r.set(o.name,{name:o.name,value:$t(o.name)?Sa(u,e):u,reason:S(c.reason)})}return r}async function it(e){const t=await E(e);await Promise.all(t.map(a=>chrome.tabs.sendMessage(e,{type:"CANCEL_ELEMENT_PICKER",tabId:e},{frameId:a}).catch(()=>{})))}async function L(e,t,a){return(await Promise.all(t.map(s=>chrome.tabs.sendMessage(e,a,{frameId:s}).catch(()=>{})))).filter(s=>!!s)}async function me(e,t,a,n){if(a!==void 0&&t.includes(a)){const s=await chrome.tabs.sendMessage(e,n,{frameId:a}).catch(()=>{});if(s)return[s]}return L(e,t,n)}function Ms(e){const t=new Map;for(const a of e){const n=a.locator.frameId;t.set(n,[...t.get(n)??[],a])}return t}async function js(e){switch(e.type){case"FILL_STATS_REPORT":{await Vt(e.run);return}case"DECIDE_FIELDS":return{type:"FIELD_DECISIONS",result:await vs(e.request)};case"GET_PROFILE":return{type:"PROFILE_DATA",profile:await N()};case"GET_JOB":{const t=await chrome.tabs.get(e.tabId).catch(()=>{});if(!e.force&&(t!=null&&t.url)){const c=await Jt(t.url);if(c!=null&&c.position&&c.company)return{type:"JOB_DATA",job:c,sufficient:!0}}const a=await E(e.tabId),s=(await L(e.tabId,a,e)).filter(c=>c.type==="JOB_DATA");if(s.length===0)return;const i=s.find(c=>c.sufficient);if(i)return t!=null&&t.url&&Bt(t.url,i.job),i;const r=s.reduce((c,u)=>u.job.description.length>c.job.description.length?u:c),o=s.map(c=>c.visibleText??"").filter(Boolean).join(`

`).slice(0,2e4);return{type:"JOB_DATA",job:r.job,sufficient:!1,visibleText:o||r.visibleText||"",pageUrl:t==null?void 0:t.url}}case"COMPLETE_JOB":{const{job:t,brief:a}=await _a(e.job,e.text);return{type:"JOB_DATA",job:t,sufficient:!0,brief:a}}case"EXTRACT_JOB_FROM_TEXT":{const t=await chrome.tabs.get(e.tabId).catch(()=>{}),{job:a,brief:n}=await Ta(e.text,(t==null?void 0:t.url)??"");return{type:"JOB_DATA",job:a,sufficient:!0,brief:n}}case"AUTOFILL":{const t=await E(e.tabId),n=(await L(e.tabId,t,e)).filter(s=>s.type==="AUTOFILL_RESULT");return{type:"AUTOFILL_RESULT",filled:n.reduce((s,i)=>s+i.filled,0),total:n.reduce((s,i)=>s+i.total,0),generatedPassword:n.map(s=>s.generatedPassword).find(Boolean)??null}}case"GENERATE_COVER_LETTER":{const{tabId:t}=e,a=e.job.url;let n="",s=0;await F(t,{jobUrl:a,status:"generating",content:""});let i;try{i=await pa(e.job,e.postingLanguage,r=>{chrome.runtime.sendMessage({type:"COVER_LETTER_STREAM_CHUNK",tabId:t,delta:r}).catch(()=>{}),n+=r,Date.now()-s>400&&(s=Date.now(),F(t,{jobUrl:a,status:"generating",content:n}).catch(()=>{}))})}catch(r){const o=r instanceof Error?r.message:String(r);throw await F(t,{jobUrl:a,status:"error",content:"",error:o}).catch(()=>{}),r}return await F(t,{jobUrl:a,status:"done",content:i.content,cleanedPatterns:i.cleaned?Array.from(new Set(i.slopFindings.map(r=>r.pattern))):[]}),await K("lastCoverLetter",i.content),{type:"COVER_LETTER_RESULT",content:i.content,slopFindings:i.slopFindings,cleaned:i.cleaned}}case"UPLOAD_FILE":{const t=await E(e.tabId),n=(e.targetLocator?await me(e.tabId,t,e.targetLocator.frameId,e):await L(e.tabId,t,e)).filter(s=>s.type==="UPLOAD_FILE_RESULT");return{type:"UPLOAD_FILE_RESULT",nativeInputs:n.reduce((s,i)=>s+i.nativeInputs,0),dropZones:n.reduce((s,i)=>s+i.dropZones,0)}}case"REVISE_COVER_LETTER":{const t=await Oa(e.content,e.instructions,e.job);return await K("lastCoverLetter",t),{type:"REVISE_COVER_LETTER_RESULT",content:t}}case"TRANSLATE_COVER_LETTER":return{type:"TRANSLATE_COVER_LETTER_RESULT",content:await Na(e.content,e.targetLanguage)};case"GENERATE_OUTREACH_MESSAGE":{const t=await v(),a=await ha({profile:t.profile,cvText:t.cvText,personalLegend:t.personalLegend,outreachRules:t.outreachRules,job:e.job,contact:e.contact,postingLanguage:e.postingLanguage});return{type:"OUTREACH_MESSAGE_RESULT",subject:a.subject,body:a.body}}case"REVISE_OUTREACH_MESSAGE":{const t=await Pa({subject:e.subject,body:e.body},e.instructions,e.job);return{type:"OUTREACH_MESSAGE_RESULT",subject:t.subject,body:t.body}}case"GET_FRAME_ACCESS":return{type:"FRAME_ACCESS",blockedOrigins:await nn(e.tabId)};case"DETECT_CUSTOM_QUESTIONS":{const t=await E(e.tabId),a=await L(e.tabId,t,e),n=new Set,s=[];for(const i of a)if(i.type==="CUSTOM_QUESTIONS_DATA")for(const r of i.questions)n.has(r.question)||(n.add(r.question),s.push({...r,id:`question-${s.length}`}));return{type:"CUSTOM_QUESTIONS_DATA",questions:s}}case"ANSWER_CUSTOM_QUESTION":{const t=await as(e.question,e.job,e.options,e.numeric,e.dateKind,e.multi,e.postingLanguage,e.catchAll);return{type:"CUSTOM_QUESTION_ANSWER",question:e.question,answer:t.answer,sufficientInfo:t.sufficientInfo}}case"FILL_CUSTOM_QUESTION_ANSWERS":{const t=await E(e.tabId),a=await L(e.tabId,t,e);let n=0;const s=[];for(const i of a)i.type==="CUSTOM_QUESTION_FILL_RESULT"&&(n+=i.filled,s.push(...i.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:n,unfilled:s}}case"START_ELEMENT_PICKER":{const t=await E(e.tabId),a=t.map(s=>chrome.tabs.sendMessage(e.tabId,e,{frameId:s}).then(i=>i?{result:i,frameId:s}:void 0).catch(()=>{})),n=await new Promise(s=>{let i=a.length;i===0&&s(void 0);for(const r of a)r.then(o=>{i-=1,o?s(o):i===0&&s(void 0)})});return await Promise.all(t.map(s=>chrome.tabs.sendMessage(e.tabId,{type:"CANCEL_ELEMENT_PICKER",tabId:e.tabId},{frameId:s}).catch(()=>{}))),n?{...n.result,picked:n.result.picked.map(s=>({...s,locator:{...s.locator,frameId:n.frameId}}))}:{type:"ELEMENT_PICKER_RESULT",cancelled:!0,picked:[],blockText:"",semanticCount:0}}case"CANCEL_ELEMENT_PICKER":{await it(e.tabId);return}case"DECOMPOSE_BLOCK":return{type:"BLOCK_QUESTIONS",questions:await os(e.blockText,e.fields)};case"FILL_QUESTION_ANSWERS_BY_LOCATOR":{const t=await E(e.tabId),a=(await Promise.all([...Ms(e.items)].map(([i,r])=>me(e.tabId,t,i,{...e,items:r})))).flat();let n=0;const s=[];for(const i of a)i.type==="CUSTOM_QUESTION_FILL_RESULT"&&(n+=i.filled,s.push(...i.unfilled));return{type:"CUSTOM_QUESTION_FILL_RESULT",filled:n,unfilled:s}}case"DETECT_CHECKBOXES":{const t=await E(e.tabId),a=await L(e.tabId,t,e),n=new Set,s=[];for(const i of a)if(i.type==="CHECKBOXES_DATA")for(const r of i.checkboxes){const o=r.name||r.label;!o||n.has(o)||(n.add(o),s.push({...r,id:`checkbox-${s.length}`}))}return{type:"CHECKBOXES_DATA",checkboxes:s}}case"DECIDE_PAGE_CONTENT":{const{checkboxDecisions:t,questionAnswers:a}=await ds(e.checkboxes,e.questions,e.job,e.postingLanguage);return{type:"PAGE_CONTENT_DECISIONS",checkboxDecisions:t,questionAnswers:a}}case"APPLY_CHECKBOX_DECISIONS":{const t=await E(e.tabId),a=await L(e.tabId,t,e);let n=0;for(const s of a)s.type==="CHECKBOX_APPLY_RESULT"&&(n+=s.changed);return{type:"CHECKBOX_APPLY_RESULT",changed:n}}case"DETECT_JOB_BRIEF":{const t=await ks(e.job);return{type:"JOB_BRIEF_DATA",language:t.language,keywords:t.keywords,contact:t.contact}}case"HIGHLIGHT_KEYWORDS":{const t=await E(e.tabId);return{type:"KEYWORD_HIGHLIGHT_RESULT",matched:(await L(e.tabId,t,e)).reduce((s,i)=>i.type==="KEYWORD_HIGHLIGHT_RESULT"?s+i.matched:s,0)}}case"CLEAR_KEYWORD_HIGHLIGHTS":{const t=await E(e.tabId);await L(e.tabId,t,e);return}case"GENERATE_FAQ_ANSWERS":{const t=await ke(),a=await gn(e.questions,t);try{await Yt(a)}catch{}return{type:"FAQ_ANSWERS_RESULT",entries:a}}case"SEARCH_JOBS":{const{searchId:t}=e,a=t?s=>{chrome.runtime.sendMessage({type:"JOB_SEARCH_PROGRESS",searchId:t,results:s}).catch(()=>{})}:void 0,n=setInterval(()=>void chrome.runtime.getPlatformInfo().catch(()=>{}),2e4);try{return{type:"JOB_SEARCH_RESULTS",...await Vn(e.query,{page:e.page,excludeResults:e.excludeResults,onResults:a})}}finally{clearInterval(n)}}case"SUGGEST_SEARCH_QUERY":{const{what:t,where:a,tags:n}=await ae(e.provider==="adzuna");return{type:"SEARCH_QUERY_SUGGESTION",what:t,where:a,...e.provider==="adzuna"?{tags:n}:{}}}case"LINKEDIN_ADD_JOBS":return{type:"LINKEDIN_JOBS_ADDED",...await Ft(Dt(e.jobs))};case"GET_LINKEDIN_COLLECTED":return{type:"LINKEDIN_COLLECTED",ids:(await qt()).map(a=>a.id)};case"FIND_EMPLOYER_POSTING":{const{tavilyApiKey:t}=await W();return{type:"EMPLOYER_POSTING_CANDIDATES",candidates:await Ut(e,t)}}case"SUGGEST_CV_VALUES":return{type:"CV_VALUES",values:await Ps(e.job,e.template)};case"CHOOSE_CV":return{type:"CV_CHOICE",choice:await Is(e.job,e.cvs,e.postingLanguage)};default:return}}const ee="filler-update-check",ye=6*60;function $s(){chrome.runtime.onInstalled.addListener(()=>{we(),B({force:!0}).catch(j)}),chrome.runtime.onStartup.addListener(()=>{we(),Gt().catch(j),B().catch(j)}),chrome.alarms.onAlarm.addListener(e=>{e.name===ee&&B({force:!0}).then(()=>be()).catch(j)}),chrome.runtime.onUpdateAvailable.addListener(e=>{Ht(e.version).then(()=>be()).catch(j)})}async function we(){await chrome.alarms.get(ee)||await chrome.alarms.create(ee,{delayInMinutes:ye,periodInMinutes:ye})}async function be(){if(!Kt())return;const{offer:e}=await Wt();if((e==null?void 0:e.kind)!=="store"||e.version===zt())return;(await chrome.runtime.getContexts({contextTypes:[chrome.runtime.ContextType.SIDE_PANEL,chrome.runtime.ContextType.TAB,chrome.runtime.ContextType.POPUP,chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]})).length===0&&chrome.runtime.reload()}function j(e){console.warn("Filler update check failed",e)}const Us="src/sidepanel/index.html";chrome.runtime.onInstalled.addListener(()=>{on(),chrome.sidePanel.setOptions({enabled:!1}),Be().catch(e=>console.error("LinkedIn collector sync failed",e))});function Y(){Be().catch(e=>console.error("LinkedIn collector sync failed",e))}chrome.runtime.onStartup.addListener(Y);chrome.permissions.onAdded.addListener(Y);chrome.permissions.onRemoved.addListener(Y);chrome.storage.onChanged.addListener((e,t)=>{Qt(e,t)&&Y()});$s();chrome.contextMenus.onClicked.addListener((e,t)=>{ln(e,t)});chrome.action.onClicked.addListener(e=>{if(e.id===void 0)return;const t=e.id;chrome.sidePanel.setOptions({tabId:t,path:`${Us}?tabId=${t}`,enabled:!0}),chrome.sidePanel.open({tabId:t}).catch(a=>console.error("sidePanel.open failed",a)),qs(t)});async function qs(e){await E(e);const t={type:"TAB_ACCESS_GRANTED",tabId:e};await chrome.runtime.sendMessage(t).catch(()=>{})}chrome.tabs.onRemoved.addListener(e=>{Xt(e)});chrome.runtime.onMessage.addListener((e,t,a)=>(js(e).then(a).catch(n=>{a({type:"ERROR",error:n instanceof Error?n.message:String(n),code:n instanceof Error?n.name:void 0})}),!0));chrome.runtime.onConnect.addListener(e=>{const t=/^picker-(\d+)$/.exec(e.name);if(!t)return;const a=Number(t[1]);e.onDisconnect.addListener(()=>{it(a)})});
